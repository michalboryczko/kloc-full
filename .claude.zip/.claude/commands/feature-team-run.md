---
description: "Scan project for feature-related resources, generate a team launch prompt with full context, and optionally spawn the feature-team. Handles git branch management across relevant repos."
argument-hint: "<feature-name> [--auto] [--git continue|new-branch|new-branch-from-default] [--size small|standard|large]"
---

# Feature Team Run

Scan the project for all resources related to a feature, generate a comprehensive prompt for the feature-team agent team, and optionally launch it. This command contains **no team logic** — it's purely a context gatherer and prompt generator.

## Step 1: Parse Arguments

From `$ARGUMENTS`, extract:

- **Feature name**: First non-flag word (kebab-case, e.g., `unified-graph-format`)
- **`--auto` flag**: If present, auto-launch the team after generating the prompt
- **`--git <strategy>`**: Git handling strategy (default: `continue`)
  - `continue` — stay on current branch, commit WIP if dirty
  - `new-branch` — create `feature/{feature}` from current branch
  - `new-branch-from-default` — checkout default branch, pull, create `feature/{feature}`
- **`--size <size>`**: Team size preset (default: `standard`)
  - `small` — 4 agents: PM, Developer-1, Developer-2, QA (devs cross-review each other, lead coordinates directly)
  - `standard` — 7 agents: PM, Architect, Developer-1, Developer-2, Reviewer-1, QA (dedicated reviewer)
  - `large` — 9 agents: PM, Architect, Developer-1, Developer-2, Developer-3, Reviewer-1, Reviewer-2, QA (2 dedicated reviewers)

If no feature name is provided, ask the user for one.

## Step 2: Scan for Related Resources

Use Glob to find all files matching the feature name across standard locations. Search for files where the path contains the feature name (or parts of it):

```
docs/specs/{feature}*.md
docs/specs/*{feature}*.md
.claude/feature-issues/**/*{feature}*/**/*.md
.claude/feature-issues/**/*{feature}*.md
.claude/progress/**/*{feature}*/**/*.md
.claude/progress/**/*{feature}*.md
.claude/qa-notes/*{feature}*.md
.claude/business-analyst/**/*{feature}*/**/*.md
.claude/business-analyst/**/*{feature}*.md
.claude/scip-php-contract-qa/**/*{feature}*/**/*.md
.claude/feature-team-runs/**/*{feature}*/**/*.md
```

Also check `notes.md` in the project root — use Grep to search for lines mentioning the feature name.

Collect all discovered files into a list. If no files are found, warn the user: "No resources found for feature `{feature}`. Continuing with minimal context."

## Step 3: Determine Relevant Repos and scip-php Detection

The project is a monorepo workspace with these sub-repos:
- `kloc-cli` — CLI tool (Python)
- `kloc-mapper` — mapping library (Python)
- `scip-php` — PHP SCIP indexer (PHP)

Read the discovered files (especially specs and issues) and grep their content for repo mentions:
- Look for mentions of `kloc-cli`, `kloc-mapper`, `scip-php`
- Any repo mentioned becomes a "relevant repo"

**scip-php detection**: Set `scip_php_involved = true` if:
- Any discovered file mentions `scip-php`, `indexer`, `SCIP index`, or PHP indexing
- Any context files are under `scip-php/`
- The feature name contains `scip` or `indexer`

For each relevant repo, capture:
- Current branch: `git -C {repo-path} branch --show-current`
- Dirty status: `git -C {repo-path} status --porcelain`

If no repos are explicitly mentioned in docs, default to checking the root repo only.

## Step 4: Handle Git

Based on the `--git` strategy, for each relevant repo:

### `continue` (default)
1. If dirty: run `git -C {repo} add -A && git -C {repo} commit -m "WIP: {feature} - auto-commit before team"`
2. Stay on current branch

### `new-branch`
1. If dirty: commit WIP (same as above)
2. Create and checkout: `git -C {repo} checkout -b feature/{feature}`

### `new-branch-from-default`
1. If dirty: commit WIP (same as above)
2. Determine default branch: `git -C {repo} symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@'`
3. Checkout default: `git -C {repo} checkout {default-branch}`
4. Pull latest: `git -C {repo} pull`
5. Create feature branch: `git -C {repo} checkout -b feature/{feature}`

**Important**: Always confirm with the user before executing git operations. Print the planned actions and ask for confirmation.

## Step 5: Generate Prompt

For each discovered file (from Step 2), read it and produce a one-line summary of its content.

Fill the prompt template below with gathered context and **print the full generated prompt**.

### Prompt Template

```
Create an agent team to develop a feature end-to-end.

Feature name: {feature_name}

Feature description:
{context_summary_from_discovered_docs — 3-5 sentence summary: key goals, current status, known issues}

Context files:
{file_list_with_one_line_descriptions}

Key source directories:
{relevant_source_dirs_with_descriptions — e.g. scip-php/src/, kloc-cli/src/}

## Team Structure

Spawn these teammates:

{IF size == "small":}
### PM
- **Name**: pm
- **Focus**: Create feature spec with acceptance criteria at docs/specs/{feature_name}.md
- **Agent definition**: Read .claude/teams/feature-team/agents/team-pm.md for role instructions
- **Model**: sonnet

### Developer 1
- **Name**: developer-1
- **Focus**: Implement work stream 1 + review developer-2's code after implementation
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **Model**: opus

### Developer 2
- **Name**: developer-2
- **Focus**: Implement work stream 2 + review developer-1's code after implementation
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **Model**: opus

### QA
- **Name**: qa
- **Focus**: Test planning and validation
- **Agent definition**: Read .claude/teams/feature-team/agents/team-qa.md for role instructions
- **Model**: opus

Note: Lead coordinates directly. Each developer cross-reviews the other's code using the code-reviewer skill. Code review must pass before QA validation.
{:ENDIF}

{IF size == "standard":}
### PM
- **Name**: pm
- **Focus**: Create feature spec with acceptance criteria at docs/specs/{feature_name}.md
- **Agent definition**: Read .claude/teams/feature-team/agents/team-pm.md for role instructions
- **Model**: sonnet

### Architect
- **Name**: architect
- **Focus**: Explore codebase and create implementation plan at docs/specs/{feature_name}-plan.md
- **Agent definition**: Read .claude/teams/feature-team/agents/team-architect.md for role instructions
- **First task**: Explore the codebase for patterns related to {feature_name}. Wait for PM's spec before creating plan.
- **Model**: opus

### Developer 1
- **Name**: developer-1
- **Focus**: Implement work stream 1
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for task assignment from lead.
- **Model**: opus

### Developer 2
- **Name**: developer-2
- **Focus**: Implement work stream 2
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for task assignment from lead.
- **Model**: opus

### Reviewer 1
- **Name**: reviewer-1
- **Focus**: Code review using code-reviewer skill (includes kloc business knowledge)
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for review assignment from lead. Read spec, plan, and QA notes while waiting.
- **Model**: opus

### QA
- **Name**: qa
- **Focus**: Test planning and validation
- **Agent definition**: Read .claude/teams/feature-team/agents/team-qa.md for role instructions
- **First task**: Review requirements for testability. Create QA notes after spec.
- **Model**: opus
{:ENDIF}

{IF size == "large":}
### PM
- **Name**: pm
- **Focus**: Create feature spec with acceptance criteria at docs/specs/{feature_name}.md
- **Agent definition**: Read .claude/teams/feature-team/agents/team-pm.md for role instructions
- **Model**: sonnet

### Architect
- **Name**: architect
- **Focus**: Explore codebase and create implementation plan at docs/specs/{feature_name}-plan.md
- **Agent definition**: Read .claude/teams/feature-team/agents/team-architect.md for role instructions
- **First task**: Explore the codebase for patterns related to {feature_name}. Wait for PM's spec before creating plan.
- **Model**: opus

### Developer 1
- **Name**: developer-1
- **Focus**: Implement work stream 1
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **Model**: opus

### Developer 2
- **Name**: developer-2
- **Focus**: Implement work stream 2
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **Model**: opus

### Developer 3
- **Name**: developer-3
- **Focus**: Implement work stream 3
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **Model**: opus

### Reviewer 1
- **Name**: reviewer-1
- **Focus**: Code review — reviews developer-1 and developer-2's changes
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for review assignment from lead. Read spec, plan, and QA notes while waiting.
- **Model**: opus

### Reviewer 2
- **Name**: reviewer-2
- **Focus**: Code review — reviews developer-3's changes + re-reviews fixes
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for review assignment from lead. Read spec, plan, and QA notes while waiting.
- **Model**: opus

### QA
- **Name**: qa
- **Focus**: Test planning and validation
- **Agent definition**: Read .claude/teams/feature-team/agents/team-qa.md for role instructions
- **Model**: opus
{:ENDIF}

{IF scip_php_involved:}
## scip-php Contract Testing

This feature involves scip-php. QA must activate contract test mode:
- Use kloc-scip-contract-scenarios skill to generate test scenarios
- Use kloc-scip-contract-test-create skill to create contract tests BEFORE implementation
- Use kloc-scip-contract-test-run skill to validate after implementation
- Contract tests at: kloc-reference-project-php/contract-tests/
- Developers CAN run tests but CANNOT modify them
{:ENDIF}

## Workflow Phases

### Phase 1: Planning (PARALLEL)
1. PM creates feature spec at docs/specs/{feature_name}.md
2. Architect explores codebase (can start before spec)
3. QA reviews requirements for testability

### Phase 2: Design (SEQUENTIAL — wait for PM's spec)
1. Architect creates plan at docs/specs/{feature_name}-plan.md
2. QA creates test plan at .claude/qa-notes/{feature_name}_qa_ref_note.md
3. PM reviews plan for completeness
{IF scip_php_involved:}4. QA sets up contract tests BEFORE implementation{:ENDIF}

### Phase 3: Task Decomposition (LEAD ONLY)
1. Read architect's plan, decompose into tasks with file ownership
2. Create implementation tasks — assign to developers (one owner per file, no overlaps)
3. Create review tasks (blocked by implementation tasks) — assign to reviewer(s)
4. IMPORTANT: Never let a developer review their own code

### Phase 4: Implementation (PARALLEL)
1. Developer(s) implement assigned tasks
2. QA prepares test infrastructure

### Phase 5: Code Review (SEQUENTIAL — after implementation)
1. Reviewer(s) review implementation using the code-reviewer skill
2. Reviewer reports verdict: APPROVE or REQUEST_CHANGES
3. If REQUEST_CHANGES: reviewer messages implementing developer with findings, developer fixes, reviewer re-reviews (max 3 loops)
4. All reviews must be APPROVED before proceeding to QA

### Phase 6: QA Validation (SEQUENTIAL — after code review passes)
1. QA validates against test plan. Report PASS/FAIL.
2. If FAIL: create fix tasks, developer fixes, reviewer re-reviews fixes, QA re-validates (max 5 loops)

### Phase 7: Completion
1. Verify all tasks done, git status (feature branch + commit)
2. Create summary, shut down team

## Pre-handled Git
- Git strategy: {git_strategy_used_and_what_was_done}
- {branch_state_per_repo}
- Do not create new branches (already handled)

## Rules for Lead
1. Use delegate mode — DO NOT implement code yourself
2. Read .claude/teams/feature-team/agents/team-lead.md for full role instructions
3. Follow phases sequentially
4. **Code review MUST pass before QA validation** — no shortcuts
5. **Never let a developer review their own code**
6. Feature is NOT complete until QA passes AND there's a commit on a feature branch
7. Never push to remote
```

## Step 6: Auto-execute or Instruct

### If `--auto` was specified:

Paste the generated prompt directly as the next user message to launch the team.

### If `--auto` was NOT specified:

Print:

```
---
Team prompt ready. To launch:
1. Copy the prompt above and paste it into a new Claude Code session
2. Or re-run with --auto: /feature-team-run {feature} --auto
---
```

## Error Handling

- If feature name is missing: ask the user
- If no files found: warn but continue with minimal context
- If git operations fail: report the error, skip git handling, continue with prompt generation
- If a repo directory doesn't exist: skip it and note in output
- If CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS is not set: warn user to enable it
