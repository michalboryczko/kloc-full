---
description: "Scan project for feature-related resources, generate a workflow prompt with full context, and optionally trigger run-workflow. Handles git branch management across relevant repos."
argument-hint: "<feature-name> [--auto] [--git continue|new-branch|new-branch-from-default]"
---

# Simple Workflow Run

Scan the project for all resources related to a feature, generate a comprehensive prompt for a workflow, and optionally trigger execution. This command contains **no workflow logic** — it's purely a context gatherer and prompt generator.

## Step 1: Parse Arguments

From `$ARGUMENTS`, extract:

- **Feature name**: First non-flag word (kebab-case, e.g., `scip-php-indexer-issues`)
- **`--auto` flag**: If present, auto-execute the workflow after generating the prompt
- **`--git <strategy>`**: Git handling strategy (default: `continue`)
  - `continue` — stay on current branch, commit WIP if dirty
  - `new-branch` — create `feature/{feature}` from current branch
  - `new-branch-from-default` — checkout default branch, pull, create `feature/{feature}`

If no feature name is provided, ask the user for one.

## Step 2: Scan for Related Resources

Use Glob to find all files matching the feature name across standard locations. Search for files where the path contains the feature name (or parts of it):

```
docs/specs/{feature}*.md
docs/specs/*{feature}*.md
.claude/feature-issues/**/*{feature}*/**/*.md
.claude/feature-issues/**/*{feature}*.md
.claude/progress/**/*{feature}*/**/*.md
.claude/progress/**/*{feature}*.md
.claude/qa-notes/*{feature}*.md
.claude/business-analyst/**/*{feature}*/**/*.md
.claude/business-analyst/**/*{feature}*.md
```

Also check `notes.md` in the project root — use Grep to search for lines mentioning the feature name.

Collect all discovered files into a list. If no files are found, warn the user: "No resources found for feature `{feature}`. Continuing with minimal context."

## Step 3: Determine Relevant Repos

The project is a monorepo workspace with these sub-repos:
- `kloc-cli` — CLI tool (TypeScript)
- `kloc-mapper` — mapping library (TypeScript)
- `scip-php` — PHP SCIP indexer (PHP)

Read the discovered files (especially specs and issues) and grep their content for repo mentions:
- Look for mentions of `kloc-cli`, `kloc-mapper`, `scip-php`
- Any repo mentioned becomes a "relevant repo"

For each relevant repo, capture:
- Current branch: `git -C {repo-path} branch --show-current`
- Dirty status: `git -C {repo-path} status --porcelain`

If no repos are explicitly mentioned in docs, default to checking the root repo only.

## Step 4: Handle Git

Based on the `--git` strategy, for each relevant repo:

### `continue` (default)
1. If dirty: run `git -C {repo} add -A && git -C {repo} commit -m "WIP: {feature} - auto-commit before workflow"`
2. Stay on current branch

### `new-branch`
1. If dirty: commit WIP (same as above)
2. Create and checkout: `git -C {repo} checkout -b feature/{feature}`

### `new-branch-from-default`
1. If dirty: commit WIP (same as above)
2. Determine default branch: `git -C {repo} symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@'`
3. Checkout default: `git -C {repo} checkout {default-branch}`
4. Pull latest: `git -C {repo} pull`
5. Create feature branch: `git -C {repo} checkout -b feature/{feature}`

**Important**: Always confirm with the user before executing git operations. Print the planned actions and ask for confirmation.

## Step 5: Generate Prompt

For each discovered file (from Step 2), read it and produce a one-line summary of its content.

Fill the prompt template below with gathered context and **print the full generated prompt**.

### Prompt Template

```
/run-workflow feature-orchestrator

Feature name: {feature_name}

## Context
{context_summary_from_discovered_docs — 3-5 sentence summary: key goals, current status, known issues}

## Pre-implementation steps
- Git strategy: {git_strategy_used_and_what_was_done}
- {branch_state_per_repo — current branch for each relevant repo}
- Do not create new branches (already handled)

## Context files
{file_list_with_one_line_descriptions}

## Key source directories
{relevant_source_dirs_with_descriptions — e.g. scip-php/src/, kloc-cli/src/}

## Test requirements
{test_info — include kloc-reference-project-php if scip-php is relevant, plus any test suites to run}
```

## Step 6: Auto-execute or Instruct

### If `--auto` was specified:

Invoke the run-workflow skill with the generated prompt as context:

```
Skill(skill: "run-workflow", args: "feature-orchestrator")
```

Then provide the generated prompt as the workflow input in your next message.

### If `--auto` was NOT specified:

Print:

```
---
Prompt ready. To execute, either:
1. Copy the prompt above and run: /run-workflow feature-orchestrator
2. Re-run with --auto: /simple-workflow-run {feature} --auto
---
```

## Error Handling

- If feature name is missing: ask the user
- If no files found: warn but continue with minimal context
- If git operations fail: report the error, skip git handling, continue with prompt generation
- If a repo directory doesn't exist: skip it and note in output
