# BA Specialist: kloc-cli Test Framework

**Agent type**: business-analyst
**Mode**: validate
**Run date**: 2026-02-07
**Output**: docs/analysis/ba-kloc-cli.md
**Agent ID**: af4b0c2
**Stats**: 47 tool uses, 135K tokens, ~7.5 min

## Prompt

Mode: validate

You are a SPECIALIST BUSINESS ANALYST focused exclusively on the kloc-cli test framework. Perform an exhaustive deep analysis of the kloc-cli contract testing strategy.

## Context

kloc-cli is a Python CLI tool that queries a Source-of-Truth JSON graph (sot.json). It provides these commands:
- `resolve` - resolve symbol to definition (supports exact, partial, case-insensitive matching)
- `usages` - find usages with BFS depth expansion (--depth, --limit)
- `deps` - find dependencies with BFS depth expansion (--depth, --limit)
- `context` - bidirectional (usages + deps) with flags: --impl (polymorphic), --direct (no member usages), --with-imports
- `owners` - containment chain (method -> class -> file)
- `inherit` - inheritance tree (--direction up/down, --depth)
- `overrides` - method override tree (--direction up/down, --depth)
- `mcp-server` - MCP server for AI assistants

The sot.json v2.0 format has:
- **Node kinds** (13): File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase, Value, Call
- **Edge types** (12): contains, extends, implements, uses_trait, overrides, uses, type_hint, calls, receiver, argument, produces, assigned_from, type_of

Each node has: id, kind, name, fqn, symbol, file, range, enclosing_range, documentation, value_kind, type_symbol, call_kind
Each edge has: type, source, target, location, position

Output formats: Rich console tree OR JSON (--json flag)

## Current Test Framework Plan

(Full kloc-cli section from tester-agents-requirements.md was included)

## Analysis Must Cover (go VERY deep on each)

### 1. Command Coverage Completeness
- For EACH of the 7 commands, list every testable behavior and parameter combination
- What edge cases exist for symbol resolution? (ambiguous symbols, symbols in vendor code, symbols with special chars)
- What happens with depth=0? depth=100? limit=0? limit=1?
- What about --impl + --direct combined? Conflicting flags?
- What about the mcp-server command? It's listed in CLI but not in test categories
- How do you test streaming MCP protocol?

### 2. Fixture Generator Feasibility
- How complex is generating valid sot.json programmatically?
- What's the minimum viable sot.json for each command to be testable?
- How do you ensure fixture generator stays in sync with kloc-mapper's actual output?
- Should fixture generator be a standalone tool or embedded in tests?
- Can you use a builder pattern? e.g., SoTBuilder().add_class("Order").add_method("getId").add_uses_edge(...)
- What about node ID generation? Must match kloc-mapper's SHA256-based IDs?

### 3. Output Validation Strategy
- How do you validate rich console output vs JSON output?
- Are tree structures deterministic? (ordering of branches)
- What about pagination/truncation with --limit?
- How do you validate access chains in context output?
- What about color/formatting in console output?

### 4. Edge Cases and Error Handling
- Symbol not found scenarios
- Empty graph (no nodes, no edges)
- Self-referential edges
- Circular dependency chains
- Very deep graphs (100+ depth)
- Unicode in symbol names
- File paths with spaces
- sot.json with v1.0 format (backward compat)
- Malformed sot.json (missing fields, wrong types)
- Very large sot.json (performance)

### 5. Missing Test Scenarios
- What specific test cases are NOT mentioned but should be?
- What about negative tests? (things that should NOT appear in results)
- What about regression tests for known bugs?
- What about testing deduplication? (same edge shouldn't appear twice)

### 6. Architecture Concerns
- Is OutputValidator sufficient or do we need more helpers?
- How do tests invoke kloc-cli? (subprocess? Python API? Both?)
- Should there be snapshot/golden-file tests?
- How do you handle test data versioning?

### 7. Prioritized Recommendations
- What are the TOP 10 most important tests to write first?
- What's the minimum viable test suite?
- What can be deferred?
- What's the estimated effort for each category?

Write your findings to /Users/michal/dev/ai/kloc/docs/analysis/ba-kloc-cli.md

Be exhaustive. List every test case you can think of. This will be cross-verified by another analyst.
