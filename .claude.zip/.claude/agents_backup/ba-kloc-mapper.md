# BA Specialist: kloc-mapper Test Framework

**Agent type**: business-analyst
**Mode**: validate
**Run date**: 2026-02-07
**Output**: docs/analysis/ba-kloc-mapper.md
**Agent ID**: ac44c1d
**Stats**: 40 tool uses, 123K tokens, ~7.4 min

## Prompt

Mode: validate

You are a SPECIALIST BUSINESS ANALYST focused exclusively on the kloc-mapper test framework. Perform an exhaustive deep analysis of the kloc-mapper contract testing strategy.

## Context

kloc-mapper is a Python tool that converts SCIP index files into Source-of-Truth JSON graphs. It has two main code paths:

### SCIPMapper (mapper.py) - processes SCIP protobuf index:
1. `_collect_symbol_metadata()` - reads documentation and relationships from SCIP symbols
2. `_create_file_nodes()` - creates File nodes for each document
3. `_create_symbol_nodes()` - classifies symbols into NodeKind and creates nodes
4. `_build_file_symbol_index()` - spatial index for fast containment lookup
5. `_build_contains_edges()` - structural containment (class contains method, file contains class)
6. `_build_inheritance_edges()` - extends, implements, uses_trait from SCIP relationships
7. `_build_type_hint_edges()` - type annotations for parameters/properties/methods
8. `_build_uses_edges()` - reference-based usage edges with deduplication
9. `_build_override_edges()` - method override relationships

### CallsMapper (calls_mapper.py) - processes calls.json data:
1. `_create_value_nodes()` - Value nodes from calls.json values (parameter, local, result, literal, constant)
2. `_create_call_nodes()` - Call nodes from calls.json calls (method, method_static, constructor, access, etc.)
3. `_create_call_edges()` - calls, receiver, argument, produces, contains edges
4. `_create_value_edges()` - assigned_from, type_of, contains edges

### Input formats:
- `.kloc` archive: ZIP containing index.scip (protobuf) + calls.json
- `.scip` file: raw SCIP protobuf

### Output format (sot.json v2.0):
```json
{
  "version": "2.0",
  "metadata": {"generated_at": "...", "source_scip": "...", "project_root": "..."},
  "nodes": [{"id": "node:abc123", "kind": "Class", "name": "Order", "fqn": "App/Entity/Order", ...}],
  "edges": [{"type": "contains", "source": "node:abc", "target": "node:def", ...}]
}
```

Node kinds (13): File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase, Value, Call
Edge types (12): contains, extends, implements, uses_trait, overrides, uses, type_hint, calls, receiver, argument, produces, assigned_from, type_of

Node IDs are deterministic SHA256 hashes of symbol strings.

### Symbol classification logic:
- Argument: contains `.($name)` pattern
- Method: ends with `().)`
- Property: contains `#$`
- Class/Interface/Trait/Enum: ends with `#` (differentiated by documentation)
- Const: has `#` but not `$` or `()`
- EnumCase: like Const but parent is Enum
- Function: ends with `().` without `#`

## Current Test Framework Plan

(Full kloc-mapper section from tester-agents-requirements.md was included)

## Analysis Must Cover (go VERY deep on each)

### 1. SCIP Fixture Generation Feasibility (CRITICAL)
- SCIP uses Protocol Buffers. How realistic is generating valid SCIP protobuf programmatically?
- The scip.proto schema defines: Index, Document, Occurrence, SymbolInformation, Relationship
- Each Document has: relative_path, occurrences[], symbols[]
- Each Occurrence has: range[], symbol, symbol_roles (bitfield), enclosing_range[]
- Each SymbolInformation has: symbol, documentation[], relationships[]
- Is there a Python library for SCIP protobuf? (scip_pb2.py exists in kloc-mapper/src/)
- Can we reuse kloc-mapper's own scip_pb2.py to generate test fixtures?
- Alternative: Could we use real .scip snapshots instead of generating them?
- What's the minimum SCIP index needed for each test scenario?

### 2. calls.json Fixture Generation
- calls.json schema: {values: [...], calls: [...]}
- Each value: {id, kind, symbol, type, location: {file, line, col}, source_value_id}
- Each call: {id, kind, callee, caller, return_type, receiver_value_id, arguments: [{position, value_id}], location}
- Is generating calls.json easier than SCIP? (it's just JSON)
- What are the minimum viable calls.json scenarios?
- How do value IDs and call IDs relate? (call ID can equal value ID for result values)

### 3. Node Creation Coverage
- For each of the 13 node kinds, what specific scenarios need testing?
- Symbol classification edge cases
- Node field completeness
- What if a symbol exists in metadata but has no definition occurrence?

### 4. Edge Creation Coverage
- For each of the 12 edge types, what scenarios need testing?
- contains, extends, implements, uses_trait, overrides, uses, type_hint, calls, receiver, argument, produces, assigned_from, type_of

### 5. Integrity and Edge Cases
- ID uniqueness, orphan nodes, orphan edges, circular contains, self-referencing edges
- Very large indexes, empty index, multiple definitions for same symbol

### 6. Missing Test Scenarios
- Archive loading path, fallback path, pretty-print flag, metadata correctness
- Node/edge sorting, enclosing_range usage

### 7. Comparison with scip-php contract tests
- How do the two frameworks relate in the test pyramid?

### 8. Prioritized Recommendations
- TOP 10 most critical tests
- Minimum viable test suite
- Realistic effort estimate

Write your findings to /Users/michal/dev/ai/kloc/docs/analysis/ba-kloc-mapper.md

Be exhaustive. Cover every mapper code path. This will be cross-verified by another analyst.
