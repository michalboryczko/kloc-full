# BA Specialist: E2E Test Framework

**Agent type**: business-analyst
**Mode**: validate
**Run date**: 2026-02-07
**Output**: docs/analysis/ba-e2e.md
**Agent ID**: af511fe
**Stats**: 55 tool uses, 131K tokens, ~7.5 min

## Prompt

Mode: validate

You are a SPECIALIST BUSINESS ANALYST focused exclusively on the E2E test framework for the kloc pipeline. Perform an exhaustive deep analysis.

## Context

The kloc pipeline processes PHP source code through 3 components:
```
kloc-reference-project-php (PHP code) -> scip-php (indexer) -> index.kloc -> kloc-mapper (converter) -> sot.json -> kloc-cli (query tool) -> output
```

The E2E tests run the REAL pipeline (no fixtures) on a known reference project and validate the final output.

### Reference Project: kloc-reference-project-php

Symfony 7.2 PHP 8.4 application with these files:

**Entities:** Order.php, Customer.php, Contact.php, Address.php
**Repositories:** OrderRepository.php, CustomerRepository.php
**Services:** OrderService.php, CustomerService.php, OrderDisplayService.php, OrderStatusHelper.php, AbstractOrderProcessor.php, StandardOrderProcessor.php
**Controllers:** OrderController.php, CustomerController.php
**DTOs:** CreateOrderInput.php, OrderOutput.php, CustomerOutput.php
**Request/Response:** CreateOrderRequest.php, OrderResponse.php, CustomerResponse.php
**Components:** EmailSenderInterface.php, EmailSender.php, InventoryCheckerInterface.php, InventoryChecker.php
**Messaging:** OrderCreatedMessage.php, OrderCreatedHandler.php

Key patterns:
- Layered architecture: Controller -> Service -> Repository -> Entity
- Interface segregation: EmailSenderInterface, InventoryCheckerInterface
- Abstract inheritance: AbstractOrderProcessor -> StandardOrderProcessor
- Constructor property promotion with readonly
- Symfony Messenger async dispatch
- Named arguments in constructor calls
- Type-hinted dependency injection

(Full OrderService.php and OrderController.php code was provided as context)

## Current E2E Test Plan

(Full E2E section from tester-agents-requirements.md was included)

## Analysis Must Cover (go VERY deep on each)

### 1. Test Scenario Completeness
- The current plan has only 8 scenarios. For a reference project with 28 PHP files, this is FAR too few
- List EVERY meaningful query against this codebase
- What about Customer domain? Messenger pattern? DTOs?

### 2. Expected Results Accuracy
- For each scenario, enumerate EVERY class that should appear (be precise!)
- For each scenario, what should NOT appear? (negative assertions)

### 3. Depth Expansion Scenarios
- What does depth=1 vs depth=2 vs depth=3 look like for each key query?
- Where do cycles or convergence happen?

### 4. Call Graph / v2.0 Scenarios
- What Value nodes should exist in OrderService::createOrder()?
- What Call nodes? What receiver/argument/produces edges?

### 5. Polymorphic / Interface Scenarios
- EmailSenderInterface::send() with --impl
- AbstractOrderProcessor::process() with --impl
- InventoryCheckerInterface::checkAvailability()

### 6. Edge Cases for E2E
- Symfony framework classes, vendor dependencies, Kernel.php
- Symfony attributes (#[Route], #[MapRequestPayload])
- Reference project brittleness

### 7. Pipeline Reliability
- Execution time, version changes, non-deterministic output
- Intermediate validation

### 8. Missing Test Categories
- Performance, regression, negative scenarios, multiple output formats

### 9. Prioritized Test Matrix
- command x scenario x expected_result
- P0/P1/P2 ranking
- Total test case count

Write your findings to /Users/michal/dev/ai/kloc/docs/analysis/ba-e2e.md

Be EXHAUSTIVE. List every test scenario with expected results. This will be cross-verified by another analyst.
