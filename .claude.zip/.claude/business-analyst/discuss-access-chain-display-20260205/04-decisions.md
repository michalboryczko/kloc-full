# Decisions

## Recommendation: Modified Option A (Current format with `on:`)

Keep the current format but make one small refinement to the label.

### Final Recommended Format

**Human-readable output:**
```
on: $this->orderService
```

**JSON output (enhanced):**
```json
{
  "access_chain": "$this->orderService",
  "access_chain_fqn": "App\\Ui\\Rest\\Controller\\OrderController::$orderService"
}
```

### Rationale

1. **Current format is correct for the primary use case**
   - The access chain answers "on what object?" - using `on:` as prefix is semantically accurate
   - `$this->orderService` directly shows the PHP code pattern
   - For developers, this is immediately recognizable

2. **Context already provides disambiguation**
   - The calling method (`OrderController::create()`) is shown on the line above
   - Within that context, `$this->orderService` is unambiguous
   - No translation needed - it's what you'd see in the code

3. **FQN should be available in JSON, not CLI**
   - AI agents using `--json` output can benefit from the additional FQN
   - Human developers using CLI don't need the extra verbosity
   - This keeps CLI output clean while providing full data for programmatic use

### Why NOT the other options

**Option B (FQN only):**
- Too verbose for the CLI display
- Loses the "this is what you'd see in code" immediacy
- `$this->` carries semantic meaning (instance property access)

**Option C (Simplified variable):**
- Loses important information: `$this->` vs `$param->` distinction matters
- Can't differentiate property access from parameter/local variable

**Option D (Combined):**
- Redundant for CLI display
- The FQN adds visual noise without proportional value
- If you need FQN, use `--json`

### Implementation Note

The JSON output enhancement (`access_chain_fqn`) would require:
1. Looking up the property FQN when building access chains
2. Adding the field to MemberRef dataclass
3. Including it in JSON serialization

This is a small enhancement that provides value for AI agent consumers without cluttering the human-readable output.
