# Access Chain Display Format Recommendation

## Verdict: Keep Option A (`on: $this->orderService`)

The current format is the best choice for the primary use case. Here's why:

---

## Analysis by User Persona

### For AI Agents

The current format works well because:

1. **Shows actual code pattern**: `$this->orderService` is what the AI would see when reading the source file. This helps it understand the dependency injection pattern and locate related code.

2. **Disambiguated by context**: The calling scope (`OrderController::create()`) is already shown, so within that method, `$this->orderService` is unambiguous.

3. **Actionable**: An AI can immediately understand "the OrderService is accessed via a property injection pattern" and know to look for constructor injection setup.

### For Human Developers

The current format is intuitive because:

1. **Familiar PHP pattern**: `$this->orderService` is exactly what you'd see in the code - no mental translation required.

2. **Semantic clarity**: The `$this->` prefix carries meaning - this is an instance property, not a parameter or local variable.

3. **Scannable**: Short, consistent format makes it easy to scan multiple usages.

---

## Why NOT the Other Options

| Option | Verdict | Reason |
|--------|---------|--------|
| **B: FQN only** | Reject | Too verbose, loses code-level immediacy |
| **C: `$orderService` only** | Reject | Loses `$this->` vs `$param->` distinction |
| **D: Combined** | Reject | Redundant, adds noise without value |

---

## Enhancement Recommendation

**Add FQN to JSON output only.**

For AI agents that need to resolve the property programmatically, the JSON output could include:

```json
{
  "member_ref": {
    "reference_type": "method_call",
    "access_chain": "$this->orderService",
    "access_chain_fqn": "App\\Ui\\Rest\\Controller\\OrderController::$orderService"
  }
}
```

This provides:
- Full resolution capability for programmatic consumers
- No clutter in human-readable CLI output
- Optional data that doesn't change the core format

---

## Final Recommended Format

**CLI Output (unchanged):**
```
== USED BY ==
App\Service\OrderService::createOrder(...)
+-- [1] App\Ui\Rest\Controller\OrderController::create(...) [method_call]
            on: $this->orderService
```

**JSON Output (enhanced):**
```json
{
  "access_chain": "$this->orderService",
  "access_chain_fqn": "App\\Ui\\Rest\\Controller\\OrderController::$orderService"
}
```

---

## Implementation Effort

To add `access_chain_fqn` to JSON:

1. **MemberRef model**: Add optional `access_chain_fqn: Optional[str]` field
2. **build_access_chain()**: Track FQN while building chain (property lookups already happen)
3. **JSON serialization**: Include new field in `context_tree_to_dict()`

Estimated effort: Small (1-2 hours).

---

## Consistency Check

The `on:` prefix is consistent with kloc-cli patterns:
- `extends` for inheritance
- `overrides` for method overrides
- `via interface:` for polymorphic grouping
- `on:` for receiver object

The prefix clearly answers "on what?" which is the semantic meaning of the access chain.
