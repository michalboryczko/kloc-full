# Brief

Analyzing the best display format for access chains in the `context` command output. The access chain shows HOW a method is being called (e.g., via which property or variable). Need to recommend a format that serves both AI agents and human developers effectively.
