# Summary

Analyzed access chain display options for kloc-cli `context` command output.

**Recommendation**: Keep current `on:` prefix format for CLI, enhance JSON output with optional FQN.

**Key insight**: The access chain answers "on what object was this method called?" The current `$this->orderService` format is the right answer because it shows the actual code pattern, which is immediately useful for both developers and AI agents understanding code flow.

The FQN (`OrderController::$orderService`) is useful metadata for programmatic consumers, so it should be available in JSON output, but shouldn't clutter the human-readable CLI output.
