# Observations

## Current Implementation Analysis

The access chain is built from graph traversal in `build_access_chain()`:
- It produces strings like `$this->orderRepository` or `$param->method()`
- The chain represents the receiver expression that leads to the method call
- Currently displayed with prefix `on:` in the tree output

## What Access Chain Actually Represents

The access chain answers: "What object was used to call this method?"

Example:
```php
$this->orderService->createOrder($data)
//    ^^^^^^^^^^^^
//    This is the access chain - the receiver of createOrder()
```

The chain is NOT:
- The full call expression (that would be `$this->orderService->createOrder($data)`)
- The property FQN (that would be `App\Controller::$orderService`)
- Just the variable name (that would be `$orderService`)

## Data Available from Graph

From the `MemberRef` dataclass:
- `access_chain`: The receiver expression string (e.g., `$this->orderRepository`)
- `target_fqn`: The full FQN of the method being called (e.g., `App\Repository::save`)
- `reference_type`: How it's being used (e.g., `method_call`, `type_hint`)

Currently we do NOT store:
- The FQN of the property being accessed (though we could derive it)
- Whether the receiver is a parameter, local, or property

## Consistency Analysis

Looking at other kloc-cli output patterns:

1. **Inheritance**: Uses `extends` prefix
   ```
   [1] extends App\Entity\BaseEntity
   ```

2. **Overrides**: Uses `overrides` prefix
   ```
   [1] overrides App\Entity\User::getName
   ```

3. **Member references**: Uses arrow notation
   ```
   App\Service\OrderService -> createOrder() [method_call]
   ```

4. **Locations**: Uses `at:` prefix (implied in file:line format)
   ```
   (src/Service/OrderService.php:23)
   ```

5. **Interface grouping**: Uses `via interface:` prefix
   ```
   <- via interface: ServiceInterface::doSomething()
   ```

The `on:` prefix is unique to access chains but consistent with the pattern of using short prefixes.

## User Persona Analysis

### AI Agents (Claude)

Primary needs:
- Understand code flow to make changes
- Navigate to the right location
- Understand dependencies

For AI agents, the current `$this->orderService` is useful because:
- It shows the actual code pattern that would appear in the file
- It helps understand the dependency injection pattern
- It can guide where to look for configuration/setup

The FQN version `App\Controller::$orderService` is useful because:
- It's unambiguous and resolvable
- It can be used for further queries
- It matches how the AI would identify the property in analysis

### Human Developers

Primary needs:
- Quick understanding of call site
- Navigate to implementation
- Debug issues

For developers, the current format is intuitive because:
- `$this->orderService` is what they'd see in the code
- Immediately recognizable PHP pattern
- Doesn't require mental translation

The FQN version is useful for:
- IDE navigation (though kloc output isn't clickable)
- Understanding which class owns the property
- Disambiguation when multiple classes have same property name

## Key Questions

1. **Is disambiguation necessary?**
   - The containing class is already shown (OrderController::create())
   - Within a method, `$this->orderService` is unambiguous
   - But for understanding at a glance, having the FQN might help

2. **Do users need to query the property?**
   - If they want to understand `$orderService`, they could run:
     `kloc-cli context OrderController::$orderService`
   - Having the FQN makes this copy-pasteable
   - But the current format already tells them the property name

3. **Is verbosity a problem?**
   - Current output is already multi-line with depth indicators
   - Adding more text increases cognitive load
   - But the information density might be worth it

## What Other Tools Do

- **PhpStorm "Find Usages"**: Shows `$this->orderService->createOrder()` (full expression)
- **VS Code "Find All References"**: Shows just the file:line with code preview
- **GitHub Code Search**: Shows code snippet with highlighting
- **Sourcegraph**: Shows code context with expandable details
