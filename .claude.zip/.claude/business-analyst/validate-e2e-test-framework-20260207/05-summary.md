# Summary

## Key Findings

1. Current 8 scenarios cover only 8.5% of the needed test surface. Identified 94 total test cases.
2. The Customer domain (6 files) is completely untested.
3. The Messenger pattern (OrderCreatedHandler, OrderCreatedMessage, NotificationService) is untested.
4. OrderDisplayService (nullsafe operators, static calls, match expressions) is untested.
5. The `resolve` command has zero E2E tests -- it is foundational.
6. Depth expansion is not systematically tested. Maximum meaningful depth is 4.
7. Polymorphic --impl scenarios need 8 specific tests covering both directions.
8. Negative assertions (what should NOT appear) are missing entirely.
9. JSON output format testing is absent.
10. Existing contract tests (235 tests) cover scip-php/calls.json only, not the full pipeline.

## Recommendations

- Implement 94 tests in 6 phases.
- Phase 1 (pipeline smoke + resolve): 10 tests
- Phase 2 (usages): 12 tests
- Phase 3 (deps): 10 tests
- Phase 4 (context): 24 tests -- highest value, most complex
- Phase 5 (owners + inherit + overrides): 14 tests
- Phase 6 (edge cases + formats): 24 tests

## Output

Full analysis written to: /Users/michal/dev/ai/kloc/docs/analysis/ba-e2e.md
