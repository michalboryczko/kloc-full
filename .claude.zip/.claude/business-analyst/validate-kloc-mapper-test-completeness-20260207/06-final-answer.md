# Analyst 3A: kloc-mapper Test Framework -- Completeness Assessment

## Strengths

1. **Node kinds are complete**: All 13 NodeKind values from models.py are listed exactly (File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase, Value, Call), correctly split between SCIP-sourced and calls.json-sourced.

2. **Edge types are complete**: All 12 EdgeType values from models.py are listed (contains, extends, implements, uses_trait, overrides, uses, type_hint, calls, receiver, argument, produces, assigned_from, type_of), with a logical grouping into structural, type, and call graph categories.

3. **Test categories are well-structured**: The six categories (smoke, node-creation, edge-creation, value-mapping, call-mapping, integrity) provide reasonable coverage of the major mapping areas and follow a logical progression from simple to complex.

4. **Fixture strategy is sound**: The dual-strategy approach (global fixtures for integration/smoke, per-test fixtures for unit tests) is appropriate. The requirement for programmatic generation and independence from scip-php is correct for isolated testing.

5. **SoTData query helpers are practical**: The four listed methods (node, edge, nodes_by_kind, edges_by_type) cover the most common lookup patterns.

6. **Pipeline position is correctly identified**: The spec accurately shows kloc-mapper's position receiving .kloc archives (index.scip + calls.json) and producing sot.json.

## Gaps

### GAP-1: Missing Node fields in test criteria (Medium)
The spec says node-creation tests verify "correct kind, fqn, file, range" but omits several fields from the Node dataclass:
- `name` -- the short display name (extracted by `extract_name_from_descriptor`)
- `symbol` -- the raw SCIP symbol string
- `enclosing_range` -- the AST extent range used for containment detection
- `documentation` -- the PHPDoc documentation strings
- `id` -- deterministic hash-based ID (critical for edge references)

**Impact**: Tests could pass while these fields contain wrong data.

### GAP-2: Missing Edge fields in test criteria (Medium)
Edges have additional fields beyond type/source/target:
- `location` (file, line, col) -- set on `uses` edges; references the occurrence position
- `position` (int) -- set on `argument` edges; the 0-based argument index

Neither is mentioned in edge-creation test criteria.

**Impact**: Argument ordering and uses-edge provenance would go untested.

### GAP-3: No test category for classification logic (Medium)
The mapper's `_classify_symbol()` method in mapper.py (lines 137-182) implements complex descriptor-pattern-based classification logic (e.g., detecting `#$` for Property, `().` for Method, inferring Class vs Interface vs Trait vs Enum from documentation). This is the most intricate part of the SCIP mapping and has no dedicated test category.

**Impact**: Misclassification bugs (e.g., an Enum mistakenly classified as Class) would only be caught indirectly through node-creation tests.

### GAP-4: No mention of deduplication and filtering logic (Low-Medium)
mapper.py has significant filtering logic that needs dedicated testing:
- Uses-edge deduplication by (source_id, target_id) pair (line 494-498)
- Parameter self-reference filtering -- skip if target is a parameter of the enclosing method (line 490-492)
- Self-reference prevention -- source_id != target_id (line 486-487)

**Impact**: Without these tests, regressions could introduce duplicate or spurious edges.

### GAP-5: Calls.json fixture schema not specified (Medium)
The spec says fixtures must be "consistent with calls.json schema" but doesn't define it. The actual schema (from calls_mapper.py) requires:
- **values**: `{id, location:{file,line,col}, kind, symbol, type, source_value_id}`
- **calls**: `{id, location:{file,line,col}, kind, callee, caller, return_type, receiver_value_id, arguments:[{position, value_id}]}`

**Impact**: Fixture generators could produce malformed data. The tester agent building the framework will have to reverse-engineer the schema from calls_mapper.py.

### GAP-6: SCIP protobuf fixture structure not specified (Medium)
The spec says "SCIP protobuf format" but doesn't detail which messages and fields are needed:
- `Index` with `documents[]` and `metadata`
- `Document` with `relative_path`, `symbols[]`, `occurrences[]`
- `SymbolInformation` with `symbol`, `documentation[]`, `relationships[]`
- `Relationship` with `symbol`, `is_implementation`, `is_reference`, `is_type_definition`, `is_definition`
- `Occurrence` with `symbol`, `range[]`, `symbol_roles`, `enclosing_range[]`

**Impact**: Building valid SCIP protobuf fixtures without this guidance requires reading the parser.py and mapper.py source code.

### GAP-7: SoTGraph output structure details missing (Low)
The spec says output is "sot.json graph with nodes and edges" but doesn't mention:
- `version` field (currently "2.0")
- `metadata` dict (generated_at, source_scip, project_root)
- Output sorting: nodes sorted by `id`, edges sorted by `(source, type, target)`

**Impact**: Smoke tests can't validate the full output shape without this information.

### GAP-8: SoTData query helpers are insufficient (Low-Medium)
The four proposed helpers lack:
- Filtering by `symbol`, `file`, or `id` on nodes
- Filtering by `location` or `position` on edges
- Accessing kind-specific fields (`value_kind`, `call_kind`, `type_symbol`)
- Count helpers
- Containment tree traversal
- "Assert no edge" / "assert unique" helpers for integrity checks

**Impact**: Test code will need ad-hoc filtering logic, reducing consistency and readability.

### GAP-9: No mention of ID generation testing (Low)
The models.py has four distinct ID generation functions:
- `generate_node_id(symbol)` -- standard nodes
- `generate_file_node_id(filepath)` -- file nodes
- `generate_value_node_id(location_id)` -- value nodes (prefix: `node:val:`)
- `generate_call_node_id(location_id)` -- call nodes (prefix: `node:call:`)

These are deterministic (SHA-256 based) and use different prefixes to avoid collisions. The spec doesn't call out testing these ID generation patterns or the collision-avoidance design.

### GAP-10: No mention of constructor call edge special handling (Low)
In calls_mapper.py lines 165-175, when a callee can't be resolved but the call kind is "constructor", it falls back to using `return_type` to find the class node. This edge case isn't called out in the test categories.

## Risks

1. **Fixture complexity risk**: Building valid SCIP protobuf fixtures programmatically requires deep knowledge of the protobuf schema and the mapper's expectations. Without explicit fixture schemas (GAPs 5 and 6), the tester agent may produce fixtures that don't exercise the right code paths.

2. **Incomplete integrity checks**: The spec lists "unique IDs, no orphans, no duplicates" but the actual invariants are more nuanced -- for example, every edge's source and target must reference existing nodes; Value/Call nodes use distinct ID prefixes; contains edges form a tree (no cycles); argument edges should have sequential positions.

3. **Missing coverage of spatial index**: The `_build_file_symbol_index()` and `_find_enclosing_symbol()` methods implement a spatial containment algorithm that is critical for correct `uses` and `contains` edge generation. This logic is not mentioned anywhere in the spec.

## Suggestions

1. **Add a "classification" test category** between smoke and node-creation, testing that descriptor patterns map to the correct NodeKind. This is pure logic that can be unit-tested with minimal fixtures.

2. **Expand node-creation criteria** to include all Node fields: id, kind, name, fqn, symbol, file, range, enclosing_range, documentation (and kind-specific fields for Value/Call).

3. **Expand edge-creation criteria** to include location and position fields.

4. **Document the calls.json fixture schema** explicitly in the spec, with field-by-field descriptions and example payloads.

5. **Document the SCIP protobuf fixture requirements** with the specific messages and fields needed, including which `symbol_roles` bitmask values to use and how `relationships` encode inheritance vs. type hints.

6. **Add SoTData helpers** for kind-specific field access, ID-based lookup, position-based edge queries, and negative assertions (assert_no_edge, assert_unique_id).

7. **Add deduplication/filtering test cases** under edge-creation or a new "edge-dedup" subcategory: duplicate uses references, parameter self-references, self-edges.

8. **Document SoTGraph output shape** including version, metadata fields, and sorting behavior.

## Verdict

**Completeness Rating: 3.5 / 5**

The spec correctly enumerates all node kinds and edge types and establishes a reasonable test framework structure. However, it has meaningful gaps in three areas: (1) it doesn't specify the full set of fields to validate on both nodes and edges, (2) it omits the fixture schemas that the tester agent will need to build valid SCIP and calls.json fixtures, and (3) it misses several important mapping behaviors that warrant dedicated test coverage (classification logic, deduplication, spatial indexing, constructor fallback). These gaps won't prevent the framework from being built, but they increase the risk of an incomplete test suite that misses real bugs. The suggestions above would bring this to a 4.5/5.
