# Observations

## Node Kinds Comparison

### Spec (13 total):
From SCIP: File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase
From calls.json: Value, Call

### models.py NodeKind enum (13 total):
FILE, CLASS, INTERFACE, TRAIT, ENUM, METHOD, FUNCTION, PROPERTY, CONST, ARGUMENT, ENUM_CASE, VALUE, CALL

**Result: EXACT MATCH. All 13 node kinds are accounted for.**

## Edge Types Comparison

### Spec lists (12 total):
- Structural: contains, extends, implements, uses_trait, overrides, uses
- Type: type_hint
- Call graph: calls, receiver, argument, produces, assigned_from, type_of

### models.py EdgeType enum (12 total):
CONTAINS, EXTENDS, IMPLEMENTS, USES_TRAIT, OVERRIDES, USES, TYPE_HINT, CALLS, RECEIVER, ARGUMENT, PRODUCES, ASSIGNED_FROM, TYPE_OF

**Result: EXACT MATCH. All 12 edge types are accounted for.**

## Mapping Logic Coverage

### mapper.py methods:
1. _collect_symbol_metadata() - collects docs, relationships from SCIP
2. _create_file_nodes() - File nodes
3. _create_symbol_nodes() - All SCIP-based nodes via _classify_symbol()
4. _build_file_symbol_index() - spatial index for containment
5. _build_contains_edges() - contains edges
6. _build_inheritance_edges() - extends, implements, uses_trait edges
7. _build_type_hint_edges() - type_hint edges
8. _build_uses_edges() - uses edges (with dedup, self-ref filtering)
9. _build_override_edges() - overrides edges
10. _process_calls_data() - delegates to calls_mapper

### calls_mapper.py methods:
1. _create_value_nodes() - Value nodes from calls.json values array
2. _create_call_nodes() - Call nodes from calls.json calls array
3. _create_call_edges() - calls, receiver, argument, produces, contains edges from calls
4. _create_value_edges() - assigned_from, type_of, contains edges from values

### Spec test categories:
- smoke - basic output validity
- node-creation - nodes correct kind, fqn, file, range
- edge-creation - edges connect correct source/target
- value-mapping - calls.json values -> Value nodes
- call-mapping - calls.json calls -> Call nodes
- integrity - unique IDs, no orphans, no duplicates

### Missing coverage areas in spec:
1. No explicit mention of testing _classify_symbol() logic (descriptor-based classification)
2. No mention of testing enclosing_range field on nodes
3. No mention of testing the metadata field on SoTGraph
4. No mention of testing sorted output (nodes sorted by id, edges sorted by source/type/target)
5. No mention of testing deduplication logic in _build_uses_edges()
6. No mention of parameter self-reference filtering in uses edges
7. No mention of the spatial index (_build_file_symbol_index) behavior
8. No mention of testing _resolve_relationship_target() fuzzy matching
9. No mention of testing symbol resolution fallbacks in calls_mapper._resolve_symbol_to_node_id()
10. No mention of testing generate_value_node_id vs generate_call_node_id prefix disambiguation

## Node Fields Not Covered in Spec

The spec mentions testing "correct kind, fqn, file, range" for node-creation, but the Node dataclass has:
- id, kind, name, fqn, symbol, file, range, enclosing_range, documentation
- value_kind, type_symbol (for Value)
- call_kind (for Call)

The spec does mention value_kind, type_symbol, call_kind for value-mapping and call-mapping.
But: name, symbol, enclosing_range, documentation are not explicitly listed.

## Edge Fields Not Covered in Spec

Edge dataclass has: type, source, target, location, position
- location (file, line, col) is set on uses edges
- position is set on argument edges
- The spec doesn't mention testing these additional edge fields

## SoTData Query Helper Coverage

### Spec lists:
- node(kind=, name=, fqn=) - find node
- edge(type=, source=, target=) - find edge
- nodes_by_kind(kind) - all of a kind
- edges_by_type(type) - all of a type

### Missing from helpers:
- No filter by file, range, or symbol
- No filter for edge location or position
- No helper for checking edge position (argument ordering)
- No helper for checking enclosing_range
- No helper for count operations
- No helper for containment tree traversal
- No helper for node-specific fields (value_kind, call_kind, type_symbol)

## Fixture Requirements

### SCIP protobuf format:
The spec says "Must be consistent with scip-php output contract (SCIP protobuf format, calls.json schema)"
But doesn't specify:
- Which protobuf messages are needed (Index, Document, Occurrence, SymbolInformation, Relationship)
- How to populate symbol_roles bitmask correctly
- How enclosing_range should be set
- How relationships should be structured for inheritance/type_hint/override detection

### calls.json format:
The spec references calls.json but doesn't specify the expected schema:
- values array: {id, location{file,line,col}, kind, symbol, type, source_value_id}
- calls array: {id, location{file,line,col}, kind, callee, caller, return_type, receiver_value_id, arguments[{position, value_id}]}

## SoTGraph Output Structure

The spec says output is "sot.json graph with nodes and edges" but doesn't detail:
- version field (currently "2.0")
- metadata field (generated_at, source_scip, project_root)
- Sorting behavior (nodes by id, edges by source/type/target)
