# Summary

## Key Findings

1. **SCIP fixture generation is fully feasible** - verified by roundtrip protobuf test using kloc-mapper's own scip_pb2.py
2. **Bug discovered**: NodeKind.FUNCTION classification is dead code (unreachable) in mapper.py line 179
3. **85+ test scenarios identified** across 15 code paths
4. **CallsMapper has zero test coverage** - 13 methods completely untested
5. **Existing tests are integration-only** - depend on real .scip artifact, no isolated unit tests
6. **Clean separation from scip-php tests** - they occupy different layers of the test pyramid
7. **Estimated effort: ~11 days** for complete contract test suite including fixture infrastructure

## Critical Recommendations

1. Fix the FUNCTION classification bug before writing tests
2. Build SCIP fixture builder utility reusing scip_pb2.py
3. Implement the SoTData query helper for ergonomic test assertions
4. Start with integrity tests (no dangling edges, no self-references) - highest ROI
5. Test the relationship flag matrix exhaustively (extends/implements/uses_trait/override)
6. Place contract tests in kloc-mapper/tests/contract/ alongside existing tests

## Output

Full analysis written to: /Users/michal/dev/ai/kloc/docs/analysis/ba-kloc-mapper.md
