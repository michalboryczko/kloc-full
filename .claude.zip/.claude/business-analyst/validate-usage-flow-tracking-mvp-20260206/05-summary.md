# Summary

Created a requirements specification at `docs/specs/usage-flow-tracking-mvp.md` that distills 8 testing issues into 8 formal requirements (R1-R8), organized into three priority tiers:

**Tier 1 (Foundation)**: R8 chaining rules, R7 recursive depth, R3 external-only filter -- these define the correctness of depth traversal and must be done first.

**Tier 2 (Core)**: R1 hide imports, R6 FQN identifiers, R2 line-number sorting -- these deliver the expected output quality for MVP.

**Tier 3 (Polish)**: R4 access chain FQN enrichment, R5 method signature completeness -- additive improvements that do not affect correctness.

The spec includes: CLI output examples for class and method queries, depth flag semantics for both directions, chainable vs non-chainable edge type definitions, JSON output schema, 32 testable acceptance criteria, and a dependency graph showing implementation order.