# Observations

## Issue Analysis Summary

### Issue 8 is foundational
Issue 8 (depth chaining through type_hint/imports) is the most critical correctness issue. It produces factually incorrect dependency chains. If this is not fixed, deeper depth traversal is actively harmful — showing false relationships. This must be addressed before Issue 7 (recursive depth) or the recursive depth feature will amplify incorrect data.

### Issues 1 and 6 are related
Both deal with PHP `use` import statements showing up as noise:
- Issue 1: Imports appear as duplicate type_hint references
- Issue 6: When imports appear, they show file paths instead of FQN

Fixing Issue 1 (hiding imports by default) would hide most instances of Issue 6. But Issue 6 is still independently needed for any remaining file-level references that are not imports.

### Issue 3 depends on Issue 8's chaining rules
Issue 3 (self-references in USED BY for classes) is related to the chaining rules in Issue 8. The self-referencing property accesses are internal implementation details. The filtering rule for Issue 3 (external-only for class queries) works hand-in-hand with Issue 8's rule about what reference types are valid for depth chaining.

### Issue 7 is the depth traversal engine
Issue 7 (USED BY depth not chaining) is the core recursive traversal bug. Once Issue 8's rules are in place to define WHICH edges to follow, Issue 7's fix actually implements the recursive following of those edges.

### Issues 2, 4, 5 are output quality improvements
- Issue 2 (sort by line number) — pure output ordering, no data model impact
- Issue 4 (access chain missing FQN) — enriching existing data, additive
- Issue 5 (malformed signatures) — data quality bug, possibly upstream in scip-php or kloc-mapper

## Priority Ordering
1. Issue 8 (define chaining rules) — FOUNDATION
2. Issue 7 (implement recursive depth) — depends on 8's rules
3. Issue 3 (filter internal self-refs) — related to chaining correctness
4. Issue 1 (hide imports) — noise reduction
5. Issue 6 (FQN for file-level refs) — consistency, related to 1
6. Issue 2 (sort by line number) — output quality
7. Issue 4 (access chain FQN) — output enrichment
8. Issue 5 (signature display) — may be upstream bug