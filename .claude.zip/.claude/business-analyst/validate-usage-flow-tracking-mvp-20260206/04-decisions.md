# Decisions

1. **Spec is user-facing, not implementation-facing**: Focus on what the user sees and expects, not how the code should change internally.

2. **Three priority tiers**: Foundation (correctness), Core (feature completeness), Polish (output quality).

3. **Issue 8's chaining rules become the central behavioral contract**: The spec defines which edge types are "chainable" for depth traversal as a first-class requirement, not an implementation detail.

4. **Issue 1's future consideration (query language) documented but deferred**: Important for the roadmap but explicitly out of scope for MVP.

5. **Issue 5 left as investigation item**: May be upstream in scip-php or kloc-mapper. The spec states the requirement (complete signatures) but acknowledges the root cause needs investigation.

6. **Acceptance criteria are testable with kloc-reference-project-php**: All criteria reference scenarios that can be validated against the existing reference project.