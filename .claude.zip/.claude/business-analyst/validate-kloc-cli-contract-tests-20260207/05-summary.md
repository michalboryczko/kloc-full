# Summary

## Key Findings

1. **277 unique test cases identified** across 19 categories covering all 7 CLI commands + MCP server
2. **Zero CLI-level tests exist today** -- all 47 existing tests operate at the Python API layer
3. **MCP server has zero test coverage** -- 28 test cases identified for protocol, tools, multi-project
4. **Context command is the most complex** -- 45 test cases, 8 behavioral rules (R1-R8), 3 flags
5. **MCP feature gap found** -- `--direct` and `--with-imports` flags not exposed in MCP protocol
6. **Fixture generator is feasible** -- human-readable IDs work, no SHA256 hashing needed, ~200-300 LOC
7. **Tree ordering is non-deterministic** for usages, deps, inherit, overrides -- tests must use set assertions

## Recommendations

- Use Typer CliRunner (not subprocess) for contract tests
- Build SoTBuilder with auto-generated contains edges and sequential line numbers
- Test JSON output only (not console) for correctness
- Structure in 5 phases: Foundation, Core Commands, Context, Edge Cases, MCP
- Minimum viable suite: 119 tests in 12-17 days
- Full suite: 277 tests

## Output

Full analysis written to `/Users/michal/dev/ai/kloc/docs/analysis/ba-kloc-cli.md`
