# Consolidated Assessment: Pure Graph Format for KLOC

**Date**: 2026-02-05
**Status**: APPROVED - Ready for Implementation
**Spec Location**: `/Users/michal/dev/ai/kloc/docs/specs/unified-graph-format.md`

---

## Executive Summary

Two previous assessments analyzed the unified graph format:
1. **First assessment** recommended typed edges with pre-computed `access_chain` strings
2. **Second assessment** recommended deferring pure graph model for MVP

**User decision**: Pure graph model is the architecture. Graph = source of truth. CLI = presentation layer.

This consolidation confirms the current spec at `docs/specs/unified-graph-format.md` is **correct and ready for implementation** with minor clarifications.

---

## 1. Reconciliation of Assessments

### First Assessment Concern: Pre-computed access_chain

The first assessment valued pre-computed `access_chain` strings on edges because:
- Simpler queries for common questions
- No traversal overhead at query time

**Resolution**: With the pure graph model, access chains are computed by traversal. This is **acceptable** because:
1. **CLI is presentation layer** - kloc-cli can cache computed chains
2. **Graph size doesn't matter** - AI agents consume CLI output, not raw JSON
3. **Traversal is straightforward** - Follow receiver edges recursively

### Second Assessment Concern: 5-10x more edges

The second assessment noted pure graph adds significant node/edge count:
- Current: ~1 edge per call with metadata
- Pure: ~8 edges per call (calls, receiver, argument, produces)

**Resolution**: This is **acceptable** because:
1. **Graph is source of truth** - Completeness matters more than compactness
2. **CLI filters** - Users see formatted output, not raw graph
3. **Enables future** - Graph algorithms, embeddings, advanced analysis

### Second Assessment Concern: Query complexity

The second assessment showed common queries require more steps in pure graph.

**Resolution**: This is **acceptable** because:
1. **kloc-cli absorbs complexity** - Users don't write graph queries
2. **Consistent model** - One way to traverse everything
3. **Better for data flow** - Pure graph wins on advanced queries

---

## 2. Final Node Kinds

The following node kinds are **confirmed** for the spec:

### Structural Nodes (Existing - 11)

| Kind | Description |
|------|-------------|
| FILE | Source file |
| CLASS | PHP class |
| INTERFACE | PHP interface |
| TRAIT | PHP trait |
| ENUM | PHP enum |
| METHOD | Class/trait method |
| FUNCTION | Standalone function |
| PROPERTY | Class property |
| CONST | Class/interface constant |
| ARGUMENT | Method/function parameter |
| ENUM_CASE | Enum case |

### Runtime Nodes (New - 2)

| Kind | Description | value_kind / call_kind |
|------|-------------|------------------------|
| VALUE | Runtime value at a location | parameter, local, result, literal, constant |
| CALL | Call site (invocation/access) | method, method_static, constructor, access, access_static, function |

**Total: 13 node kinds**

---

## 3. Final Edge Types

The following edge types are **confirmed** for the spec:

### Structural Edges (Existing - 5)

| Type | Description |
|------|-------------|
| contains | Parent-child containment (File->Class->Method) |
| extends | Class/interface inheritance |
| implements | Interface implementation |
| uses_trait | Trait usage |
| overrides | Method override |

### Type Reference Edges (New - 1)

| Type | Description |
|------|-------------|
| type_hint | Type annotation reference (param/return/property -> Class/Interface) |

### Call Relationship Edges (New - 3)

| Type | Description |
|------|-------------|
| calls | Call node -> target (Method/Function/Property/Constructor) |
| receiver | Call node -> Value node (object being called on) |
| argument | Call node -> Value node (value passed), with `position` field |

### Value Relationship Edges (New - 3)

| Type | Description |
|------|-------------|
| produces | Call node -> Value node (result of call) |
| assigned_from | Value -> Value (assignment source) |
| type_of | Value -> Class/Interface (runtime type) |

**Total: 12 edge types**

---

## 4. Implementation Priority

Given the user's decision for pure graph, here is the recommended implementation order:

### Phase 1: Foundation (Week 1)
**Focus**: Get nodes and edges working

1. Add VALUE and CALL node kinds to models
2. Add new edge types to models
3. Create .kloc archive loader
4. Generate structural nodes and edges (existing functionality)

### Phase 2: Calls Integration (Week 2)
**Focus**: Convert calls.json to graph nodes/edges

1. Create Value nodes from calls.json values array
2. Create Call nodes from calls.json calls array
3. Generate `calls` edges (Call -> target method/property)
4. Generate `receiver` edges (Call -> receiver Value)
5. Generate `argument` edges (Call -> argument Values)
6. Generate `produces` edges (Call -> result Value)

### Phase 3: Type Relationships (Week 2)
**Focus**: Complete the type information

1. Generate `type_hint` edges from SCIP relationships
2. Generate `type_of` edges from value type information
3. Generate `assigned_from` edges from value assignments

### Phase 4: kloc-cli Updates (Week 3)
**Focus**: Update CLI to consume new graph

1. Remove `--calls` option
2. Update graph loader for new node/edge types
3. Implement access chain traversal function
4. Update `context` query output
5. Update `usages` query
6. Update tree display

### Phase 5: Testing (Week 4)
**Focus**: Validate everything works

1. Unit tests for new node/edge types
2. Integration tests with kloc-reference-project-php
3. End-to-end tests for CLI commands
4. Performance testing

---

## 5. kloc-cli Impact Analysis

### Files to Remove

| File | Reason |
|------|--------|
| `src/graph/calls.py` | Logic moves to kloc-mapper |

### CLI Options to Remove

| Option | Reason |
|--------|--------|
| `--calls` | No longer needed; calls data is in sot.json |

### Files to Modify

| File | Change |
|------|--------|
| `src/graph/loader.py` | Load Value and Call nodes |
| `src/graph/index.py` | Index new node types, support new edge types |
| `src/graph/models.py` | Add VALUE, CALL node kinds; add new edge types |
| `src/queries/context.py` | Build access chain via graph traversal |
| `src/queries/usages.py` | Adapt for Call nodes |
| `src/queries/deps.py` | Adapt for new edge types |
| `src/output/tree.py` | Display Call/Value info |
| `src/cli.py` | Remove --calls option |

### New Functions Required in kloc-cli

```python
def build_access_chain(graph, call_node) -> str:
    """
    Traverse receiver edges to build chain like '$this->orderRepository'.

    Algorithm:
    1. Get receiver edge from call_node
    2. If receiver is parameter/local, return its name
    3. If receiver is result, find producing call, recurse
    4. Join parts with '->'
    """
    pass

def get_containing_scope(graph, call_node) -> Node:
    """
    Find the method/function that contains this call.

    Algorithm:
    1. Find 'contains' edge where target is call_node
    2. Return the source node
    """
    pass

def format_call_for_ai(graph, call_node) -> str:
    """
    Format a call for AI agent consumption.

    Output format:
    "OrderService::createOrder() -> save() [method_call]"
    "    on: $this->orderRepository"
    """
    pass
```

### Query Pattern Changes

**Old (with --calls)**:
```python
# Load calls.json separately
calls_data = load_calls_file(calls_path)
# Match by location
call = find_call_at(calls_data, file, line)
# access_chain is pre-computed string
chain = call["access_chain"]
```

**New (pure graph)**:
```python
# Everything is in the graph
call_nodes = graph.edges.filter(type="calls", target=method)
for call_edge in call_nodes:
    call = call_edge.source  # Call node
    chain = build_access_chain(graph, call)  # Traverse
    scope = get_containing_scope(graph, call)
```

---

## 6. Risk Assessment

### Risk 1: Traversal Performance

**Risk**: Building access chains via traversal is slower than reading pre-computed strings.

**Mitigation**:
- Cache computed chains in kloc-cli during query execution
- For typical queries (10-50 calls), traversal is negligible (<10ms)
- If needed, add LRU cache for chain computation

**Assessment**: LOW RISK

### Risk 2: Graph Size

**Risk**: 5-10x more edges increases sot.json file size significantly.

**Mitigation**:
- AI agents use CLI, not raw JSON
- Compression (gzip) reduces impact
- For 500-method codebase: ~2MB vs ~500KB - still manageable

**Assessment**: LOW RISK (per user: "graph size doesn't matter")

### Risk 3: Query Complexity in kloc-cli

**Risk**: CLI code becomes more complex with graph traversal.

**Mitigation**:
- Traversal logic is well-defined and testable
- Only a few functions need to traverse (build_access_chain, get_containing_scope)
- Most queries still simple edge filters

**Assessment**: LOW RISK

### Risk 4: Migration Effort

**Risk**: Significant changes to both kloc-mapper and kloc-cli.

**Mitigation**:
- Changes are additive in kloc-mapper (new node/edge types)
- kloc-cli changes are mostly updates to existing queries
- 4-week implementation plan is realistic

**Assessment**: MEDIUM RISK (manageable with proper testing)

### Risk 5: Backward Compatibility

**Risk**: Existing sot.json files (v1.0) won't work with new CLI.

**Mitigation**:
- Version field in sot.json enables detection
- kloc-cli can show clear error: "This graph was generated with v1.0, please regenerate with kloc-mapper"
- Consider supporting both versions during transition

**Assessment**: LOW RISK

---

## 7. Final Recommendation

### Verdict: PROCEED

The current spec at `/Users/michal/dev/ai/kloc/docs/specs/unified-graph-format.md` is **approved and ready for implementation**.

### Spec Confirmation

| Aspect | Status |
|--------|--------|
| Node kinds (13) | Correct |
| Edge types (12) | Correct |
| Value node structure | Correct |
| Call node structure | Correct |
| Edge structure with position | Correct |
| .kloc archive format | Correct |
| Query examples | Correct |
| Implementation phases | Correct |
| Test cases | Correct |

### Minor Suggestions for Spec

1. **Add caching note**: In kloc-cli section, mention that access chain computation can be cached if performance is a concern.

2. **Clarify edge direction for contains**: The spec shows Call nodes as targets of `contains` edges from methods. This is correct - just ensure kloc-mapper implements this consistently.

3. **Consider adding return_type edge**: Not blocking, but could be useful for "what methods return this type" queries. Add to Phase 2 or later.

### Implementation Checklist

- [ ] kloc-mapper: Add VALUE, CALL node kinds
- [ ] kloc-mapper: Add new edge types
- [ ] kloc-mapper: Create archive.py for .kloc loading
- [ ] kloc-mapper: Create calls_mapper.py for Value/Call generation
- [ ] kloc-mapper: Generate all new edge types
- [ ] kloc-mapper: Unit tests
- [ ] kloc-cli: Remove --calls option
- [ ] kloc-cli: Update graph loader
- [ ] kloc-cli: Implement build_access_chain()
- [ ] kloc-cli: Update context query
- [ ] kloc-cli: Update usages query
- [ ] kloc-cli: Update tree display
- [ ] kloc-cli: Unit tests
- [ ] Integration tests with kloc-reference-project-php
- [ ] End-to-end tests
- [ ] Documentation updates

---

## Appendix: Summary of Both Previous Assessments

### Assessment 1: Unified Graph Format (validate-unified-graph-format-20260205)

**Key Recommendations**:
- Tiered edge types (type_hint, method_call, instantiation as Tier 1)
- Keep pre-computed access_chain strings on edges
- Do NOT add Value/Call nodes (too many nodes)
- Include raw calls/values arrays for advanced queries

**Verdict**: Proceed with modifications (hybrid approach)

### Assessment 2: Pure Graph Model (validate-pure-graph-model-20260205)

**Key Findings**:
- Pure graph adds 5-10x edges
- Common queries require more steps
- Data flow queries become cleaner
- Implementation effort: 3-4 weeks

**Verdict**: Defer pure graph for MVP

### Reconciliation

User decision overrides both assessments: **Pure graph is the architecture**.

Both assessments' concerns are addressed by the architecture decision:
- Pre-computed strings not needed (CLI computes on demand)
- Extra edges/nodes acceptable (CLI formats for AI)
- Query complexity in CLI acceptable (CLI is presentation layer)

The current spec correctly implements the pure graph model.
