# Business Analyst Agent Runs

This directory contains outputs from the `business-analyst` agent runs.

## Directory Structure

Each run creates a subdirectory named `{mode}-{topic}-{timestamp}/`:

```
.claude/business-analyst/
├── README.md                           # This file
├── validate-dead-code-20260205/        # Example run
│   ├── 01-brief.md                     # What the agent is doing
│   ├── 02-plan.md                      # How it will approach the task
│   ├── 03-observations.md              # Notes during investigation
│   ├── 04-decisions.md                 # Key decisions and rationale
│   ├── 05-summary.md                   # High-level summary
│   └── 06-final-answer.md              # The deliverable
└── discuss-semantic-search-20260206/   # Another run
    └── ...
```

## Modes

- **validate**: Assess a feature proposal
- **discuss**: Conversational feature exploration
- **roadmap**: Generate prioritized feature ideas

## Run ID Format

`{mode}-{topic-kebab-case}-{timestamp}`

Example: `validate-dead-code-detection-20260205`
