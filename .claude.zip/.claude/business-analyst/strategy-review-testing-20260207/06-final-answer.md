# Overall Testing Strategy Assessment

## Strengths

### 1. Clear Pipeline Decomposition
The spec correctly maps the system pipeline (`scip-php -> index.kloc -> kloc-mapper -> sot.json -> kloc-cli -> output`) and creates a test framework for each seam. This is textbook contract testing -- each component validates its own input/output contract independently, and E2E validates the full chain.

### 2. Independent Fixture Strategy per Component
Each component framework (kloc-cli, kloc-mapper) specifies programmatic fixture generation that is *independent of upstream components*. This is strategically critical: it means kloc-cli tests can run without kloc-mapper being available, and kloc-mapper tests can run without scip-php. This enables parallel development and independent CI pipelines.

### 3. Existing scip-php Contract Tests Serve as Blueprint
The existing `contract-tests/` framework (235 tests, 205 passing, 30 experimental skips) is mature and well-structured. The spec correctly references it as a pattern to follow for the new frameworks. Key patterns that should carry over:
- `#[ContractTest]` / `@contract_test` decorator for documentation generation
- Docker-based execution for reproducibility
- `bin/run.sh` CLI interface consistency
- Category-based test organization

### 4. Strong Assertion Vocabulary
The spec defines rich assertion types: exact match, count validation, depth validation, no false positives, reference type accuracy. This goes beyond basic "it works" testing into semantic correctness, which is appropriate for a code analysis tool where false positives/negatives directly impact user trust.

### 5. E2E Tests Grounded in Real Code Patterns
The E2E test scenarios reference actual architectural patterns (`OrderController -> OrderService -> OrderRepository -> Order`) that exist in the reference project. This is not theoretical -- the expected results are verifiable against known code.

## Gaps

### 1. No Explicit Contract Schema Between Components
The spec says kloc-cli fixtures "must be consistent with kloc-mapper output contract (sot.json v2.0 schema)" and kloc-mapper fixtures "must be consistent with scip-php output contract (SCIP protobuf format, calls.json schema)". But **there is no formal schema artifact that both the component and its fixture generator reference**. If sot.json v2.0 changes, who updates what? The contract is implicit, living only in code.

**Risk**: Schema drift between fixture generators and actual component outputs. A fixture might produce sot.json that kloc-mapper would never actually produce, making kloc-cli tests pass on unrealistic input.

### 2. No Regression Test Strategy
The spec covers what to test but not **when tests break, what happens**. Specifically:
- No mention of golden file / snapshot testing for expected outputs
- No mention of how to update expected results when intentional changes occur
- No mention of test tagging for "known failing" vs "unexpected regression"
- The existing scip-php tests have an "experimental" concept (26 tests), but the new frameworks don't define equivalent progressive validation

### 3. Missing Negative / Error Path Testing
The spec is entirely focused on happy-path correctness:
- What happens when kloc-cli receives a malformed sot.json?
- What happens when kloc-mapper receives a corrupted .kloc archive?
- What about missing fields, truncated files, version mismatches?
- What about symbols that don't exist (resolve with bad input)?

The kloc-cli spec mentions "resolve: not found" as a category, but the kloc-mapper spec has no error handling tests at all.

### 4. No Performance Baseline
For a code analysis tool, performance matters significantly (especially for AI agent usage where latency affects conversation flow). The spec has zero mention of:
- Indexing time benchmarks
- Query response time expectations
- Memory usage baselines
- Scaling characteristics (small project vs. large project)

### 5. No Cross-Version Compatibility Testing
The pipeline involves version-sensitive formats (sot.json v1.0 vs v2.0, calls.json schema versions). The spec doesn't address:
- Backward compatibility testing (new kloc-cli with old sot.json)
- Forward compatibility handling
- Version negotiation behavior

The kloc-cli CLAUDE.md explicitly states it supports both v1.0 and v2.0 formats, but no test validates this.

### 6. Gap Between E2E and Component: The kloc-mapper Middle Layer
Looking at the test levels:
- **scip-php contract tests**: Test calls.json + index.scip output (existing, 235 tests)
- **kloc-mapper component tests**: Test .kloc -> sot.json transformation (proposed)
- **kloc-cli component tests**: Test sot.json -> query output (proposed)
- **E2E**: Test full pipeline (proposed)

The gap is that **kloc-mapper tests use synthetic fixtures**, while E2E uses real data. If kloc-mapper has a bug that only manifests with real scip-php output (e.g., edge cases in SCIP protobuf encoding), the component tests won't catch it, and the E2E tests will fail without clear isolation of *where* the failure occurred.

## Risks

### 1. Fixture Maintenance Burden (HIGH)
Three separate frameworks, each with their own fixture generators, each needing to stay in sync with upstream schemas. The scip-php contract tests already have a mature fixture approach (bootstrap.php generates fresh index from real code). The new frameworks propose *synthetic* fixtures, which require ongoing maintenance as schemas evolve. With 3 fixture generators + 1 real pipeline, the maintenance surface is significant.

### 2. Docker Orchestration Complexity for E2E (MEDIUM)
The E2E framework requires orchestrating scip-php, kloc-mapper, and kloc-cli in Docker. The spec doesn't detail:
- How Docker images are versioned and pinned
- Whether the E2E tests use the same Docker images as CI/CD
- How to debug failures in the Docker pipeline
- Container startup time and its impact on test cycle time

### 3. Overlapping Coverage Between Existing and New Tests (MEDIUM)
The existing kloc-cli has its own test suite (`test_index.py`, `test_integration.py`, `test_reference_type.py`, `test_usage_flow.py`) that already tests resolve, usages, deps, inheritance, overrides with both unit fixtures and real artifacts. The proposed `contract-tests-kloc-cli` framework appears to duplicate much of this coverage. The spec doesn't clarify the relationship between these two test suites or whether the existing tests should migrate to the new framework.

### 4. Implementability Timeline (MEDIUM)
The spec proposes 3 new test frameworks + fixture generators + Docker configurations + documentation tooling. This is a substantial engineering effort. Without prioritization guidance, there's a risk of all three being started but none being completed to a useful depth.

## Suggestions

### 1. Define Shared Schema Artifacts
Create formal JSON Schema files for sot.json v2.0 and calls.json that serve as the single source of truth. Both fixture generators and components should validate against these schemas. This eliminates the implicit contract risk.

**Location**: `docs/schemas/sot-v2.0.json`, `docs/schemas/calls-v3.2.json`

### 2. Prioritize Component Tests Over E2E Initially
The existing scip-php contract tests already validate the indexer. Adding kloc-mapper component tests next provides the most incremental value because kloc-mapper is the least-tested component. E2E can come last, after the individual components are independently validated.

**Recommended order**: kloc-mapper component tests -> kloc-cli component tests -> E2E framework

### 3. Add an Integration Shim Between Components
Instead of jumping from component tests (synthetic fixtures) to full E2E (real pipeline), add a lighter integration layer: "use real scip-php output as kloc-mapper input" and "use real kloc-mapper output as kloc-cli input". These are simpler than full E2E but catch the fixture-vs-reality gap.

### 4. Address Error Path Testing Explicitly
Add a test category "error" or "negative" to each framework spec, with at least:
- Malformed input handling (corrupt JSON, missing fields)
- Version mismatch handling
- Symbol-not-found handling
- Empty input handling

### 5. Clarify Relationship with Existing kloc-cli Tests
The spec should explicitly state whether `contract-tests-kloc-cli` replaces, supplements, or coexists with `kloc-cli/tests/`. Recommendation: the existing tests remain as developer-facing unit/integration tests, while contract tests serve as API-level behavioral contracts. Document this distinction.

### 6. Add Performance Smoke Tests
Even without full benchmarking, add a "timing" category that asserts:
- Full pipeline completes in < N seconds for the reference project
- Individual CLI queries respond in < M milliseconds for the reference sot.json

### 7. Define CI/CD Integration Strategy
The spec mentions Docker-based execution but doesn't address CI integration:
- Which tests run on every PR?
- Which tests run nightly?
- How are test results reported?
- What blocks a merge?

## Verdict: 3.5 / 5 -- Good Foundation, Needs Refinement

The testing strategy is **fundamentally sound** in its approach: pipeline decomposition, independent fixture strategies, contract-based testing, and E2E validation. The existing scip-php contract tests demonstrate that this team can execute well on this pattern.

However, the strategy has **material gaps** that could undermine its value:
1. No formal schema contracts between components (highest risk)
2. No error/negative path testing
3. No performance considerations
4. Potential duplication with existing kloc-cli tests
5. No CI/CD integration plan
6. The maintenance burden of 3 separate fixture generators is significant

**Recommendation**: Proceed with implementation, but address gaps #1 (shared schemas) and #5 (clarify relationship with existing tests) before starting. Implement in phases: kloc-mapper first, then kloc-cli, then E2E. Add error path tests as a required category in each framework.
