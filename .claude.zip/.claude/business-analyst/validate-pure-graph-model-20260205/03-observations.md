# Observations: Pure Graph Model Assessment

## 1. Current Unified-Graph-Format Model (from spec)

### Node Types (11)
- FILE, CLASS, INTERFACE, TRAIT, ENUM
- METHOD, FUNCTION, PROPERTY, CONST, ARGUMENT, ENUM_CASE

### Edge Types (14)
- Structural: CONTAINS, EXTENDS, IMPLEMENTS, USES_TRAIT, OVERRIDES
- Reference types (new): TYPE_HINT, METHOD_CALL, STATIC_CALL, INSTANTIATION,
  PROPERTY_ACCESS, STATIC_PROPERTY, FUNCTION_CALL, CONSTANT_ACCESS
- Fallback: USES

### Edge Structure
```python
@dataclass
class Edge:
    type: EdgeType
    source: str          # node id (enclosing scope)
    target: str          # node id (referenced symbol)
    location: Location
    target_member: str   # "save()" for method calls
    access_chain: str    # "$this->orderRepository"
    call_id: str         # Reference to raw call record (optional)
```

### Separate Arrays
The spec includes `calls` and `values` arrays in the unified JSON for "advanced data flow queries".

---

## 2. Proposed Pure Graph Model

### Node Types (13 - adds 2)
- Existing: FILE, CLASS, INTERFACE, TRAIT, ENUM, METHOD, FUNCTION, PROPERTY, CONST, ARGUMENT, ENUM_CASE
- **NEW: Value** - Runtime values (parameter, local, result, literal, constant)
- **NEW: Call** - Call sites (method call, property access, constructor)

### Edge Types (existing + 6 new)
- Existing structural edges unchanged
- **NEW: type_hint** - Type annotation reference
- **NEW: calls** - Call node -> target Method/Function/Property
- **NEW: receiver** - Call node -> Value node (what object the call is on)
- **NEW: argument** - Call node -> Value node (what's passed)
- **NEW: produces** - Call node -> Value node (result)
- **NEW: assigned_from** - Value -> Value (variable assignment)

### Key Insight
In pure graph: `access_chain` becomes a traversable path rather than a string.

---

## 3. Concrete Example Comparison

### Code: `$this->orderRepository->save($order)`

### CURRENT MODEL (unified-graph-format)

**Edges:**
```json
{
  "type": "method_call",
  "source": "node:OrderService::createOrder",
  "target": "node:OrderRepository::save",
  "location": {"file": "...", "line": 40, "col": 26},
  "target_member": "save()",
  "access_chain": "$this->orderRepository"
}
```

**Plus raw data in arrays:**
```json
"calls": [{...call record...}],
"values": [{...value record...}]
```

### PROPOSED PURE GRAPH MODEL

**Nodes:**
1. `node:OrderService::createOrder` (Method) - existing
2. `node:OrderService::$orderRepository` (Property) - existing
3. `node:OrderRepository::save` (Method) - existing
4. `value:this@40:8` (Value kind=parameter) - NEW
5. `call:property_access@40:8` (Call) - NEW
6. `value:result@40:8` (Value kind=result) - NEW
7. `call:method_call@40:26` (Call) - NEW
8. `value:$order@...` (Value kind=local/parameter) - NEW

**Edges:**
1. createOrder --(contains)--> call:property_access@40:8
2. createOrder --(contains)--> call:method_call@40:26
3. call:property_access@40:8 --(calls)--> Property:$orderRepository
4. call:property_access@40:8 --(receiver)--> value:this@40:8
5. call:property_access@40:8 --(produces)--> value:result@40:8
6. call:method_call@40:26 --(calls)--> Method:save
7. call:method_call@40:26 --(receiver)--> value:result@40:8
8. call:method_call@40:26 --(argument)--> value:$order

**Comparison:**
- Current: 1 edge + raw arrays
- Pure graph: 8 nodes + 8 edges (for one line of code!)

---

## 4. Node Count Impact Analysis

### Estimation for typical PHP method (10 lines, 3 calls)

**Current model:**
- 1 Method node
- 3 edges (one per call) with embedded chain data
- 6 call records in array
- 10 value records in array

**Pure graph model:**
- 1 Method node
- ~6 Call nodes (property access + method calls)
- ~10 Value nodes (parameters, locals, results)
- ~30 edges (contains, calls, receiver, produces, argument)

**Multiplier:** ~3-5x more nodes, ~5-10x more edges

### For a 500-method codebase:
- Current: ~600 nodes, ~3000 edges, ~3000 call/value records
- Pure graph: ~3000 nodes, ~15000+ edges

---

## 5. Query Pattern Analysis

### Query 1: "What calls OrderRepository::save()?"

**Current model:**
```python
# Find all edges where target=OrderRepository::save and type=method_call
edges = [e for e in edges if e.target == "node:save" and e.type == "method_call"]
# access_chain available directly on edge
for e in edges:
    print(f"{e.source} via {e.access_chain}")
```

**Pure graph model:**
```python
# Find all Call nodes where calls->OrderRepository::save
call_nodes = [n for n in nodes if
    any(e.target == "node:save" and e.type == "calls" for e in edges_from(n))]
# To get access chain, must traverse receiver edges
for call in call_nodes:
    chain = build_chain_by_traversal(call)  # Follow receiver edges recursively
    print(f"{get_containing_method(call)} via {chain}")
```

**Verdict:** Current model is simpler for this common query.

---

### Query 2: "What's the access chain for this call?"

**Current model:**
```python
edge = get_edge_for_call(file, line)
return edge.access_chain  # Pre-computed string
```

**Pure graph model:**
```python
call = get_call_node(file, line)
chain = []
current = get_receiver(call)
while current:
    if current.kind == "result":
        source_call = get_source_call(current)
        chain.append(extract_member_name(source_call))
        current = get_receiver(source_call)
    else:
        chain.append(current.name)
        break
return "->".join(reversed(chain))
```

**Verdict:** Current model is simpler (pre-computed). Pure graph enables more flexibility but adds traversal overhead.

---

### Query 3: "What are all usages of OrderRepository?" (class, not just methods)

**Current model:**
- Find edges targeting OrderRepository (type_hint, method_call, etc.)
- Group by edge type

**Pure graph model:**
- Find edges targeting OrderRepository (type_hint, extends, implements)
- Find Call nodes that call methods ON OrderRepository (requires traversing receiver->type)
- More steps but same eventual answer

**Verdict:** Comparable complexity.

---

### Query 4: "Trace data flow: Where does $order come from and where does it go?"

**Current model:**
- Must use raw calls/values arrays
- Follow source_call_id and receiver_value_id chains
- Build chain manually from arrays

**Pure graph model:**
- Find Value node for $order
- Follow assigned_from edges backward (where it came from)
- Follow argument edges forward (where it's passed)
- Standard graph traversal

**Verdict:** Pure graph is cleaner for data flow analysis.

---

## 6. AI Agent Perspective

### What AI agents actually need:
1. Quick answers to "what calls X" and "what does X call"
2. Understanding of access chains (how a variable flows to a call)
3. Impact analysis (if I change X, what breaks)
4. Context for refactoring (show me related code)

### Current model serves well:
- Pre-computed `access_chain` string is immediately usable
- Single edge per reference with all metadata
- JSON output is compact and readable

### Pure graph advantages:
- Data flow queries become first-class (trace $order's journey)
- Uniform model (everything is node/edge) simplifies mental model
- Better for future graph algorithms (centrality, clustering)

### Pure graph disadvantages:
- More verbose output (agent must filter more)
- Chain reconstruction requires traversal (slower, more complex)
- Large JSON size may hit context limits

---

## 7. kloc-cli Impact Assessment

### Commands affected:

**`context --used-by`:**
- Current: Show edges with type, access_chain embedded
- Pure graph: Must query Call nodes, traverse to build chains

**`usages`:**
- Similar impact to context

**`deps`:**
- Must filter to "calls" edges from Call nodes, not direct edges

**Tree display:**
- Current: Edge has all info for display
- Pure graph: Must join across nodes to build display string

### Estimated changes:
- **loader.py**: Load Call and Value nodes
- **index.py**: New indices for Call/Value nodes
- **queries/context.py**: Rewrite chain building
- **output/tree.py**: Adapt for node-based model
- **All query files**: Adjust for new edge types

### Effort: **Medium-High** (2-3 weeks)

---

## 8. kloc-mapper Impact Assessment

### Changes needed:

**Node generation:**
- Add Value node creation from values array
- Add Call node creation from calls array
- Generate unique IDs for Call/Value nodes

**Edge generation:**
- Convert call records to edges (calls, receiver, argument, produces)
- Convert value assignments to edges (assigned_from)
- Keep existing structural edges

**Algorithm:**
- No longer build access_chain strings
- No longer embed call_id in edges
- Simpler edge structure, more edges

### Estimated changes:
- **models.py**: Add Call, Value node kinds; new edge types
- **mapper.py**: Rewrite call integration logic
- **calls.py**: Adapt to generate nodes/edges

### Effort: **Medium** (1-2 weeks)

---

## 9. Archive Format (.kloc) Assessment

### Proposal:
Bundle index.scip + calls.json in a ZIP archive, pass to mapper as single input.

### Benefits:
1. Single file to pass around (UX improvement)
2. Ensures index.scip and calls.json are paired correctly
3. Versioning: can include metadata.json with schema version
4. Extensible: add more files later (embeddings, etc.)

### Concerns:
1. Adds extraction step before processing
2. Minor overhead (ZIP read)
3. Debugging harder (can't just `cat` the input)

### Recommendation: **PROCEED**
This is a good UX improvement regardless of graph model choice. Low risk, clear benefit.

### Suggested format:
```
project.kloc (ZIP archive)
├── manifest.json   # version, timestamp, project name
├── index.scip      # SCIP protobuf
└── calls.json      # Calls data (optional)
```

---

## 10. Key Trade-off Summary

| Aspect | Current (Unified-Graph) | Pure Graph |
|--------|------------------------|------------|
| Node count | Lower | 3-5x higher |
| Edge count | Lower | 5-10x higher |
| File size | Smaller | Larger |
| access_chain | Pre-computed string | Traversal required |
| Common queries | Simpler | More steps |
| Data flow queries | Use arrays | First-class |
| Mental model | Hybrid (edges + arrays) | Uniform (nodes/edges) |
| Future extensibility | Good | Better |
| Implementation effort | Less (existing spec) | More (new spec) |
