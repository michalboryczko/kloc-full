# Brief: Pure Graph Model Assessment

**Date**: 2026-02-05
**Mode**: VALIDATE
**Topic**: Pure graph model where everything (Values, Calls) becomes nodes and edges

## What I'm Doing

Assessing the proposed pure graph model against the current unified-graph-format spec. The user proposes converting `calls` and `values` arrays into nodes/edges rather than keeping them as separate arrays with reference types on edges.

## Key Question

Is "nodes and edges all the way down" the right approach for AI agent consumption, or does the current hybrid approach (typed edges with embedded data) serve users better?
