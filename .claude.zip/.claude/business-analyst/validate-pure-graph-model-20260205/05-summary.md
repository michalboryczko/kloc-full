# Summary: Pure Graph Model Assessment

## Executive Summary

The pure graph model (Value and Call as first-class nodes) is a **valid architectural direction** but **not justified for MVP**. The current unified-graph-format spec with typed edges and pre-computed access_chain strings better serves immediate user needs with lower complexity.

**Recommendation**: Implement unified-graph-format as specified. Adopt .kloc archive format. Revisit pure graph model when data flow analysis becomes a primary use case.

---

## What Was Assessed

1. **Pure Graph Model**: Converting calls/values arrays into nodes/edges
2. **Node Count Impact**: Estimated 3-5x more nodes, 5-10x more edges
3. **Query Patterns**: Compared complexity for common queries
4. **kloc-cli Impact**: What changes would be needed
5. **kloc-mapper Impact**: What changes would be needed
6. **Archive Format**: .kloc bundle for index.scip + calls.json

---

## Key Findings

### Pure Graph Model

| Criterion | Assessment |
|-----------|------------|
| User Value (MVP) | Neutral - no new capabilities |
| Query Simplicity | Worse for common queries |
| Data Flow | Better for advanced tracing |
| Output Size | Larger (5-10x more edges) |
| Implementation Effort | High (rewrite both tools) |
| Future Extensibility | Better |

**Verdict**: DEFER - architecturally sound but not needed for MVP

### Archive Format (.kloc)

| Criterion | Assessment |
|-----------|------------|
| User Value | High - single file UX |
| Complexity | Low - ZIP handling |
| Risk | Low |
| Extensibility | High - add more files later |

**Verdict**: PROCEED - implement regardless of graph model

---

## Recommendations by Priority

### P0 - Critical (Do Now)
1. **Implement unified-graph-format spec** as written in `docs/specs/unified-graph-format.md`
2. **Include calls/values in raw_data section** for advanced use cases

### P1 - High (MVP)
3. **Implement .kloc archive format** as mapper input
4. **Support both archive and separate files** for backward compatibility

### P2 - Future
5. **Document pure graph as future option** in architecture notes
6. **Revisit when data flow analysis is prioritized**

---

## Risks Mitigated

| Risk | Mitigation |
|------|------------|
| Pure graph bloats output | Defer; keep compact edges |
| Complex queries for AI agents | Pre-computed access_chain |
| index.scip/calls.json mismatch | .kloc archive bundles them |
| Future needs pure graph | raw_data section preserves source data |
