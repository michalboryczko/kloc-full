# Decisions: Pure Graph Model Assessment

## Decision 1: Pure Graph Model - DEFER

**Verdict**: The pure graph model is architecturally sound but not justified for MVP. Implement the current unified-graph-format spec first.

### Rationale

1. **MVP Focus**: The current spec solves the immediate user problem (show HOW symbols are used). Pure graph is a larger architectural change that doesn't unlock new user capabilities for v1.

2. **Complexity vs Value**: Pure graph adds 5-10x more edges without proportional user benefit. The access_chain string in current spec is sufficient for all identified use cases.

3. **Query Patterns**: The most common queries ("what calls X", "show usages") are simpler with pre-computed access_chain strings. Pure graph only wins on advanced data flow tracing, which is not an MVP requirement.

4. **AI Agent Context Limits**: Larger graph = more tokens in responses. The current model's compact representation is better for AI consumption.

### When to Reconsider

- If data flow analysis becomes a primary use case
- If graph algorithms (centrality, clustering) are needed
- If the hybrid model proves awkward to extend

---

## Decision 2: Archive Format (.kloc) - PROCEED

**Verdict**: Implement the .kloc archive format regardless of graph model choice.

### Rationale

1. **Clear UX Improvement**: Single file is easier to pass around than two files
2. **Correctness**: Ensures index.scip and calls.json are always paired
3. **Low Risk**: ZIP handling is trivial, adds minimal overhead
4. **Extensible**: Can add embeddings, metadata later

### Specification

```
project.kloc (ZIP archive)
├── manifest.json    # Required
│   {
│     "version": "1.0",
│     "format": "kloc-archive",
│     "created_at": "2026-02-05T...",
│     "project_name": "my-project"
│   }
├── index.scip       # Required - SCIP protobuf
└── calls.json       # Optional - calls data
```

### CLI Changes

**kloc-mapper:**
```bash
# Accept .kloc archive
kloc-mapper map --archive project.kloc --out sot.json

# Or separate files (backward compat)
kloc-mapper map --scip index.scip --calls calls.json --out sot.json
```

**scip-php (future):**
```bash
# Generate .kloc archive directly
scip-php index src/ --output project.kloc
```

---

## Decision 3: Keep calls/values Arrays in Unified Format - YES

**Verdict**: Include raw calls and values arrays in the unified output for advanced use cases.

### Rationale

1. **Data Flow**: Users who need to trace data flow can use arrays directly
2. **Debugging**: Raw data helps troubleshoot edge classification
3. **Forward Compatibility**: If we later adopt pure graph, data is preserved
4. **Opt-in Complexity**: Most users ignore arrays, power users benefit

### Implementation

```json
{
  "version": "2.0",
  "nodes": [...],
  "edges": [...],
  "raw_data": {           // Optional section
    "calls": [...],       // From calls.json
    "values": [...]       // From calls.json
  }
}
```

Add CLI flag to exclude raw data for smaller output:
```bash
kloc-mapper map ... --no-raw-data
```

---

## Decision 4: Hybrid Approach for Future - NOTED

**Verdict**: If pure graph becomes needed, consider a hybrid approach.

### Hybrid Model Concept

Keep current edge structure with optional "expansion" via separate arrays:

```json
{
  "edges": [
    {
      "type": "method_call",
      "source": "node:OrderService::createOrder",
      "target": "node:OrderRepository::save",
      "access_chain": "$this->orderRepository",
      "call_node_id": "call:40:26"   // Link to expanded Call node
    }
  ],
  "call_nodes": [...]  // Detailed Call nodes for those who need them
}
```

This gives:
- Simple access for common queries (use edge.access_chain)
- Detailed traversal for advanced queries (use call_nodes)
- Backward compatibility

**Status**: Not for MVP, document as future option.
