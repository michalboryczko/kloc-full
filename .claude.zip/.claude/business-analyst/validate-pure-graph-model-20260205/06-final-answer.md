# Final Assessment: Pure Graph Model

## Verdict

| Item | Recommendation |
|------|----------------|
| Pure Graph Model | **DEFER** - Not for MVP |
| .kloc Archive Format | **PROCEED** - Implement now |
| Keep raw calls/values | **YES** - In optional section |

---

## 1. Pure Graph Model Assessment

### Strengths

1. **Uniform Model**: Everything is nodes and edges. Simpler mental model for consumers who think in graph terms.

2. **First-Class Data Flow**: Tracing "where does $order come from and where does it go" becomes standard graph traversal instead of array lookups.

3. **Graph Algorithms**: Enables future use of centrality, clustering, and pathfinding algorithms directly on the graph.

4. **No String Parsing**: Access chains are traversable paths, not strings to parse.

### Concerns

1. **5-10x More Edges**: For `$this->orderRepository->save($order)`:
   - Current: 1 edge with embedded metadata
   - Pure graph: 8 edges (contains, calls, receiver, produces, argument...)

2. **Query Complexity Increases**: The most common query "what calls X" becomes multi-step:
   ```
   Current:  edges.filter(target=X, type=method_call)
   Pure:     nodes.filter(kind=Call).filter(has_calls_edge_to(X)).map(build_chain)
   ```

3. **AI Agent Output Bloat**: Larger graphs mean more tokens in responses. The pre-computed `access_chain: "$this->orderRepository"` is immediately usable; the traversable graph requires reconstruction.

4. **Implementation Cost**: Would require rewriting both kloc-mapper and kloc-cli edge handling. Estimated 3-4 weeks.

### Verdict: DEFER

The pure graph model is architecturally cleaner but doesn't unlock new user capabilities for MVP. The current unified-graph-format spec with typed edges and pre-computed access_chain strings serves immediate needs better.

**Revisit when**:
- Data flow analysis (trace variable from source to sink) becomes primary use case
- Graph algorithms (find highly coupled components) are needed
- Users complain about the hybrid model being confusing

---

## 2. Node Count Impact

### Estimation for Single Statement

```php
$this->orderRepository->save($order);
```

| Model | Nodes | Edges |
|-------|-------|-------|
| Current | 0 new | 1 (with metadata) |
| Pure Graph | 5 new | 8 |

### Estimation for Typical Method (10 lines, 3 calls)

| Model | Total Nodes | Total Edges |
|-------|-------------|-------------|
| Current | ~1 | ~5 |
| Pure Graph | ~15 | ~40 |

### Estimation for 500-Method Codebase

| Model | Total Nodes | Total Edges | JSON Size |
|-------|-------------|-------------|-----------|
| Current | ~600 | ~3000 | ~500KB |
| Pure Graph | ~3000+ | ~15000+ | ~2MB+ |

**Impact**: Pure graph increases storage and transmission by 3-5x. Not prohibitive, but meaningful for large codebases.

---

## 3. Query Pattern Changes

### Query: "What calls OrderRepository::save()?"

**Current Model** (simpler):
```python
# Direct filter on edges
usages = [e for e in edges
          if e.target == "OrderRepository::save"
          and e.type == "method_call"]

# access_chain immediately available
for e in usages:
    print(f"{e.source} via {e.access_chain} at {e.location}")
```

**Pure Graph Model** (more steps):
```python
# Find Call nodes that have "calls" edge to target
call_nodes = [n for n in nodes
              if n.kind == "Call"
              and any(e.type == "calls" and e.target == "OrderRepository::save"
                      for e in edges_from(n))]

# Build chain by traversing receiver edges
for call in call_nodes:
    chain = build_access_chain(call)  # recursive traversal
    containing = get_containing_method(call)
    print(f"{containing} via {chain} at {call.location}")

def build_access_chain(call):
    parts = []
    receiver_edge = get_edge(call, type="receiver")
    if not receiver_edge:
        return None
    current = receiver_edge.target  # Value node
    while current:
        if current.kind == "parameter":
            parts.append(f"${current.name}")
            break
        elif current.kind == "result":
            source_call = get_source_call(current)
            parts.append(extract_member(source_call))
            current = get_receiver(source_call)
        else:
            break
    return "->".join(reversed(parts))
```

### Query: "Trace where $order flows"

**Current Model** (uses raw arrays):
```python
# Must use calls/values arrays directly
value = find_value_by_name("$order")
# Trace via source_call_id, receiver_value_id...
```

**Pure Graph Model** (first-class):
```python
# Standard graph traversal
value = find_value_node("$order")
forward = traverse(value, edge_types=["argument", "assigned_from"])
backward = traverse(value, edge_types=["produces"], reverse=True)
```

**Winner**: Pure graph is cleaner for data flow, but this is not an MVP query.

---

## 4. kloc-cli Impact

### Changes Required (if pure graph adopted)

| File | Change | Effort |
|------|--------|--------|
| `graph/loader.py` | Load Call/Value nodes | Low |
| `graph/index.py` | Index Call/Value nodes, new edge types | Medium |
| `queries/context.py` | Rewrite chain building | High |
| `queries/usages.py` | Adapt for Call nodes | Medium |
| `queries/deps.py` | Adapt for Call nodes | Medium |
| `output/tree.py` | Display Call/Value info | Medium |
| `models/node.py` | Add Call, Value kinds | Low |
| `models/edge.py` | Add new edge types | Low |

**Total Effort**: 2-3 weeks

### Recommendation
Defer this work. The current unified-graph-format spec is already ready for implementation and serves MVP needs.

---

## 5. kloc-mapper Impact

### Changes Required (if pure graph adopted)

| Component | Change | Effort |
|-----------|--------|--------|
| Node generation | Create Call/Value nodes from arrays | Medium |
| Edge generation | Generate calls, receiver, argument, produces edges | Medium |
| ID generation | Unique IDs for Call/Value nodes | Low |
| Remove | access_chain computation | Simplifies |

**Total Effort**: 1-2 weeks

### Recommendation
Defer. Implement unified-graph-format as currently specified.

---

## 6. Archive Format (.kloc) - PROCEED

### Recommendation: Implement Now

The archive format is **independent of graph model choice** and provides clear user value.

### Specification

```
project.kloc (ZIP archive)
├── manifest.json
│   {
│     "version": "1.0",
│     "format": "kloc-archive",
│     "created_at": "2026-02-05T12:00:00Z",
│     "project_name": "my-project",
│     "scip_version": "0.3",
│     "calls_version": "3.2"     // null if no calls.json
│   }
├── index.scip       # Required
└── calls.json       # Optional
```

### CLI Interface

```bash
# kloc-mapper with archive (new)
kloc-mapper map --archive project.kloc --out sot.json

# kloc-mapper with separate files (existing)
kloc-mapper map --scip index.scip --calls calls.json --out sot.json

# Auto-detect: if .kloc extension, treat as archive
kloc-mapper map project.kloc --out sot.json
```

### Benefits
1. Single file to pass between tools
2. Ensures index.scip and calls.json are correctly paired
3. Extensible: add embeddings.bin, metadata.json later
4. Version information in manifest

### Implementation Effort: Low (1-2 days)

---

## Priority Tiers

### P0: Do Now (MVP Blockers)

1. **Implement unified-graph-format** as specified in `docs/specs/unified-graph-format.md`
   - Typed edges (method_call, type_hint, etc.)
   - Pre-computed access_chain strings
   - target_member field

2. **Include raw_data section** with calls/values arrays
   - Enables advanced data flow queries
   - Preserves source data for future pure graph migration

### P1: High Priority (MVP Enhancers)

3. **Implement .kloc archive format**
   - ZIP containing manifest.json, index.scip, calls.json
   - Support in kloc-mapper CLI

4. **Add --no-raw-data flag** to kloc-mapper
   - Omits calls/values arrays for smaller output

### P2: Future (Post-MVP)

5. **Document pure graph as future architecture option**
   - Add to architecture decision records
   - Note conditions for revisiting

6. **Consider hybrid approach if needed**
   - Edges with embedded data PLUS optional expanded Call/Value nodes
   - Best of both worlds if use cases diverge

---

## Final Recommendation

**Proceed with unified-graph-format spec as written.** The pure graph model is a valid architectural direction but not justified for MVP scope. The current spec with typed edges and pre-computed strings optimally serves AI agents who need quick, actionable answers.

**Do implement .kloc archive format** - it's a clear UX win with low implementation cost.

**Keep raw calls/values** in an optional section for power users and future migration path.
