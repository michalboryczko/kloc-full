# Summary: Unified Graph Format Assessment

## Verdict: PROCEED with Modifications

The proposed unified format is well-conceived and addresses real user pain points. The core architecture (combining SCIP + calls.json in kloc-mapper) is correct.

## Key Modifications Recommended

### 1. Prioritize Edge Types (Tier 1 First)
Focus initial implementation on `type_hint`, `method_call`, and `instantiation`. These three cover the vast majority of refactoring and impact analysis questions AI agents ask.

### 2. Do NOT Add Value/Call Node Types
Keep the node model stable. Instead, include calls.json data as supplementary arrays in the unified format for advanced queries.

### 3. Simplify Edge Fields
Keep `access_chain` (high value). Drop `target_member` and `call_id` (redundant or derivable).

### 4. Maintain Graceful Degradation
The format should work with SCIP-only indexes (no calls.json), falling back to inference-based edge typing.

## What This Enables

AI coding agents will be able to answer questions like:
- "What files need to change if I rename this method?" (method_call edges)
- "What's affected if I change this constructor?" (instantiation edges)
- "What depends on this class for typing vs actual usage?" (type_hint vs method_call)

## Implementation Recommendation

Phase 1 (immediate):
1. Add type_hint, method_call, instantiation edge types
2. Add access_chain field to edges
3. Move calls.json processing to kloc-mapper
4. Include optional calls/values arrays in output

Phase 2 (next iteration):
1. Add static_call, property_access, function_call
2. Enhance kloc-cli queries to leverage new edge types
