# Decisions: Unified Graph Format

## Decision 1: Edge Types

**Decision**: Adopt semantic edge types with tiered implementation

| Tier | Edge Types | Priority |
|------|------------|----------|
| 1 (MVP) | type_hint, method_call, instantiation | Immediate |
| 2 | static_call, property_access, function_call | Next release |
| 3 | static_property, constant_access | As needed |

**Rationale**:
- Tier 1 covers 90%+ of refactoring use cases
- Tier 2 adds precision for specialized analysis
- Tier 3 is rare enough to defer

**Keep USES**: Yes, as fallback for unclassified edges. This ensures backward compatibility and handles edge cases.

## Decision 2: Node Types

**Decision**: Keep current node types; do NOT add Value or Call nodes

**Rationale**:
- Values are data-flow artifacts, not navigable code elements
- Call nodes duplicate edge information
- Adding these would 3-5x the node count for marginal benefit

**Alternative**: Include `values` and `calls` arrays in unified format as supplementary sections for advanced data-flow queries.

## Decision 3: Edge Structure

**Decision**: Minimal edge enhancement

```json
{
  "type": "method_call",
  "source": "node:...",
  "target": "node:...",
  "location": {"file": "...", "line": 40, "col": 26},
  "access_chain": "$this->repo"
}
```

**Include**: `access_chain` (valuable, non-trivial to compute)
**Exclude**: `target_member` (derivable), `call_id` (use location)

## Decision 4: Unified Format Structure

**Decision**: Adopt with modifications

```json
{
  "version": "2.0",
  "metadata": {...},
  "nodes": [...],
  "edges": [...],
  "calls": [...],     // Optional: raw call records
  "values": [...]     // Optional: raw value records
}
```

**Rationale**:
- Single file eliminates --calls awkwardness
- Optional arrays preserve access to rich data
- Version 2.0 clearly signals breaking change

## Decision 5: Backward Compatibility

**Decision**: Support both modes

1. **With calls.json**: Full edge type classification + access chains
2. **Without calls.json**: SCIP-only inference (less precise but functional)

**Rationale**: Not all users will have scip-php with calls tracking. The tool should work with standard SCIP indexes too.
