# Observations: Unified Graph Format Analysis

## Current State

### Existing Edge Types (6)
| Edge Type | Purpose | Source |
|-----------|---------|--------|
| contains | Structural hierarchy (File->Class->Method) | SCIP |
| extends | Class/interface inheritance | SCIP |
| implements | Interface implementation | SCIP |
| uses_trait | Trait usage | SCIP |
| overrides | Method override relationship | SCIP |
| uses | Generic "references" (everything else) | SCIP |

**Problem**: The `uses` edge is too coarse - it lumps together:
- Type hints (`User $user`)
- Method calls (`$user->save()`)
- Property access (`$user->name`)
- Instantiation (`new User()`)
- Constant access (`User::STATUS_ACTIVE`)
- Function calls (`strlen()`)

### Existing Node Types (11)
File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase

**Assessment**: Node types are comprehensive for PHP code structure.

---

## Proposed Edge Types Analysis

### Tier 1: Essential for AI Agents (Strongly Recommend)

| Edge Type | Why Essential |
|-----------|---------------|
| `type_hint` | Distinct from runtime usage; needed to understand dependencies vs actual execution flow |
| `method_call` | Core execution flow; most common operation in OOP code |
| `instantiation` | Shows where objects are created; critical for understanding object lifecycle |

**Rationale**: An AI agent asking "what happens when I change this method signature" needs to distinguish:
1. **Type hints**: Will cause PHP type errors at call sites
2. **Method calls**: Will cause runtime behavior changes
3. **Instantiation**: Will affect object creation sites

Without this distinction, the agent cannot give accurate refactoring advice.

### Tier 2: Valuable for Precision (Recommend)

| Edge Type | Why Valuable |
|-----------|--------------|
| `static_call` | Different call semantics than instance calls; important for testing/mocking analysis |
| `property_access` | Useful for encapsulation analysis; distinct from method calls |
| `function_call` | Helps distinguish global functions from methods (less common in modern PHP) |

**Rationale**: These provide precision when analyzing code patterns, but the absence wouldn't block core use cases.

### Tier 3: Nice to Have (Optional)

| Edge Type | Assessment |
|-----------|------------|
| `static_property` | Rare in well-designed PHP code; could merge with property_access |
| `constant_access` | Rarely changes; low priority for refactoring analysis |
| `array_access` | Very specific; better kept in calls.json for advanced queries |

---

## Proposed Node Types Analysis

### Value Nodes - NOT RECOMMENDED

**Proposal**: Add `Value` nodes for data flow (parameter, local, result values)

**Assessment**: Reject for the unified format. Reasoning:

1. **Explosion of nodes**: Every parameter, local variable, and call result would become a node. For a medium project (1000 methods with average 3 parameters each), this adds 3000+ nodes just for parameters.

2. **Different abstraction level**: Values are runtime/data-flow concepts, not structural code concepts. The current node types represent "things you can navigate to in an IDE" - classes, methods, files. Values are intermediate analysis artifacts.

3. **Better alternative**: Keep the calls.json `values` array in the unified format as a separate section. AI agents that need data flow can query it; those that don't won't be overwhelmed.

**Recommendation**: Include `values` and `calls` arrays in unified format as supplementary data, not as first-class nodes/edges.

### Call Nodes - NOT RECOMMENDED

**Proposal**: Add `Call` nodes for call sites

**Assessment**: Reject. Call sites are already represented as edges with location data. Adding Call nodes would:
1. Duplicate information already in edges
2. Add complexity for no user-facing benefit
3. Make the graph harder to query (do I look for edges or Call nodes?)

---

## Format Assessment

### Strengths of Proposed Unified Format

1. **Single file**: Eliminates `--calls` flag awkwardness
2. **Pre-computed chains**: `access_chain` field saves runtime computation
3. **Version bump (1.0 -> 2.0)**: Clean break for breaking changes
4. **Optional calls/values**: Backward-compatible progression

### Concerns

1. **Edge field explosion**: Adding `target_member`, `access_chain`, `call_id` to every edge increases file size significantly

2. **Redundancy**: `target_member` is extractable from the target node's name; storing it on edges duplicates data

3. **`call_id` field**: If we're including the calls array anyway, the edge location + type should be sufficient to correlate

### Recommendations for Format

**Simplified edge structure**:
```json
{
  "type": "method_call",
  "source": "node:abc123",
  "target": "node:def456",
  "location": {"file": "...", "line": 40, "col": 26},
  "access_chain": "$this->orderRepository"
}
```

**Keep**: `access_chain` (valuable, hard to compute at query time)
**Drop**: `target_member` (derivable from target node), `call_id` (use location for correlation)

---

## Priority Ranking for Refactoring/Impact Analysis

### Must Have for MVP
1. **type_hint** - Critical for "change signature" refactoring
2. **method_call** - Core execution flow
3. **instantiation** - Object creation sites

### Should Have (Phase 2)
4. **static_call** - Testing/mocking patterns
5. **property_access** - Encapsulation analysis
6. **function_call** - Global function tracking

### Nice to Have (Phase 3)
7. **static_property** - Rare, can defer
8. **constant_access** - Low change frequency

---

## Key Insight: What AI Agents Actually Need

After analyzing the spec, the most valuable enhancement is **semantic edge types**. Currently, an AI agent querying "what uses UserRepository" gets a flat list of `uses` edges. With typed edges, it can distinguish:

- "3 classes have UserRepository as a type hint (dependency injection)"
- "15 methods call UserRepository::find() (actual usage)"
- "2 locations instantiate UserRepository with `new` (rare, might indicate missing DI)"

This enables intelligent refactoring advice like:
- "Changing the constructor signature affects 2 direct instantiations and 12 DI configurations"
- "Renaming the `find` method affects 15 call sites but no type hints"
