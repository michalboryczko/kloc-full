# Plan: Unified Graph Format Validation

## Approach

1. **Edge Kinds Analysis**
   - Review current edge types (contains, extends, implements, uses_trait, overrides, uses)
   - Evaluate proposed additions against AI agent use cases
   - Identify gaps or unnecessary additions

2. **Node Kinds Analysis**
   - Review current node types
   - Evaluate Value/Call node proposals
   - Consider complexity vs benefit trade-off

3. **Format Assessment**
   - Evaluate unified format for AI agent consumption
   - Consider JSON structure, field naming, queryability
   - Assess backward compatibility approach

4. **Prioritization**
   - Rank edge types by value for refactoring/impact analysis
   - Consider implementation complexity
   - Recommend phased approach

## Key Questions to Answer

- Does the edge type granularity help or hurt AI agent understanding?
- Is the distinction between method_call and static_call actually useful?
- Should type_hint be a separate edge type or is it fundamentally different?
- Are Value/Call nodes necessary or would enhanced edges suffice?
- What does an AI agent actually need to answer refactoring questions?
