# Brief: Unified Graph Format Validation

## Task
Validate the proposed unified graph format that combines SCIP index + calls.json data, with focus on:
1. Missing edge kinds for AI coding agents
2. Missing node kinds (Value, Call)
3. Format optimality for AI agent consumption
4. Priority ranking for refactoring/impact analysis use cases

## Context
- Primary consumers: AI coding agents (like Claude Code)
- Use cases: code structure understanding, usage finding, impact analysis, refactoring support
- Current state: SCIP provides symbols/relationships, calls.json provides call records with receiver chains

## Deliverable
Assessment with specific recommendations on edge types, node types, and format design.
