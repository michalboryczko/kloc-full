# Assessment: Unified Graph Format for KLOC

**Status**: Approved with Modifications
**Spec Location**: `/Users/michal/dev/ai/kloc/docs/specs/unified-graph-format.md`

---

## Executive Summary

The proposed unified format is **well-designed** and solves a real architecture problem. The core decision to move calls.json processing from kloc-cli to kloc-mapper is correct. However, some proposed additions need refinement.

---

## 1. Edge Types Assessment

### Current State
The existing `uses` edge is too coarse. An AI agent cannot distinguish between a type hint dependency and an actual method call, which is critical for accurate refactoring advice.

### Proposed Additions: Tiered Recommendation

| Priority | Edge Type | Verdict | Rationale |
|----------|-----------|---------|-----------|
| **Tier 1** | `type_hint` | MUST HAVE | Distinguishes compile-time deps from runtime usage |
| **Tier 1** | `method_call` | MUST HAVE | Core execution flow; most common refactoring target |
| **Tier 1** | `instantiation` | MUST HAVE | Shows object creation sites; critical for DI analysis |
| **Tier 2** | `static_call` | SHOULD HAVE | Important for testing/mocking patterns |
| **Tier 2** | `property_access` | SHOULD HAVE | Encapsulation analysis |
| **Tier 2** | `function_call` | SHOULD HAVE | Global function tracking |
| **Tier 3** | `static_property` | NICE TO HAVE | Rare; could merge with property_access |
| **Tier 3** | `constant_access` | NICE TO HAVE | Constants rarely change |

### Missing Edge Type to Consider

**`return_type`**: When a method returns a type (e.g., `function find(): User`), this is distinct from a type hint on a parameter. Consider adding this in Tier 2 to track "what methods produce this type" for impact analysis.

---

## 2. Node Types Assessment

### Current Nodes (Keep As-Is)
File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase

These are comprehensive for PHP code structure.

### Proposed Value/Call Nodes: NOT RECOMMENDED

| Proposed | Verdict | Rationale |
|----------|---------|-----------|
| `Value` node | REJECT | Would 3-5x node count; values are data-flow artifacts, not navigable code elements |
| `Call` node | REJECT | Duplicates edge information; adds query complexity |

**Alternative**: Include `values` and `calls` arrays as supplementary sections in the unified JSON. AI agents needing data-flow analysis can use them; others aren't overwhelmed.

---

## 3. Format Assessment

### Strengths of Proposed Format
1. Single file eliminates awkward `--calls` flag
2. Pre-computed `access_chain` field saves query-time computation
3. Clean version bump (1.0 -> 2.0) signals breaking change

### Modifications Recommended

#### Edge Structure (Simplified)
```json
{
  "type": "method_call",
  "source": "node:abc123",
  "target": "node:def456",
  "location": {"file": "src/Service.php", "line": 40, "col": 26},
  "access_chain": "$this->orderRepository"
}
```

| Field | Verdict | Rationale |
|-------|---------|-----------|
| `type` | KEEP | Core semantic information |
| `source/target` | KEEP | Node references |
| `location` | KEEP | Essential for navigation |
| `access_chain` | KEEP | High value; non-trivial to compute |
| `target_member` | DROP | Derivable from target node's name |
| `call_id` | DROP | Use location to correlate with calls array |

#### Overall Structure
```json
{
  "version": "2.0",
  "metadata": {
    "generated_at": "2026-02-05T...",
    "source_scip": "index.scip",
    "source_calls": "calls.json",
    "project_root": "/path/to/project"
  },
  "nodes": [...],
  "edges": [...],
  "calls": [...],    // Optional: preserved for advanced data-flow queries
  "values": [...]    // Optional: preserved for advanced data-flow queries
}
```

---

## 4. Priority Ranking for Refactoring/Impact Analysis

When an AI agent asks "what's the impact of changing X?", here's what matters most:

### Critical (Implement First)
1. **type_hint** - "These 5 classes have User as a parameter type"
2. **method_call** - "These 12 locations call User::save()"
3. **instantiation** - "These 2 places create User with `new`"

### Important (Implement Second)
4. **static_call** - Static methods have different semantics
5. **property_access** - Direct property access vs getter usage

### Lower Priority
6. **function_call**, **static_property**, **constant_access**

---

## 5. Use Case Validation

### Scenario: Rename Method
**User query**: "What happens if I rename `OrderRepository::save()` to `persist()`?"

**With current format**: "23 usages found" (flat list)

**With proposed format**:
```
Impact of renaming OrderRepository::save():

Method calls (19 locations):
  - OrderService::createOrder()     src/Service/OrderService.php:45
  - OrderService::updateOrder()     src/Service/OrderService.php:78
  ...

Type hints (0 locations):
  (methods don't appear in type hints)

No instantiation impact (not a constructor)
```

This is dramatically more useful for refactoring decisions.

### Scenario: Change Constructor Signature
**User query**: "What if I add a required parameter to User constructor?"

**With proposed format**:
```
Impact of changing User::__construct():

Instantiation sites (3 locations):
  - UserFactory::create()           src/Factory/UserFactory.php:22
  - UserFixtures::load()            tests/Fixtures/UserFixtures.php:15
  - UserServiceTest::setUp()        tests/Service/UserServiceTest.php:30

Type hints (12 locations):
  (not affected - type hints don't call constructors)
```

---

## 6. Recommendations

### Immediate (Tier 1 Implementation)
1. Add `type_hint`, `method_call`, `instantiation` edge types to kloc-mapper
2. Add `access_chain` field to edges (from calls.json data)
3. Move calls.json loading from kloc-cli to kloc-mapper
4. Include optional `calls`/`values` arrays in unified output
5. Remove `--calls` option from kloc-cli

### Phase 2
1. Add `static_call`, `property_access`, `function_call` edge types
2. Consider `return_type` edge for methods that return typed values
3. Enhance kloc-cli queries to filter by edge type

### Do NOT Do
1. Do NOT add Value or Call node types
2. Do NOT include `target_member` field (redundant)
3. Do NOT include `call_id` field (use location for correlation)

---

## Conclusion

The unified format proposal is sound. The key insight - moving semantic analysis from query-time (kloc-cli) to index-time (kloc-mapper) - is architecturally correct. With the modifications above, this will significantly improve AI agent effectiveness for code understanding and refactoring tasks.

**Verdict**: PROCEED with Tier 1 implementation prioritizing `type_hint`, `method_call`, and `instantiation` edge types.
