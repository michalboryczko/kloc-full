# E2E Test Framework -- Feasibility Assessment

**Analyst**: 1B (Feasibility)
**Scope**: Lines 23-96 of tester-agents-requirements.md

---

## Strengths

1. **Pipeline is already proven end-to-end in the existing contract tests.** The `bin/run.sh` in `contract-tests/` already orchestrates scip-php (host) + Docker container (PHPUnit). The E2E spec is extending a pattern that works, not inventing from scratch.

2. **Test scenarios are grounded in real, known code patterns.** The table (lines 44-54) references specific classes from kloc-reference-project-php (OrderController, OrderService, OrderRepository, EmailSenderInterface, etc.). These are real, stable domain objects -- not synthetic fixtures. This makes the tests meaningful.

3. **Assertion types are well-graduated.** The spec distinguishes exact match, count validation, depth validation, no-false-positives, and reference-type accuracy (line 64-69). This avoids the common trap of tests that only check "something exists" without checking correctness.

4. **The directory structure mirrors the existing contract-tests pattern.** Developers already know `bin/run.sh test`, Docker-based execution, and output directories. This is a good UX decision for test authors.

5. **Test categories align with kloc-cli command structure.** Categories (usages, deps, inheritance, overrides, context, call-graph) map 1:1 to kloc-cli commands, making it easy to trace failures to specific functionality.

---

## Gaps

### G1: Docker orchestration of 3 tools is underspecified

The spec says "Docker-based (orchestrates all components)" but the pipeline requires:
- **scip-php**: Runs via its own Docker image (`scip-php`) on the host, producing `index.kloc`
- **kloc-mapper**: A Python tool that takes `.kloc` and produces `sot.json` -- runs how? Own Docker image? Host Python?
- **kloc-cli**: A Python tool that queries `sot.json` -- runs how? Inside the E2E test container? As a subprocess?

The existing contract-tests solve this by running scip-php on the host (shell script) and then running PHPUnit in a single Docker container that only reads output files. The E2E spec doesn't clarify whether the pipeline_runner.py will:
- Shell out to Docker for scip-php, then shell out to kloc-mapper, then invoke kloc-cli
- Or run everything inside a single container (which would require all three tools installed)
- Or use docker-compose with multiple services

This is the biggest feasibility gap. A multi-container orchestration would be significantly more complex than the existing single-container approach.

### G2: `pipeline_runner.py` is a black box

The spec mentions `pipeline_runner.py` (line 84) that "runs scip-php -> kloc-mapper -> kloc-cli" but provides no detail on:
- How it discovers tool locations/binaries
- How it handles errors at each pipeline stage
- Whether it caches intermediate artifacts (index.kloc, sot.json)
- Whether it re-runs the full pipeline per test or once per test session

### G3: `output_validator.py` overlaps with test assertions

The spec lists an `output_validator.py` (line 85) but also describes assertion types (lines 64-69). It's unclear whether assertions live in the validator class or in pytest assertions. The spec should clarify the responsibility boundary.

### G4: `expected/` directory approach is vague

Line 92 mentions an `expected/` directory for "expected results for known queries" but doesn't specify:
- What format? JSON snapshots? Python data structures?
- How are expected results generated initially?
- How are they updated when the reference project evolves?

### G5: Technology choice mismatch -- pytest for orchestration

The spec proposes Python/pytest (line 32) but the existing contract-tests use PHP/PHPUnit. This means the E2E tests are in a different language from the existing test infrastructure. While pytest is a natural choice for testing kloc-cli (which is Python), using it for Docker orchestration of scip-php (PHP tool) and multi-step pipeline coordination is unusual. The test infrastructure would need to handle:
- Docker image existence checks
- Process management for shell commands
- Artifact file management across pipeline stages
- Timeout handling for long-running Docker operations

pytest can do all of this, but it requires careful fixture design (session-scoped fixtures for pipeline execution, etc.).

---

## Risks

### R1: Pipeline execution time -- CI/CD impact (HIGH)

Estimated execution time per full test run:
- scip-php indexing: 10-30 seconds (Docker startup + PHP analysis)
- kloc-mapper transformation: 2-5 seconds
- kloc-cli queries: <1 second each, but ~8 scenarios = ~5 seconds with startup overhead
- Docker build/pull: 30-60 seconds (first run), 5 seconds (cached)

**Total: 1-2 minutes minimum per E2E run.** This is acceptable for CI but not for rapid iteration during development. The spec should recommend running E2E tests only as a CI gate, not on every commit.

### R2: Expected results maintenance burden (HIGH)

The test scenarios (lines 44-54) hardcode specific class names and relationships. When the reference project changes:
- Adding a new service that uses `Order` would break the `usages "App\Entity\Order"` count validation
- Renaming `OrderService` would break multiple scenarios
- Adding a new `EmailSenderInterface` implementation would break the inheritance test

**Mitigation needed**: The spec should distinguish between "must include" assertions (OrderService MUST appear in Order usages) and "exact match" assertions (Order usages MUST be exactly [OrderRepository, OrderService, OrderController]). The former is much more maintainable.

### R3: Output format brittleness (MEDIUM)

The spec mentions testing kloc-cli output, but kloc-cli has two output modes: rich console (default) and JSON (`--json`). If tests parse rich console output, they'll break whenever tree formatting changes. If they use `--json`, the JSON schema must be stable.

**Recommendation**: Tests MUST use `--json` flag exclusively. Console output should never be tested for content (only for "exits 0" smoke tests).

### R4: Pipeline ordering dependencies (MEDIUM)

Each test scenario requires the full pipeline to have run successfully first. If scip-php changes its output format (even slightly), ALL E2E tests fail simultaneously. This creates a "cascade failure" pattern where a single upstream bug produces dozens of test failures, making root cause analysis harder.

### R5: Docker dependency in CI (LOW-MEDIUM)

The framework requires Docker in CI. Most CI systems support this, but Docker-in-Docker or privileged mode may be needed depending on the CI provider. This is a solvable but non-trivial infrastructure concern.

### R6: Cross-platform differences (LOW)

scip-php runs in Docker (Linux), but kloc-mapper and kloc-cli are Python tools that could run on the host (macOS for developers, Linux for CI). File paths, line endings, or ordering differences between platforms could cause flaky tests.

---

## Suggestions

### S1: Adopt the existing contract-tests orchestration pattern

Instead of inventing new Docker orchestration in Python, extend the existing `bin/run.sh` pattern:
1. `bin/run.sh` generates index via scip-php (host-side, exactly like contract-tests)
2. `bin/run.sh` runs kloc-mapper on the generated index.kloc (host-side or simple Docker call)
3. `bin/run.sh` runs pytest in a Docker container that has kloc-cli installed and access to sot.json

This keeps orchestration in bash (proven) and testing in pytest (appropriate for kloc-cli testing).

### S2: Use session-scoped pytest fixtures for pipeline execution

```python
@pytest.fixture(scope="session")
def sot_json(tmp_path_factory):
    """Run the full pipeline once, return path to sot.json."""
    # Pipeline already run by bin/run.sh before pytest starts
    path = Path("output/sot.json")
    assert path.exists(), "sot.json not found -- did bin/run.sh run the pipeline?"
    return path

@pytest.fixture(scope="session")
def kloc_cli(sot_json):
    """Return a callable that invokes kloc-cli with the session's sot.json."""
    def run(command, *args, json_output=True):
        cmd = ["kloc-cli", command, *args, "--sot", str(sot_json)]
        if json_output:
            cmd.append("--json")
        result = subprocess.run(cmd, capture_output=True, text=True)
        if json_output:
            return json.loads(result.stdout)
        return result
    return run
```

### S3: Use "must-include" assertions instead of exact-match by default

Instead of:
```python
assert result["usages"] == ["OrderRepository", "OrderService", "OrderController"]
```

Use:
```python
fqns = [u["fqn"] for u in result["usages"]]
assert "App\\Repository\\OrderRepository" in fqns
assert "App\\Service\\OrderService" in fqns
assert "App\\Ui\\Rest\\Controller\\OrderController" in fqns
```

Reserve exact-match for scenarios that truly need it (like `owners` which has a fixed containment chain).

### S4: Separate pipeline smoke from query correctness tests

- `test_pipeline.py`: Only verifies that the pipeline runs without errors and produces valid output files. Zero dependency on specific class names.
- `test_usages.py`, `test_deps.py`, etc.: Verify query correctness. These are the ones that reference specific classes.

This way, pipeline changes only break `test_pipeline.py`, and reference project changes only break query tests.

### S5: Document the expected CI time budget

State explicitly: "E2E tests are expected to take 1-2 minutes. They should run as a separate CI job, not block rapid feedback loops."

---

## Verdict: Feasibility Rating 3.5/5

**Summary**: The E2E test framework is feasible but requires significant specification refinement before implementation.

**What works**: The test scenarios are well-chosen, grounded in real code, and cover the right kloc-cli commands. The assertion types are appropriate. The overall structure mirrors proven patterns from contract-tests.

**What needs work**: The Docker orchestration approach is underspecified and is the biggest implementation risk. The `expected/` directory approach needs a clear maintenance strategy. The relationship between `pipeline_runner.py`, `output_validator.py`, and pytest assertions needs clarification. Expected results should default to "must-include" rather than exact-match to reduce maintenance burden.

**Recommendation**: REFINE before implementation. Specifically:
1. Clarify the orchestration model (recommend: bash for pipeline, pytest for assertions)
2. Define the caching strategy (run pipeline once per session, not per test)
3. Specify the expected results format and update process
4. Add a CI time budget and recommend E2E as a separate CI stage
