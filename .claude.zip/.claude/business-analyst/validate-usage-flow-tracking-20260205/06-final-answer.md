
## Strengths

### 1. Correct Problem Identification
The gap between "OrderService uses PaymentGateway" and "OrderService::process() calls PaymentGateway::charge() via $this->gateway" is exactly the information AI agents need for accurate refactoring and impact analysis.

### 2. Sound Data Model
```python
@dataclass
class UsageFlow:
    scope: NodeData        # The containing scope
    reference: Reference   # How the target is accessed
    depth: int             # Expansion depth
    children: list["UsageFlow"]
```
This structure is clean and extensible.

### 3. Comprehensive Test Cases
TC1-TC6 cover:
- Type hints
- Method calls via properties
- Chained calls
- Multiple refs in same scope
- Argument passing
- Depth expansion

### 4. Phased Implementation
The 3-phase approach (Enhanced Display -> Access Chain -> Full Resolution) manages complexity well.

---

## Concerns

### 1. calls.json Not Referenced

The spec mentions needing "AST-level analysis or enhanced SCIP data" for access chains, but the existing `calls.json` schema already provides this:

```json
{
  "id": "src/Service.php:10:20",
  "kind": "method",
  "callee": "...#charge().",
  "receiver_value_id": "src/Service.php:10:8"  // <- This is the access chain!
}
```

**Recommendation**: Update the spec to explicitly leverage calls.json for Phase 2.

### 2. Output Verbosity

The proposed default format:
```
├── [1] OrderService::process()
│       └── via: charge() (method_call)
│           └── on: $this->gateway
│               └── at: src/Service/OrderService.php:15
```

This is 4 lines per reference. With multiple references, output becomes overwhelming.

**Recommendation**: Use compact format by default:
```
├── [1] OrderService::process() → charge() [method_call]
│       on: $this->gateway (src/Service/OrderService.php:15)
```

Add `--verbose` flag for full detail.

### 3. Argument Tracking Adds Complexity

The `argument_pass` reference type (TC5) requires tracking data flow through call boundaries. This is valuable but significantly more complex.

**Recommendation**: Defer to Phase 2+. Focus Phase 1 on what's directly observable at the reference site.

### 4. Incomplete Chain Handling

The spec asks "When intermediate types can't be resolved, how to display?" but doesn't answer.

**Recommendation**: Show what's known, mark unknown with `?`:
```
on: $this->service->? (type unknown)
```

---

## Suggestions for Improvement

### 1. Tighter Phase 1 Scope

Split Phase 1:

**Phase 1a** - Reference Types Only (Small effort, immediate value)
- Add `reference_type` field to existing MemberRef
- Types: type_hint, method_call, property_access, static_call, instantiation, extends, implements
- Uses existing sot.json data

**Phase 1b** - Access Chains (Medium effort, high value)
- Load calls.json alongside sot.json
- Build chains from receiver_value_id
- Display on: expression

### 2. Update Output Examples

Current spec shows deep nesting. Consider flat alternatives for machine consumption:

```json
{
  "scope": "OrderService::process()",
  "reference_type": "method_call",
  "target_member": "charge()",
  "access_chain": "$this->gateway",
  "location": {"file": "...", "line": 15}
}
```

### 3. Add Success Metrics

How do we know this feature is working?
- AI agent task completion rate improves
- Fewer follow-up queries after context command
- User feedback (if applicable)

### 4. Consider MCP Tool Enhancement

The MCP server exposes `kloc_context`. Should the enhanced flow data be:
- Always included (might be too verbose)
- Optional via parameter (`include_flow=true`)
- Separate tool (`kloc_usage_flow`)

---

## Revised Phase Plan

| Phase | Scope | Data Source | Effort | Value |
|-------|-------|-------------|--------|-------|
| 1a | Reference types | sot.json | S | HIGH |
| 1b | Access chains | calls.json | M | HIGH |
| 2 | Type resolution | enhanced indexer | L | MEDIUM |
| 3 | Argument tracking | calls.json | L | MEDIUM |

---

## Final Verdict

**PROCEED** - This feature addresses a real gap in the product. The core concept is sound and the data model is clean.

**Required refinements before implementation**:
1. Update spec to reference calls.json as the data source for access chains
2. Define compact default output format
3. Split Phase 1 into 1a (types) and 1b (chains)
4. Defer argument tracking to Phase 2+
5. Define behavior for incomplete chains

**The feature directly serves our primary customer (AI coding agents) and builds toward the intelligent code analysis service vision.**

---

## Files Referenced

- Spec: `/Users/michal/dev/ai/kloc/docs/specs/usage-flow-tracking.md`
- Related: `/Users/michal/dev/ai/kloc/docs/reference/kloc-cli/context-usage-flow.md`
- Current impl: `/Users/michal/dev/ai/kloc/kloc-cli/src/queries/context.py`
- Calls schema: `/Users/michal/dev/ai/kloc/docs/reference/kloc-scip/calls-schema-docs.md`
