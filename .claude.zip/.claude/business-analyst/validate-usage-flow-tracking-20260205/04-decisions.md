# Decisions: Usage Flow Tracking

## Key Decisions and Rationale

### 1. Feature is VALUABLE - Proceed with refinement

**Rationale**: The core insight is correct - knowing HOW a symbol is used matters as much as knowing WHERE. This directly serves our primary customer (AI coding agents).

### 2. Recommend phased approach (already in spec)

The spec already proposes phases, but I recommend even tighter scope for Phase 1:

**Phase 1a** (MVP): Add reference_type to existing MemberRef
- Just add a `type` field: "method_call", "type_hint", "instantiation", etc.
- No access chain yet
- Uses existing SCIP data only

**Phase 1b**: Integrate calls.json for access chains
- Load calls.json alongside sot.json
- Build chains from receiver_value_id
- This is where the real magic happens

**Phase 2**: Full resolution with type information

### 3. Output format needs simplification

**Current proposal** is too verbose for default output:
```
├── [1] OrderService::process()
│       └── via: charge() (method_call)
│           └── on: $this->gateway
│               └── at: src/Service/OrderService.php:15
```

**Suggested default** (compact):
```
├── [1] OrderService::process() → charge() [method_call]
│       on: $this->gateway (src/Service/OrderService.php:15)
```

**Verbose mode** (`--verbose` or `--full-flow`) for the detailed format.

### 4. calls.json is the right data source for chains

The spec mentions "Option C: Use heuristics from surrounding occurrences" - this is wrong. The calls.json format already provides the proper data via receiver_value_id chains. The spec should be updated to acknowledge this.

### 5. Deferred: Argument tracking

The spec includes "argument_pass" tracking. While valuable, it adds significant complexity. Recommend deferring to Phase 2+.
