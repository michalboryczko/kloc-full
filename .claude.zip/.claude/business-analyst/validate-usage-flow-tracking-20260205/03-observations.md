# Observations: Usage Flow Tracking

## Current State Analysis

### What exists today in context.py

1. **Member tracking partially exists**: The `MemberRef` structure already captures which member is accessed when a class is used via its members (methods, properties, constants).

2. **Current output shows**: `source → ::member` format with file:line

3. **Current grouping**: Groups by source ID, shows all edges per source, including member edges sorted by line number.

4. **Missing pieces**:
   - Access chain (the `$this->service->repository` path)
   - Reference type (method_call, type_hint, etc.)
   - The "on what" context (what expression holds the target)

### Gap Analysis (Current vs Proposed)

| Aspect | Current | Proposed |
|--------|---------|----------|
| Which member | Yes (MemberRef) | Yes |
| Reference type | No | Yes (type_hint, method_call, etc.) |
| Access chain | No | Yes ($this->service->repository) |
| All refs preserved | Yes | Yes |
| Depth expansion | Yes | Yes |

### Data Availability

**From SCIP (sot.json)**:
- Symbol references with file/line
- Edge types (uses, extends, implements)
- Containment (what's in what)
- No expression structure

**From calls.json** (new format):
- Call records with receiver_value_id
- Value records tracking data flow
- Full expression chain trackable
- Return type information

**Key insight**: The calls.json schema already provides the data needed for access chains. The spec mentions needing "AST-level analysis or enhanced SCIP data" but the calls.json format solves this.

## User Value Assessment

### AI Coding Agent (Primary Customer)

**Pain point addressed**: When an agent sees "OrderService uses PaymentGateway", it doesn't know HOW. Is it:
- A type hint on a property (safe to refactor the property)
- A method call (need to understand call semantics)
- An instantiation (need constructor args)

**Value**: HIGH. This context is essential for accurate refactoring, understanding dependencies, and impact analysis.

**Frequency**: Every context query benefits from this additional information.

### Human Developer

**Pain point addressed**: "Where is this class used?" often needs follow-up: "Okay, but how?"

**Value**: MEDIUM-HIGH. Humans can often infer from the code, but having it in the output saves navigation time.

### Tech Lead / Architect

**Pain point addressed**: Understanding coupling depth. "Not only does A depend on B, but A deeply accesses B's internals via long chains."

**Value**: MEDIUM. Useful for architectural review but not daily use.

## Technical Feasibility

### Phase 1: Reference Types (HIGH Feasibility)
- Reference types can be inferred from edge metadata and node kinds
- Some already available, others need minimal enhancement to mapper

### Phase 2: Access Chains (MEDIUM Feasibility)
- calls.json provides the receiver_value_id chain
- Need to integrate calls.json loading into kloc-cli
- The spec mentions this as Phase 2/3, which is appropriate

### Phase 3: Full Resolution (LOWER Feasibility)
- Requires type resolution for intermediate steps
- May need enhanced indexer support
- Good stretch goal but not MVP

## Future Alignment

**Immediate value**: Yes - better context for AI agents today
**Builds toward Phase 2 (embeddings)**: Indirectly - richer semantic context
**Builds toward Phase 3 (service)**: Yes - deeper understanding enables smarter queries

## Concerns Identified

1. **Scope creep**: The full spec is ambitious. Phase 1 alone is valuable.

2. **Output verbosity**: The proposed tree format is complex. May overwhelm users.

3. **Performance**: Building access chains requires more lookups. Need caching strategy.

4. **Incomplete chains**: What happens when types can't be resolved? Spec acknowledges but doesn't define fallback.

5. **calls.json dependency**: The best solution requires the new calls.json format. This creates a dependency on scip-php enhancements.
