# Cross-Cutting Consistency Review: tester-agents-requirements.md

## Scope

Reviewed: All three component test frameworks (kloc-cli, kloc-mapper, e2e) plus the existing scip-php `contract-tests/` as the established reference pattern.

---

## STRENGTHS: Where Consistency is Well-Maintained

### S1. CLI Interface Pattern is Uniform
All three new frameworks specify `bin/run.sh test` and `bin/run.sh docs` as the entry point, matching the existing scip-php contract-tests `bin/run.sh` interface exactly. The existing `run.sh` (lines 14-38 in contract-tests/bin/run.sh) establishes `test`, `docs`, and `help` as commands. The spec for all three new frameworks mirrors this.

### S2. Docker-Based Execution is Consistent
All frameworks specify Docker-based execution. The existing contract-tests use `docker-compose.yml` with a named volume pattern. The spec asks each new framework to follow the same Docker-based approach.

### S3. Directory Structure Pattern is Aligned
All three frameworks follow the established pattern:
```
contract-tests-{component}/
  bin/run.sh
  src/
  tests/
  output/
  {config file}
  Dockerfile
```
This mirrors `contract-tests/` which has the same layout with `bin/`, `src/`, `tests/`, `output/`.

### S4. PHP FQN Notation is Explicitly Required
Both kloc-cli (line 149) and kloc-mapper (line 220) sections explicitly state: "Use PHP FQN notation in tests (e.g., `App\Entity\User::getId()`)". This is consistent with how the existing contract-tests reference PHP code (e.g., `App\Repository\OrderRepository`).

### S5. Test Category Organization
Each framework defines named test categories that map to separate test files/directories, consistent with how the existing `phpunit.xml` organizes suites (smoke, integrity, reference, chain, argument, etc.).

### S6. Fixture Independence is Clearly Specified
Both kloc-cli and kloc-mapper sections explicitly state fixtures should be independent of upstream components. kloc-cli says "independent, no kloc-mapper dependency" (line 133) and kloc-mapper says "independent, no scip-php dependency" (line 206). This is a strong design decision that enables isolated testing.

---

## GAPS: Inconsistencies and Misalignments

### G1. Language/Tech Stack Mismatch with Reference
**Severity: Medium**

The existing contract-tests framework is PHP/PHPUnit (PHP 8.4). All three proposed frameworks are Python/pytest. This is not inherently wrong (kloc-cli and kloc-mapper ARE Python projects), but it creates a divergence in patterns:

| Aspect | Existing (scip-php) | Proposed (new 3) |
|--------|---------------------|-------------------|
| Language | PHP | Python |
| Test framework | PHPUnit | pytest |
| Base class | `CallsContractTestCase` | None specified |
| Metadata | `#[ContractTest]` attribute | `@contract_test` decorator |
| Config | `config.php` | `pyproject.toml` |
| Autoloading | Composer autoload | Python imports |

The spec says "you can use `contract-tests/` as some reference" but does not reconcile the language gap. An agent implementing this might struggle with "how closely should I follow the PHP patterns in Python?"

### G2. No Equivalent of `#[ContractTest]` Attribute Fully Specified for Python
**Severity: High**

The existing contract-tests framework has a rich `#[ContractTest]` attribute system (name, description, category, status, experimental) that powers documentation generation. The requirements mention `@contract_test` decorator in the directory structures for kloc-cli and kloc-mapper (`src/decorators.py`) but provide **zero specification** for:
- What parameters the decorator accepts
- Whether it should match the PHP attribute's fields (name, description, category, status, experimental)
- How documentation generation works with it
- Whether `bin/run.sh docs` should produce the same documentation format

This is a major consistency gap. The decorator is mentioned in file listings but never defined.

### G3. No Documentation Generation Spec for Python Frameworks
**Severity: High**

The existing `bin/run.sh docs` command generates markdown/JSON/CSV documentation via `bin/generate-docs.php`. The new frameworks all list `bin/run.sh docs` in their CLI interface but the spec provides no guidance on:
- What the documentation output should contain
- How it maps to the PHP documentation output format
- How `@contract_test` decorator metadata feeds into docs

### G4. Query Helper API Naming Inconsistency
**Severity: Low-Medium**

The query helper classes have different naming patterns:

| Framework | Query Class | Methods |
|-----------|------------|---------|
| Existing (scip-php) | `ValueQuery`, `CallQuery`, `MethodScope` | `.kind()`, `.symbolContains()`, `.all()` |
| kloc-cli | `OutputValidator` | `json_output()`, `expect_node()`, `expect_edge()`, `expect_tree_depth()`, `expect_count()` |
| kloc-mapper | `SoTData` | `node()`, `edge()`, `nodes_by_kind()`, `edges_by_type()` |

The existing framework uses a fluent query builder pattern (`values().kind('parameter').symbolContains(...).all()`). The kloc-mapper `SoTData` looks like a simple data accessor. The kloc-cli `OutputValidator` looks like an assertion helper. These are three different API paradigms.

### G5. Fixture Strategy is Underspecified
**Severity: Medium**

The spec says kloc-cli needs "Tool/code to generate `sot.json` programmatically" and kloc-mapper needs "Tool/code to generate `.kloc` archives programmatically." Both list a `fixture_generator.py` file. But:
- No schema or contract is specified for the fixture generator
- No guidance on fixture size or complexity
- The phrase "global fixtures for integration tests / per-test fixtures for unit tests" is used identically for both, which feels copy-pasted rather than tailored
- No mention of whether fixtures should be checked into git or generated at test time

The existing contract-tests generate their fixtures live via `bin/run.sh` calling scip-php. The new frameworks propose synthetic generation, which is a fundamentally different approach that needs more specification.

### G6. E2E Framework Has No Fixture Generator -- By Design, But Unclear Boundary
**Severity: Low**

The e2e spec says "Runs real scip-php on real PHP code (no fixtures)" but then lists an `expected/` directory for "Expected results for known queries." This is essentially a fixture -- expected output snapshots. The line between "no fixtures" and "expected results" should be clarified.

### G7. Missing `--experimental` Flag Pattern in Python Frameworks
**Severity: Medium**

The existing contract-tests have a well-developed `--experimental` flag pattern:
- `bin/run.sh test --experimental` passes env var
- `CONTRACT_TESTS_EXPERIMENTAL=1` env var
- `#[ContractTest(experimental: true)]` attribute on individual tests
- `skipIfExperimentalTest()` in base class auto-skips

None of the three new frameworks mention experimental test support at all. If scip-php adds new experimental call kinds, the downstream test frameworks would have no way to conditionally test them.

### G8. No `--filter` or `--suite` Equivalents Specified for Python Frameworks
**Severity: Low**

The existing `bin/run.sh` supports `--filter <name>` and `--suite <name>`. The requirements just say `bin/run.sh test` and `bin/run.sh docs` for the Python frameworks but do not specify equivalent filtering options. pytest has native `-k` and `-m` marker support, but the `bin/run.sh` wrapper should expose them consistently.

---

## RISKS: What Inconsistencies Could Cause Confusion or Bugs

### R1. Three Test Frameworks, Two Languages, No Shared Tooling
The biggest risk is that each framework will be implemented independently with no shared infrastructure. The PHP contract-tests framework has a mature base class, query API, and attribute system. Each Python framework will need to reinvent:
- A base class or conftest.py pattern
- A query/assertion API
- A decorator for metadata
- A documentation generator

Without a shared Python testing library (e.g., a `kloc-test-utils` package), these three Python frameworks will likely diverge in implementation style.

### R2. Docker Compose Isolation Risk
Each framework has its own `Dockerfile` and presumably its own `docker-compose.yml`. The e2e framework needs to orchestrate scip-php, kloc-mapper, and kloc-cli. The risk is:
- Port conflicts if running multiple frameworks simultaneously
- Docker image naming collisions
- The e2e framework needs Docker images from the other components but the spec doesn't specify how images are named or referenced

### R3. Test Category Overlap Between Frameworks
Some test categories appear in multiple frameworks:
- `smoke` -- in kloc-cli and kloc-mapper
- `usages`, `deps`, `inheritance`, `overrides`, `context` -- in both kloc-cli and e2e

When a test fails, which framework should an agent look at first? The spec doesn't establish a diagnostic hierarchy (e.g., "if kloc-mapper smoke fails, don't bother running kloc-cli or e2e tests").

### R4. FQN Notation Appears Consistent But Uses Two Formats
The spec uses `App\Entity\User::getId()` format (PHP-style with `::` for methods) while the existing contract-tests use SCIP symbol format like `OrderRepository#save().($order)` (with `#` for class separator and `().` for method). These are two different notation systems for the same concepts. The spec should clarify: tests use PHP FQN for human-readable parts, but assertion data may contain SCIP symbol strings.

### R5. Assertion Depth Mismatch
The kloc-cli framework specifies rich assertions (`expect_node`, `expect_edge`, `expect_tree_depth`, `expect_count`), while kloc-mapper specifies data accessors (`node()`, `edge()`, `nodes_by_kind()`). This means:
- kloc-mapper tests will need raw pytest assertions (assert node["kind"] == "Class")
- kloc-cli tests will use custom assertion helpers
- The existing PHP tests use a fluent assertion builder pattern

Three different assertion paradigms across four test suites.

---

## SUGGESTIONS: How to Improve Alignment

### SU1. Create a Shared Python Test Utilities Package
Introduce `kloc-reference-project-php/contract-tests-common/` containing:
- `contract_test_decorator.py` -- Python equivalent of `#[ContractTest]` with same fields
- `docs_generator.py` -- Python equivalent of `generate-docs.php`
- `base_runner.sh` -- Shared `bin/run.sh` template with `test`, `docs`, `help`, `--filter`, `--suite`

This prevents three independent implementations of the same cross-cutting concerns.

### SU2. Specify the `@contract_test` Decorator Fully
Define it to match the PHP attribute:
```python
@contract_test(
    name="OrderService resolves to correct definition",
    description="Verifies resolve command finds OrderService with correct file and range",
    category="resolve",
    status="active",          # active/skipped/pending
    experimental=False,       # requires --experimental flag
)
def test_order_service_resolve():
    ...
```

### SU3. Add a Pipeline Dependency Diagram with Test Order
Clarify which test suites should run in what order:
```
1. contract-tests (scip-php) -- must pass first
2. contract-tests-kloc-mapper -- depends on scip-php contract
3. contract-tests-kloc-cli -- depends on kloc-mapper contract
4. contract-tests-e2e -- depends on all three being correct
```
This establishes a clear test pyramid.

### SU4. Standardize `bin/run.sh` Options Across All Frameworks
All `bin/run.sh` scripts should support:
```
bin/run.sh test                     # Run all tests
bin/run.sh test --filter <pattern>  # Run specific tests
bin/run.sh test --category <name>   # Run test category
bin/run.sh test --experimental      # Include experimental tests
bin/run.sh docs                     # Generate documentation
bin/run.sh docs --format=json       # JSON format
bin/run.sh docs --output=FILE       # Output to file
bin/run.sh help                     # Show help
```

### SU5. Clarify FQN vs SCIP Symbol Notation
Add a section to the requirements explaining:
- **Human-readable**: `App\Entity\User::getId()` -- used in test names, descriptions, expected output
- **SCIP symbol**: `composer package_name 1.0.0 App/Entity/User#getId().` -- used in raw index assertions
- **sot.json FQN**: `App\Entity\User::getId()` -- used in graph node lookups

### SU6. Define Fixture Lifecycle Clearly
For each framework, specify:
- Are fixtures checked into git or generated at test time?
- Is there a `bin/run.sh generate-fixtures` command?
- What happens when the schema changes -- how are fixtures updated?

---

## VERDICT: Overall Consistency Rating

**Rating: 3 out of 5 -- Moderate Consistency**

**Summary**: The requirements document establishes good high-level patterns (Docker-based, `bin/run.sh` interface, test category organization, fixture independence) that are directionally consistent with the existing scip-php contract-tests. However, it falls short in three critical areas:

1. **The `@contract_test` decorator and docs generation are referenced but never specified** -- this is the biggest gap. The PHP framework's `#[ContractTest]` attribute system is one of its best features, and the Python equivalent needs equal rigor.

2. **Query/assertion APIs diverge without justification** -- three different paradigms (fluent builder, assertion helper, data accessor) will make it harder for agents and developers to switch between frameworks.

3. **Cross-framework orchestration is unaddressed** -- how the four test suites compose (run order, shared Docker setup, diagnostic hierarchy) is left entirely to the implementer, creating risk of inconsistent implementations.

The foundation is solid, but the spec needs one more pass to standardize the Python-specific patterns and the inter-framework coordination.
