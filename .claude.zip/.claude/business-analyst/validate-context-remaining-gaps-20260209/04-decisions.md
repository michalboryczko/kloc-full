# Decisions

1. **value_expr goes on the argument edge, not the Node**: Adding an `expression` field to the `argument` edge in sot.json is cleaner than changing the Node schema. The expression is a property of the argument relationship (this value was passed with this expression at this call site), not an intrinsic property of the Value node itself. A local variable `$order` might be passed to multiple calls with different expressions.

2. **Local variables as ContextEntry, not a new node type**: Reuse ContextEntry with a marker (e.g., `reference_type='local_variable'`) rather than creating a new entry type. This keeps the output model uniform and requires minimal formatter changes.

3. **Definition section is compact, not a dependency schema dump**: Follow the BA recommendation from the previous analysis. Show signature + typed params + return type. Do NOT embed interface schemas. Users can run `kloc-cli context InterfaceName` separately.

4. **Implementation order prioritizes the data pipeline fix first**: ISSUE-A is a cross-component change but small. Doing it first means all subsequent CLI improvements benefit from real expression text instead of placeholder names.

5. **Rich argument display (ISSUE-D) is deferred to Phase 4**: While the user's vision is clear, the 4-part display is complex and depends on both the value_expr pipeline fix and type resolution. The simpler 2-part display with real expressions (after ISSUE-A) delivers most of the value.
