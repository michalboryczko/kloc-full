# Brief

Analyze the user's `previous_issues.md` vision against the shipped cli-context-fix feature to identify remaining gaps. Produce a prioritized list of follow-up issues with effort estimates and implementation order.
