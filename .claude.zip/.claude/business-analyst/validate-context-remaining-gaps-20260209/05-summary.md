# Summary

The cli-context-fix shipped 4 phases covering reference types, argument tracking, execution flow, and smart depth. Compared to the user's vision in `previous_issues.md`, there are 6 remaining gaps:

**Critical (P1)**:
- ISSUE-A: kloc-mapper drops `value_expr` from scip-php's ArgumentRecord, so argument display shows `(result)` instead of `$input->productId`. Cross-component fix needed (kloc-mapper + kloc-contracts + kloc-cli). Small effort.
- ISSUE-C: Local variables are invisible. Users cannot trace data flow between calls. CLI-only fix, medium effort.

**Important (P2)**:
- ISSUE-B: Value types not shown in argument display. CLI-only, small.
- ISSUE-E: No Definition section in output. CLI-only, small.

**Nice to have (P3)**:
- ISSUE-D: User wants 4-part argument display; we have 2-part. CLI-only, large.
- ISSUE-F: Minor chain deduplication cleanup. CLI-only, small.

5 of 6 issues are CLI-only. Only ISSUE-A requires cross-component work (kloc-mapper + kloc-contracts). No scip-php changes needed.
