# Observations

## What Was Shipped (cli-context-fix)

### Phase 1 - Reference Types (DONE)
- Constructor calls show as `[instantiation]` via constructor fallback in `find_call_for_usage()`
- `_infer_reference_type()` distinguishes `parameter_type`, `return_type`, `property_type`
- Both tree and JSON formatters render these labels

### Phase 2 - Argument Tracking (PARTIAL)
- `ArgumentInfo` dataclass exists with position, param_name, value_expr, value_source
- `_get_argument_info()` resolves arguments from Call->Value edges
- `_find_result_var()` follows Call->produces->Value->assigned_from->local
- `_resolve_param_name()` gets formal parameter names from callee
- **GAP**: `value_expr` for arguments shows the Value node's `name` field, which comes from `_extract_value_name()` in kloc-mapper. For `result` kind: `(result)`. For `literal` kind: `(literal)`. For params/locals: `$varName`. The user wanted to see the FULL SOURCE EXPRESSION like `$input->productId`, not just `$productId`.

### Phase 3 - Execution Flow (PARTIAL)
- `_build_execution_flow()` iterates Call children by line number
- Type references are separated via `_get_type_references()`
- **GAP**: No local variable entries shown. Variables only appear as argument values in calls.
- **GAP**: No `value_expr` from scip-php's ArgumentRecord is preserved in sot.json

### Phase 4 - Smart Depth (DONE)
- Execution flow naturally filters: depth 2 expands into callee's Call nodes, not structural deps
- Cycle guard prevents infinite recursion

## User's Key Gaps

### Requirement 1: Pipeline Data Preservation (value_expr)
- scip-php's `ArgumentRecord` has `value_expr` field with full expression text
- kloc-mapper creates `argument` edges (Call -> Value) with `position` only
- The `value_expr` from ArgumentRecord is DROPPED -- never stored in sot.json
- sot.json Node schema has no field for expression text
- This is a kloc-mapper + kloc-contracts gap

### Requirement 2: Value Type Resolution
- Value nodes have `type_symbol` field
- `get_type_of()` exists in index.py
- But the context output NEVER shows the resolved type of argument values
- The user wants to see `$input->productId` resolves to `string` type
- For union types, scip-php tracks multiple type references

### Requirement 3: Argument Resolving for Flow Tracking
- 3.1: Arguments ARE in the graph via argument edges, but the display is thin
  - Shows `$productId <- (result)` instead of `$productId <- $input->productId`
  - The full chain user wants: formal param FQN, definition expression, resolved value reference, source
- 3.2: Constructor arguments are tracked (same path as method calls)
- 3.3: Literals show as `(literal)` not `'something'` -- no code snippet preserved

### Requirement 4: Deduplication
- The shipped code deduplicates within a parent via `local_visited` set
- property_access + method_call chains ARE separate entries in execution flow
- User wants chain `$this->inventoryChecker->checkAvailability()` as ONE entry
- Currently: if method_call has access chain, it's shown as one entry with `on:` line
- BUT property_access itself could also appear separately from `uses` edges
- In execution flow mode, this is largely handled since only Call children are iterated

### Requirement 5: Local Variables
- Not visible at all. Only appear implicitly as `value_expr` in argument lists
- User wants `$order`, `$processedOrder`, `$savedOrder` as entries showing source and type

### Requirement 6: Definition Block
- Not implemented. No separate section for method signature, dependencies schema
- BA recommended simplifying this to just signature + type references

### Requirement 7: Rich Argument Display
- Current: `$productId <- (result)` or `$productId <- $processedOrder`
- User wants 4-part display per argument:
  1. Formal parameter FQN
  2. Definition (source expression text)
  3. Value (resolved reference)
  4. Source (access chain showing how the value is obtained)
