# Context Command: Remaining Gaps vs User Vision

## Gap Analysis

| # | User Requirement | Shipped | Remaining Gap | Severity |
|---|-----------------|---------|---------------|----------|
| 1 | Pipeline cannot lose data (value_expr in graph) | Argument edges exist with position | `value_expr` from ArgumentRecord is DROPPED by kloc-mapper. Not in sot.json schema. | HIGH |
| 2 | Value type resolution (attach final type to values) | Value nodes have `type_symbol` field; `get_type_of()` exists | Context output never displays resolved types for argument values or local variables | MEDIUM |
| 3.1 | Arguments fully resolvable for flow tracking | `_get_argument_info()` returns position, param_name, value_expr, value_source | value_expr shows Value node `name` (`$productId`, `(result)`, `(literal)`) not the full source expression (`$input->productId`). Missing: formal param FQN, multi-step chain tracing | HIGH |
| 3.2 | Constructor arguments same treatment as methods | Constructor Call nodes tracked; arguments resolved | Working. No gap. | NONE |
| 3.3 | Literals show code snippets like `'something'` | Literals show as `(literal)` | No snippet text preserved. scip-php has `value_expr` for literals but kloc-mapper drops it | MEDIUM |
| 4 | Chain deduplication (property_access + method_call = one entry) | Execution flow iterates Call children; `on:` shows receiver | Largely mitigated by execution flow. Property_access Call nodes still appear as separate entries when scip-php emits them as standalone calls | LOW |
| 5 | Local variables visible with source and type | Not shown. Only appear implicitly as argument value_expr | `$order`, `$processedOrder`, `$savedOrder` never appear as entries | HIGH |
| 6 | Definition block (signature, argument types, return type, dependency schemas) | Not implemented | No DEFINITION section in output | MEDIUM |
| 7 | Rich 4-part argument display (formal FQN, definition, value, source) | Shows `param <- value_expr` (2 parts) | Missing: formal param FQN, resolved value reference, source access chain per argument | MEDIUM |


## Proposed Follow-Up Issues

### ISSUE-A: Preserve value_expr in sot.json pipeline

**Problem**: scip-php's `ArgumentRecord` includes `value_expr` (the pretty-printed source expression like `$input->productId` or `'pending'`), but kloc-mapper only creates an `argument` edge from Call to Value with `position`. The expression text is silently dropped. This means kloc-cli can only show the Value node's `name` field, which for `result`-kind values is `(result)` and for literals is `(literal)`.

**Where**: kloc-mapper + kloc-contracts (sot-json.json schema)

**What to do**:
- Option A (preferred): Add an `expression` field to the sot.json `Edge` schema for `argument` edges, carrying `value_expr` alongside `position`. The edge already has `position`; adding `expression` is additive.
- Option B: Add an `expression` field to the sot.json `Node` schema for Value nodes. This is broader but changes the Node shape.
- Then update kloc-mapper's `_create_call_edges()` to read `value_expr` from each `ArgumentRecord` and store it on the argument edge.
- Finally update kloc-cli's `_get_argument_info()` to prefer the edge's `expression` over the Value node's `name`.

**Effort**: S (schema addition + mapper change + CLI change, all small)

**Priority**: P1 -- this is the foundation for requirements 1, 3.1, 3.3, and 7. Without it, argument display stays broken.

**Acceptance criteria**:
1. sot.json `argument` edges include `expression` field with the source text
2. `kloc-cli context` shows `$productId <- $input->productId` instead of `$productId <- (result)`
3. Literal arguments show `status <- 'pending'` instead of `status <- (literal)`
4. kloc-contracts schema validates the new field

---

### ISSUE-B: Display resolved types for argument values

**Problem**: The user wants to see the resolved type of each argument value. Value nodes already have `type_symbol` and `get_type_of()` exists in the index. But the context output never uses it.

**Where**: kloc-cli only

**What to do**:
- In `_get_argument_info()`, after building each `ArgumentInfo`, also resolve the Value node's type via `get_type_of()` and include it.
- Add a `value_type` field to `ArgumentInfo` (e.g., `"string"`, `"App\\Dto\\CreateOrderInput"`)
- Update tree formatter to show: `$productId (string) <- $input->productId`
- For union types, show all options: `$value (string|int) <- ...`

**Effort**: S (add field to dataclass, one lookup in query, formatter change)

**Priority**: P2 -- valuable for understanding what types flow through the code, but not blocking

**Dependency**: None (works with current data)

**Acceptance criteria**:
1. Argument display includes the resolved type from the Value node's type_of edge
2. Union types (multiple type_of edges) show as `Type1|Type2`
3. JSON output includes `value_type` field in argument objects

---

### ISSUE-C: Local variable entries in execution flow

**Problem**: The user explicitly asked for `$order`, `$processedOrder`, `$savedOrder` to appear as entries with their source (what call produced them) and type. Currently, local variables are invisible -- they only appear indirectly as `value_expr` text in argument lists or `result ->` annotations.

**Where**: kloc-cli only

**What to do**:
- In `_build_execution_flow()`, after processing Call children, also collect Value nodes with `value_kind='local'` contained by the method.
- For each local that participates in data flow (is an argument to a call, receives a call result, or is a receiver), create a `ContextEntry` showing:
  - Variable name and type
  - Source: which call produced it (via `assigned_from` -> result -> Call)
  - Where it is consumed: which call(s) use it as argument
- Order these entries by line number alongside Call entries
- Apply the BA's recommendation: only show locals that participate in inter-symbol data flow (passed as arguments, receive call results, serve as receivers). Do NOT show purely internal variables.

**Effort**: M (new traversal logic, new entry type or reuse ContextEntry with variable markers, formatter changes)

**Priority**: P1 -- the user called flow tracking "critical" and local variables are the missing link between calls. Without seeing `$order` as an entry, the user cannot trace how data flows from one call to the next.

**Dependency**: Works independently. Better with ISSUE-A (shows richer expressions).

**Acceptance criteria**:
1. Local variables that receive call results appear as entries: `$order [local] (line:32) from: new Order(...)`
2. Local variables that are arguments to calls show their destination: `$order -> passed to process() as $order`
3. Purely internal variables (never passed to another call) are NOT shown
4. Entries are ordered by line number among Call entries
5. JSON output includes local variable entries with source and type

---

### ISSUE-D: Rich argument display (formal FQN + source chain)

**Problem**: The user's vision shows a 4-part argument display:
1. Formal parameter FQN: `App\Component\InventoryCheckerInterface::checkAvailability().$productId(string)`
2. Definition (source expression): `$input->productId`
3. Value (resolved reference): `App\Dto\CreateOrderInput::$productId`
4. Source: `App\Dto\CreateOrderInput::$productId [property_access] on: $input`

The shipped code shows 2 parts: `$productId <- (result)`.

**Where**: kloc-cli only (assuming ISSUE-A provides expression text)

**What to do**:
- Extend `ArgumentInfo` with:
  - `param_fqn`: Full FQN of the formal parameter (from callee's Argument node FQN)
  - `value_type`: Resolved type (from ISSUE-B)
  - `value_ref_fqn`: If the argument value traces to a known symbol (property, parameter), its FQN
  - `source_chain`: How the value is obtained (access chain from the argument Value node's source)
- In `_get_argument_info()`, for each argument Value node:
  - Resolve param FQN from the callee's Argument children (already have param_name, extend to use FQN)
  - Follow `assigned_from` edge to find source Value
  - If source is a result of a property_access Call, build the access chain
  - Resolve the property/parameter FQN from the access chain
- Update tree formatter for multi-line argument display
- Update JSON formatter with all new fields

**Effort**: L (significant query logic for chain tracing, complex formatter changes, multiple edge cases)

**Priority**: P3 -- this is the "gold standard" output the user described. Very valuable but depends on ISSUE-A and ISSUE-B, and the basic 2-part display is functional in the meantime.

**Dependency**: ISSUE-A (for expression text), ISSUE-B (for types)

**Acceptance criteria**:
1. Each argument shows formal param FQN, expression, resolved type, source chain
2. Multi-step chains (e.g., `$input->productId` where `$input` is a parameter) show full trace
3. JSON output includes all 4 parts per argument

---

### ISSUE-E: Definition section in context output

**Problem**: The user described a "Definition" section showing the method signature, argument types, return type, and dependency schemas (interfaces/classes with their methods, properties, arguments).

**Where**: kloc-cli only

**What to do**:
- Add a `DEFINITION` section before `USED BY` in context output
- For Method/Function nodes, show:
  - Full signature (already available as `node.signature`)
  - Parameters with their types (from Argument children + type_hint edges)
  - Return type (from Method's type_hint edge to Class/Interface)
- Follow the BA recommendation: keep it compact. Show signature + typed parameters + return type. Do NOT embed full dependency schemas (that belongs in separate `context` calls on those types).
- Optionally list "Type references" as a one-liner: types used in the signature

**Effort**: S (data already available, just need new formatter section)

**Priority**: P2 -- useful context for both humans and AI agents, quick to implement

**Dependency**: None

**Acceptance criteria**:
1. `context` output starts with a `DEFINITION` section for Method/Function nodes
2. Shows signature with typed parameters and return type
3. For non-method nodes (Class, Interface), shows kind, FQN, file, line
4. JSON output includes a `definition` object in the result

---

### ISSUE-F: Chain deduplication cleanup

**Problem**: The user flagged that `$inventoryChecker [property_access]` followed by `checkAvailability() [method_call] on: $this->inventoryChecker` is redundant. These should be ONE entry at one depth level.

**Where**: kloc-cli only

**What to do**:
- In `_build_execution_flow()`, when iterating Call children, detect when a property_access Call and a method_call Call form a chain (the method_call's receiver is the result of the property_access).
- Suppress the standalone property_access entry when it is already shown as the `on:` chain of a method_call.
- This is partially mitigated already because execution flow shows Call nodes and the method_call entry already shows `on: $this->inventoryChecker`. But if scip-php emits a standalone `access` Call for the property read, it would show as a separate entry.

**Effort**: S (filter logic in execution flow)

**Priority**: P3 -- mostly cosmetic; execution flow already handles this better than the old structural view

**Dependency**: None

**Acceptance criteria**:
1. A property_access that is consumed by a method_call as receiver does NOT appear as a separate entry
2. The method_call entry shows the access chain via `on:` as it does today
3. Standalone property accesses (not followed by a method call) still appear


## Recommended Implementation Order

```
Phase 1 (Foundation)
  ISSUE-A: Preserve value_expr in pipeline  [S, P1]
    -- Unblocks everything else. Schema + mapper + CLI.
    -- After this: argument display jumps from "(result)" to "$input->productId"

Phase 2 (Core Visibility)
  ISSUE-C: Local variable entries            [M, P1]
    -- The critical flow tracking gap. Makes data flow between calls visible.
    -- After this: users can trace $order -> process($order) -> $processedOrder

  ISSUE-E: Definition section                [S, P2]
    -- Quick win. Adds method signature + typed params as header.
    -- After this: context output has all 3 sections user described

Phase 3 (Enrichment)
  ISSUE-B: Value type resolution             [S, P2]
    -- Adds type info to argument display.
    -- After this: "$productId (string) <- $input->productId"

  ISSUE-F: Chain deduplication               [S, P3]
    -- Polish. Removes any remaining duplicate entries.

Phase 4 (Gold Standard)
  ISSUE-D: Rich 4-part argument display      [L, P3]
    -- The full vision. Formal FQN + expression + resolved ref + source chain.
    -- After this: matches the user's example output exactly.
```

### Rationale

1. **ISSUE-A first** because it is the data foundation. Without `value_expr` in sot.json, argument display is crippled. Everything that shows argument values depends on this.

2. **ISSUE-C second** because the user called flow tracking "critical" and local variables are the primary gap. This is where the shipped feature falls most short of the user's vision.

3. **ISSUE-E third** because it is a quick win (S effort, all data available) that completes the 3-section structure the user described.

4. **ISSUE-B and ISSUE-F** are enrichment. Both are small and improve output quality.

5. **ISSUE-D last** because it is large, depends on A and B, and the simpler 2-part display is functional. This transforms the output from "good" to "matches the user's exact vision."

### Cross-Component Summary

| Issue | scip-php | kloc-mapper | kloc-contracts | kloc-cli | Effort |
|-------|----------|-------------|----------------|----------|--------|
| A: value_expr preservation | -- | CHANGE | CHANGE | CHANGE | S |
| B: Value type resolution | -- | -- | -- | CHANGE | S |
| C: Local variable entries | -- | -- | -- | CHANGE | M |
| D: Rich argument display | -- | -- | -- | CHANGE | L |
| E: Definition section | -- | -- | -- | CHANGE | S |
| F: Chain dedup cleanup | -- | -- | -- | CHANGE | S |

Total: 1 cross-component issue (A), 5 CLI-only issues. No scip-php changes needed.
