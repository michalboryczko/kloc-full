# Observations

## Data Pipeline Trace

### Layer 1: scip-php (PHP indexer)

scip-php produces two relevant data structures:

1. **ValueRecord** -- has `kind`, `symbol`, `type`, `location`, `source_call_id`, `source_value_id`
   - For `result` values: `symbol` is null, no expression text
   - For `literal` values: `symbol` is null, no expression text
   - For `parameter`/`local` values: `symbol` is set (SCIP symbol string like `#method().($name)` or `#method().local$name@`)

2. **ArgumentRecord** -- has `position`, `parameter`, `value_id`, `value_expr`
   - `value_expr` contains the **pretty-printed source text** (e.g., `$input->productId`, `0`, `'pending'`)
   - This is the expression text the user wants to see

### Layer 2: kloc-mapper (graph builder)

kloc-mapper creates Value nodes from ValueRecords:

- `_extract_value_name()` extracts names from SCIP symbols
  - For `parameter`: extracts `$name` from symbol pattern `.($name)`
  - For `local`: extracts `$name` from symbol pattern `.local$name@`
  - For `result`: returns `"(result)"` (fallback, no symbol available)
  - For `literal`: returns `"(literal)"` (fallback, no symbol available)

kloc-mapper creates `argument` edges from ArgumentRecords:

- Creates edge: Call --argument--> Value (with `position` field)
- The `value_id` from ArgumentRecord is resolved to a Value node ID
- **CRITICAL**: `value_expr` from ArgumentRecord is NOT stored anywhere in sot.json

### Layer 3: kloc-cli (query and display)

kloc-cli's `_get_argument_info()`:
- Calls `index.get_arguments(call_node_id)` to get (value_node_id, position)
- For each argument, reads the Value node's `name` field as `value_expr`
- Reads the Value node's `value_kind` as `value_source`

So when `value_kind == "result"`, the display shows:
- `value_expr = "(result)"` (the Value node's name)
- `value_source = "result"` (the Value node's value_kind)

## What's Missing

The `value_expr` field from scip-php's ArgumentRecord contains the actual expression text
(e.g., `$input->productId`, `0`, `'pending'`, `new DateTimeImmutable()`).

This expression text is:
1. Produced by scip-php
2. Present in the unified JSON output (index.json)
3. **NOT carried through** kloc-mapper into sot.json
4. Therefore unavailable to kloc-cli

## Why This Happens

kloc-mapper was designed to create a graph of nodes and edges. The `argument` edge connects
Call to Value and carries only `position`. The Value node has `name` (from symbol) and
`value_kind`. For `result` and `literal` values, there is no symbol, so the name falls back
to `(result)` and `(literal)`.

The actual source expression text (`$input->productId`) is only in the ArgumentRecord's
`value_expr` field, which is not mapped to any node property or edge metadata.

## Two Possible Resolution Paths

### Path A: Resolve via graph traversal (kloc-cli only)

For `result` values: follow the `produces` edge backward to find the Call node that produced
this value, then follow that Call's `calls` edge to find the callee, and build an expression
like `$input->productId` from the access chain.

For `literal` values: no graph data to resolve from. The literal text is lost.

**Pros**: No pipeline changes needed.
**Cons**: Does not work for literals. Reconstructed expressions may not match source exactly.

### Path B: Carry `value_expr` through the pipeline (kloc-mapper + sot.json change)

Add the `value_expr` field from ArgumentRecord into either:
- The `argument` edge (as additional metadata), or
- The Value node itself (as a new field)

**Pros**: Exact source text preserved. Works for all value kinds.
**Cons**: Requires kloc-mapper change and sot.json schema update.
