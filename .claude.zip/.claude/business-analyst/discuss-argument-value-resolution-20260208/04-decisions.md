# Decisions

## Classification: This is a split pipeline issue, not a single-layer bug

The problem spans two layers:

1. **kloc-mapper drops `value_expr`** -- the `ArgumentRecord.value_expr` from scip-php
   (containing actual source text like `$input->productId`) is not carried into sot.json.
   The `argument` edge only stores `position`. The Value node `name` falls back to
   `(result)` or `(literal)` for value kinds without SCIP symbols.

2. **kloc-cli already has the graph traversal logic** -- `_build_chain_from_value()` can
   reconstruct expressions for `result` values by following call chains. But it is only
   used for access chains (`on:` field), not for argument value display.

## Recommended approach: Two-track fix

### Track 1: kloc-cli quick fix (immediate value, no pipeline change)

Use `_build_chain_from_value()` to resolve argument value expressions for `result` values
in `_get_argument_info()`. This would transform:

```
$productId <- (result)       -->    $productId <- $input->productId
$order <- (result)            -->    $order <- $order
arg[0] <- (result)            -->    arg[0] <- $savedOrder->id
```

This works because:
- `result` values have `produces` edges linking back to their source Call
- `_build_chain_from_value()` already handles property access, method calls, and chaining
- It already works correctly for the `on:` field in current output

Limitation: `literal` values remain as `(literal)` -- the literal text is lost.

### Track 2: kloc-mapper pipeline enhancement (complete fix, requires coordination)

Carry `value_expr` from scip-php's ArgumentRecord through to sot.json. Options:

**Option A**: Add `value_expr` as metadata on the `argument` edge
**Option B**: Add an `expression` field on Value nodes

Option A is cleaner because `value_expr` is a property of the argument-at-call-site
relationship, not of the Value node itself. A Value node representing `(literal) 0` doesn't
inherently know it appears as `0` -- that's context from the call site.

However, Option B is simpler to implement and query.

## Priority assessment

Track 1 should ship first because:
- It fixes the most impactful cases (result values showing as `(result)`)
- No cross-repo coordination needed
- The code pattern already exists and is proven
- It makes the just-shipped feature much more useful immediately

Track 2 can follow as a separate issue because:
- It requires kloc-mapper changes and sot.json schema update
- It mainly fixes `literal` values (lower volume, less confusing than `(result)`)
- It provides the "ground truth" expression text for all cases
