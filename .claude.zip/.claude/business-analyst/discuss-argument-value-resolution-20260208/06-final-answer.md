# Final Answer: Argument Value Resolution Analysis

## Root Cause

This is a **pipeline data loss issue**, not a presentation bug.

scip-php produces `value_expr` in its `ArgumentRecord` -- the pretty-printed source text
of each argument expression (e.g., `$input->productId`, `0`, `'pending'`). But kloc-mapper
does not carry this field into sot.json. Instead, argument edges only store `position`, and
Value nodes get their `name` from SCIP symbol extraction. For `result` and `literal` value
kinds, there is no SCIP symbol, so `_extract_value_name()` falls back to `"(result)"` and
`"(literal)"` as placeholder names.

kloc-cli then displays these placeholder names as-is in the argument block.

## Where Each Piece Lives

| Data | scip-php | kloc-mapper | sot.json | kloc-cli |
|------|----------|-------------|----------|----------|
| Source text (e.g., `$input->productId`) | ArgumentRecord.value_expr | **DROPPED** | Not present | Not available |
| Value kind (`result`, `literal`) | ValueRecord.kind | Value node.value_kind | Present | Displayed as fallback |
| Graph structure (Call->produces->Value) | N/A | Edges built correctly | Present | Used for `on:` chains but NOT for arg values |

## Recommended Two-Track Fix

### Track 1: Graph-based resolution in kloc-cli (quick win)

**What**: In `_get_argument_info()`, instead of using the raw Value node `name` as
`value_expr`, call `_build_chain_from_value()` to reconstruct the expression from the graph.

**Why it works**: `_build_chain_from_value()` already exists and correctly handles:
- `parameter` values: returns `$input` (the parameter name)
- `local` values: returns `$order` (the variable name)
- `result` values: follows `produces` edges to reconstruct chains like `$input->productId`
  or `$savedOrder->id`
- `constant` values: returns the constant name

**What it fixes**: All `(result)` labels become resolvable expressions.

**What it does NOT fix**: `(literal)` values remain as `(literal)` because the actual
literal text (`0`, `'pending'`, `new DateTimeImmutable()`) is not in the graph.

**Expected output after Track 1:**
```
args:
  $productId <- $input->productId    (was: $productId <- (result))
  $quantity <- $input->quantity      (was: $quantity <- (result))
  $order <- $order                   (was: $order <- (result))
  arg[0] <- (literal)                (still unresolved)
  arg[1] <- $input->customerEmail    (was: arg[1] <- (result))
```

**Effort**: Small (S). Single function change in `context.py`.

**Scope**: kloc-cli only. No pipeline or schema changes.

### Track 2: Carry `value_expr` through pipeline (complete fix)

**What**: In kloc-mapper's `_create_call_edges()`, read `value_expr` from each
ArgumentRecord and store it either as:
- (Option A) Metadata on the `argument` edge, or
- (Option B) A new `expression` field on the Value node

Then update kloc-cli to prefer `value_expr` when available, falling back to graph
reconstruction.

**What it fixes**: All argument labels, including literals:
```
args:
  arg[0] <- 0                          (was: arg[0] <- (literal))
  arg[3] <- 'pending'                  (was: arg[3] <- (literal))
  arg[5] <- new DateTimeImmutable()    (was: arg[5] <- (result))
```

**Effort**: Medium (M). Requires kloc-mapper change, sot.json schema update,
and kloc-cli update.

**Dependencies**: Track 1 should ship first (provides immediate improvement).

## Filing Recommendation

File this as a **follow-up feature**, not a bug. The current behavior is working as
designed -- the data pipeline was built for graph relationships, and expression text
was out of scope for the initial call graph implementation.

Suggested issue structure:
1. **Issue A (Track 1)**: "Resolve argument value expressions via graph traversal"
   - Scope: kloc-cli only
   - Priority: High (fixes the most visible problem with shipped feature)
   - Effort: S
2. **Issue B (Track 2)**: "Carry value_expr through pipeline for literal argument display"
   - Scope: kloc-mapper + sot.json schema + kloc-cli
   - Priority: Medium (literals are less common and less confusing)
   - Effort: M
   - Blocked by: Issue A (design should be compatible)

## Open Questions for Discussion

1. **Should Track 1 also handle constructor `arg[N]` labels?** Currently, constructor
   arguments show as `arg[0]`, `arg[1]`, etc. because `_resolve_param_name()` looks up
   the callee's Argument children, but constructors may not always have them mapped.
   Is the positional fallback acceptable for now?

2. **For Track 2, should `value_expr` go on the edge or the node?** The expression text
   is contextual to the call site (a value `$order` is always `$order`, but a `result`
   value could appear as `$this->repo->find()` in one context and `$obj->method()` in
   another). This suggests the `argument` edge is the right place. But the sot.json
   Edge schema currently only allows `position` as extra metadata.

3. **Is there a naming issue too?** Looking at the output again, constructors show
   `arg[0]`, `arg[1]` instead of parameter names. This may be a separate issue with
   `_resolve_param_name()` not finding constructor parameters. Worth investigating
   alongside Track 1?
