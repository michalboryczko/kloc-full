# Decisions

## D1: Verdict is "Proceed with refinements"

The architecture is fundamentally sound. The testing pyramid (component + E2E) is correct for a linear pipeline. The scip-php contract tests prove the team can execute. But five specific areas need refinement before implementation.

## D2: Hybrid fixture strategy recommended

Pure synthetic fixtures are too risky for SCIP protobuf and too brittle for sot.json. Recommend: captured real outputs for happy path, synthetic generators for edge cases and error scenarios. This gives high fidelity without the maintenance burden of full synthetic generation.

## D3: sot.json JSON Schema is the #1 priority

Without a formal schema for the kloc-mapper/kloc-cli boundary, all downstream testing is built on implicit assumptions. This is a small effort (extract from models.py) with critical impact.

## D4: Cross-component schema validation is a missing layer

The plan has component tests and E2E tests but nothing that validates interface compatibility between components. This must be added as a separate concern.

## D5: Error handling tests must be added to the plan

Zero negative tests in the entire proposal. This is a significant gap that must be addressed for each component.
