# Observations

## Current State

1. **scip-php contract tests are mature**: 235 tests (205 pass, 30 skipped/experimental), well-structured PHP/PHPUnit framework with ContractTest attributes, query API, assertion categories, Docker-based execution, and documentation generation.

2. **kloc-mapper has basic tests only**: 3 test files (test_models.py, test_parser.py, test_mapper.py). The mapper has been recently extended to handle unified graph format (v2.0) with Value/Call nodes but tests have not caught up.

3. **kloc-cli has more tests than kloc-mapper**: test_index.py (unit), test_integration.py (integration with real artifact), test_usage_flow.py (integration with reference project output), test_reference_type.py (unit). However, these are scattered and not structured as a formal contract test framework.

4. **No formal sot.json schema exists**: The sot.json format is defined implicitly by the kloc-mapper model code and the kloc-cli loader code. There is no JSON Schema document, no schema version validation, and no formal contract at this boundary.

5. **The pipeline has been working end-to-end**: The reference project has been indexed, the contract-tests/output/ directory contains index.scip, calls.json, index.kloc, and sot.json. The kloc-cli usage flow tests use this sot.json directly. So the pipeline works in practice, but there is no automated verification of the full chain.

6. **calls.json has a formal schema**: `docs/reference/kloc-scip/calls-schema.json` exists and is used for validation. This is the model to follow for sot.json.

7. **The .kloc archive format is documented**: docs/reference mentions the .kloc archive (ZIP with manifest.json, index.scip, calls.json). kloc-mapper has `archive.py` to load it.

8. **The reference project has rich patterns**: 28 PHP files covering layered architecture, interfaces, inheritance, DTOs, Messenger, nested entities, nullsafe operators. This is a good test corpus.

## Key Insights

- The biggest risk is not in any individual component but at the boundaries between components.
- The fixture generation approach for SCIP protobuf is the hardest technical challenge.
- The naming convention inconsistency (contract-tests vs contract-tests-kloc-mapper) is minor but symptomatic of a plan that was written incrementally rather than designed holistically.
- The existing scip-php contract test framework is excellent and sets a high bar that the new frameworks should match.
