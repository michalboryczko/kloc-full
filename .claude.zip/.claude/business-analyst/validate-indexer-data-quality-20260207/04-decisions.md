# Decisions

## Key Decision 1: Issue 6 first is correct
The proposed implementation order (Issue 6 first) is strategically sound from a product perspective. Adding callee verification to find_call_for_usage() is a single guard that converts "confidently wrong" into "correctly inferred or honestly unknown." This is the highest-value change per line of code.

## Key Decision 2: Issue 5 is the most damaging to users
While the proposed order puts Issue 6 first (correct), Issue 5 is the most dangerous from a user trust perspective because it causes SILENT data loss. Users who don't notice missing entries will make decisions on incomplete data. Issue 6 makes wrong data VISIBLE; Issue 5's data loss is invisible.

## Key Decision 3: "Consistency over completeness" is the right principle, with a nuance
The design principle is correct for a code analysis tool. However, the word "unknown" needs careful UX treatment. For the CLI, silent omission with a summary count is better than [unknown] tags everywhere. For JSON/MCP output, an explicit "unresolved" field is better.

## Key Decision 4: These are NOT MVP blockers, but Issue 5 is close
The issues were found in the depth-2 USES path, which is an advanced feature. Depth-1 queries (the most common case) are not affected by Issues 1/5. Issues 2/3/4 affect all depths but are wrong metadata on correct symbols -- annoying but not misleading about what the code depends on. Issue 5's non-determinism is the closest to a blocker because it produces different results on each run.

## Key Decision 5: The implementation order should be reordered slightly
Proposed: 6 -> 5 -> 2+4 -> 3
Recommended: 5 -> 6 -> 2+4 -> 3
Rationale: Issue 5 is more dangerous because it's silent data loss. Issue 6 converts visible errors into visible unknowns -- still visible, just more honest. Fixing Issue 5 first restores data completeness; then Issue 6 restores data accuracy.
