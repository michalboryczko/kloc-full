# Plan

## Approach

Analyze 6 data quality issues from the scip-php indexer pipeline from the customer's perspective. For each issue, evaluate:

1. What the user sees (symptom)
2. What decision they might make based on wrong data
3. Whether the issue is silent or visible
4. How it affects the three personas (AI agent, developer, tech lead)

Then evaluate the collection holistically: trust impact, priority ordering, design principles, and MVP readiness.

## Documents Read

- issues-v1.md (the 6 issues)
- docs/summary.md (KLOC MVP overview)
- kloc-cli/README.md (CLI interface and capabilities)
- docs/reference/from-obsidian/KlOC.md (project vision)
- docs/reference/kloc-cli/context-usage-flow.md (context command spec)
- docs/specs/usage-flow-tracking-mvp.md (the feature these issues were found in)
- docs/reference/kloc-scip/calls-schema-docs.md (SCIP schema)

## Key Understanding

The issues affect the `context` command's USES direction with `--depth 2`. This is the command that answers "what does this method call, and what do those call?" -- a critical question for refactoring and impact analysis. The issues produce:

- Missing data at depth 2 (Issues 1, 5)
- Wrong reference types (Issues 2, 3)
- Wrong receiver chains (Issue 4)
- No defensive fallback for unmatched data (Issue 6)
