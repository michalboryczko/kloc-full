# Business Analysis: scip-php Indexer Data Quality Issues

**Analyst**: Product Strategist (Business Analyst role)
**Date**: 2026-02-07
**Source**: `/Users/michal/dev/ai/kloc/.claude/feature-issues/scip-php-indexer-issues/issues-v1.md`
**Scope**: 6 data quality issues in the scip-php -> kloc-mapper -> kloc-cli pipeline

---

## 1. User Impact Assessment

### Issue 1 + Issue 5: Missing properties at depth 2 (Data Loss)

**Issues 1 and 5 are the same problem.** Issue 1 describes the symptom (missing `$customerEmail` and `$productId` at depth 2); Issue 5 identifies the root cause (global `visited` set in `_build_outgoing_tree()` causes DFS-order-dependent data loss). I analyze them together because the user experiences them as one problem.

**What the user sees**: When running `kloc-cli context "OrderService::createOrder" --depth 2`, the `save()` method's subtree shows 7 of 10 dependencies instead of all 10. Three properties silently vanish.

**What the user DOES NOT see**: That anything is missing. There is no indication in the output that entries were dropped. The tree looks complete. The user does not know `$customerEmail` and `$productId` are dependencies of `save()`.

**Decisions users might make incorrectly**:

| Scenario | Wrong conclusion | Real risk |
|----------|-----------------|-----------|
| "Can I remove the `$customerEmail` property from Order?" | "save() doesn't use it -- safe to remove" | Runtime error: save() writes to `$customerEmail` at line 31 |
| AI agent analyzing save() impact | Agent omits `$customerEmail` from affected-fields list | Agent produces incomplete refactoring plan |
| Tech lead reviewing Order entity | "$customerEmail is only used at depth 1, not by callees" | Underestimates coupling between OrderService and Order |

**The non-determinism makes this worse.** Because the global `visited` set interacts with edge iteration order, the same query might produce different results if the underlying data changes slightly (e.g., after re-indexing). The user could run the same query twice and get different depth-2 trees. For a tool whose value proposition is "reliable code understanding," non-deterministic output is deeply undermining.

**Severity from user perspective**: **CRITICAL** -- silent data loss affecting completeness, with non-deterministic behavior.

---

### Issue 2: Constructor arguments inherit [instantiation] reference type

**What the user sees**: `$nextId` (a static property access via `self::$nextId++`) appears as `[instantiation]` in the output. `OrderRepository` (not the class being instantiated) also appears as `[instantiation]`.

**What the user thinks**: "OrderRepository is being instantiated at line 30" and "$nextId is being instantiated at line 30." Both are wrong. The actual code is `$newOrder = new Order(id: self::$nextId++, ...)` -- it's `Order` being instantiated, and `$nextId` is a static property being read and incremented.

**Decisions users might make incorrectly**:

| Scenario | Wrong conclusion | Real risk |
|----------|-----------------|-----------|
| "How is OrderRepository used here?" | "It's being instantiated -- new OrderRepository()" | Developer looks for constructor call that doesn't exist |
| "What patterns access $nextId?" | "It's an instantiation pattern" | Misunderstands the ID generation mechanism |
| AI agent classifying usage patterns | Labels this as "OrderRepository creation" | Agent's dependency graph has wrong semantics |

**Visibility**: **Moderately visible.** A PHP developer reading the output would likely notice that `OrderRepository [instantiation]` makes no sense in the context of `save()`. But an AI agent or a developer unfamiliar with the codebase would accept the label at face value.

**Severity from user perspective**: **MEDIUM** -- wrong metadata on correct symbols. The user can still see that `$nextId` and `OrderRepository` ARE dependencies; they just misunderstand HOW they're used.

---

### Issue 3: getName() misclassified as [property_access]

**What the user sees**: `AbstractOrderProcessor::getName()` appears with `[property_access]` instead of `[method_call]`.

**What the user thinks**: "getName is a property being accessed, not a method being called."

**Decisions users might make incorrectly**:

| Scenario | Wrong conclusion | Real risk |
|----------|-----------------|-----------|
| "Is getName() called anywhere?" | Searching for [method_call] entries misses this | Developer misses a call site |
| AI agent filtering by reference type | Agent excludes this from "method calls to getName()" | Incomplete method call analysis |
| "What's the performance profile of this code?" | Property access is O(1); method call might be expensive | Wrong performance assumptions (minor) |

**Visibility**: **Visible.** A developer knows that `getName()` with parentheses is a method call, not a property access. The `()` in the name contradicts the `[property_access]` label.

**Severity from user perspective**: **LOW-MEDIUM** -- the contradiction between the method name (with parentheses) and the label is confusing but the user can mentally correct it. More problematic for automated consumers (AI agents, scripts) that filter by reference type.

---

### Issue 4: Named arguments misattributed to wrong receiver chain

**What the user sees**: `Order::$customerEmail` appears as `[method_call]` with `on: $this->emailSender`. The property access is attributed to a completely different object.

**What the user thinks**: "$customerEmail is accessed through the email sender object" -- this is factually wrong. The actual code is `$savedOrder->customerEmail` inside the arguments of `$this->emailSender->send(to: ...)`.

**Decisions users might make incorrectly**:

| Scenario | Wrong conclusion | Real risk |
|----------|-----------------|-----------|
| "What touches $customerEmail?" | "The email sender accesses it" | Wrong understanding of data flow |
| "What does emailSender depend on?" | "It depends on Order::$customerEmail" | False dependency: emailSender receives email as a string argument, not the property |
| AI agent tracing data flow | Agent constructs wrong data flow graph: emailSender -> Order::$customerEmail | Agent recommends wrong refactoring |
| "Can I change how emailSender works?" | "I need to consider the customerEmail property" | Wasted investigation time |

**Visibility**: **Moderately visible.** A careful reader would question why an email sender would access customerEmail directly. But in a large codebase with many dependencies, users skim reference types and receivers without deeply questioning each one.

**Severity from user perspective**: **MEDIUM-HIGH** -- this is the most semantically misleading issue. Both the reference type AND the receiver chain are wrong. The user gets a completely false picture of the data flow. Unlike Issue 2 (wrong type, right symbol) or Issue 3 (wrong type, obviously contradicted by name), Issue 4 constructs a plausible but entirely fictional relationship.

---

### Issue 6: Defensive fallback design principle

**What it proposes**: When the correct Call node cannot be matched, fall back to type-inference or show `[unknown]` rather than displaying data from the wrong Call node.

**What the user would see (after fix)**: Instead of `[instantiation]` for `$nextId`, they would see `[static_property]` (inferred from the target node being a Property with static access) or in edge cases `[unknown]`.

**User impact**: Strictly positive. The user either gets a correct inferred type or an honest "I don't know" rather than a confident lie.

---

## 2. Trust and Reliability Analysis

### The Trust Equation

For a code analysis tool, user trust is built on a specific equation:

> **Trust = Accuracy of what IS shown + Completeness of what SHOULD be shown**

The 6 issues attack both sides of this equation:

| Trust dimension | Issues | Impact |
|----------------|--------|--------|
| **Accuracy** (what is shown is correct) | 2, 3, 4 | Wrong reference types and receiver chains |
| **Completeness** (everything relevant is shown) | 1, 5 | Silent data loss at depth 2 |
| **Honesty** (tool admits what it doesn't know) | 6 | Currently absent; proposed as fix |

### Silent vs. Visible Issues

This distinction matters enormously for trust:

**Silent issues (user won't notice)**:
- Issues 1/5: Missing depth-2 entries. The user sees a tree that looks complete. Nothing signals that 3 entries were dropped. This is the most dangerous category because the user builds confidence in incomplete data.

**Visible issues (user will see something odd)**:
- Issue 2: `[instantiation]` for `$nextId` -- experienced PHP dev will notice
- Issue 3: `[property_access]` for `getName()` -- contradicted by the parentheses in the method name
- Issue 4: `on: $this->emailSender` for `$customerEmail` -- requires careful reading to spot

**The paradox**: Visible issues are less dangerous than silent ones, but they erode trust faster. A user who notices `[property_access]` on a method call thinks "this tool is buggy." A user who never notices missing data thinks "this tool works great" -- until they make a wrong decision based on it.

### Trust Trajectory by User Persona

**AI Coding Agent**: Agents do not have the PHP knowledge to spot contradictions. They trust the reference types literally. Issues 2, 3, 4 will propagate directly into agent reasoning. Issue 5 will cause incomplete analysis. An agent using kloc for refactoring recommendations will produce subtly wrong advice. The user blames the agent, but the root cause is kloc data quality.

**Human Developer (new to codebase)**: This user relies heavily on kloc because they don't yet have mental models of the code. They are the most trusting audience. They will accept `[instantiation]` labels without questioning. Issues 1/5 will cause them to miss dependencies they should know about.

**Tech Lead / Architect**: This user has enough context to spot some issues. When they notice `getName() [property_access]`, they lose confidence in the tool. One visible bug makes them question ALL output, including the parts that are correct. The tech lead may recommend against adopting kloc for the team.

### Collective Trust Impact

The combination of all 6 issues creates a layered trust problem:

1. **Layer 1** (most dangerous): Silent incompleteness (Issues 1/5) means the tool's output cannot be taken at face value. Users must independently verify completeness, which defeats the purpose of the tool.

2. **Layer 2** (reputation risk): Visible inaccuracies (Issues 2/3/4) create "war stories" -- "I tried kloc and it told me $nextId was being instantiated." These stories spread and are hard to undo.

3. **Layer 3** (philosophical): Without Issue 6's defensive design, the tool has no mechanism to self-correct. It will confidently display wrong data for any new edge case the indexer doesn't handle perfectly.

---

## 3. Priority Validation

### Proposed Order (from issues-v1.md)

1. Issue 6 (defensive fallback) -- add callee verification
2. Issue 5 (global visited set) -- fix depth-2 data loss
3. Issues 2+4 (location fixes) -- fix uses edge locations in scip-php/mapper
4. Issue 3 (call_kind fix) -- fix chained method call classification

### My Assessment: Mostly Agree, with One Reorder

The proposed order is technically sound. Issue 6 is described as "a one-line guard that immediately fixes Issues 2, 3, and 4 at the kloc-cli level." This is efficient engineering: one change addresses three symptoms.

However, from a **user impact** perspective, I would argue for a slight reorder:

**Recommended order**:

| Priority | Issue | Rationale |
|----------|-------|-----------|
| **P0** | Issue 5 | Silent data loss is the most dangerous user-facing problem. Non-determinism is unacceptable for a tool whose value is reliable analysis. Fix completeness first. |
| **P1** | Issue 6 | Now that output is complete, make it honest. The callee verification guard converts wrong data into correct inference or [unknown]. This immediately improves Issues 2, 3, 4. |
| **P2** | Issues 2+4 | Fix the root cause in scip-php/mapper so that the callee verification actually finds correct matches (rather than falling back to inference). |
| **P3** | Issue 3 | Lowest urgency because (a) the inference fallback from Issue 6 will already show [method_call] based on target type, and (b) the contradiction between getName() and [property_access] is obvious enough that users self-correct. |

**Why I prioritize Issue 5 over Issue 6**:

Issue 6 changes wrong data into correct-or-unknown data. That's a quality improvement. But Issue 5 changes **missing** data into present data. A tool that shows the right symbols with wrong labels (pre-Issue-6) is more useful than a tool that silently drops symbols entirely (pre-Issue-5). The user who sees `$nextId [instantiation]` at least knows $nextId is involved. The user who never sees `$customerEmail` doesn't know it exists.

Furthermore, Issue 5's non-determinism is a correctness bug at the algorithmic level, not a data quality issue at the matching level. It should be fixed with urgency regardless of the other issues.

**Counterargument for the original order**: Issue 6 is described as "a one-line guard" while Issue 5 requires restructuring the visited set logic. If the team can ship Issue 6 in hours but Issue 5 takes days, the ROI calculation favors the original order. The one-line guard immediately makes Issues 2/3/4 better, which is three issues mitigated for minimal effort. This is a valid engineering argument; I just want the team to be aware that Issue 5 is the more dangerous user-facing problem.

---

## 4. Design Principle Evaluation: "Consistency Over Completeness"

### The Principle

> "It is better to show `[unknown]` or omit a reference type than to show a wrong one. Wrong data erodes trust; missing data prompts investigation."

### Assessment: The Principle is Correct, with Important UX Nuances

**Why it's correct**:

1. **Trust asymmetry**: Users can recover from "I don't know" but cannot recover from "I was told something wrong." If kloc says `[instantiation]` and the user makes a decision based on that, the error is kloc's fault. If kloc says `[unknown]`, the user investigates and finds the truth themselves. The worst case is wasted time; with wrong data, the worst case is a wrong decision.

2. **AI agent behavior**: This principle is especially important for the MCP use case. AI agents treat tool output as ground truth. An `[unknown]` label tells the agent "you need to check the source code for this one." A wrong label tells the agent "proceed with confidence" -- and it will.

3. **Precedent in tooling**: Static analyzers, type checkers, and IDEs all follow this principle. TypeScript shows `any` rather than guessing. ESLint shows warnings rather than auto-fixing incorrectly. The tools that guess wrong are the ones users disable.

### UX Nuances to Consider

**Nuance 1: The word "unknown" implies the tool is broken**

In CLI output aimed at developers, `[unknown]` reads as "this tool failed." Consider these alternatives for different contexts:

| Context | Better than [unknown] | Why |
|---------|----------------------|-----|
| CLI human output | Omit the reference type entirely: just show the symbol and location | Less visual noise; the user can click through to the source |
| CLI human output (verbose) | `[unresolved]` | Implies "we know this exists but can't classify it" rather than "we have no idea" |
| JSON/MCP output | `"reference_type": null` with `"reference_type_source": "unresolved"` | Machine-parseable; agents can handle null explicitly |
| Summary line | "3 references with unresolved types" (count at end) | Quantifies the gap without polluting every entry |

**Nuance 2: Frequency matters**

If 1 in 50 entries shows `[unknown]`, users accept it as a minor limitation. If 10 in 50 show `[unknown]`, users perceive the tool as unreliable. The principle is only tenable if the fallback is rare.

Based on the investigation in the issues document, the inference fallback (`_infer_reference_type()`) will produce correct results for most cases:
- Property targets -> `[property_access]` or `[static_property]` (correct)
- Method targets -> `[method_call]` (correct)
- Class targets used as `new` -> `[instantiation]` (correct)

The only true `[unknown]` case identified is when a Class node is used as a `self::` qualifier (not a type hint, not an instantiation). This is rare. So the principle is tenable in practice because `[unknown]` will be uncommon.

**Nuance 3: The principle should be documented as a contract**

Users and agent developers need to know: "kloc guarantees that if it shows a reference type, that type is correct. If it cannot determine the type, it will either infer from the target kind or mark it as unresolved."

This is a **quality contract** that builds trust. Document it in the CLI README and the MCP tool descriptions.

### Recommendation

Adopt the principle with these specifics:

1. **CLI output**: When reference type cannot be determined from a verified Call node, use `_infer_reference_type()` which derives the type from the target node kind. This will be correct in the vast majority of cases. Only show `[unresolved]` for the rare cases where even inference cannot determine the type.

2. **JSON/MCP output**: Include a `reference_type_confidence` field: `"verified"` (from matched Call node), `"inferred"` (from target node kind), or `"unresolved"` (neither worked). This lets agents adjust their reasoning based on confidence.

3. **Never show `[unknown]` in the default CLI output.** Either infer correctly or omit the tag. The `[unknown]` label should only appear if the user explicitly requests verbose/diagnostic output.

---

## 5. Risk Assessment: Ship vs. Fix

### Risk of Shipping With These Issues

| Risk | Severity | Likelihood | Issues |
|------|----------|------------|--------|
| User makes wrong refactoring decision based on missing depth-2 data | High | Medium | 1, 5 |
| AI agent produces incorrect dependency analysis | High | High (agents trust output literally) | 2, 3, 4 |
| Tech lead encounters visible bug, recommends against adoption | Medium | Medium | 2, 3 |
| User sees wrong receiver chain, misunderstands data flow | Medium | Medium | 4 |
| User runs same query twice, gets different results | High | Low (requires specific conditions) | 5 |
| Competitor analysis shows kloc output contradictions | Low | Low | 2, 3 |

### Risk of Delaying to Fix

| Risk | Severity | Likelihood |
|------|----------|------------|
| Losing early adopter momentum | Medium | Medium |
| Scope creep: "let's fix one more thing before release" | Medium | High |
| Perfect becoming enemy of good | Medium | Medium |

### MVP Blocker Assessment

| Issue | MVP Blocker? | Rationale |
|-------|-------------|-----------|
| Issue 5 (non-deterministic data loss) | **Yes -- borderline** | Non-determinism is a correctness bug, not a feature limitation. If a user reports that results change between runs, the tool's credibility is destroyed. However, this only manifests at depth >= 2, which is an advanced feature. |
| Issue 6 (defensive fallback) | **No, but strongly recommended** | This is a quality-of-life improvement. Without it, issues 2/3/4 produce wrong labels. With it, they produce correct inferred labels. The tool works either way; it's just more trustworthy with the guard. |
| Issues 2, 3, 4 (wrong metadata) | **No** | These affect reference type labels and receiver chains, which are metadata enrichments on top of the core dependency data. The core information ("what depends on what") is still correct. Users can still see that `$nextId` is a dependency of `save()`; they just misunderstand HOW it's used. |
| Issue 1 (symptom of 5) | **N/A** | Same as Issue 5. |

### Recommended MVP Strategy

**Ship with Issues 2, 3, 4 as known limitations. Fix Issues 5 and 6 before shipping.**

The reasoning:

1. **Issue 5 must be fixed** because non-deterministic output is a class of bug that users will surface immediately. It's not a feature limitation they can work around; it's a trust-destroying correctness failure. The fix (per-subtree or per-depth visited sets) is contained within one function and does not require cross-component changes.

2. **Issue 6 should be fixed** because it's described as "a one-line guard" and it mitigates three other issues simultaneously. The cost-benefit is extremely favorable.

3. **Issues 2, 3, 4 can ship as known limitations** because:
   - They affect metadata (reference types, receiver chains), not core dependency data
   - They require cross-component fixes (scip-php + kloc-cli)
   - Issue 6's guard will convert them from "confidently wrong" to "correctly inferred" in most cases
   - They can be documented: "Reference types for some patterns (constructor named arguments, chained method calls) may use inferred types rather than precise types"

---

## 6. Product Recommendations

### Recommendation 1: Fix Issues 5 and 6 before any early adopter release

**Priority**: Must-do
**Effort**: Small-medium (Issue 6 is one guard; Issue 5 is a scoped refactor of the visited set)
**Impact**: Eliminates silent data loss and converts wrong data into honest data

Specific actions:
- Fix `_build_outgoing_tree()` to use per-subtree or per-parent visited sets (Issue 5)
- Add callee verification to `find_call_for_usage()` (Issue 6)
- Ship the result. Issues 2/3/4 are now mitigated by the inference fallback.

### Recommendation 2: Add a data quality summary line to context output

**Priority**: Should-do (for MVP)
**Effort**: Small

After the USES/USED BY tree, add a one-line summary:

```
== USES == (13 references, 2 with inferred types)
```

Or for JSON:
```json
{
  "uses_summary": {
    "total": 13,
    "verified": 11,
    "inferred": 2,
    "unresolved": 0
  }
}
```

This makes data quality visible without polluting individual entries. Users know how many entries used inference rather than precise Call node matching. Over time, as scip-php improves, these numbers trend toward 100% verified.

### Recommendation 3: Document the quality contract

**Priority**: Should-do (for MVP)
**Effort**: Small

Add to `kloc-cli/README.md` and MCP tool descriptions:

> **Reference Type Accuracy**: kloc-cli determines reference types using Call node matching when available, with type inference as a fallback. Reference types labeled as `verified` are derived from the SCIP index Call data. Reference types labeled as `inferred` are derived from the target symbol's kind. In rare cases, a reference type may be `unresolved` when neither source provides sufficient information.

This sets expectations. Users know what they're getting. Agents can use the confidence metadata.

### Recommendation 4: Track these issues in a "data quality backlog" not a "bug tracker"

**Priority**: Process recommendation
**Effort**: None

Issues 2, 3, 4 are not bugs in the traditional sense. They are data quality gaps that will shrink as scip-php's coverage improves. Frame them as a data quality backlog with measurements:

- "X% of references have verified types" (target: 95%+)
- "Y% of references have correct receiver chains" (target: 90%+)

This turns bug-fixing into metric-improving, which is better for long-term product health.

### Recommendation 5: Add a `--depth-max-verified` diagnostic flag (future)

**Priority**: Nice-to-have (post-MVP)
**Effort**: Medium

For power users and data quality debugging, a flag that shows the raw Call matching information:

```bash
kloc-cli context "OrderService::createOrder" --depth 2 --debug-matching
```

Output includes annotations:
```
[2] Order::$nextId [static_property] (line 30) -- inferred: no Call match (edge location mismatch)
```

This helps the team diagnose new edge cases and helps advanced users understand why a reference type was inferred rather than verified.

### Recommendation 6: Consider the reference project as a regression test suite

**Priority**: Should-do (during fix implementation)
**Effort**: Small

The `kloc-reference-project-php` already contains the exact patterns that trigger these issues. After fixing Issues 5 and 6, add integration tests that verify:

- Depth-2 USES for `createOrder()` returns all 10 expected entries for `save()` (guards against Issue 5 regression)
- `$nextId` shows `[static_property]` not `[instantiation]` (guards against Issue 2)
- `getName()` shows `[method_call]` not `[property_access]` (guards against Issue 3)
- `$customerEmail` in send() args shows receiver as `$savedOrder` not `$this->emailSender` (guards against Issue 4)

These become the contract tests for data quality.

---

## Summary Matrix

| Issue | User Impact | Trust Impact | MVP Blocker? | Fix Effort | Recommendation |
|-------|-------------|-------------|-------------|------------|----------------|
| 5 (data loss) | CRITICAL -- silent, non-deterministic | Destroys completeness trust | Borderline yes | Medium | Fix before release |
| 6 (defensive fallback) | HIGH -- prevents future wrong data | Establishes honesty contract | No, but strongly recommended | Small | Fix before release |
| 4 (wrong receiver) | MEDIUM-HIGH -- false data flow | Misleads about object relationships | No | Medium (cross-component) | Mitigate via Issue 6, fix later |
| 2 (wrong instantiation) | MEDIUM -- wrong label, right symbol | Confuses but doesn't hide data | No | Medium (cross-component) | Mitigate via Issue 6, fix later |
| 3 (wrong property_access) | LOW-MEDIUM -- visibly contradictory | Minor confusion, self-correctable | No | Medium (scip-php) | Mitigate via Issue 6, fix later |
| 1 (symptom of 5) | N/A -- same as Issue 5 | N/A | N/A | N/A | Fixed by Issue 5 |

### Bottom Line

Fix Issues 5 and 6 before shipping to early adopters. These two changes together restore data completeness and convert wrong metadata into honest metadata. Issues 2, 3, and 4 become "known limitations with correct fallback behavior" rather than "active bugs producing wrong output." Document the quality contract, ship, and iterate on the scip-php fixes for Issues 2/3/4 in subsequent releases.
