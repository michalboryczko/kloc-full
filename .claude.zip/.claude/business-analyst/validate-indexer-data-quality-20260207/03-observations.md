# Observations

## Issue Taxonomy

The 6 issues fall into three categories:

### Category A: Data Loss (Issues 1, 5)
- Properties missing from depth-2 output
- Root cause: global visited set + DFS iteration order
- Issue 1 is the symptom; Issue 5 is the root cause
- Non-deterministic: depends on edge iteration order

### Category B: Wrong Metadata (Issues 2, 3, 4)
- Correct symbol identified, but wrong reference type or receiver chain
- Root cause: find_call_for_usage() matches wrong Call node
- All three are deterministic: consistently wrong

### Category C: Defensive Design (Issue 6)
- Meta-issue: proposes a design principle to prevent Category B
- "Never show wrong data; prefer unknown or inferred"

## Key User Scenarios Affected

### Scenario: "What does createOrder() depend on?"
User runs: `kloc-cli context "OrderService::createOrder" --depth 2`
Expected: see all dependencies of createOrder, and all dependencies of those dependencies
Affected by: Issues 1, 2, 3, 4, 5

### Scenario: "Is it safe to refactor save()?"
User runs: `kloc-cli context "OrderRepository::save" --depth 1`
Expected: complete picture of what save() touches
Affected by: Issues 2, 4 (wrong reference types at save()'s level)

### Scenario: AI agent analyzing impact of change
Agent calls: kloc_context("OrderService::createOrder", depth=2)
Expected: structured, accurate dependency tree to reason about
Affected by: All issues -- AI agent will propagate errors into its analysis

## Silent vs Visible Issues

- Issue 5 (data loss): SILENT -- user doesn't know what they're missing. They see 7 entries and think that's complete.
- Issue 2 (wrong [instantiation]): VISIBLE to experienced PHP dev -- they know self::$nextId is not an instantiation
- Issue 3 (wrong [property_access]): VISIBLE -- getName() is obviously a method, not a property
- Issue 4 (wrong receiver): VISIBLE to careful reader -- emailSender is not the receiver of customerEmail
- Issue 1 (depth-2 missing): SILENT -- same as Issue 5, which is the root cause
- Issue 6 (design principle): N/A -- meta-issue about how to handle B-category issues
