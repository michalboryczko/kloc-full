# QA Notes: QA Preparation -- Multi-Component Test Pipeline

## Feature Summary

This feature establishes automated QA coverage for the entire kloc code intelligence pipeline by creating four test frameworks: extending the existing scip-php contract tests, plus new contract test frameworks for kloc-mapper, kloc-cli, and a full E2E integration test framework. Each component framework uses independent fixtures; only E2E uses real pipeline data.

**Spec**: `docs/specs/qa-preparation.md`
**Requirements**: `tester-agents-requirements.md`
**Existing reference**: `kloc-reference-project-php/contract-tests/` (scip-php, 235 tests)

---

## Acceptance Criteria Summary

| ID | Criterion | Framework |
|----|-----------|-----------|
| AC-1 | scip-php existing tests still pass + SCIP validation tests added | scip-php |
| AC-2 | kloc-mapper framework runs in Docker, validates 13 node kinds + 12 edge types, has docs | kloc-mapper |
| AC-3 | kloc-cli framework runs in Docker, validates 7 commands in console + JSON, has docs | kloc-cli |
| AC-4 | E2E runs full pipeline on real PHP code, validates 8 known scenarios | E2E |
| AC-5 | All frameworks handle Docker unavailable, expose help, produce machine-readable results | Cross-cutting |

---

## Test Scenarios

### Happy Path

#### HP-1: scip-php contract tests continue to pass (AC-1)

- GIVEN the existing contract test framework WHEN `bin/run.sh test` is run THEN all 205 existing passing tests still pass and 0 new regressions are introduced
- GIVEN new SCIP validation tests are added WHEN `bin/run.sh test --suite scip` is run THEN SCIP-specific tests (type hints, inheritance, symbols, occurrences) execute and pass

#### HP-2: kloc-mapper framework bootstraps and runs (AC-2)

- GIVEN a new directory `kloc-reference-project-php/contract-tests-kloc-mapper/` WHEN `bin/run.sh test` is run THEN Docker builds, pytest discovers tests, and results are printed
- GIVEN the SoTData query helper WHEN `sot_data.node(kind="Class", fqn="App\\Service\\OrderService")` is called on test output THEN the correct node is returned with matching kind, fqn, file, and range
- GIVEN a fixture containing all 13 node kinds WHEN kloc-mapper processes it THEN each kind appears in the output sot.json
- GIVEN a fixture containing all 12 edge types WHEN kloc-mapper processes it THEN each edge type appears with correct source and target

#### HP-3: kloc-cli framework bootstraps and runs (AC-3)

- GIVEN a new directory `kloc-reference-project-php/contract-tests-kloc-cli/` WHEN `bin/run.sh test` is run THEN Docker builds, pytest discovers tests, and results are printed
- GIVEN a generated sot.json fixture WHEN `kloc-cli resolve "App\Entity\Order" --sot fixture.json --json` is run THEN valid JSON output is returned with the Order class definition
- GIVEN each of the 7 commands (resolve, usages, deps, context, owners, inherit, overrides) WHEN tested with appropriate fixtures THEN correct results are returned

#### HP-4: E2E pipeline runs end-to-end (AC-4)

- GIVEN the PHP code in `kloc-reference-project-php/src/` WHEN `bin/run.sh test` is run THEN scip-php, kloc-mapper, and kloc-cli all execute sequentially and tests validate output
- GIVEN the known layered architecture pattern WHEN `usages "App\Entity\Order"` is queried THEN results include OrderRepository, OrderService, OrderController
- GIVEN the interface implementation pattern WHEN `inherit "App\Component\EmailSenderInterface" --direction down` is queried THEN EmailSender appears
- GIVEN a context query WHEN `context "App\Repository\OrderRepository::save()"` is run THEN both USES and USED BY relationships appear

#### HP-5: Documentation generation works (AC-1 through AC-4)

- GIVEN any framework WHEN `bin/run.sh docs` is run THEN a markdown report is generated with summary table, tests grouped by category, and pass/fail/skip status
- GIVEN the Python frameworks WHEN `@contract_test` decorator is used on test functions THEN metadata (name, description, category) is captured and appears in docs output

---

### Edge Cases

#### EC-1: Docker not available (AC-5)

- GIVEN Docker is not installed or not running WHEN `bin/run.sh test` is run for any framework THEN the error message says "Docker is required" (not a cryptic failure)

#### EC-2: Missing binary in path (AC-5)

- GIVEN scip-php Docker image is not built WHEN E2E `bin/run.sh test` is run THEN error says "scip-php binary not found" with build instructions
- GIVEN kloc-mapper is not installed WHEN E2E `bin/run.sh test` is run THEN error identifies kloc-mapper as the missing component
- GIVEN kloc-cli is not installed WHEN E2E `bin/run.sh test` is run THEN error identifies kloc-cli as the missing component

#### EC-3: Invalid or corrupt input (AC-5)

- GIVEN a corrupt .kloc archive WHEN kloc-mapper processes it THEN a parse error with details is shown (not a crash)
- GIVEN a malformed sot.json WHEN kloc-cli queries it THEN a meaningful JSON parse error is shown
- GIVEN an empty input directory (no PHP files) WHEN scip-php processes it THEN the error is graceful

#### EC-4: Schema version mismatch (AC-2, AC-3)

- GIVEN a sot.json with v1.0 schema (no Value/Call nodes) WHEN kloc-cli tests run against it THEN a version mismatch warning or error is shown
- GIVEN a .kloc archive without calls.json WHEN kloc-mapper processes it THEN it still produces sot.json (with nodes from SCIP only, no Value/Call nodes)

#### EC-5: Symbol not found (AC-3, AC-4)

- GIVEN a valid sot.json WHEN `kloc-cli resolve "NonExistent\Class" --sot fixture.json` is run THEN the result is an empty set (not an exception or crash)

#### EC-6: Fixture generation edge cases (AC-2, AC-3)

- GIVEN the fixture generator for kloc-mapper WHEN asked to create a .kloc with 0 documents THEN it produces a valid but minimal archive
- GIVEN the fixture generator for kloc-cli WHEN asked to create a sot.json with no edges THEN it produces valid JSON with empty edges array

---

### Error Handling

#### EH-1: Pipeline step failure in E2E (AC-4)

- GIVEN the E2E pipeline WHEN scip-php fails THEN the error message says "scip-php failed" with the exit code and stderr
- GIVEN the E2E pipeline WHEN kloc-mapper fails THEN the error message says "kloc-mapper failed" with the exit code, not just "pipeline failed"
- GIVEN the E2E pipeline WHEN kloc-cli fails THEN the error message says "kloc-cli failed" with the specific command that failed

#### EH-2: Test infrastructure failures

- GIVEN any framework WHEN Docker build fails THEN the error message includes the Docker build output (not silent failure)
- GIVEN any framework WHEN test dependencies are missing (PHPUnit/pytest) THEN the error says which dependency and how to install

#### EH-3: Timeout handling (AC-5)

- GIVEN component tests WHEN execution exceeds 2 minutes THEN a timeout error is shown
- GIVEN E2E tests WHEN execution exceeds 10 minutes THEN a timeout error is shown
- GIVEN fixture generation WHEN it exceeds 5 seconds for any single fixture THEN a warning is shown

---

### Integration

#### INT-1: Frameworks are independent (AC-5)

- GIVEN all four framework directories exist WHEN `bin/run.sh test` is run in one framework THEN it does not affect, depend on, or modify artifacts in other framework directories
- GIVEN kloc-mapper contract tests WHEN run without scip-php installed THEN tests still execute (using synthetic fixtures, not real scip-php output)
- GIVEN kloc-cli contract tests WHEN run without kloc-mapper installed THEN tests still execute (using synthetic fixtures)

#### INT-2: Shared patterns are consistent (AC-5)

- GIVEN all four frameworks WHEN `bin/run.sh help` is run in each THEN the output format is consistent (same subcommands: test, docs, help)
- GIVEN all four frameworks WHEN tests complete THEN results are available as console output AND machine-readable format (JUnit XML for PHP, JUnit XML or JSON for Python)

#### INT-3: PHP FQN notation is consistent (AC-2 through AC-4)

- GIVEN any test across any framework WHEN referencing PHP symbols THEN the notation follows PHP FQN conventions: `App\Entity\Order`, `App\Repository\OrderRepository::save()`, `App\Entity\Order::$id`

---

### Regression

#### REG-1: Existing scip-php contract tests (AC-1)

- GIVEN the current 235 tests (205 pass, 30 skipped experimental) WHEN the framework is extended THEN the same 205 tests still pass and 30 are still skipped
- GIVEN the existing test suites (smoke, integrity, reference, chain, argument, callkind, operator, scip) WHEN new categories or tests are added THEN existing test names and behaviors are unchanged

#### REG-2: Existing kloc-reference-project-php code (AC-4)

- GIVEN the reference PHP project source code WHEN E2E tests are added THEN no modifications are made to `kloc-reference-project-php/src/` (tests are read-only consumers)
- GIVEN the existing `composer.json` in `kloc-reference-project-php/` WHEN new test frameworks are added THEN no changes to the project-level composer.json

---

## Test Data / Fixtures

### Existing Artifacts (scip-php)

| Artifact | Path | Notes |
|----------|------|-------|
| calls.json | `contract-tests/output/calls.json` | Generated fresh by `bin/run.sh test` |
| index.scip | `contract-tests/output/index.scip` | SCIP protobuf index |
| index.scip.json | `contract-tests/output/index.scip.json` | JSON conversion of SCIP |

### New Artifacts Needed (kloc-mapper)

| Artifact | Path | How Generated |
|----------|------|---------------|
| Minimal .kloc fixture | `contract-tests-kloc-mapper/fixtures/minimal.kloc` | `fixture_generator.py` -- single class, one method |
| Full .kloc fixture | `contract-tests-kloc-mapper/fixtures/full.kloc` | `fixture_generator.py` -- all 13 node kinds, 12 edge types |
| Per-test .kloc fixtures | `contract-tests-kloc-mapper/fixtures/test_*.kloc` | `fixture_generator.py` -- focused on specific scenarios |
| Output sot.json | `contract-tests-kloc-mapper/output/sot.json` | Generated by kloc-mapper during test |

### New Artifacts Needed (kloc-cli)

| Artifact | Path | How Generated |
|----------|------|---------------|
| Minimal sot.json | `contract-tests-kloc-cli/fixtures/minimal.json` | `fixture_generator.py` -- simple graph |
| Full sot.json | `contract-tests-kloc-cli/fixtures/full.json` | `fixture_generator.py` -- realistic complexity |
| Per-command sot.json | `contract-tests-kloc-cli/fixtures/test_*.json` | `fixture_generator.py` -- focused per command |
| kloc-cli output | `contract-tests-kloc-cli/output/` | Captured during test |

### New Artifacts Needed (E2E)

| Artifact | Path | How Generated |
|----------|------|---------------|
| index.kloc | `contract-tests-e2e/output/index.kloc` | scip-php on `kloc-reference-project-php/src/` |
| sot.json | `contract-tests-e2e/output/sot.json` | kloc-mapper on index.kloc |
| Query results | `contract-tests-e2e/output/results/` | kloc-cli queries |
| Expected results | `contract-tests-e2e/expected/` | Manually verified snapshots |

---

## Automated Test Expectations

### Framework Validation Tests (run by QA to validate each framework)

#### Phase 1: Infrastructure Validation

| Test | Framework | What to Verify |
|------|-----------|----------------|
| Docker image builds | All 4 | `docker compose build` succeeds, image runs |
| bin/run.sh test works | All 4 | Exit code 0 when tests pass, non-zero when tests fail |
| bin/run.sh docs works | All 4 | Markdown output generated |
| bin/run.sh help works | All 4 | Usage text printed |
| Fixture generation works | kloc-mapper, kloc-cli | `fixture_generator.py` produces valid artifacts |
| Test discovery works | All 4 | pytest/PHPUnit discovers all test files |

#### Phase 2: Test Quality Validation

| Test | Framework | What to Verify |
|------|-----------|----------------|
| Every test has metadata | All 4 | `#[ContractTest]` or `@contract_test` on every test method/function |
| Every test has assertion | All 4 | No test methods that only print (no "informational only" tests except explicit report tests) |
| Category coverage complete | kloc-mapper | At least 1 test per category: smoke, node-creation, edge-creation, value-mapping, call-mapping, integrity |
| Category coverage complete | kloc-cli | At least 1 test per category: smoke, resolve, usages, deps, context, owners, inherit, overrides, output |
| Category coverage complete | E2E | At least 1 test per category: pipeline, usages, deps, inheritance, overrides, context |
| Node kind coverage | kloc-mapper | At least 1 test per node kind (13 total) |
| Edge type coverage | kloc-mapper | At least 1 test per edge type (12 total) |
| Command coverage | kloc-cli | At least 1 test per command (7 total) |

#### Phase 3: Integration Validation

| Test | Framework | What to Verify |
|------|-----------|----------------|
| Independent execution | All 4 | Each framework runs successfully when others don't exist |
| No cross-contamination | All 4 | Running one framework doesn't modify another's output/ directory |
| E2E pipeline order | E2E | scip-php runs before kloc-mapper, kloc-mapper before kloc-cli |
| Machine-readable results | All 4 | JUnit XML or JSON results are produced alongside console output |

#### Phase 4: Documentation Validation

| Test | Framework | What to Verify |
|------|-----------|----------------|
| Docs have summary table | All 4 | Generated docs include pass/fail/skip counts |
| Docs have category grouping | All 4 | Tests are grouped by category in docs |
| Docs have test descriptions | All 4 | Each test entry has name and description from metadata |
| Docs are self-consistent | All 4 | Counts in summary match number of test entries |

---

## Risk-Based Test Priority

### Critical (must test first)

1. **Docker builds succeed** -- if Docker doesn't build, nothing works
2. **bin/run.sh test runs and exits cleanly** -- the primary interface
3. **Fixture generators produce valid artifacts** -- kloc-mapper and kloc-cli test correctness depends on fixture quality
4. **E2E pipeline completes without errors** -- validates the entire chain

### High (test second)

5. **scip-php existing tests still pass** -- regression guard
6. **Query helpers return correct results** -- SoTData and OutputValidator are the assertion backbone
7. **All 13 node kinds validated** -- kloc-mapper completeness
8. **All 7 CLI commands validated** -- kloc-cli completeness
9. **bin/run.sh docs generates output** -- documentation generation

### Medium (test third)

10. **Error messages are descriptive** -- edge cases and failure modes
11. **Docker unavailability is handled** -- graceful degradation
12. **Schema version checks work** -- forward compatibility
13. **Machine-readable results produced** -- CI integration readiness
14. **Timeout handling works** -- robustness

### Low (test last)

15. **Documentation format consistency** -- cosmetic
16. **Help text accuracy** -- cosmetic
17. **PHP FQN notation consistency** -- convention adherence

---

## Fixture Strategy Risk Assessment

| Framework | Risk Level | Mitigation |
|-----------|-----------|------------|
| scip-php | Low | Already proven -- uses real scip-php output on real PHP code |
| kloc-mapper | **High** | SCIP protobuf generation is complex. Recommend hybrid: programmatic for simple unit tests, snapshot of real scip-php output for integration tests |
| kloc-cli | Medium | sot.json is plain JSON, generator is feasible. Recommend hybrid: programmatic for unit tests, real kloc-mapper output snapshots for integration tests |
| E2E | Low | No fixtures needed -- runs real pipeline. Risk is pipeline reliability, not fixture quality |

**Key recommendation from testability review:** If the kloc-mapper fixture generator (`fixture_generator.py`) proves too complex for SCIP protobuf, fall back to a snapshot approach -- run scip-php once on known PHP code, save the .kloc archive as a test fixture, and update it when the scip-php output contract changes.

---

## Validation Commands

### Quick validation (run after implementation)

```bash
# 1. scip-php contract tests (existing)
cd kloc-reference-project-php/contract-tests && bin/run.sh test

# 2. kloc-mapper contract tests (new)
cd kloc-reference-project-php/contract-tests-kloc-mapper && bin/run.sh test

# 3. kloc-cli contract tests (new)
cd kloc-reference-project-php/contract-tests-kloc-cli && bin/run.sh test

# 4. E2E integration tests (new)
cd kloc-reference-project-php/contract-tests-e2e && bin/run.sh test

# 5. Documentation generation (all frameworks)
cd kloc-reference-project-php/contract-tests && bin/run.sh docs
cd kloc-reference-project-php/contract-tests-kloc-mapper && bin/run.sh docs
cd kloc-reference-project-php/contract-tests-kloc-cli && bin/run.sh docs
cd kloc-reference-project-php/contract-tests-e2e && bin/run.sh docs
```

### Deep validation (run for sign-off)

```bash
# Verify fixture generators independently
cd kloc-reference-project-php/contract-tests-kloc-mapper && python src/fixture_generator.py --verify
cd kloc-reference-project-php/contract-tests-kloc-cli && python src/fixture_generator.py --verify

# Verify test metadata coverage
cd kloc-reference-project-php/contract-tests-kloc-mapper && bin/run.sh docs --format=json | python -c "
import json, sys
data = json.load(sys.stdin)
categories = set(t['category'] for t in data['tests'])
expected = {'smoke', 'node-creation', 'edge-creation', 'value-mapping', 'call-mapping', 'integrity'}
missing = expected - categories
print(f'Categories: {categories}')
if missing:
    print(f'MISSING: {missing}')
    sys.exit(1)
print('All categories covered')
"

# Verify E2E scenarios against expected results
cd kloc-reference-project-php/contract-tests-e2e && bin/run.sh test --verbose 2>&1 | grep -E '(PASS|FAIL|ERROR)'

# Verify framework independence
cd kloc-reference-project-php
rm -rf contract-tests-kloc-cli/  # Temporarily remove
cd contract-tests-kloc-mapper && bin/run.sh test  # Should still pass
cd .. && git checkout contract-tests-kloc-cli/  # Restore
```

---

## Pass/Fail Criteria

- **PASS**: All four frameworks run via `bin/run.sh test` with exit code 0, all acceptance criteria verified, docs generation works, no regressions in existing scip-php tests
- **FAIL**: Any framework fails to build Docker image, any `bin/run.sh test` exits non-zero for unexpected reasons, existing scip-php tests regress, fixture generators produce invalid artifacts, or any AC is not met

---

## Common Failure Modes

| Failure Mode | Symptom | Investigation |
|--------------|---------|---------------|
| Docker build failure | `bin/run.sh test` fails before any test runs | Check Dockerfile syntax, base image availability, dependency installation |
| Fixture generator produces invalid data | Tests fail with parse errors, not assertion errors | Validate fixture output independently: `python fixture_generator.py --verify` |
| SCIP protobuf generation complexity | kloc-mapper fixture generator can't produce valid .kloc | Switch to snapshot approach: use real scip-php output as fixture |
| sot.json schema mismatch | kloc-cli tests fail because fixture doesn't match schema | Check sot.json version field, compare with kloc-mapper output contract |
| E2E pipeline timeout | Tests hang or exceed time limit | Check which pipeline step is slow, add per-step timeouts |
| Python dependency conflicts | pytest fails to import test modules | Verify pyproject.toml dependencies, check Docker Python version |
| Test metadata missing | `bin/run.sh docs` produces incomplete report | Verify every test function has `@contract_test` decorator |
| Cross-framework contamination | Running one framework modifies another's output/ | Check volume mounts in docker-compose.yml, ensure output/ paths are isolated |
| scip-php regression | Existing 205 tests no longer pass | Check if any framework setup modified contract-tests/ directory |
