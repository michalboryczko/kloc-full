# QA Reference Note: Context Command v3 (Issues A-C)

**Date:** 2026-02-10
**Feature Branch:** feature/cli-context-fix
**Scope:** scip-php (ISSUE-A, ISSUE-C) + kloc-cli (all issues)
**Spec:** `docs/specs/cli-context-fix-v3.md` (24 acceptance criteria)
**Issues:** 3 issues: A (constructor promotion), B (filter signature types), C (orphan property access)
**Depends on:** v2 feature (shipped: variable-centric flow, rich args, DEFINITION section)

---

## 0. Acceptance Criteria Traceability Matrix

The spec defines 24 acceptance criteria (AC 1-24). Each is mapped to test scenarios below.

| Spec AC | Description | Test Scenarios | Test Type |
|---------|-------------|----------------|-----------|
| AC 1 | scip-php emits assigned_from for public promoted param | A-CT-01, A-CT-02 | Contract test (scip-php) |
| AC 2 | scip-php emits assigned_from for private/protected promoted param | A-CT-03 | Contract test (scip-php) |
| AC 3 | scip-php does NOT create Argument node for promoted param | A-CT-04, A-CT-05 | Contract test (scip-php) |
| AC 4 | Non-promoted params still get Argument nodes (regression) | A-CT-06 | Contract test (scip-php) |
| AC 5 | CLI shows Property FQN instead of arg[N] for promoted constructor | A-CLI-01, A-CLI-02 | CLI integration |
| AC 6 | All 6 Order constructor args resolve to Property FQNs | A-CLI-03 | CLI integration |
| AC 7 | Single promoted param resolves correctly | A-CLI-04 | CLI integration |
| AC 8 | Regular method args resolve via Argument nodes (regression) | A-CLI-05 | CLI integration |
| AC 9 | JSON includes Property FQN and type for promoted args | A-CLI-06 | CLI integration |
| AC 10 | USES excludes return_type entries for methods with DEFINITION | B-CLI-01 | CLI integration |
| AC 11 | USES excludes parameter_type entries for methods with DEFINITION | B-CLI-02 | CLI integration |
| AC 12 | Multiple parameter types all filtered | B-CLI-03 | CLI integration |
| AC 13 | property_type entries kept in USES | B-CLI-04 | CLI integration |
| AC 14 | type_hint entries kept in USES | B-CLI-05 | CLI integration |
| AC 15 | JSON uses array excludes return_type/parameter_type | B-CLI-06 | CLI integration |
| AC 16 | Non-Method queries unchanged (regression) | B-CLI-07 | CLI integration |
| AC 17 | Orphan $savedOrder->id (concat) filtered from USES | C-CLI-01 | CLI integration |
| AC 18 | Orphan sprintf property accesses filtered from USES | C-CLI-02 | CLI integration |
| AC 19 | Consumed $savedOrder->id (OrderOutput arg) remains nested | C-CLI-03 | CLI integration |
| AC 20 | Standalone property-to-local NOT filtered | C-CLI-04 | CLI integration |
| AC 21 | Receiver property access NOT filtered | C-CLI-05 | CLI integration |
| AC 22 | Genuinely standalone orphan NOT filtered | C-CLI-06 | CLI integration |
| AC 23 | JSON excludes orphan property access entries | C-CLI-07 | CLI integration |
| AC 24 | Tree and JSON output consistent for orphan filtering | C-CLI-08 | CLI integration |

---

## 1. Test Scenarios: ISSUE-A — Constructor Promotion

### 1.1 Contract Tests (scip-php) — Run BEFORE implementation

These tests validate the scip-php output (index.json / calls.json) for constructor promotion detection.

| ID | Scenario | GIVEN | WHEN | THEN | AC |
|----|----------|-------|------|------|----|
| A-CT-01 | Public promoted param creates assigned_from edge | Order::__construct() has `public int $id` | scip-php processes Order.php | index.json has a Value for `__construct().$id` that is the target of an assigned_from relationship to the Property `Order::$id` | 1 |
| A-CT-02 | All 6 Order promoted params have assigned_from | Order has 6 promoted params ($id, $customerEmail, $productId, $quantity, $status, $createdAt) | scip-php processes Order.php | Each of the 6 Value(parameter) nodes in __construct() has a corresponding assigned_from relationship to its Property node | 1 |
| A-CT-03 | Private promoted param creates assigned_from edge | OrderService::__construct() has `private OrderRepositoryInterface $orderRepository` | scip-php processes OrderService.php | Value `__construct().$orderRepository` has assigned_from to Property `OrderService::$orderRepository` | 2 |
| A-CT-04 | Promoted params have NO Argument kind nodes | Order::__construct() uses all promoted params | scip-php processes Order.php | No Value with kind=Argument exists for Order::__construct() parameters | 3 |
| A-CT-05 | All promoted constructors lack Argument nodes | All 18 promoted constructors in reference project | scip-php processes all files | None of the promoted constructors have Argument-kind child values | 3 |
| A-CT-06 | Regular method params still have Argument nodes | EmailSender::send($to, $subject, $body) is a regular method | scip-php processes EmailSender.php | send() has Argument entries for $to, $subject, $body in its parameter list (existing behavior preserved) | 4 |

**Contract test file location:** `kloc-reference-project-php/contract-tests/tests/ConstructorPromotion/`

**Note on AC 4 regression:** The reference project has 0 non-promoted constructors. We rely on regular method params (EmailSender::send) for regression testing. If a mixed constructor (both promoted and non-promoted params) is needed, we should add one to the reference project.

### 1.2 CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| A-CLI-01 | Order constructor arg shows Property FQN | `context "OrderService::createOrder"` | Order::__construct() args show `Order::$id (int): \`0\` literal` not `arg[0]` | 5 |
| A-CLI-02 | Property type shown in parentheses | Same query | `Order::$customerEmail (string)` shows the Property type from type_of edge | 5 |
| A-CLI-03 | All 6 Order args resolve | Same query | All 6 args: `Order::$id`, `Order::$customerEmail`, `Order::$productId`, `Order::$quantity`, `Order::$status`, `Order::$createdAt` | 6 |
| A-CLI-04 | Single promoted param resolves | Same query (dispatch section) | `OrderCreatedMessage::$orderId (int): \`$savedOrder->id\`` | 7 |
| A-CLI-05 | Regular method regression | Same query (checkAvailability section) | `checkAvailability().$productId (string): \`$input->productId\`` — via Argument nodes, unchanged | 8 |
| A-CLI-06 | JSON output for promoted args | `context "OrderService::createOrder" --json` | Each promoted arg has `param_fqn` containing Property FQN and `value_type` with Property type | 9 |

**Test file:** `kloc-cli/tests/test_usage_flow.py` (extend existing) or new `test_context_v3.py`

**Fixture dependency:** Tests A-CLI-01 through A-CLI-06 require:
1. scip-php ISSUE-A changes complete (assigned_from edges emitted)
2. sot.json regenerated with new edges
3. Until then, use synthetic sot.json fixtures with assigned_from edges

---

## 2. Test Scenarios: ISSUE-B — Filter Signature Types

### CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| B-CLI-01 | return_type entry removed | `context "OrderService::createOrder"` | No `OrderOutput [return_type]` entry in USES section | 10 |
| B-CLI-02 | parameter_type entry removed | Same query | No `CreateOrderInput [parameter_type]` entry in USES section | 11 |
| B-CLI-03 | Multiple parameter types filtered | Method with 2+ typed params | None of the parameter_type entries appear in USES | 12 |
| B-CLI-04 | property_type entries kept | `context "App\Entity\Order"` (class query) | `int [property_type]`, `string [property_type]` still present in USES | 13 |
| B-CLI-05 | type_hint entries kept | Method with instanceof check | `[type_hint]` entry remains in USES | 14 |
| B-CLI-06 | JSON excludes filtered types | `--json` output | `uses` array has no entries with `reference_type: "return_type"` or `"parameter_type"` | 15 |
| B-CLI-07 | Class query unchanged (regression) | `context "App\Repository\InMemoryOrderRepository"` | Class-level USES still shows structural type references | 16 |

**Test file:** `kloc-cli/tests/test_usage_flow.py` (extend)

**Existing test impact:**
- `test_t1_3_parameter_type_shows_parameter_type` — will FAIL (parameter_type removed from USES). Must be updated or marked xfail.
- `test_t1_4_return_type_shows_return_type` — will FAIL (return_type removed from USES). Must be updated or marked xfail.
- `test_no_bare_type_hint_for_param_or_return` — logic still valid but assertions about presence of entries need review.

---

## 3. Test Scenarios: ISSUE-C — Filter Orphan Property Access

### CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| C-CLI-01 | Concat orphan filtered | `context "OrderService::createOrder"` | No top-level `Order::$id [property_access]` at line 49/50 | 17 |
| C-CLI-02 | sprintf orphans filtered | Same query | No top-level `Order::$id`, `Order::$productId`, `Order::$quantity` at lines 52-55 | 18 |
| C-CLI-03 | Consumed instance preserved | Same query | `Order::$id` at line 61 is nested inside OrderOutput constructor args | 19 |
| C-CLI-04 | Standalone property-to-local NOT filtered | Same query | `$this->orderRepository` appears as Kind 1 variable `on:` inside method calls (receiver chain) | 20 |
| C-CLI-05 | Receiver property access NOT filtered | Same query | `$this->inventoryChecker` appears as `on:` inside checkAvailability entry | 21 |
| C-CLI-06 | Genuinely standalone orphan kept | Synthetic fixture with orphan access not in any expression | Property access remains as top-level entry | 22 |
| C-CLI-07 | JSON excludes orphans | `--json` output | `uses` array does not contain orphan property access entries | 23 |
| C-CLI-08 | Tree/JSON consistency | Both `context` and `context --json` | Same entries present/absent in both formats | 24 |

**Test file:** `kloc-cli/tests/test_usage_flow.py` (extend)

### Orphan identification logic

An entry is an orphan property access if ALL of the following are true:
1. It is a top-level entry (not nested inside another entry)
2. Its `member_ref.reference_type` is `"property_access"`
3. Its result Value is NOT consumed by any Call via receiver/argument edge
4. The property's short name (e.g., `$savedOrder->id`) appears in an argument `value_expr` of another top-level entry

If condition 4 is NOT met, the orphan is genuinely standalone and should be kept (C-CLI-06).

---

## 4. Test Infrastructure

### 4.1 Existing Test Impact Summary

| File | Tests | Impact |
|------|-------|--------|
| `test_usage_flow.py::TestPhase1ReferenceTypeDistinction` | `test_t1_3_parameter_type` | WILL FAIL after ISSUE-B (entry removed) |
| `test_usage_flow.py::TestPhase1ReferenceTypeDistinction` | `test_t1_4_return_type` | WILL FAIL after ISSUE-B (entry removed) |
| `test_usage_flow.py::TestPhase2ArgumentTracking` | `test_t2_2_constructor_shows_arguments` | May need update for Property FQN labels after ISSUE-A |
| `test_usage_flow.py::TestPhase1ExpressionDisplay` | Various | Should still pass (expressions unchanged) |
| `test_usage_flow.py::TestValueTypeResolution` | Various | Should still pass |
| `test_usage_flow.py::TestPhase4ParamFqn` | Various | May need update for promoted constructors |
| Contract tests (PHPUnit, 235 total) | 205 pass, 30 skip | Baseline clean. New contract tests for ISSUE-A |

### 4.2 New Test Files

**scip-php contract tests:**
- `kloc-reference-project-php/contract-tests/tests/ConstructorPromotion/ConstructorPromotionTest.php`

**CLI tests:**
- Extend `kloc-cli/tests/test_usage_flow.py` with new test classes:
  - `TestV3IssueAConstructorPromotion`
  - `TestV3IssueBFilterSignatureTypes`
  - `TestV3IssueCOrphanPropertyAccess`

### 4.3 Fixture Requirements

| Fixture | Used By | Status | Action |
|---------|---------|--------|--------|
| Reference project sot.json | Integration tests (all issues) | EXISTS but needs regeneration | Regenerate after scip-php ISSUE-A changes |
| Synthetic sot.json with assigned_from to Property | A-CLI-01 through A-CLI-06 (interim) | NEEDS CREATION | Small fixture: promoted constructor with assigned_from edges |
| Synthetic sot.json with orphan + expression match | C-CLI-06 | NEEDS CREATION | Fixture with standalone orphan access |
| Reference project index.json | Contract tests A-CT-01 through A-CT-06 | Auto-generated by bin/run.sh | No action needed |

---

## 5. Regression Risks

### 5.1 High Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| Existing Argument resolution | Regular methods (send, checkAvailability, save) must keep working via Argument nodes | A-CLI-05, A-CT-06 test regression |
| USES entry count changes | ISSUE-B removes 2+ entries, ISSUE-C removes 3-4 entries | Tests that assert exact entry counts need updating |
| JSON structure | Consumers reading `uses` array get fewer entries | ISSUE-B/C are subtractive only; definition object unchanged |

### 5.2 Medium Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| Orphan heuristic false positives | Property name coincidentally matches unrelated expression | Use full expression fragment (e.g., `$savedOrder->id`) not just `$id` |
| Mixed constructor handling | Constructor with both promoted and non-promoted params | Edge case test needed (not in reference project) |

### 5.3 Low Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| Performance | Expression-match heuristic O(orphans * entries * args) | Typical methods <20 entries, negligible |
| assigned_from fallback triggering incorrectly | Could fire for methods that aren't promoted constructors | Fallback only triggers when zero Argument children exist |

---

## 6. Phase Gate Checklists

### Phase 1 Gate (ISSUE-A)

```
[ ] Contract tests A-CT-01 through A-CT-06 pass (scip-php)
[ ] CLI tests A-CLI-01 through A-CLI-06 pass
[ ] sot.json regenerated with assigned_from edges
[ ] All 18 promoted constructors show Property FQN labels
[ ] Regular method args unchanged (regression: checkAvailability, send, save)
[ ] JSON output includes param_fqn and value_type for promoted args
[ ] Existing test suite: 56+ tests green (with xfail for expected breakage)
```

### Phase 2 Gate (ISSUE-B + ISSUE-C, parallel)

```
[ ] CLI tests B-CLI-01 through B-CLI-07 pass
[ ] CLI tests C-CLI-01 through C-CLI-08 pass
[ ] USES section starts with execution flow, no redundant type entries
[ ] No orphan property access entries in createOrder output
[ ] property_type and type_hint entries preserved
[ ] Consumed property accesses still nested correctly
[ ] JSON output matches tree output for both ISSUE-B and ISSUE-C
[ ] Full regression: all automated tests green
[ ] Combined output matches spec "Combined Expected Output" section
```

---

## 7. Manual Testing Steps

```bash
# ISSUE-A: Verify promoted constructor args
cd /Users/michal/dev/ai/kloc/kloc-cli
uv run kloc-cli context "OrderService::createOrder" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json
# Check: Order::__construct args show Property FQNs, not arg[N]

# ISSUE-B: Verify no return_type/parameter_type in USES
# Check: USES starts with execution flow entries, no [return_type] or [parameter_type]

# ISSUE-C: Verify no orphan property accesses
# Check: No standalone Order::$id, Order::$productId, Order::$quantity entries

# JSON verification
uv run kloc-cli context "OrderService::createOrder" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json --json | python -m json.tool
# Check: uses array has no return_type/parameter_type entries
# Check: uses array has no orphan property_access entries
# Check: promoted constructor args have param_fqn with Property FQN

# Class-level regression
uv run kloc-cli context "App\Entity\Order" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json
# Check: property_type entries still present
```

---

## 8. Contract Test Mode: ISSUE-A Setup

### Pre-implementation state
- Current contract test baseline: 205 pass, 0 fail, 30 skip
- New contract tests will be created BEFORE scip-php implementation
- Expected: new tests will FAIL until scip-php changes are made

### Contract test scenarios for ISSUE-A
See section 1.1 above (A-CT-01 through A-CT-06).

### Test creation approach
1. Use `kloc-scip-contract-scenarios` skill to generate scenarios
2. Use `kloc-scip-contract-test-create` skill to create PHPUnit tests
3. Verify tests run (expected: fail before implementation, pass after)
4. After implementation: run full suite to verify no regressions
