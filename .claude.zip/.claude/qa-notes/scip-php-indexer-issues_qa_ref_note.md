# QA Testing Notes: scip-php-indexer-issues

## Feature Summary

This feature fixes 6 data quality issues in the scip-php indexer pipeline (scip-php -> kloc-mapper -> kloc-cli) that cause incorrect reference types, missing depth-2 entries, and misattributed receiver chains in `kloc-cli context` output. The core design principle is "consistency over completeness" -- never display a confidently wrong reference type.

**Spec**: `docs/specs/scip-php-indexer-issues.md`
**Plan**: `docs/specs/scip-php-indexer-issues-plan.md`
**Issues**: `.claude/feature-issues/scip-php-indexer-issues/issues-v1.md`
**Progress**: `.claude/progress/scip-php-indexer-issues.md`

---

## Issue Summary

| # | Issue | Component | Severity |
|---|-------|-----------|----------|
| 1 | Missing property accesses at depth 2 (symptom of #5) | kloc-cli | High |
| 2 | Constructor args inherit `[instantiation]` type | kloc-cli / scip-php | Medium |
| 3 | `getName()` misclassified as `[property_access]` | scip-php | Medium |
| 4 | Named args misattributed to enclosing call receiver | scip-php / kloc-cli | Medium |
| 5 | Global visited set drops depth-2 entries (root cause of #1) | kloc-cli | High |
| 6 | Defensive fallback: never display incorrect data | kloc-cli / scip-php | High |

---

## Acceptance Criteria

| ID | Criterion | Issues |
|----|-----------|--------|
| AC1 | `find_call_for_usage()` never returns a Call node whose callee does not match the usage target | 6 |
| AC2 | Depth-2 subtrees show all dependencies of the expanded method, regardless of what depth-1 entries exist | 1, 5 |
| AC3 | `OrderRepository::$nextId` at line 30 shows `[static_property]`, not `[instantiation]` | 2 |
| AC4 | `AbstractOrderProcessor::getName()` at line 43 shows `[method_call]`, not `[property_access]` | 3 |
| AC5 | `Order::$customerEmail` at line 48 shows correct receiver (`$savedOrder`), not `$this->emailSender` | 4 |
| AC6 | When Call matching fails, output shows inference-based type or `[unknown]` -- never a wrong type | 6 |
| AC7 | Depth-2 output from `createOrder --depth 2` includes `$customerEmail` (line 31) and `$productId` (line 32) under `save()` | 1, 5 |
| AC8 | All existing tests continue to pass (no regressions) | All |

---

## Pipeline Setup

Every test MUST execute the full pipeline. A runtime error at any step is an automatic FAIL.

```bash
# Step 1: Generate SCIP index
cd scip-php && ./bin/scip-php.sh -d ../kloc-reference-project-php -o /tmp/kloc-test-output

# Step 2: Generate sot.json (unified graph format)
cd kloc-mapper && uv run kloc-mapper map /tmp/kloc-test-output/index.kloc -o /tmp/kloc-test-output/sot.json

# Step 3: Run context queries
cd kloc-cli && uv run kloc-cli context "SYMBOL" --sot /tmp/kloc-test-output/sot.json --depth N
```

Test data source: `kloc-reference-project-php/` ONLY.

SOT path shorthand: `{sot}` = `/tmp/kloc-test-output/sot.json`

Pre-generated fixture shorthand: `{fixture-sot}` = `kloc-reference-project-php/contract-tests/output/sot.json`

---

## Test Data / Fixtures

### Source Files

| File | Key Code | Relevant Lines |
|------|----------|----------------|
| `kloc-reference-project-php/src/Repository/OrderRepository.php` | `save()` method with constructor, static property, property accesses | Lines 26-45 |
| `kloc-reference-project-php/src/Service/OrderService.php` | `createOrder()` method with chained calls, named args, constructor | Lines 28-68 |
| `kloc-reference-project-php/src/Entity/Order.php` | Readonly entity with constructor property promotion | Lines 9-19 |

### Critical Code Blocks (for reference during testing)

**OrderRepository::save() lines 26-45** (Issues 1, 2, 5):
```php
public function save(Order $order): Order               // line 26
{
    if ($order->id === 0) {                              // line 28
        $newOrder = new Order(                           // line 29 - constructor call
            id: self::$nextId++,                         // line 30 - static property access
            customerEmail: $order->customerEmail,        // line 31 - property access
            productId: $order->productId,                // line 32 - property access
            quantity: $order->quantity,                   // line 33 - property access
            status: $order->status,                      // line 34 - property access
            createdAt: $order->createdAt,                // line 35 - property access
        );
        self::$orders[$newOrder->id] = $newOrder;        // line 37 - static property access
```

**OrderService::createOrder() lines 28-58** (Issues 3, 4):
```php
public function createOrder(CreateOrderInput $input): OrderOutput  // line 28
{
    $this->inventoryChecker->checkAvailability(...);     // line 30 - chained method call
    $order = new Order(                                  // line 32 - constructor call
        id: 0,                                           // line 33
        customerEmail: $input->customerEmail,            // line 34
        productId: $input->productId,                    // line 35
        quantity: $input->quantity,                       // line 36
        status: 'pending',                               // line 37
        createdAt: new DateTimeImmutable(),               // line 38
    );
    $processedOrder = $this->orderProcessor->process($order);  // line 42 - chained method call
    $processorName = $this->orderProcessor->getName();   // line 43 - chained method call (Issue 3)
    $savedOrder = $this->orderRepository->save($processedOrder);  // line 45 - method call
    $this->emailSender->send(                            // line 47 - method call via property
        to: $savedOrder->customerEmail,                  // line 48 - property access (Issue 4)
        subject: 'Order Confirmation #' . $savedOrder->id,  // line 49
        ...
    );
    $this->messageBus->dispatch(new OrderCreatedMessage($savedOrder->id));  // line 58
```

### Pre-generated Artifacts

- `kloc-reference-project-php/contract-tests/output/sot.json` -- unified graph (v2.0)
- `kloc-reference-project-php/contract-tests/output/calls.json` -- raw calls data
- `kloc-reference-project-php/contract-tests/output/index.scip` -- SCIP index

Note: After scip-php changes (Phases 3 and 4), these fixtures MUST be regenerated.

### Test Data Integrity Pre-Check

Before running any test scenario, validate the test data is usable:

```bash
# Verify sot.json exists and is valid JSON
python3 -c "import json; json.load(open('{fixture-sot}')); print('sot.json valid')"

# Verify save() has uses edges to the expected targets
cd kloc-cli && python3 -c "
import json
with open('{fixture-sot}') as f:
    data = json.load(f)
save_edges = [e for e in data.get('edges', []) if 'save' in e.get('source', '') and e.get('type') == 'uses']
print(f'save() uses edges: {len(save_edges)}')
for e in save_edges:
    loc = e.get('location', {})
    print(f'  -> {e[\"target\"][:60]}  line={loc.get(\"line\", \"N/A\")}')
"

# Verify Call nodes exist for key lines
cd kloc-cli && python3 -c "
import json
with open('{fixture-sot}') as f:
    data = json.load(f)
calls = [n for n in data.get('nodes', []) if n.get('kind') == 'Call']
for c in calls:
    r = c.get('range', {})
    line = r.get('start_line', -1)
    if line in [29, 30, 31, 32, 43, 45, 47, 48]:
        print(f'Call at line {line}: kind={c.get(\"call_kind\")}, id={c[\"id\"][:40]}')
"
```

---

## Test Scenarios

### Category 1: Callee Verification Guard (Phase 1 -- Issue 6)

#### Scenario 1.1: find_call_for_usage rejects wrong Call node (AC1)

**Scenario**: When multiple Call nodes exist at the same line, callee verification prevents matching the wrong one.

**Command**: `kloc-cli context "App\Repository\OrderRepository::save" --sot {sot} --depth 1`

| Check | Expected | AC |
|-------|----------|----|
| 1.1.1 | `$nextId` at line 30 shows `[static_property]` (from inference), NOT `[instantiation]` | AC3 |
| 1.1.2 | `OrderRepository` (class) at line 30 shows `[type_hint]` or `[instantiation]` appropriately -- not `[instantiation]` from a mismatched constructor Call | AC6 |
| 1.1.3 | The constructor `new Order(...)` at line 29 still shows `[instantiation]` correctly | AC6 |

**Why this works**: Line 30 has both the `new Order(` constructor Call (which spans from line 29) and the `self::$nextId++` access. Without callee verification, `find_call_for_usage()` picks the constructor (wrong target) for `$nextId`. With the fix, it rejects the constructor (callee is `Order::__construct`, not `OrderRepository::$nextId`), returns None, and `_infer_reference_type()` correctly identifies Property -> `static_property`.

**Edge Case**: If there is no Call node at the correct line at all (uses edge has wrong location pointing to line 29), the function should return None and fall back to inference.

---

#### Scenario 1.2: Method call correctly classified after guard (AC4)

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 1`

| Check | Expected | AC |
|-------|----------|----|
| 1.2.1 | `AbstractOrderProcessor::getName()` at line 43 shows `[method_call]`, NOT `[property_access]` | AC4 |
| 1.2.2 | `AbstractOrderProcessor::process()` at line 42 shows `[method_call]` | AC6 |
| 1.2.3 | `OrderRepository::save()` at line 45 shows `[method_call]` | AC6 |

**Why**: The Call node for `getName()` has `call_kind=access` (scip-php bug, Issue 3). With callee verification, if the wrong Call is matched, it falls through to inference. `_infer_reference_type()` sees a Method target and returns `method_call`.

**Nuance on Phase 1 vs Phase 4**: After Phase 1, `getName()` shows `[method_call]` via inference fallback. After Phase 4 (scip-php `call_kind` fix), it shows `[method_call]` from the Call node directly. Both are correct for AC4, but the mechanism differs. To distinguish: check whether `access_chain` is populated (Call-based) or absent (inference-based).

---

#### Scenario 1.3: Named argument property access has correct receiver (AC5)

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 1 --impl`

| Check | Expected | AC |
|-------|----------|----|
| 1.3.1 | `Order::$customerEmail` at line 48 shows `[property_access]`, NOT `[method_call]` | AC5 |
| 1.3.2 | Receiver for `$customerEmail` at line 48 is `$savedOrder` (or `Order`), NOT `$this->emailSender` | AC5 |
| 1.3.3 | `EmailSenderInterface::send()` at line 47 still shows `[method_call]` with `on: $this->emailSender` | AC6 |

**Why**: The `$savedOrder->customerEmail` access at line 48 is inside `send()` argument list. Without callee verification, `find_call_for_usage()` matches the enclosing `send()` Call node (which spans lines 47-56), inheriting its `[method_call]` type and `$this->emailSender` receiver. With verification, the `send()` Call is rejected (callee is `EmailSenderInterface::send`, not `Order::$customerEmail`), and inference correctly returns `property_access`.

**Important**: After Phase 1 (callee verification only), the access_chain for `$customerEmail` at line 48 will be `None` (inference path has no Call node). After Phase 3 (scip-php location fix), a separate Call node for `$savedOrder->customerEmail` should exist with `receiver=$savedOrder`, providing the correct access chain.

---

#### Scenario 1.4: find_call_for_usage returns None gracefully

**Automated test**: Unit test in `kloc-cli/tests/test_callee_verification.py`

| Check | Expected | AC |
|-------|----------|----|
| 1.4.1 | When all Call nodes at matching line have wrong callee targets, returns None | AC1 |
| 1.4.2 | When `call_children` list is empty, returns None without error | AC1 |
| 1.4.3 | When no Call node exists at the given line, returns None | AC1 |
| 1.4.4 | When correct Call node exists, returns its ID (not broken by the guard) | AC1 |

---

### Category 2: Per-Subtree Visited Set (Phase 2 -- Issue 5)

#### Scenario 2.1: Depth-2 subtree shows complete dependencies (AC2, AC7)

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 2`

| Check | Expected | AC |
|-------|----------|----|
| 2.1.1 | `save()` subtree at depth 2 includes `Order::$customerEmail` (line 31) | AC7 |
| 2.1.2 | `save()` subtree at depth 2 includes `Order::$productId` (line 32) | AC7 |
| 2.1.3 | `save()` subtree at depth 2 includes `Order::$quantity` (line 33) | AC2 |
| 2.1.4 | `save()` subtree at depth 2 includes `Order::$status` (line 34) | AC2 |
| 2.1.5 | `save()` subtree at depth 2 includes `Order::$createdAt` (line 35) | AC2 |
| 2.1.6 | `save()` subtree at depth 2 includes `Order::$id` (line 28) | AC2 |
| 2.1.7 | `save()` subtree at depth 2 includes `OrderRepository [instantiation]` (line 29/30) | AC2 |
| 2.1.8 | `save()` subtree at depth 2 includes `OrderRepository::$nextId` (line 30) | AC2 |
| 2.1.9 | `save()` subtree at depth 2 includes `OrderRepository::$orders` (line 37) | AC2 |
| 2.1.10 | Total depth-2 entries under `save()` is at least 9 (was 7 before fix, should be 9-10) | AC2 |

**Why this is critical**: The global `visited` set caused DFS-order-dependent data loss. When `createOrder()` iterates `$customerEmail` and `$productId` at depth 1 before reaching `save()`, those targets are added to the global visited set and then skipped at depth 2. The fix uses per-parent (or per-branch) visited sets so depth-2 expansion is independent.

**Non-determinism note**: Before the fix, the missing entries at depth 2 could vary depending on edge iteration order from `get_deps()`. If the test data happens to iterate `save()` before the overlapping properties, the bug would not manifest. Always test with the actual kloc-reference-project-php data where this ordering issue is known to occur.

---

#### Scenario 2.2: Same target appears at depth 1 AND depth 2

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 2`

| Check | Expected | AC |
|-------|----------|----|
| 2.2.1 | `Order::$customerEmail` appears at depth 1 (from createOrder direct usage) | AC2 |
| 2.2.2 | `Order::$customerEmail` also appears at depth 2 under `save()` subtree | AC2 |
| 2.2.3 | `Order::$productId` appears at both depth 1 and depth 2 | AC2 |
| 2.2.4 | No duplicate entries at the SAME depth under the SAME parent | AC2 |

**Edge Case**: Within a single parent's uses list at the same depth, deduplication should still apply. Only cross-depth/cross-parent deduplication is removed.

---

#### Scenario 2.3: Direct depth-1 query unaffected (regression check)

**Command**: `kloc-cli context "App\Repository\OrderRepository::save" --sot {sot} --depth 1`

| Check | Expected | AC |
|-------|----------|----|
| 2.3.1 | Depth-1 output shows all 10 uses of `save()` (unchanged from before) | AC8 |
| 2.3.2 | Output includes `Order [type_hint]` (line 26) | AC8 |
| 2.3.3 | Output includes `Order::$id` (line 28) | AC8 |
| 2.3.4 | Output includes `Order::$customerEmail` (line 31) | AC8 |
| 2.3.5 | Output includes `Order::$productId` (line 32) | AC8 |

---

#### Scenario 2.4: No infinite loops with cyclic references

**Automated test**: Integration test in `kloc-cli/tests/test_usage_flow.py`

| Check | Expected | AC |
|-------|----------|----|
| 2.4.1 | Self-referencing methods do not cause infinite recursion | AC8 |
| 2.4.2 | The `start_id` is still in the initial visited set for cycle prevention | AC8 |
| 2.4.3 | Query completes within reasonable time (no hangs) | AC8 |

---

### Category 3: Uses Edge Location Accuracy (Phase 3 -- Issues 2, 4)

#### Scenario 3.1: self::$nextId uses edge has correct location

**Validation method**: Inspect sot.json for the uses edge from `save()` to `OrderRepository::$nextId`

| Check | Expected | AC |
|-------|----------|----|
| 3.1.1 | Uses edge location has `line=30` (the line of `self::$nextId++`), NOT `line=29` (the line of `new Order(`) | AC3 |
| 3.1.2 | The Call node at line 30 with `call_kind=access_static` matches the uses edge line | AC3 |
| 3.1.3 | After location fix, `find_call_for_usage()` matches the correct `access_static` Call node directly (not via fallback inference) | AC3 |

**Manual inspection step**:
```bash
# Check uses edge location in sot.json
cd kloc-cli && python3 -c "
import json
with open('{fixture-sot}') as f:
    data = json.load(f)
# Search for uses edge from save() to \$nextId and check its location
for edge in data.get('edges', []):
    if edge.get('type') == 'uses' and 'nextId' in edge.get('target', ''):
        print(json.dumps(edge, indent=2))
"
```

**Distinguishing Phase 1 vs Phase 3**: After Phase 1, `$nextId` shows `[static_property]` via inference. After Phase 3, it should show `[static_property]` from the `access_static` Call node. To verify Phase 3 is working: the access chain should be populated (e.g., `on: self`) when matching the correct Call node directly, rather than being absent from inference.

---

#### Scenario 3.2: $savedOrder->customerEmail has separate occurrence

**Validation method**: Inspect sot.json/calls.json

| Check | Expected | AC |
|-------|----------|----|
| 3.2.1 | The property access `$savedOrder->customerEmail` at line 48 has its own Call node | AC5 |
| 3.2.2 | That Call node has `call_kind=access` and callee pointing to `Order::$customerEmail` | AC5 |
| 3.2.3 | The Call node's receiver points to `$savedOrder` (a Value node), NOT to `$this->emailSender` | AC5 |
| 3.2.4 | The uses edge from `createOrder()` to `Order::$customerEmail` at line 48 has location `line=48` | AC5 |

---

### Category 4: call_kind for Chained Method Calls (Phase 4 -- Issue 3)

#### Scenario 4.1: getName() has correct call_kind in raw data

**Validation method**: Inspect calls.json after scip-php fix

| Check | Expected | AC |
|-------|----------|----|
| 4.1.1 | Call node for `getName()` at line 43 has `call_kind=method`, NOT `call_kind=access` | AC4 |
| 4.1.2 | Call node callee is `AbstractOrderProcessor::getName` | AC4 |
| 4.1.3 | After this fix, kloc-cli shows `[method_call]` directly from the Call node (not from inference fallback) | AC4 |

**Manual inspection step**:
```bash
# Check calls.json for getName() call kind
cd kloc-reference-project-php && python3 -c "
import json
with open('contract-tests/output/calls.json') as f:
    data = json.load(f)
for call in data:
    if 'getName' in call.get('callee', ''):
        print(json.dumps(call, indent=2))
"
```

---

#### Scenario 4.2: Chained expression with 3+ levels

**Source reference**: `$this->orderProcessor->getName()` is a 2-level chain. If test data includes deeper chains, verify each level.

| Check | Expected | AC |
|-------|----------|----|
| 4.2.1 | In `$this->orderProcessor->getName()`, `orderProcessor` is `[property_access]` and `getName()` is `[method_call]` | AC4 |
| 4.2.2 | Each level of the chain has its own Call node with the appropriate `call_kind` | AC4 |

---

### Category 5: End-to-End Validation

#### Scenario 5.1: Full createOrder depth-2 output (all ACs)

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 2`

This single command validates the majority of acceptance criteria. Verify the USES output against the expected tree:

```
== USES ==
[depth 1 entries from createOrder() - ordered by line]
...
|- [1] App\Repository\OrderRepository::save() [method_call] (line 45)
|   on: $this->orderRepository (App\Service\OrderService::$orderRepository)
|   |- [2] App\Entity\Order [type_hint] (line 26)
|   |- [2] App\Entity\Order::$id [property_access] (line 28)
|   |- [2] App\Repository\OrderRepository [instantiation] (line 29 or 30)
|   |- [2] App\Repository\OrderRepository::$nextId [static_property] (line 30)    <- AC3
|   |- [2] App\Entity\Order::$customerEmail [property_access] (line 31)           <- AC7
|   |- [2] App\Entity\Order::$productId [property_access] (line 32)              <- AC7
|   |- [2] App\Entity\Order::$quantity [property_access] (line 33)
|   |- [2] App\Entity\Order::$status [property_access] (line 34)
|   |- [2] App\Entity\Order::$createdAt [property_access] (line 35)
|   |- [2] App\Repository\OrderRepository::$orders [static_property] (line 37)
...
|- [1] App\Service\AbstractOrderProcessor::getName(): string [method_call] (line 43)  <- AC4
...
|- [1] App\Entity\Order::$customerEmail [property_access] (line 48)               <- AC5
|   on: $savedOrder (App\Entity\Order)                                            <- AC5 (correct receiver)
...
```

| Check | Expected | AC |
|-------|----------|----|
| 5.1.1 | `$nextId` at depth 2 under save() shows `[static_property]` | AC3 |
| 5.1.2 | `getName()` at depth 1 shows `[method_call]` | AC4 |
| 5.1.3 | `$customerEmail` at depth 1 (line 48) shows `[property_access]` with receiver `$savedOrder` | AC5 |
| 5.1.4 | `$customerEmail` at depth 2 under save() (line 31) is present | AC7 |
| 5.1.5 | `$productId` at depth 2 under save() (line 32) is present | AC7 |
| 5.1.6 | No entry shows a wrong reference type from an unrelated Call node | AC6 |
| 5.1.7 | Depth-2 subtree under save() has at least 9 entries | AC2 |

---

#### Scenario 5.2: JSON output correctness

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 2 --json`

| Check | Expected | AC |
|-------|----------|----|
| 5.2.1 | JSON is valid and parseable | AC8 |
| 5.2.2 | `member_ref.reference_type` values match the text output | AC6 |
| 5.2.3 | `member_ref.access_chain` for `$customerEmail` at line 48 shows `$savedOrder`, not `$this->emailSender` | AC5 |
| 5.2.4 | Depth-2 entries are nested correctly under their parent entries | AC2 |

**JSON validation script**:
```bash
cd kloc-cli && uv run kloc-cli context "App\Service\OrderService::createOrder" \
    --sot {sot} --depth 2 --json | python3 -c "
import json, sys
data = json.load(sys.stdin)
uses = data.get('uses', [])

# Find save() entry and check depth-2 children
for entry in uses:
    if 'save' in entry.get('fqn', ''):
        children = entry.get('children', [])
        child_fqns = [c.get('fqn', '') for c in children]
        print(f'save() depth-2 children ({len(children)}):')
        for c in children:
            ref = c.get('member_ref', {})
            print(f'  {c.get(\"fqn\", \"?\")} [{ref.get(\"reference_type\", \"?\")}] (line {c.get(\"line\", \"?\")})')

        # Check for critical entries
        has_email = any('customerEmail' in f for f in child_fqns)
        has_product = any('productId' in f for f in child_fqns)
        print(f'customerEmail present: {has_email}')
        print(f'productId present: {has_product}')

# Check $customerEmail at line 48 receiver
for entry in uses:
    if 'customerEmail' in entry.get('fqn', ''):
        ref = entry.get('member_ref', {})
        line = entry.get('line')
        if line == 48 or line == 47:
            print(f'customerEmail at line {line}: chain={ref.get(\"access_chain\")}, type={ref.get(\"reference_type\")}')
"
```

---

### Category 6: Regression Tests

#### Scenario 6.1: Existing automated test suites pass (AC8)

**Commands**:
```bash
# kloc-cli unit + integration tests
cd kloc-cli && uv run pytest tests/ -v

# kloc-mapper tests
cd kloc-mapper && uv run pytest tests/ -v

# scip-php contract tests
cd kloc-reference-project-php/contract-tests && bin/run.sh test
```

| Check | Expected | AC |
|-------|----------|----|
| 6.1.1 | All tests in `test_usage_flow.py` pass (TC1-TC8, EC1, OF3) | AC8 |
| 6.1.2 | All tests in `test_reference_type.py` pass | AC8 |
| 6.1.3 | All tests in `test_index.py` pass | AC8 |
| 6.1.4 | kloc-mapper tests pass | AC8 |
| 6.1.5 | scip-php contract tests pass | AC8 |

---

#### Scenario 6.2: Backward compatibility with v1.0 sot.json

**Setup**: Use a sot.json that lacks Value/Call nodes (v1.0 format).

| Check | Expected | AC |
|-------|----------|----|
| 6.2.1 | Context query runs without crashes | AC8 |
| 6.2.2 | All references fall back to inference (no Call-based matching) | AC6 |
| 6.2.3 | Reference types are still reasonable (method_call, property_access, type_hint) | AC6 |

---

#### Scenario 6.3: Other context command flags still work

**Commands**:
```bash
kloc-cli context "App\Repository\OrderRepository" --sot {sot} --depth 2 --impl
kloc-cli context "App\Repository\OrderRepository" --sot {sot} --depth 1 --direct
kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 1 --with-imports
```

| Check | Expected | AC |
|-------|----------|----|
| 6.3.1 | `--impl` flag resolves interface implementations correctly | AC8 |
| 6.3.2 | `--direct` flag filters to direct references only | AC8 |
| 6.3.3 | `--with-imports` flag includes type_hint/import lines | AC8 |

---

## Automated Test Expectations

### New unit tests (Phase 1)

File: `kloc-cli/tests/test_callee_verification.py`

| Test | Description |
|------|-------------|
| `test_find_call_returns_none_when_callee_does_not_match` | Mock index with Call node at correct line but wrong callee target; verify returns None |
| `test_find_call_returns_correct_call_when_callee_matches` | Mock index with correct Call node; verify returns the matching call ID |
| `test_find_call_skips_wrong_target_picks_correct_one` | Multiple Call nodes at same line; verify it skips wrong callee, picks correct one |
| `test_find_call_returns_none_when_no_calls_exist` | Empty call_children list; verify returns None without error |
| `test_find_call_container_fallback_also_verifies_callee` | Container-based matching path also checks callee match |

### New integration tests (Phases 1-2)

File: `kloc-cli/tests/test_usage_flow.py` (additions)

| Test | Description |
|------|-------------|
| `test_nextId_shows_static_property_not_instantiation` | Query save() depth 1; verify $nextId is `[static_property]` |
| `test_getName_shows_method_call_not_property_access` | Query createOrder() depth 1; verify getName() is `[method_call]` |
| `test_customerEmail_not_attributed_to_emailSender` | Query createOrder() depth 1 with --impl; verify $customerEmail receiver is not $this->emailSender |
| `test_depth2_createOrder_save_includes_customerEmail` | Query createOrder() depth 2; verify $customerEmail appears under save() |
| `test_depth2_createOrder_save_includes_productId` | Query createOrder() depth 2; verify $productId appears under save() |
| `test_depth1_save_shows_all_uses` | Query save() depth 1; verify all 10 entries present (regression) |
| `test_same_target_at_depth1_and_depth2` | Query createOrder() depth 2; verify same target can appear at both depths |
| `test_no_infinite_loop_on_self_reference` | Ensure cyclic references terminate without hang |

### Test implementation patterns

Tests should follow the existing pattern in `test_usage_flow.py`:

```python
# Fixture setup (existing module-level fixture)
@pytest.fixture(scope="module")
def index():
    return SoTIndex(SOT_PATH)

# Helper to find entries
def find_entry_by_fqn(entries, fqn_substring):
    for entry in entries:
        if fqn_substring in entry.fqn:
            return entry
    return None

# Test example (new)
def test_nextId_shows_static_property_not_instantiation(self, index):
    node = index.resolve_symbol("App\\Repository\\OrderRepository::save")[0]
    query = ContextQuery(index)
    result = query.execute(node.id, depth=1)
    entry = find_entry_by_fqn(result.uses, "$nextId")
    assert entry is not None
    assert entry.member_ref is not None
    assert entry.member_ref.reference_type == "static_property"
    assert entry.member_ref.reference_type != "instantiation"
```

---

## Integration Points to Verify

| Integration Point | Components | What to Check |
|-------------------|------------|---------------|
| scip-php -> calls.json | scip-php | Call nodes have correct `call_kind` and locations |
| calls.json -> sot.json | kloc-mapper | Uses edge locations match SCIP occurrence positions |
| sot.json -> ContextQuery | kloc-cli | `find_call_for_usage()` matches correct Call nodes |
| ContextQuery -> output | kloc-cli | `reference_type` and `access_chain` display correctly |
| `_build_outgoing_tree` depth expansion | kloc-cli | Per-subtree visited sets allow cross-depth appearances |
| `_infer_reference_type` fallback | kloc-cli | Correct inference when Call matching fails |
| `get_call_target` verification | kloc-cli | Returns the callee node ID from the `calls` edge of a Call node |

### Key code locations for each integration point

| Integration Point | File | Function / Line |
|-------------------|------|-----------------|
| Callee verification | `kloc-cli/src/queries/context.py` | `find_call_for_usage()` at line 145 (line-matching loop at 167-173, container fallback at 176-182) |
| Visited set | `kloc-cli/src/queries/context.py` | `_build_outgoing_tree()` at line 784 (visited set at 795, dedup check at 809) |
| Reference type from Call | `kloc-cli/src/queries/context.py` | `get_reference_type_from_call()` at line ~130 |
| Reference type inference | `kloc-cli/src/queries/context.py` | `_infer_reference_type()` at line 295 |
| Access chain building | `kloc-cli/src/queries/context.py` | `build_access_chain()` at line 28 |
| Uses edge location | `kloc-mapper/src/mapper.py` | `_build_uses_edges()` at line ~451 |
| scip-php call_kind | `scip-php/src/DocIndexer.php` | `resolveCallKind()` |
| scip-php occurrence pos | `scip-php/src/DocIndexer.php` | `buildCallRecord()` / `buildAccessOrOperatorCallRecord()` |

---

## Performance Considerations

| Concern | Impact | Acceptance |
|---------|--------|------------|
| Callee verification adds one extra lookup per Call match attempt | Low -- `get_call_target()` is a dict lookup | Acceptable; no measurable overhead |
| Per-subtree visited sets may allow more entries in output | Medium -- depth-2 subtrees may be larger than before | Expected; the previous behavior was a data loss bug |
| Removing global dedup could theoretically show many duplicates | Low -- per-parent dedup still prevents same-depth duplicates | Verify total output size is reasonable with `--depth 3` |

**Performance check**: Run `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 3` and verify the output completes in reasonable time (under 5 seconds) and does not produce an unreasonably large tree.

---

## Phase-Ordered Testing Strategy

Testing should follow the implementation phases, as each phase builds on the previous.

### After Phase 1 (Callee verification guard):
- Run Scenarios 1.1, 1.2, 1.3, 1.4
- Run Scenario 6.1 (regression)
- Issues 2, 3, 4 should show improved output via inference fallback
- Issue 5 (depth-2 data loss) is NOT yet fixed
- **Verify**: `$nextId` shows `[static_property]` (inference path), `getName()` shows `[method_call]` (inference path), `$customerEmail` at line 48 shows `[property_access]` (inference path)
- **Not yet fixed**: depth-2 data loss (Scenarios 2.1-2.2)

### After Phase 2 (Per-subtree visited set):
- Run Scenarios 2.1, 2.2, 2.3, 2.4
- Re-run Scenarios 1.1-1.3 (ensure Phase 1 fixes not regressed)
- Run Scenario 5.1 (end-to-end minus scip-php fixes)
- Issue 1 should now be fully resolved
- **Verify**: `$customerEmail` and `$productId` appear at depth 2 under `save()`
- **Verify**: Same target can appear at both depth 1 and depth 2

### After Phase 3 (Uses edge location fix):
- Regenerate test fixtures (sot.json)
- Run Scenario 3.1, 3.2
- Re-run all previous scenarios with new fixtures
- Callee verification now matches correct Call nodes directly (not just inference)
- **Verify**: `$nextId` now has access chain populated (matched via correct Call node)
- **Verify**: `$customerEmail` at line 48 has correct receiver from Call node

### After Phase 4 (call_kind fix):
- Regenerate test fixtures (calls.json, sot.json)
- Run Scenario 4.1, 4.2
- Run Scenario 5.1, 5.2 (full end-to-end)
- Run Scenario 6.1, 6.2, 6.3 (full regression suite)
- ALL acceptance criteria should pass
- **Verify**: `getName()` shows `[method_call]` from Call node directly (not inference)

---

## Pass/Fail Criteria

- **PASS**: All 8 acceptance criteria pass AND all regression tests pass AND pipeline runs without errors
- **FAIL**: Any acceptance criterion fails, any regression test fails, or any pipeline command errors

---

## Common Failure Modes to Watch For

| Failure Mode | Symptom | Investigation |
|--------------|---------|---------------|
| Callee verification too strict | Many entries show `[unknown]` or inference types where Call-based types were previously shown | Check if `get_call_target()` is returning the correct ID format; may need to match by symbol instead of ID |
| Visited set fix causes duplicates | Same entry appears multiple times at same depth under same parent | Per-parent dedup is not working; check the visited set scope |
| Fixture staleness after scip-php changes | Tests pass with old fixtures but fail with freshly generated ones | Regenerate fixtures and update test expectations |
| Non-deterministic depth-2 output | Tests intermittently fail depending on edge iteration order | The visited set fix should eliminate this; if persisting, check edge ordering in `get_deps()` |
| Infinite recursion from visited set changes | Stack overflow or timeout on cyclic methods | Ensure `start_id` is still in the initial visited set for cycle prevention |
| Callee verification breaks container fallback | Entries that previously matched via container path now return None | The container fallback loop (context.py lines 176-182) must also verify callee match |
| Reference type regression for unrelated symbols | Symbols not affected by these 6 issues show different reference types | Run full test_usage_flow.py suite to catch regressions |
| Access chain disappears for entries using inference | After Phase 1, entries falling back to inference lose their access chain | Expected behavior -- access chain requires a matched Call node. Phase 3 fixes restore Call matching for these entries |

### Debugging commands

```bash
# Check what find_call_for_usage returns for a specific target
cd kloc-cli && python3 -c "
from src.graph import SoTIndex
from src.queries.context import find_call_for_usage
idx = SoTIndex('{fixture-sot}')
# Resolve save() and $nextId
save_nodes = idx.resolve_symbol('OrderRepository::save')
nextid_nodes = idx.resolve_symbol('OrderRepository::\$nextId')
if save_nodes and nextid_nodes:
    result = find_call_for_usage(idx, save_nodes[0].id, nextid_nodes[0].id, 'src/Repository/OrderRepository.php', 29)
    print(f'find_call_for_usage result: {result}')
    if result:
        node = idx.nodes.get(result)
        print(f'  Call kind: {node.call_kind}, range: {node.range}')
"

# Check the global visited set behavior
cd kloc-cli && python3 -c "
from src.graph import SoTIndex
from src.queries import ContextQuery
idx = SoTIndex('{fixture-sot}')
node = idx.resolve_symbol('App\\\Service\\\OrderService::createOrder')[0]
query = ContextQuery(idx)
result = query.execute(node.id, depth=2)
# Find save() subtree
for entry in result.uses:
    if 'save' in entry.fqn:
        print(f'save() depth-2 children: {len(entry.children)}')
        for child in entry.children:
            print(f'  {child.fqn} [{child.member_ref.reference_type if child.member_ref else \"?\"}] (line {child.line})')
"
```

---

## Source Code Line Number Reference

These are the actual 1-based line numbers from the PHP source files, verified against the repository. Use these when checking output from `kloc-cli context` commands. Note that sot.json may use 0-based line numbers internally; the CLI output should display 1-based.

### OrderRepository.php (`kloc-reference-project-php/src/Repository/OrderRepository.php`)

| Line | Code | Issue Relevance |
|------|------|-----------------|
| 7 | `use App\Entity\Order;` | Import |
| 10 | `final class OrderRepository` | Class declaration |
| 13 | `private static array $orders = [];` | Static property declaration |
| 15 | `private static int $nextId = 1;` | Static property declaration |
| 26 | `public function save(Order $order): Order` | Method signature (type hint for `Order`) |
| 28 | `if ($order->id === 0) {` | Property access on `$order` |
| 29 | `$newOrder = new Order(` | Constructor call (instantiation) |
| 30 | `id: self::$nextId++,` | **Issue 2**: Static property access, NOT instantiation |
| 31 | `customerEmail: $order->customerEmail,` | **Issue 1/5**: Property access, missing at depth 2 |
| 32 | `productId: $order->productId,` | **Issue 1/5**: Property access, missing at depth 2 |
| 33 | `quantity: $order->quantity,` | Property access |
| 34 | `status: $order->status,` | Property access |
| 35 | `createdAt: $order->createdAt,` | Property access |
| 37 | `self::$orders[$newOrder->id] = $newOrder;` | Static property access + property access |

### OrderService.php (`kloc-reference-project-php/src/Service/OrderService.php`)

| Line | Code | Issue Relevance |
|------|------|-----------------|
| 28 | `public function createOrder(CreateOrderInput $input): OrderOutput` | Method signature |
| 30 | `$this->inventoryChecker->checkAvailability(...)` | Chained method call |
| 32 | `$order = new Order(` | Constructor call |
| 42 | `$processedOrder = $this->orderProcessor->process($order);` | Chained method call |
| 43 | `$processorName = $this->orderProcessor->getName();` | **Issue 3**: Chained method call, misclassified as property_access |
| 45 | `$savedOrder = $this->orderRepository->save($processedOrder);` | Method call via property |
| 47 | `$this->emailSender->send(` | Method call via property |
| 48 | `to: $savedOrder->customerEmail,` | **Issue 4**: Named arg property access, wrong receiver |
| 49 | `subject: 'Order Confirmation #' . $savedOrder->id,` | Property access in expression |
| 58 | `$this->messageBus->dispatch(new OrderCreatedMessage(...))` | Method call + constructor |
