# QA Notes: Repository Interfaces Refactoring

## Test Scenarios

### Happy Path

- GIVEN new interface files WHEN `src/Repository/OrderRepositoryInterface.php` is inspected THEN it declares `interface OrderRepositoryInterface` with `findById(int $id): ?Order` and `save(Order $order): Order`
- GIVEN new interface files WHEN `src/Repository/CustomerRepositoryInterface.php` is inspected THEN it declares `interface CustomerRepositoryInterface` with `findById(int $id): ?Customer`, `save(Customer $customer): Customer`, and `createCustomer(...)` matching current signature
- GIVEN renamed implementations WHEN `src/Repository/InMemoryOrderRepository.php` is inspected THEN it declares `final class InMemoryOrderRepository implements OrderRepositoryInterface` with identical internal logic
- GIVEN renamed implementations WHEN `src/Repository/InMemoryCustomerRepository.php` is inspected THEN it declares `final class InMemoryCustomerRepository implements CustomerRepositoryInterface` with identical internal logic
- GIVEN service type-hints WHEN `OrderService`, `OrderDisplayService`, `NotificationService` constructors are inspected THEN all type-hint `OrderRepositoryInterface` (not `OrderRepository`)
- GIVEN service type-hints WHEN `CustomerService` constructor is inspected THEN it type-hints `CustomerRepositoryInterface` (not `CustomerRepository`)
- GIVEN DI config WHEN `config/services.yaml` is inspected THEN it binds `OrderRepositoryInterface` to `InMemoryOrderRepository` and `CustomerRepositoryInterface` to `InMemoryCustomerRepository`
- GIVEN contract test suite WHEN `bin/run.sh test` is executed THEN all tests pass (after symbol string updates)

### Edge Cases

- GIVEN `InMemoryCustomerRepository` WHEN inspected THEN `clearAll()` exists as a static method on the concrete class only (NOT on the interface)
- GIVEN `InMemoryOrderRepository` WHEN inspected THEN `private static $orders` and `private static $nextId` remain as private static properties (implementation details, not on interface)
- GIVEN the SCIP index WHEN the project is indexed THEN both interface definitions AND implementation definitions exist as separate symbols
- GIVEN services type-hinting interfaces WHEN SCIP occurrences are checked THEN type-hint references point to the INTERFACE symbol, not the implementation symbol

### Error Handling

- GIVEN old file names WHEN checking `src/Repository/` THEN `OrderRepository.php` and `CustomerRepository.php` no longer exist (deletion verified)
- GIVEN Symfony DI WHEN application boots without interface bindings THEN DI container throws error (validates services.yaml is required)

### Regression

- GIVEN contract test suite WHEN `bin/run.sh test` is run THEN all 235 existing tests pass (after symbol updates)
- GIVEN the Symfony application WHEN Docker containers are started and routes are accessed THEN the application functions identically (no runtime errors)
- GIVEN scip-php indexer WHEN run on the project THEN it completes without errors and produces valid calls.json and index.scip.json

### Integration

- GIVEN scip-php indexing WHEN the project is indexed THEN the output contains `implements` relationships for both `InMemoryOrderRepository -> OrderRepositoryInterface` and `InMemoryCustomerRepository -> CustomerRepositoryInterface`
- GIVEN scip-php indexing WHEN the SCIP index is inspected THEN interface method declarations (e.g., `OrderRepositoryInterface#save()`) have definition occurrences
- GIVEN scip-php indexing WHEN the SCIP index is inspected THEN implementation method declarations (e.g., `InMemoryOrderRepository#save()`) have definition occurrences

## Contract Test Validation Strategy

### Key Insight: Substring Matching Behavior

The contract test query API (`callerContains`, `calleeContains`, `symbolContains`, `inFile`) all use PHP `str_contains()` internally. Since `OrderRepository` is a substring of `InMemoryOrderRepository`, most `*Contains()` assertions will still match after the rename WITHOUT changes. This dramatically reduces the number of tests that actually break.

**Critical substring rules:**
- `symbolContains('OrderRepository#save()')` MATCHES `InMemoryOrderRepository#save()` -- SAFE
- `callerContains('OrderRepository#save()')` MATCHES `InMemoryOrderRepository#save()` -- SAFE
- `inFile('OrderRepository.php')` MATCHES `InMemoryOrderRepository.php` -- SAFE
- `inFile('Repository/OrderRepository.php')` does NOT match `Repository/InMemoryOrderRepository.php` -- BREAKS
- `symbolContains('OrderRepository#')` does NOT match `OrderRepositoryInterface#` -- `#` follows `Interface`, not `Repository` -- BREAKS in type-hint context

### Phase 1: Pre-Implementation Baseline

Before any source code changes:
1. Run `bin/run.sh test` and save results as baseline (all 235 tests should pass)
2. Record current test count per suite

### Phase 2: Corrected Breakage Analysis

After source code changes, contract tests fall into 3 categories:

#### Category A: WILL BREAK -- inFile() with Path Prefix (3 occurrences)

The `inFile('Repository/OrderRepository.php')` pattern breaks because `str_contains('Repository/InMemoryOrderRepository.php', 'Repository/OrderRepository.php')` is false.

| File | Line | Current Code | Fix |
|------|------|-------------|-----|
| `tests/Scip/TypeHint/TypeHintTest.php` | 117 | `->inFile('Repository/OrderRepository.php')` | `->inFile('Repository/InMemoryOrderRepository.php')` |
| `tests/Scip/TypeHint/TypeHintTest.php` | 156 | `->inFile('Repository/OrderRepository.php')` | `->inFile('Repository/InMemoryOrderRepository.php')` |
| `tests/Scip/TypeHint/TypeHintTest.php` | 232 | `->inFile('Repository/OrderRepository.php')` | `->inFile('Repository/InMemoryOrderRepository.php')` |

#### Category B: WILL BREAK -- expectedFiles Array with Path Prefix (1 occurrence)

| File | Line | Current Code | Fix |
|------|------|-------------|-----|
| `tests/Scip/Occurrence/OccurrenceTest.php` | 137 | `$expectedFiles = ['Repository/OrderRepository.php', ...]` | `$expectedFiles = ['Repository/InMemoryOrderRepository.php', ...]` |

#### Category C: WILL BREAK -- Type-Hint Symbol Changes (2 occurrences)

After refactoring, services type-hint `OrderRepositoryInterface` instead of `OrderRepository`. The SCIP symbol changes from `...OrderRepository#` to `...OrderRepositoryInterface#`. The substring `OrderRepository#` is NOT a substring of `OrderRepositoryInterface#` (the `#` comes after `Interface`, not after `Repository`).

| File | Line | Current Code | Fix | Why Breaks |
|------|------|-------------|-----|------------|
| `tests/Scip/TypeHint/TypeHintTest.php` | 37 | `->symbolContains('OrderRepository#')` | `->symbolContains('OrderRepositoryInterface#')` | Type-hint in OrderService now references interface symbol |
| `tests/Scip/Occurrence/OccurrenceTest.php` | 172 | `->symbolContains('OrderRepository#save()')` | `->symbolContains('InMemoryOrderRepository#save()')` or keep as-is IF scip-php resolves to implementation | Method call in OrderService -- depends on how scip-php resolves through interface |

**Note on OccurrenceTest line 172:** This test checks for `OrderRepository#save()` reference in `Service/OrderService.php`. After refactoring, `OrderService` calls `save()` on a property typed as `OrderRepositoryInterface`. Whether scip-php resolves this reference to `OrderRepositoryInterface#save()` or `InMemoryOrderRepository#save()` determines whether this test passes or breaks. If resolved to the interface, `OrderRepository#save()` is NOT a substring of `OrderRepositoryInterface#save()` so it BREAKS. If resolved to the implementation, `OrderRepository#save()` IS a substring of `InMemoryOrderRepository#save()` so it passes. **This needs manual verification after re-indexing.**

#### Category D: SAFE -- Substring Match Works (majority of tests)

These tests use `callerContains`, `calleeContains`, `symbolContains`, or `inFile` with patterns where `OrderRepository` is a substring of `InMemoryOrderRepository`. No changes needed for functional correctness.

| Test File | Pattern | Why SAFE |
|-----------|---------|----------|
| `tests/SmokeTest.php:65` | `symbolContains('OrderRepository#save().($order)')` | Substring of `InMemoryOrderRepository#save().($order)` |
| `tests/Reference/OneValuePerDeclarationTest.php:45,98,382,437` | `inMethod('App\Repository\OrderRepository', 'save')` | `inMethod` builds `App/Repository/OrderRepository#save()` which is substring of `App/Repository/InMemoryOrderRepository#save()` via `symbolContains` |
| `tests/Reference/OneValuePerDeclarationTest.php:494` | `inFile('OrderRepository.php')` | Bare filename -- substring of `InMemoryOrderRepository.php` |
| `tests/Reference/ReceiverAttributionTest.php:202,269` | `inMethod(...)` / `callerContains('OrderRepository#save()')` | Substring matches |
| `tests/Chain/ChainIntegrityTest.php:292` | `callerContains('OrderRepository#save()')` | Substring matches |
| `tests/CallKind/CallKindTest.php:429,456` | `callerContains('OrderRepository#save()')` / `callerContains('OrderRepository')` | Substring matches |
| `tests/CallKind/ChainedCallKindTest.php:159,173,195` | `callerContains('OrderRepository#save()')` / `'OrderRepository#$nextId'` | Substring matches |
| `tests/Integrity/LocationAccuracyTest.php:46,66,90,100,152` | `callerContains('OrderRepository#save()')` / `assertStringContainsString('OrderRepository.php', ...)` | Substring matches |
| `tests/ReturnType/ReturnTypeTest.php:60,89` | `calleeContains('OrderRepository')` | Substring matches |
| `tests/Argument/ArgumentBindingTest.php:100,185` | `callerContains('OrderRepository#save()')` | Substring matches |
| `tests/UsageFlow/UsageFlowTrackingTest.php:49` | `assertStringContainsString('OrderRepository', $param['type'])` | `OrderRepository` IS a substring of `OrderRepositoryInterface` -- SAFE but semantically imprecise |
| `tests/ValueKind/ValueKindTest.php:88` | `#[ContractTest]` description only | Metadata, no functional assertion |

#### Category E: SAFE -- Property Names Unchanged

| Test File | Why SAFE |
|-----------|----------|
| `tests/Chain/ChainIntegrityTest.php` | `calleeContains('orderRepository')` -- lowercase property name, unchanged |
| `tests/Chain/ChainedExpressionTest.php` | References property `$this->orderRepository` chain -- unchanged |
| `tests/UsageFlow/UsageFlowTrackingTest.php` | `calleeContains('orderRepository')` -- property name, unchanged |
| `tests/Reference/ParameterReferenceTest.php` | Constructor param names unchanged |

#### Category F: CustomerRepository -- No Test References

Grep for `CustomerRepository` across all contract test files returns ZERO matches. No contract test updates needed for the CustomerRepository rename.

### Summary: Actual Breaking Changes

| Category | Count | Files Affected |
|----------|-------|---------------|
| A: inFile() with path prefix | 3 | TypeHintTest.php |
| B: expectedFiles array | 1 | OccurrenceTest.php |
| C: Type-hint symbol change | 1-2 | TypeHintTest.php, OccurrenceTest.php (depends on scip-php resolution) |
| **Total hard breaks** | **5-6** | **2 files** |

This is dramatically fewer than the initial estimate of ~32 methods across 13 files.

### Phase 3: Line Number Sensitivity Assessment

Many contract tests assert specific line numbers. Analysis of whether they will break:

**InMemoryOrderRepository line numbers** -- The class declaration changes from `final class OrderRepository` (line 10) to `final class InMemoryOrderRepository implements OrderRepositoryInterface` (still line 10 -- fits on one line). The `use` statements at the top are unchanged. Therefore:

| Current Line | Content | Will Line Shift? |
|-------------|---------|-----------------|
| 10 | `final class OrderRepository` -> `final class InMemoryOrderRepository implements OrderRepositoryInterface` | NO -- same line |
| 21 | `public function findById(int $id): ?Order` | NO |
| 26 | `public function save(Order $order): Order` | NO |
| 29 | `$newOrder = new Order(` | NO |
| 30 | `id: self::$nextId++,` | NO |
| 31-35 | Property accesses `$order->customerEmail`, etc. | NO |

**Verdict: Line numbers should remain stable** as long as the `implements` clause fits on the same line as class declaration. If it wraps to a new line, ALL line-specific assertions in the following tests would need +1 adjustment:

- `tests/Reference/OneValuePerDeclarationTest.php` -- asserts line 26, 31-35
- `tests/Integrity/LocationAccuracyTest.php` -- asserts lines 29, 30, 31-35
- `tests/CallKind/ChainedCallKindTest.php` -- asserts lines 29, 30

**Recommendation:** Implementer MUST keep `final class InMemoryOrderRepository implements OrderRepositoryInterface` on a single line to avoid cascading line number shifts.

### Phase 4: New Test Scenarios for Interface Patterns

New contract tests needed (following existing InheritanceTest.php patterns):

#### 4a. Interface SCIP Symbol Tests (in `tests/Scip/Inheritance/InheritanceTest.php`)

```
- Verify InMemoryOrderRepository has is_implementation relationship to OrderRepositoryInterface
- Verify InMemoryCustomerRepository has is_implementation relationship to CustomerRepositoryInterface
- Verify OrderRepositoryInterface symbol exists in SCIP index
- Verify CustomerRepositoryInterface symbol exists in SCIP index
```

#### 4b. Interface Type-Hint Tests (in `tests/Scip/TypeHint/TypeHintTest.php`)

```
- Verify OrderService.$orderRepository type hint references OrderRepositoryInterface (not InMemoryOrderRepository)
- Verify NotificationService.$orderRepository type hint references OrderRepositoryInterface
- Verify CustomerService.$repository type hint references CustomerRepositoryInterface
```

#### 4c. Interface Method Definition Tests (in `tests/Scip/Symbol/SymbolTest.php`)

```
- Verify OrderRepositoryInterface#save() has definition occurrence
- Verify OrderRepositoryInterface#findById() has definition occurrence
- Verify CustomerRepositoryInterface#save() has definition occurrence
- Verify CustomerRepositoryInterface#findById() has definition occurrence
```

### Phase 5: Post-Implementation Validation

1. Re-run scip-php indexer: `bin/run.sh test` (generates fresh index + runs tests)
2. Verify all 235 existing tests pass (after the 5-6 required updates)
3. Verify new interface tests pass
4. Run grep validation to confirm no stale path-prefixed references remain:
   - `grep -r "inFile('Repository/OrderRepository.php')" contract-tests/tests/` returns zero matches
   - `grep -r "'Repository/OrderRepository.php'" contract-tests/tests/` returns zero matches
   - Verify `symbolContains('OrderRepository#')` is updated where it tests type-hint references (not implementation references)
5. Verify `bin/run.sh test --experimental` also passes (experimental call kinds)

## Cosmetic Updates (Non-Breaking)

These are not functional breaks but should be updated for accuracy:

### #[ContractTest] Attribute Metadata

Test names and descriptions reference `OrderRepository` in human-readable text. These should be updated for documentation accuracy but will NOT cause test failures:

| File | Lines | Example |
|------|-------|---------|
| `tests/SmokeTest.php` | 57-58 | `name: 'OrderRepository::save() $order Parameter'` |
| `tests/Reference/OneValuePerDeclarationTest.php` | 38, 92, 376, 431, 486-487 | `name: 'OrderRepository::save() $order - Single Value Entry'` |
| `tests/ReturnType/ReturnTypeTest.php` | 50, 79 | `name: 'OrderRepository findById Returns Nullable Order'` |
| Multiple other files | Various | Description/name fields mentioning OrderRepository |

### Docblock Comments

Code references like `Code reference: src/Repository/OrderRepository.php:26` should be updated to `InMemoryOrderRepository.php:26` for accuracy.

### Non-Test Files

| File | Changes |
|------|---------|
| `src/Query/ValueQuery.php` | @example docblocks (2 occurrences) |
| `src/Query/CallQuery.php` | @example docblock (1 occurrence) |
| `src/Query/MethodScope.php` | @example docblock (1 occurrence) |
| `src/CallsContractTestCase.php` | @param docblock (1 occurrence) |
| `src/Assertions/ReferenceConsistencyAssertion.php` | @example docblock (1 occurrence) |
| `CLAUDE.md` | Documentation examples (7 occurrences) |
| `TESTS.md` | Test inventory (15 occurrences) |
| `bin/run.sh` | Filter example (1 occurrence) |

## Test Data / Fixtures

- No new fixtures required -- the contract tests read from `calls.json` and `index.scip.json` generated by scip-php at test time
- The fresh index is generated by `bin/run.sh` before tests run, so it will automatically reflect the new source code
- No manual fixture updates needed

## Automated Test Expectations

### Existing Tests (after 5-6 updates)
- All 235 contract tests should pass with `bin/run.sh test`
- All experimental tests should pass with `bin/run.sh test --experimental`

### New Tests (to be added)
- ~4-6 new test methods in InheritanceTest.php for interface relationships
- ~3 new test methods in TypeHintTest.php for interface type-hint occurrences
- ~4 new test methods in SymbolTest.php for interface method definitions
- Estimated total: ~11-13 new test methods

## Manual Testing Steps

1. Verify old files deleted: `ls src/Repository/OrderRepository.php` should fail
2. Verify new files exist: `ls src/Repository/OrderRepositoryInterface.php InMemoryOrderRepository.php`
3. Verify Symfony boots: `docker-compose exec php bin/console debug:container OrderRepository`
4. Run contract tests: `bin/run.sh test`
5. Run experimental tests: `bin/run.sh test --experimental`
6. Run grep validation commands from Phase 5 above
7. Verify SCIP index contains interface symbols: inspect `output/index.scip.json` for `OrderRepositoryInterface#`
8. Manually verify OccurrenceTest line 172 -- check whether scip-php resolves method calls through interfaces to the interface symbol or implementation symbol

## Risk Assessment

**Overall: LOW** (revised down from MEDIUM after substring analysis)

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Line numbers shift in InMemoryOrderRepository | LOW | HIGH (12+ assertions break) | Keep `implements` clause on same line as class declaration |
| inFile() path-prefix tests not updated | HIGH (will definitely break) | LOW (only 3 occurrences, easy fix) | Category A update list above |
| Type-hint symbol resolution ambiguity | MEDIUM | MEDIUM (1-2 tests) | Manual verification after re-indexing (Phase 5 step 8) |
| Cosmetic metadata not updated | LOW impact | LOW (no functional breakage) | Batch find-replace after functional tests pass |
| New interface tests incomplete | LOW | LOW (missing coverage, not breakage) | Follow InheritanceTest.php pattern exactly |
