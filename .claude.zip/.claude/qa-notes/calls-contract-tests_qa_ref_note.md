# QA Testing Notes: calls-contract-tests

## Feature Summary

The `calls-contract-tests` feature provides a PHPUnit-based contract testing framework to validate `calls.json` output from the `scip-php` indexer. The framework tests against real PHP code in `kloc-reference-project-php/src/` and verifies that the indexer produces correct, consistent output conforming to the kloc-scip specification.

**Spec**: `docs/specs/calls-contract-tests.md`
**Plan**: `docs/specs/calls-contract-tests-plan.md`
**Progress**: `.claude/progress/calls-contract-tests.md`

---

## Key Acceptance Criteria

| ID | Criterion | Priority |
|----|-----------|----------|
| AC1 | `SmokeTest::testOrderRepositorySaveParameterExists()` passes | CRITICAL |
| AC2 | Docker build completes without errors | CRITICAL |
| AC3 | Tests can query values from generated index | HIGH |
| AC4 | Tests can query calls from generated index | HIGH |
| AC5 | Documentation is complete and accurate | MEDIUM |

---

## Test Scenarios

### Category 1: Infrastructure and Setup

#### 1.1 Docker Build and Execution

**Scenario**: Docker container builds and runs tests successfully

**Preconditions**:
- Docker and docker-compose installed
- Working directory: `kloc-reference-project-php/contract-tests/`
- `scip-php` binary exists at `../../scip-php/build/scip-php`

**Test Steps**:
1. Run `docker-compose build`
2. Verify no build errors
3. Run `docker-compose up`
4. Verify PHPUnit executes
5. Verify test results are reported

**Expected Results**:
- Build completes with exit code 0
- PHP 8.3 image is created
- Composer dependencies are installed
- PHPUnit runs all tests
- Exit code reflects test success/failure

**Edge Cases**:
- Missing scip-php binary: Should fail with clear error message
- Volume mount issues: Should fail at index generation step
- Composer install failure: Should fail during build

---

#### 1.2 Index Generation (bootstrap.php)

**Scenario**: Index is generated once before all tests run

**Preconditions**:
- Valid `config.php` with correct paths
- `scip-php` binary is executable
- `kloc-reference-project-php/src/` contains PHP files

**Test Steps**:
1. Run PHPUnit (triggers bootstrap.php)
2. Check `output/` directory for generated files
3. Verify `calls.json` exists
4. Verify `calls.json` is valid JSON

**Expected Results**:
- `calls.json` created in `output/` directory
- File contains valid JSON with `version`, `values`, `calls` keys
- Values array is non-empty
- Calls array is non-empty

**Validation**:
```bash
# Check file exists
ls -la contract-tests/output/calls.json

# Validate JSON structure
jq '. | {version, values_count: (.values | length), calls_count: (.calls | length)}' output/calls.json
```

**Edge Cases**:
- Empty src/ directory: Should produce empty values/calls arrays
- scip-php returns non-zero: Should throw RuntimeException with captured output
- Invalid scip-php path: Should throw RuntimeException with path in message
- Output directory not writable: Should fail with permission error

---

#### 1.3 Configuration Override via Environment

**Scenario**: Environment variables override config.php defaults

**Test Steps**:
1. Set `SCIP_PHP_BINARY=/custom/path`
2. Set `OUTPUT_DIR=/custom/output`
3. Run tests
4. Verify custom paths are used

**Expected Results**:
- When env var is set, it takes precedence
- When env var is not set, config.php default is used
- Custom paths work correctly in Docker

---

### Category 2: SmokeTest (Critical Path)

#### 2.1 testIndexWasGenerated

**Scenario**: Verify `calls.json` file exists after bootstrap

**Expected Behavior**:
- `CALLS_JSON_PATH` constant is defined
- File at that path exists
- Assertion: `assertFileExists(CALLS_JSON_PATH)`

**Failure Investigation**:
- Check if bootstrap.php ran
- Check if scip-php binary executed successfully
- Check output directory permissions

---

#### 2.2 testCallsDataLoaded

**Scenario**: Verify CallsData wrapper loaded successfully

**Expected Behavior**:
- `self::$calls` is not null
- `valueCount()` returns > 0
- `callCount()` returns > 0

**Failure Investigation**:
- Check if calls.json is valid JSON
- Check if CallsData::load() threw exception
- Verify JSON structure matches expected schema

---

#### 2.3 testOrderRepositorySaveParameterExists (PRIMARY ACCEPTANCE TEST)

**Scenario**: Query finds the $order parameter in OrderRepository::save()

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Repository/OrderRepository.php
// Line 26
public function save(Order $order): Order
```

**Expected Values in calls.json**:
```json
{
  "kind": "parameter",
  "symbol": "...OrderRepository#save().($order)",
  "type": "...App/Entity/Order#"
}
```

**Test Steps**:
1. Query values with `kind('parameter')`
2. Filter with `symbolContains('OrderRepository#save().($order)')`
3. Assert at least one result
4. Verify result has `kind: "parameter"`
5. Verify symbol contains `($order)`
6. Verify type contains `Order`

**Expected Results**:
- Exactly one value entry found
- Kind is "parameter"
- Symbol matches expected pattern
- Type is Order or App\Entity\Order

**Failure Investigation**:
- If no results: scip-php may not be indexing the file
- If wrong symbol format: Check SCIP symbol generation
- If missing type: Check type inference

---

### Category 3: Query API

#### 3.1 ValueQuery - Filter by Kind

**Test Data**: All value kinds in calls.json

| Kind | Expected Source | Example Symbol |
|------|-----------------|----------------|
| `parameter` | Method/function parameters | `#save().($order)` |
| `local` | Local variable assignments | `#save().local$newOrder@29` |
| `literal` | String/int/array literals | (no symbol) |
| `constant` | Constants | `App/Entity/Order#STATUS_PENDING` |
| `result` | Call results | (no symbol, has source_call_id) |

**Test Steps**:
```php
$this->values()->kind('parameter')->count();  // Should be > 0
$this->values()->kind('local')->count();      // Should be > 0
$this->values()->kind('result')->count();     // Should be > 0
```

---

#### 3.2 ValueQuery - Filter by Symbol

**Scenarios**:

| Method | Input | Expected Match |
|--------|-------|----------------|
| `symbol()` | Exact SCIP symbol | Exact match only |
| `symbolContains()` | `'OrderRepository'` | All symbols containing substring |
| `symbolMatches()` | `'*#save().($order)'` | Wildcard pattern match |

**Edge Cases**:
- Symbol with special regex characters (e.g., `$`, `()`, `#`)
- Empty string: Should return all or error gracefully
- Non-existent symbol: Should return empty results

---

#### 3.3 ValueQuery - Filter by Location

**Test Steps**:
```php
$this->values()
    ->inFile('src/Repository/OrderRepository.php')
    ->atLine(26)
    ->all();
```

**Expected Results**:
- Returns values at specified file/line
- Line numbers are 1-based
- File paths are relative to project root

---

#### 3.4 ValueQuery - hasSourceCallId / hasSourceValueId

**Scenario**: Filter values by their source linkage

**Test Steps**:
```php
// Result values always have source_call_id
$results = $this->values()->kind('result')->hasSourceCallId()->all();

// Locals assigned from calls have source_call_id
$locals = $this->values()->kind('local')->hasSourceCallId()->all();
```

---

#### 3.5 CallQuery - Filter by Kind

**Test Data**: All call kinds

| Kind | kind_type | Example |
|------|-----------|---------|
| `method` | invocation | `$order->save()` |
| `method_static` | invocation | `Order::create()` |
| `constructor` | invocation | `new Order(...)` |
| `function` | invocation | `sprintf(...)` |
| `access` | access | `$order->id` |
| `access_static` | access | `self::$orders` |
| `access_array` | access | `$orders[$id]` |

**Test Steps**:
```php
$this->calls()->kind('method')->count();       // > 0
$this->calls()->kind('constructor')->count();  // > 0
$this->calls()->kind('access')->count();       // > 0
```

---

#### 3.6 CallQuery - Filter by Callee/Caller

**Test Steps**:
```php
// Find calls TO OrderRepository::save()
$this->calls()
    ->calleeMatches('*OrderRepository#save().*')
    ->all();

// Find calls FROM OrderService::createOrder()
$this->calls()
    ->callerMatches('*OrderService#createOrder().*')
    ->all();
```

**Expected Results**:
- Callee filter matches the method being called
- Caller filter matches the method containing the call

---

#### 3.7 CallQuery - withReceiverValueId

**Scenario**: Verify all calls on same variable share receiver_value_id

**Source Code Reference**:
```php
// OrderService.php lines 43-50 (multiple accesses on $savedOrder)
$this->emailSender->send(
    to: $savedOrder->customerEmail,      // access
    subject: 'Order Confirmation #' . $savedOrder->id,  // access
    body: sprintf(..., $savedOrder->id, $savedOrder->productId, $savedOrder->quantity),
);
```

**Expected Behavior**:
- All calls accessing `$savedOrder` have same `receiver_value_id`
- That ID points to local variable defined at line 40

---

### Category 4: Assertion API - Reference Consistency

#### 4.1 Single Value Entry Per Variable

**Scenario**: Parameter has exactly one value entry

**Source Code Reference**:
```php
// OrderRepository.php:26
public function save(Order $order): Order
{
    // $order used on lines 28, 31-35, 42, 44
}
```

**Test Steps**:
```php
$this->assertReferenceConsistency()
    ->inMethod('App\Repository\OrderRepository', 'save')
    ->forParameter('$order')
    ->verify();
```

**Expected Behavior**:
- Exactly one value entry with symbol `...#save().($order)`
- All calls using `$order` as receiver reference this single value ID
- No duplicate value entries for same parameter

**Failure Modes**:
- Multiple value entries for same parameter (indexer bug)
- Calls referencing wrong value ID (linkage bug)
- Missing value entry (indexer not tracking parameters)

---

#### 4.2 Local Variable Reference Consistency

**Scenario**: Local variable has one value entry per assignment

**Source Code Reference**:
```php
// OrderRepository.php:29-36
$newOrder = new Order(...);  // Assignment at line 29
self::$orders[$newOrder->id] = $newOrder;  // Usage at line 37
return $newOrder;  // Usage at line 39
```

**Test Steps**:
```php
$this->assertReferenceConsistency()
    ->inMethod('App\Repository\OrderRepository', 'save')
    ->forLocal('$newOrder')
    ->verify();
```

---

### Category 5: Assertion API - Chain Integrity

#### 5.1 Property Access Chain

**Scenario**: `$order->customerEmail` creates proper value-call chain

**Source Code Reference**:
```php
// OrderService.php:43
to: $savedOrder->customerEmail,
```

**Expected Chain**:
```
$savedOrder (local value)
    -> access call (callee: Order#$customerEmail.)
        -> result value (type: string)
```

**Verification**:
- Access call has `receiver_value_id` pointing to `$savedOrder` local value
- Access call has corresponding result value with same ID
- Result value has `source_call_id` pointing to access call

---

#### 5.2 Method Call on Property Access Result

**Scenario**: Chained operations like `$this->orderRepository->findById($id)`

**Source Code Reference**:
```php
// NotificationService.php:20
$order = $this->orderRepository->findById($orderId);
```

**Expected Chain**:
```
$this (parameter/local value)
    -> access call (callee: ...#$orderRepository.)
        -> result value (type: OrderRepository)
            -> method call (callee: ...#findById().)
                -> result value (type: ?Order)
                    -> assigned to $order local
```

---

#### 5.3 Multi-Step Chain Integrity

**Scenario**: Complex chain maintains proper linkage

**Test Steps**:
```php
$this->assertChain()
    ->startingFrom('App\Service\OrderService', 'createOrder', '$this')
    ->throughAccess('orderRepository')
    ->throughMethod('save')
    ->verify();
```

**Expected Results**:
- Each step has proper `receiver_value_id` pointing to previous result
- Each step has corresponding result value
- Final result has correct type

---

### Category 6: Assertion API - Argument Binding

#### 6.1 Simple Argument Binding

**Scenario**: Method argument points to correct value

**Source Code Reference**:
```php
// OrderService.php:40
$savedOrder = $this->orderRepository->save($order);
//                                         ^^^^^^ argument
```

**Test Steps**:
```php
$this->assertArgument()
    ->inMethod('App\Service\OrderService', 'createOrder')
    ->atCall('save')
    ->position(0)
    ->pointsToLocal('$order')
    ->verify();
```

**Expected Results**:
- Argument at position 0 has `value_id`
- That `value_id` points to `$order` local value
- Local value has kind "local" and symbol containing `$order`

---

#### 6.2 Chain Result as Argument

**Scenario**: Property access result passed as argument

**Source Code Reference**:
```php
// OrderService.php:43
$this->emailSender->send(
    to: $savedOrder->customerEmail,  // Chain result as argument
```

**Test Steps**:
```php
$this->assertArgument()
    ->inMethod('App\Service\OrderService', 'createOrder')
    ->atCall('send')
    ->position(0)  // 'to' parameter
    ->pointsToResultOf('access', '*#customerEmail.')
    ->verify();
```

---

#### 6.3 Constructor Arguments

**Scenario**: Constructor call has properly bound arguments

**Source Code Reference**:
```php
// OrderService.php:31-38
$order = new Order(
    id: 0,
    customerEmail: $input->customerEmail,
    productId: $input->productId,
    quantity: $input->quantity,
    ...
);
```

**Test Steps**:
```php
// Verify constructor call exists
$constructorCall = $this->calls()
    ->kind('constructor')
    ->calleeMatches('*Order#__construct()*')
    ->inMethod('App\Service\OrderService', 'createOrder')
    ->one();

// Verify argument bindings
// Position 0: literal 0
// Position 1: $input->customerEmail result
// Position 2: $input->productId result
// Position 3: $input->quantity result
```

---

### Category 7: Assertion API - Data Integrity

#### 7.1 No Parameter Duplicates

**Scenario**: Each parameter symbol appears exactly once

**Test Steps**:
```php
$this->assertIntegrity()
    ->noParameterDuplicates()
    ->verify();
```

**Expected Results**:
- No two values with kind "parameter" have same symbol
- Each parameter in source code maps to one value entry

---

#### 7.2 No Orphaned References

**Scenario**: All ID references point to existing entries

**Test Steps**:
```php
$this->assertIntegrity()
    ->allReceiverValueIdsExist()
    ->allArgumentValueIdsExist()
    ->allSourceCallIdsExist()
    ->allSourceValueIdsExist()
    ->verify();
```

**Expected Results**:
- Every `receiver_value_id` in calls array points to existing value
- Every argument `value_id` points to existing value
- Every `source_call_id` in values array points to existing call
- Every `source_value_id` in values array points to existing value

**Failure Investigation**:
- Orphaned IDs indicate indexer bug
- May indicate values or calls being incorrectly filtered/omitted

---

#### 7.3 Result Value Consistency

**Scenario**: Every call has corresponding result value

**Test Steps**:
```php
$this->assertIntegrity()
    ->everyCallHasResultValue()
    ->resultValueTypesMatch()
    ->verify();
```

**Expected Results**:
- For each call, a result value exists with same ID
- Result value's `type` matches call's `return_type`

---

### Category 8: Error Handling

#### 8.1 Missing calls.json File

**Scenario**: CallsData::load() with non-existent file

**Expected Behavior**:
- Throws descriptive exception
- Message includes file path attempted

---

#### 8.2 Malformed JSON

**Scenario**: CallsData::load() with invalid JSON

**Expected Behavior**:
- Throws JsonException
- Does not cause cryptic errors

---

#### 8.3 Query Returns No Results

**Scenario**: Query with filters matching nothing

**Expected Behavior**:
- `all()` returns empty array
- `first()` returns null
- `one()` throws AssertionError with descriptive message
- `count()` returns 0
- `assertCount(1)` fails with clear message

---

#### 8.4 Assertion Failure Messages

**Scenario**: Assertions fail with useful context

**Expected Behavior**:
- Failure messages include:
  - What was expected
  - What was found (or not found)
  - Context (method, class, file, line)
  - Relevant IDs for debugging

---

## Test Data / Fixtures

### Expected Values in calls.json

Based on `kloc-reference-project-php/src/` source files:

#### Parameters to Test

| File | Method | Parameter | Expected Symbol Pattern |
|------|--------|-----------|------------------------|
| OrderRepository.php:26 | save | $order | `#save().($order)` |
| OrderRepository.php:21 | findById | $id | `#findById().($id)` |
| OrderService.php:27 | createOrder | $input | `#createOrder().($input)` |
| OrderService.php:65 | getOrder | $id | `#getOrder().($id)` |
| NotificationService.php:18 | notifyOrderCreated | $orderId | `#notifyOrderCreated().($orderId)` |
| EmailSender.php:12 | send | $to, $subject, $body | `#send().($to)`, etc. |

#### Local Variables to Test

| File | Method | Variable | Context |
|------|--------|----------|---------|
| OrderRepository.php:29 | save | $newOrder | Constructor result assignment |
| OrderService.php:31 | createOrder | $order | Constructor result assignment |
| OrderService.php:40 | createOrder | $savedOrder | Method result assignment |
| NotificationService.php:20 | notifyOrderCreated | $order | Method result assignment |

#### Constructor Calls to Test

| File | Line | Class | Arguments |
|------|------|-------|-----------|
| OrderRepository.php:29 | 29-36 | Order | 6 named arguments |
| OrderService.php:31 | 31-38 | Order | 6 named arguments |
| OrderService.php:53 | 53 | OrderCreatedMessage | 1 argument |
| OrderService.php:55 | 55-62 | OrderOutput | 6 named arguments |

#### Property Access Chains to Test

| File | Line | Chain | Expected Types |
|------|------|-------|----------------|
| OrderService.php:43 | 43 | `$savedOrder->customerEmail` | Order -> string |
| OrderService.php:44 | 44 | `$savedOrder->id` | Order -> int |
| NotificationService.php:27 | 27 | `$order->customerEmail` | ?Order -> string |

---

## Manual Testing Steps

### 1. Initial Setup Validation

```bash
# Navigate to contract-tests directory
cd kloc-reference-project-php/contract-tests/

# Verify Docker files exist
ls -la Dockerfile docker-compose.yml composer.json phpunit.xml config.php

# Verify source directory exists
ls -la ../src/

# Verify scip-php binary exists
ls -la ../../scip-php/build/scip-php
```

### 2. Docker Build Test

```bash
# Build container
docker-compose build

# Expected: Build completes successfully
# Watch for: Composer install errors, missing PHP extensions
```

### 3. Full Test Run

```bash
# Run all tests
docker-compose up

# Expected output includes:
# - "Index generated: output/calls.json"
# - PHPUnit test execution
# - Green bar for passing tests
```

### 4. Individual Test Suite Execution

```bash
# Run only smoke tests
docker-compose run --rm contract-tests vendor/bin/phpunit tests/SmokeTest.php

# Run by testsuite
docker-compose run --rm contract-tests vendor/bin/phpunit --testsuite=integrity
docker-compose run --rm contract-tests vendor/bin/phpunit --testsuite=reference
docker-compose run --rm contract-tests vendor/bin/phpunit --testsuite=chain
docker-compose run --rm contract-tests vendor/bin/phpunit --testsuite=argument
```

### 5. Inspect Generated Index

```bash
# View calls.json structure
docker-compose run --rm contract-tests cat output/calls.json | jq '.version'

# Count entries
docker-compose run --rm contract-tests cat output/calls.json | jq '{
  values: (.values | length),
  calls: (.calls | length)
}'

# Find specific parameter
docker-compose run --rm contract-tests cat output/calls.json | jq '
  .values[] | select(.symbol? and (.symbol | contains("OrderRepository#save().($order)")))
'
```

### 6. Local Development (without Docker)

```bash
cd kloc-reference-project-php/contract-tests/

# Install dependencies
composer install

# Run tests
vendor/bin/phpunit

# Run with verbose output
vendor/bin/phpunit -v

# Run single test
vendor/bin/phpunit --filter testOrderRepositorySaveParameterExists
```

---

## Integration Points

### 1. scip-php Binary

**Integration**: IndexGenerator executes scip-php binary

**Validation**:
- Binary exists at configured path
- Binary is executable
- Binary produces valid calls.json output
- Exit code is 0 on success

**Failure Modes**:
- Binary not found (path misconfiguration)
- Binary not executable (permissions)
- Binary crashes (scip-php bug)
- Invalid output (schema mismatch)

### 2. calls.json Schema

**Integration**: CallsData parses JSON according to schema

**Validation**:
- Version field exists
- Values array exists with expected structure
- Calls array exists with expected structure
- All required fields present

**Schema Reference**: `docs/reference/kloc-scip/calls-schema.json`

### 3. kloc-reference-project-php Source

**Integration**: Tests reference specific code patterns

**Validation**:
- Source files exist at expected locations
- Line numbers in tests match actual code
- Class/method names match actual code
- No accidental changes break test assumptions

---

## Performance Considerations

### Index Generation Time

- Index generation happens once per PHPUnit run (in bootstrap.php)
- Expected time: 1-5 seconds for reference project
- If slow: Check scip-php performance, file count in src/

### Test Execution Time

- Tests load calls.json once (cached in static property)
- Individual tests should execute in < 100ms
- Query operations should be O(n) where n = entries count

### Memory Usage

- calls.json is loaded entirely into memory
- For reference project: < 1MB expected
- For large projects: May need streaming approach

---

## Regression Test Suite

### Known Issue Tests (from spec)

These tests verify fixes for known indexer issues:

| Issue | Test | Expected Outcome |
|-------|------|------------------|
| Duplicate parameter values | `testNoParameterDuplicates` | No duplicates found |
| Orphaned receiver_value_id | `testAllReceiverIdsExist` | All IDs resolve |
| Missing result values | `testEveryCallHasResult` | All calls have results |
| Wrong receiver ID on chain | `testChainReceiversCorrect` | Chain linkage intact |

---

## Documentation Verification

### Files to Verify

| Path | Content |
|------|---------|
| `docs/reference/kloc-scip/contract-tests/README.md` | Overview and quick start |
| `docs/reference/kloc-scip/contract-tests/framework-api.md` | Complete API reference |
| `docs/reference/kloc-scip/contract-tests/test-categories.md` | Category descriptions |
| `docs/reference/kloc-scip/contract-tests/writing-tests.md` | How to write new tests |
| `kloc-reference-project-php/contract-tests/CLAUDE.md` | Agent instructions |

### Documentation Checks

1. All code examples compile/run
2. API methods documented match implementation
3. File paths are correct and files exist
4. Quick start instructions work end-to-end

---

## Troubleshooting Guide

### SmokeTest Failures

| Failure | Likely Cause | Resolution |
|---------|--------------|------------|
| `testIndexWasGenerated` fails | scip-php not found or failed | Check binary path, run manually |
| `testCallsDataLoaded` fails | Invalid JSON output | Check scip-php stderr, validate JSON |
| `testOrderRepositorySaveParameterExists` fails | Schema change or indexer bug | Check calls.json manually |

### Query Returns Unexpected Results

1. Dump all values/calls to inspect: `var_dump(self::$calls->values());`
2. Check symbol format matches expected pattern
3. Verify file/line references are correct
4. Check if symbol contains expected substrings

### Docker Issues

| Issue | Resolution |
|-------|------------|
| Volume mount fails | Check paths in docker-compose.yml |
| Permission denied | Check file permissions, user in container |
| Binary not found in container | Check mount path for scip-php binary |

---

## Version History

| Date | Version | Changes |
|------|---------|---------|
| 2026-01-31 | 1.0 | Initial QA notes created |
