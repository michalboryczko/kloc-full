# QA Testing Notes: usage-flow-tracking

## Feature Summary

The `usage-flow-tracking` feature enhances the `kloc-cli context --used-by` output to show **HOW** symbols are used, not just **WHERE**. This enables AI coding agents to understand usage patterns for accurate refactoring and impact analysis.

**Spec**: `docs/specs/usage-flow-tracking-v2.md`
**Plan**: `docs/specs/usage-flow-tracking-plan.md`

### Key Enhancements

1. **Reference Type Classification**: Each usage entry displays a `[reference_type]` indicator (e.g., `[type_hint]`, `[method_call]`, `[instantiation]`)
2. **Access Chain Display**: Method calls and property accesses show the receiver expression (e.g., `on: $this->orderRepository`)
3. **calls.json Integration**: New `--calls` flag enables full access chain resolution

---

## Key Acceptance Criteria

| ID | Criterion | Priority |
|----|-----------|----------|
| AC1 | Every `used_by` entry shows `[reference_type]` indicator | CRITICAL |
| AC2 | Method calls show `on: $expression` when `--calls` provided | CRITICAL |
| AC3 | Default compact format fits terminal width | HIGH |
| AC4 | JSON output includes `reference_type` and `access_chain` fields | HIGH |
| AC5 | Works without `--calls` (graceful degradation) | HIGH |
| AC6 | All tests pass against `kloc-reference-project-php` data | CRITICAL |
| AC7 | Existing behavior unchanged when `--calls` not provided | HIGH |

---

## Test Scenarios

### Category 1: Reference Type Classification (Phase 1a - sot.json only)

#### TC1: Type Hint Detection

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Service/OrderService.php
// Line 20
private OrderRepository $orderRepository,
```

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json
```

**Expected Output**:
```
USED BY (n):
...
[1] App\Service\OrderService -> $orderRepository [type_hint]
    (src/Service/OrderService.php:20)
...
```

**Validation Steps**:
1. Run the context command for `OrderRepository`
2. Verify `OrderService` appears in USED BY list
3. Verify reference type shows `[type_hint]`
4. Verify `$orderRepository` property name is displayed
5. Verify file and line reference is correct (line 20)

---

#### TC2: Interface Type Hint Detection

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Service/OrderService.php
// Line 21
private EmailSenderInterface $emailSender,
```

**Test Command**:
```bash
uv run kloc-cli context "App\Component\EmailSenderInterface" --sot sot.json
```

**Expected Output**:
```
USED BY (n):
...
[1] App\Service\OrderService -> $emailSender [type_hint]
    (src/Service/OrderService.php:21)
...
```

**Validation Steps**:
1. Query `EmailSenderInterface`
2. Verify `OrderService` shows as usage with `[type_hint]`
3. Verify property name `$emailSender` is displayed

---

#### TC3: Reference Type from Edge Type - extends

**Test Command**:
```bash
uv run kloc-cli context "SomeBaseClass" --sot sot.json
```

**Expected Behavior**:
- When a class extends another, show `[extends]` reference type
- Edge type directly maps to reference type

---

#### TC4: Reference Type from Edge Type - implements

**Test Command**:
```bash
uv run kloc-cli context "SomeInterface" --sot sot.json
```

**Expected Behavior**:
- When a class implements an interface, show `[implements]` reference type
- Edge type directly maps to reference type

---

### Category 2: Access Chain Building (Phase 1b - calls.json)

#### TC5: Method Call via Property Access

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Service/OrderService.php
// Line 40
$savedOrder = $this->orderRepository->save($order);
```

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json
```

**Expected Output**:
```
USED BY (n):
...
[1] App\Service\OrderService::createOrder() -> save() [method_call]
    on: $this->orderRepository (src/Service/OrderService.php:40)
...
```

**Validation Steps**:
1. Run context command with `--calls` flag
2. Verify `save()` method call is identified
3. Verify reference type is `[method_call]`
4. Verify access chain shows `on: $this->orderRepository`
5. Verify line number is 40

**calls.json Data Reference**:
```json
{
  "id": "src/Service/OrderService.php:40:22",
  "kind": "method",
  "callee": "...OrderRepository#save().",
  "receiver_value_id": "src/Service/OrderService.php:40:29"
}
```

---

#### TC6: Method Call via Parameter (findById)

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Service/OrderService.php
// Line 67
$order = $this->orderRepository->findById($id);
```

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json
```

**Expected Output**:
```
USED BY (n):
...
[1] App\Service\OrderService::getOrder() -> findById() [method_call]
    on: $this->orderRepository (src/Service/OrderService.php:67)
...
```

**Validation Steps**:
1. Verify `findById()` appears as separate entry from `save()`
2. Verify correct scope `getOrder()` (not `createOrder()`)
3. Verify line 67 is referenced

---

#### TC7: Interface Method Call

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Service/OrderService.php
// Lines 42-51
$this->emailSender->send(
    to: $savedOrder->customerEmail,
    subject: 'Order Confirmation #' . $savedOrder->id,
    body: sprintf(...),
);
```

**Test Command**:
```bash
uv run kloc-cli context "App\Component\EmailSenderInterface" --sot sot.json --calls calls.json
```

**Expected Output**:
```
USED BY (n):
...
[1] App\Service\OrderService::createOrder() -> send() [method_call]
    on: $this->emailSender (src/Service/OrderService.php:42)
...
```

**Validation Steps**:
1. Query `EmailSenderInterface`
2. Verify `send()` method call is shown
3. Verify access chain shows `$this->emailSender`
4. Verify reference type is `[method_call]`

---

#### TC8: Constructor Call (Instantiation)

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Service/OrderService.php
// Lines 31-38
$order = new Order(
    id: 0,
    customerEmail: $input->customerEmail,
    productId: $input->productId,
    quantity: $input->quantity,
    status: 'pending',
    createdAt: new DateTimeImmutable(),
);
```

**Test Command**:
```bash
uv run kloc-cli context "App\Entity\Order" --sot sot.json --calls calls.json
```

**Expected Output**:
```
USED BY (n):
...
[1] App\Service\OrderService::createOrder() [instantiation]
    (src/Service/OrderService.php:31)
...
```

**Validation Steps**:
1. Query `App\Entity\Order`
2. Verify `[instantiation]` reference type (not `[method_call]`)
3. Verify NO access chain (constructors have no receiver)
4. Verify line 31 is referenced

---

#### TC9: Multiple References Same Scope

**Source Code Reference**:
```php
// OrderService.php - createOrder() has multiple calls to Order properties:
// Line 43: $savedOrder->customerEmail
// Line 44: $savedOrder->id
// Lines 47-49: $savedOrder->id, productId, quantity
```

**Test Command**:
```bash
uv run kloc-cli context "App\Entity\Order" --sot sot.json --calls calls.json
```

**Expected Behavior**:
- Each distinct reference appears as separate entry
- All share same scope (`createOrder()`) but different target members
- All should show `on: $savedOrder` as access chain

**Validation Steps**:
1. Count total references from `createOrder()` to Order members
2. Verify references are NOT collapsed into single entry
3. Each reference shows correct target member name

---

### Category 3: Static Access Patterns

#### TC10: Static Method Call

**Source Code Reference**:
```php
// If project has static method calls like:
// OrderRepository::create() or self::$orders
```

**Expected Output**:
```
[1] SomeClass::someMethod() -> create() [static_call]
    (file.php:line)
```

**Validation Steps**:
1. Find static method call in reference project
2. Verify `[static_call]` reference type
3. Verify NO `on:` expression (static calls have no receiver instance)

---

#### TC11: Static Property Access

**Source Code Reference**:
```php
// File: kloc-reference-project-php/src/Repository/OrderRepository.php
// Lines 13, 15
private static array $orders = [];
private static int $nextId = 1;
```

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json
```

**Expected Behavior**:
- References to `self::$orders` show `[static_property]` or `[access_static]`
- No receiver expression needed

---

### Category 4: Edge Cases

#### EC1: No calls.json Provided (Graceful Degradation)

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json
# Note: NO --calls flag
```

**Expected Behavior**:
- Reference types still shown (inferred from sot.json edge metadata)
- NO access chains displayed
- No errors or crashes
- Output format similar but without `on:` lines

**Validation Steps**:
1. Run without `--calls` flag
2. Verify `[type_hint]`, `[method_call]` types still appear (inferred)
3. Verify no `on:` expressions shown
4. Compare with output when `--calls` IS provided

---

#### EC2: Call Not Found in calls.json

**Scenario**: Edge exists in sot.json but no matching call record in calls.json

**Expected Behavior**:
- Show `[unknown]` as reference type
- No access chain displayed
- Do not crash or fail

---

#### EC3: Incomplete Chain (Type Unknown)

**Scenario**: `receiver_value_id` points to value without sufficient type info

**Expected Behavior**:
- Show partial chain: `on: $expr->?`
- Add `(type unknown)` indicator
- Continue processing other references

---

#### EC4: Self-Reference (Class Uses Own Method)

**Source Code Reference**:
```php
// OrderRepository::save() calls self::$orders and self::$nextId
```

**Expected Behavior**:
- Include self-references normally
- No special handling or filtering required

---

#### EC5: Circular References at Depth > 1

**Scenario**: A -> B -> A dependency cycle

**Expected Behavior**:
- Standard visited set prevents infinite loops
- Each node appears only once in output

---

### Category 5: Output Format Testing

#### OF1: Compact Format (Default)

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json
```

**Expected Format**:
```
USED BY (5):
+-- [1] App\Service\OrderService -> $orderRepository [type_hint]
|       (src/Service/OrderService.php:20)
+-- [1] App\Service\OrderService::createOrder() -> save() [method_call]
|       on: $this->orderRepository (src/Service/OrderService.php:40)
+-- [1] App\Service\OrderService::getOrder() -> findById() [method_call]
        on: $this->orderRepository (src/Service/OrderService.php:67)
```

**Validation**:
- Single entry per line (compact)
- Reference type in brackets at end
- Access chain on `on:` line below (when applicable)
- File:line in parentheses

---

#### OF2: Verbose Format

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json --verbose
```

**Expected Format**:
```
USED BY (5):
+-- [1] App\Service\OrderService
|       +-- via: $orderRepository property (type_hint)
|           +-- at: src/Service/OrderService.php:20
+-- [1] App\Service\OrderService::createOrder()
|       +-- via: save() (method_call)
|           +-- on: $this->orderRepository
|               +-- at: src/Service/OrderService.php:40
```

**Validation**:
- Multi-line format with nested structure
- `via:` shows target member and reference type
- `on:` shows access chain
- `at:` shows location

---

#### OF3: JSON Output

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json --json
```

**Expected JSON Structure**:
```json
{
  "target": {
    "fqn": "App\\Repository\\OrderRepository",
    "kind": "Class",
    "file": "src/Repository/OrderRepository.php"
  },
  "used_by": [
    {
      "depth": 1,
      "scope": {
        "fqn": "App\\Service\\OrderService::createOrder()",
        "kind": "Method"
      },
      "reference": {
        "type": "method_call",
        "target_member": "save()",
        "access_chain": "$this->orderRepository",
        "location": {
          "file": "src/Service/OrderService.php",
          "line": 40
        }
      }
    }
  ]
}
```

**Validation**:
1. Parse JSON output
2. Verify `reference` object exists in each `used_by` entry
3. Verify `type` field present (never null)
4. Verify `target_member` present for member references
5. Verify `access_chain` present when calls.json provided

---

### Category 6: Integration Testing

#### INT1: End-to-End with Reference Project

**Preconditions**:
- `kloc-reference-project-php` indexed to produce `sot.json`
- `scip-php` generated `calls.json`

**Test Steps**:
1. Generate fresh index:
   ```bash
   cd kloc-reference-project-php
   ../bin/scip-php.sh -d . -o contract-tests/output
   ```
2. Run context query with both files:
   ```bash
   uv run kloc-cli context "App\Repository\OrderRepository" \
       --sot contract-tests/output/sot.json \
       --calls contract-tests/output/calls.json
   ```
3. Verify all expected usages appear with correct reference types

---

#### INT2: MCP Server Exposes Flow Data

**Test Steps**:
1. Start MCP server:
   ```bash
   uv run kloc-cli mcp-server --sot sot.json --calls calls.json
   ```
2. Call `kloc_context` tool via MCP protocol
3. Verify response includes `reference_type` and `access_chain` fields

---

### Category 7: Regression Testing

#### REG1: Existing Context Output Unchanged Without --calls

**Test Steps**:
1. Capture current output:
   ```bash
   uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json > before.txt
   ```
2. Apply feature changes
3. Run same command (without --calls):
   ```bash
   uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json > after.txt
   ```
4. Diff outputs - only difference should be `[reference_type]` additions

---

#### REG2: No Performance Degradation

**Test Steps**:
1. Measure baseline query time:
   ```bash
   time uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json
   ```
2. Measure with calls.json:
   ```bash
   time uv run kloc-cli context "App\Repository\OrderRepository" \
       --sot sot.json --calls calls.json
   ```
3. Verify time with calls.json is within 2x of baseline

---

### Category 8: Error Handling

#### EH1: Invalid calls.json Path

**Test Command**:
```bash
uv run kloc-cli context "App\Repository\OrderRepository" \
    --sot sot.json --calls /nonexistent/calls.json
```

**Expected Behavior**:
- Clear error message: "Error: calls.json not found at /nonexistent/calls.json"
- Exit code 1
- No Python traceback for normal users

---

#### EH2: Malformed calls.json

**Test Steps**:
1. Create malformed JSON file
2. Run with `--calls malformed.json`

**Expected Behavior**:
- msgspec.DecodeError or similar with descriptive message
- Exit code 1
- Message indicates JSON parsing failure

---

#### EH3: Schema Version Mismatch

**Test Steps**:
1. Create calls.json with `"version": "1.0"` (unsupported)
2. Run context command

**Expected Behavior**:
- Warning message about potential compatibility issues
- Attempt to proceed or fail gracefully

---

## Test Data / Fixtures

### Expected Reference Types by Location

Based on `kloc-reference-project-php/src/Service/OrderService.php`:

| Line | Code | Expected Reference Type |
|------|------|------------------------|
| 20 | `private OrderRepository $orderRepository` | `type_hint` |
| 21 | `private EmailSenderInterface $emailSender` | `type_hint` |
| 22 | `private InventoryCheckerInterface $inventoryChecker` | `type_hint` |
| 23 | `private MessageBusInterface $messageBus` | `type_hint` |
| 29 | `$this->inventoryChecker->checkAvailability(...)` | `method_call` |
| 31 | `new Order(...)` | `instantiation` |
| 37 | `new DateTimeImmutable()` | `instantiation` |
| 40 | `$this->orderRepository->save($order)` | `method_call` |
| 42 | `$this->emailSender->send(...)` | `method_call` |
| 53 | `$this->messageBus->dispatch(...)` | `method_call` |
| 55 | `new OrderOutput(...)` | `instantiation` |
| 67 | `$this->orderRepository->findById($id)` | `method_call` |

### Expected Access Chains

| Location | Call | Expected Access Chain |
|----------|------|----------------------|
| OrderService.php:40 | `save()` | `$this->orderRepository` |
| OrderService.php:42 | `send()` | `$this->emailSender` |
| OrderService.php:53 | `dispatch()` | `$this->messageBus` |
| OrderService.php:67 | `findById()` | `$this->orderRepository` |

### calls.json Key Records for Testing

**Parameter values** (test that these exist):
```json
{
  "id": "src/Service/OrderService.php:20:32",
  "kind": "parameter",
  "symbol": "...OrderService#__construct().($orderRepository)"
}
```

**Method calls with receiver_value_id** (test chain building):
```json
{
  "id": "src/Service/OrderService.php:40:22",
  "kind": "method",
  "callee": "...OrderRepository#save().",
  "receiver_value_id": "src/Service/OrderService.php:40:29"
}
```

---

## Manual Testing Steps

### 1. Setup Verification

```bash
# Navigate to project
cd /Users/michal/dev/ai/kloc

# Verify reference project exists
ls -la kloc-reference-project-php/src/Service/OrderService.php

# Verify test data exists
ls -la kloc-reference-project-php/contract-tests/output/calls.json
```

### 2. Generate Fresh Test Data

```bash
# Build scip-php if needed
cd scip-php && ./build/build.sh && cd ..

# Generate index for reference project
./bin/scip-php.sh -d kloc-reference-project-php -o kloc-reference-project-php/contract-tests/output
```

### 3. Run Context Query Tests

```bash
# Test without calls.json (baseline)
uv run kloc-cli context "App\Repository\OrderRepository" \
    --sot kloc-reference-project-php/contract-tests/output/sot.json

# Test with calls.json (full feature)
uv run kloc-cli context "App\Repository\OrderRepository" \
    --sot kloc-reference-project-php/contract-tests/output/sot.json \
    --calls kloc-reference-project-php/contract-tests/output/calls.json

# Test JSON output
uv run kloc-cli context "App\Repository\OrderRepository" \
    --sot kloc-reference-project-php/contract-tests/output/sot.json \
    --calls kloc-reference-project-php/contract-tests/output/calls.json \
    --json | jq .
```

### 4. Verify Specific Test Cases

```bash
# TC1: Type hint detection
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json | grep -A1 "type_hint"

# TC5: Method call with chain
uv run kloc-cli context "App\Repository\OrderRepository" --sot sot.json --calls calls.json | grep -A2 "save()"

# TC8: Instantiation
uv run kloc-cli context "App\Entity\Order" --sot sot.json --calls calls.json | grep "instantiation"
```

---

## Automated Test Expectations

### Unit Tests (kloc-cli/tests/)

#### test_reference_type_inference.py

```python
def test_type_hint_inference():
    """Edges pointing to Class with uses edge type -> type_hint"""
    # Setup: edge from OrderService to OrderRepository (property type)
    # Assert: reference_type == "type_hint"

def test_method_call_inference():
    """Edges pointing to Method with uses edge type -> method_call"""
    # Setup: edge from createOrder to save method
    # Assert: reference_type == "method_call"

def test_extends_edge_mapping():
    """extends edge type maps directly to extends reference type"""
    # Setup: edge with type "extends"
    # Assert: reference_type == "extends"

def test_implements_edge_mapping():
    """implements edge type maps directly to implements reference type"""
    # Setup: edge with type "implements"
    # Assert: reference_type == "implements"
```

#### test_calls_data.py

```python
def test_calls_data_load():
    """CallsData loads and indexes calls.json correctly"""
    # Load test fixture
    # Assert values_by_id populated
    # Assert calls_by_id populated
    # Assert calls_by_location populated

def test_get_call_at_location():
    """get_call_at() finds call by file:line"""
    # Setup: call at OrderService.php:40
    # Assert: returns save() call record

def test_build_access_chain_simple():
    """build_access_chain() resolves $this->property"""
    # Setup: call with receiver_value_id pointing to property access
    # Assert: returns "$this->orderRepository"

def test_build_access_chain_nested():
    """build_access_chain() handles nested accesses"""
    # Setup: $this->service->repository->find()
    # Assert: returns full chain
```

### Integration Tests (kloc-cli/tests/test_integration.py)

```python
def test_context_with_calls_shows_reference_type():
    """context command with --calls shows reference types"""
    # Run: kloc-cli context OrderRepository --sot sot.json --calls calls.json
    # Assert: output contains [method_call], [type_hint]

def test_context_with_calls_shows_access_chain():
    """context command with --calls shows access chains"""
    # Run: kloc-cli context OrderRepository --sot sot.json --calls calls.json
    # Assert: output contains "on: $this->orderRepository"

def test_context_without_calls_graceful():
    """context command without --calls still works"""
    # Run: kloc-cli context OrderRepository --sot sot.json
    # Assert: no errors, shows reference types (inferred)

def test_context_json_includes_flow_fields():
    """JSON output includes reference_type and access_chain"""
    # Run: kloc-cli context OrderRepository --sot sot.json --calls calls.json --json
    # Parse JSON
    # Assert: each used_by entry has reference.type
    # Assert: method_call entries have reference.access_chain
```

---

## Performance Considerations

### calls.json Loading

- File size: ~400KB for reference project (5000+ records)
- Loading strategy: Load once, build indices
- Expected load time: < 100ms
- Memory: Entire file held in memory

### Index Lookup Performance

- `values_by_id`: O(1) dict lookup
- `calls_by_id`: O(1) dict lookup
- `calls_by_location`: O(1) dict lookup, then O(k) for k calls at same location
- Chain building: O(d) where d = chain depth (typically < 5)

### Query Performance

- Without calls.json: Same as current (no change)
- With calls.json: Additional O(n) lookups where n = usage count
- Expected overhead: < 50ms for typical queries

---

## Files Modified by Feature

| File | Changes |
|------|---------|
| `kloc-cli/src/models/results.py` | Add `reference_type`, `access_chain` to `MemberRef` |
| `kloc-cli/src/graph/calls.py` | NEW: `CallsData` loader and chain builder |
| `kloc-cli/src/graph/__init__.py` | Export `CallsData` |
| `kloc-cli/src/queries/context.py` | Add `_infer_reference_type()`, integrate calls lookup |
| `kloc-cli/src/cli.py` | Add `--calls / -c` option |
| `kloc-cli/src/output/tree.py` | Update display format for reference types and chains |
| `kloc-cli/src/output/json_formatter.py` | Include new fields in JSON output |

---

## Troubleshooting Guide

### Missing Reference Types

| Symptom | Likely Cause | Resolution |
|---------|--------------|------------|
| No `[type]` shown | Feature not implemented | Check results.py for reference_type field |
| Always `[unknown]` | Edge type not recognized | Check _infer_reference_type() logic |
| Wrong type | Inference rules incorrect | Review classification logic |

### Missing Access Chains

| Symptom | Likely Cause | Resolution |
|---------|--------------|------------|
| No `on:` shown | `--calls` not provided | Add calls.json flag |
| `on: ?` shown | receiver_value_id missing | Check calls.json data |
| Partial chain | Chain resolution incomplete | Check build_access_chain() |

### Performance Issues

| Symptom | Likely Cause | Resolution |
|---------|--------------|------------|
| Slow with --calls | Index not built | Verify CallsData builds indices on load |
| Memory spikes | Large calls.json | Consider streaming or lazy loading |

---

## Version History

| Date | Version | Changes |
|------|---------|---------|
| 2026-02-05 | 1.0 | Initial QA notes created |
