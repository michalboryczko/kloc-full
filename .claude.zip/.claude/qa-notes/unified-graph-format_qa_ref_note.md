# QA Testing Notes: unified-graph-format

## Feature Summary

The `unified-graph-format` feature implements a pure graph model that combines SCIP index + calls.json data into a single unified source-of-truth (sot.json v2.0). This eliminates the need for separate data sources and enables graph-based traversal for all code intelligence queries.

**Key Changes**:
1. **kloc-mapper**: Adds VALUE and CALL node kinds, new edge types, and .kloc archive loading
2. **kloc-cli**: Removes `--calls` option, updates graph loader for new types, implements access chain traversal via graph

**Spec**: `docs/specs/unified-graph-format.md`
**Plan**: `docs/specs/unified-graph-format-plan.md`

---

## Key Acceptance Criteria

| ID | Criterion | Priority |
|----|-----------|----------|
| AC1 | kloc-mapper accepts .kloc archive (ZIP containing index.scip + calls.json) | CRITICAL |
| AC2 | kloc-mapper outputs sot.json v2.0 with Value and Call nodes | CRITICAL |
| AC3 | All new edge types implemented: type_hint, calls, receiver, argument, produces, assigned_from, type_of | CRITICAL |
| AC4 | kloc-cli works without `--calls` option (data is in sot.json) | CRITICAL |
| AC5 | kloc-cli can build access chains via graph traversal | HIGH |
| AC6 | Backward compatibility: kloc-mapper accepts plain .scip files (no call data) | HIGH |
| AC7 | All existing tests pass | HIGH |
| AC8 | New tests cover Value/Call nodes and all new edge types | MEDIUM |

---

## Test Scenarios

### Category 1: kloc-mapper - Archive Loading

#### 1.1 Valid .kloc Archive Loading

**Scenario**: kloc-mapper successfully loads a valid .kloc archive

**Preconditions**:
- Valid .kloc archive (ZIP format) containing:
  - `manifest.json`
  - `index.scip`
  - `calls.json`

**Test Steps**:
1. Run `kloc-mapper map project.kloc --out sot.json`
2. Verify command completes without error
3. Verify output file is created
4. Verify output is valid JSON

**Expected Results**:
- Exit code 0
- sot.json created with valid JSON structure
- Version is "2.0"
- Contains both structural nodes (File, Class, Method, etc.) and runtime nodes (Value, Call)

**Edge Cases**:
- Archive with only manifest.json and index.scip (no calls.json): Should succeed with no Value/Call nodes
- Archive with empty calls.json: Should succeed with no Value/Call nodes
- Archive with different file order in ZIP: Should work regardless of order

---

#### 1.2 Invalid Archive Handling

**Scenario**: kloc-mapper provides clear errors for invalid archives

**Test Cases**:

| Input | Expected Error |
|-------|----------------|
| Non-existent file | File not found error |
| Not a ZIP file | "Invalid archive format" or similar |
| ZIP without manifest.json | "Missing manifest.json" |
| ZIP without index.scip | "Missing index.scip" |
| ZIP with malformed manifest.json | JSON parse error with context |
| ZIP with malformed calls.json | JSON parse error with context |

**Test Steps**:
1. Create test archives with each invalid condition
2. Run kloc-mapper map on each
3. Verify appropriate error message is returned
4. Verify exit code is non-zero

---

#### 1.3 Manifest Version Handling

**Scenario**: kloc-mapper handles manifest version appropriately

**Test Cases**:

| Manifest Version | Expected Behavior |
|-----------------|-------------------|
| "1.0" (current) | Process normally |
| "1.1" (minor bump) | Process normally with warning |
| "2.0" (major bump) | Warning about version, attempt processing |
| Missing version field | Error or use default |

---

#### 1.4 Backward Compatibility - Plain .scip Input

**Scenario**: kloc-mapper still accepts plain .scip files

**Preconditions**:
- Valid index.scip file (not in archive)

**Test Steps**:
1. Run `kloc-mapper map index.scip --out sot.json`
2. Verify command completes
3. Verify sot.json has version "2.0"
4. Verify sot.json has structural nodes
5. Verify sot.json has NO Value or Call nodes (no call data available)

**Expected Results**:
- Backward compatible with existing .scip files
- Output format is v2.0 but without runtime nodes

---

### Category 2: kloc-mapper - Node Generation

#### 2.1 Value Node Creation

**Scenario**: Value nodes are created correctly from calls.json values array

**Source Reference** (calls.json):
```json
{
  "values": [
    {
      "id": "src/Service.php:10:8",
      "kind": "parameter",
      "symbol": "...#process().($order)",
      "type": "...Order#",
      "location": {"file": "src/Service.php", "line": 10, "col": 8}
    }
  ]
}
```

**Expected sot.json Node**:
```json
{
  "id": "node:val:<hash>",
  "kind": "Value",
  "name": "$order",
  "fqn": "...",
  "symbol": "...#process().($order)",
  "file": "src/Service.php",
  "range": {"start_line": 10, "start_col": 8, ...},
  "value_kind": "parameter",
  "type_symbol": "...Order#"
}
```

**Test Cases by value_kind**:

| value_kind | Has symbol | Has source_call_id | Has source_value_id |
|------------|------------|-------------------|---------------------|
| parameter | Yes | No | No |
| local | Yes | Sometimes | Sometimes |
| literal | No | No | No |
| constant | Yes | No | No |
| result | No | Yes | No |

**Verification Steps**:
1. Load generated sot.json
2. Filter nodes by kind="Value"
3. Verify each value_kind is represented
4. Verify required fields are present
5. Verify node IDs are deterministic (same input = same ID)

---

#### 2.2 Call Node Creation

**Scenario**: Call nodes are created correctly from calls.json calls array

**Source Reference** (calls.json):
```json
{
  "calls": [
    {
      "id": "src/Service.php:10:20",
      "kind": "method",
      "kind_type": "invocation",
      "caller": "...#process().",
      "callee": "...#save().",
      "return_type": "...Order#",
      "location": {"file": "src/Service.php", "line": 10, "col": 20},
      "receiver_value_id": "src/Service.php:10:8",
      "arguments": [...]
    }
  ]
}
```

**Expected sot.json Node**:
```json
{
  "id": "node:call:<hash>",
  "kind": "Call",
  "name": "save()",
  "fqn": "...#process()@10:20",
  "symbol": null,
  "file": "src/Service.php",
  "range": {"start_line": 10, "start_col": 20, ...},
  "call_kind": "method"
}
```

**Test Cases by call_kind**:

| call_kind | Has receiver | Has arguments | Example |
|-----------|--------------|---------------|---------|
| method | Yes | Yes | `$obj->method()` |
| method_static | No | Yes | `Foo::method()` |
| constructor | No | Yes | `new Foo()` |
| access | Yes | No | `$obj->prop` |
| access_static | No | No | `Foo::$prop` |
| function | No | Yes | `func()` |

**Verification Steps**:
1. Load generated sot.json
2. Filter nodes by kind="Call"
3. Verify each call_kind is represented
4. Verify call_kind field is present on all Call nodes
5. Verify node IDs are deterministic

---

#### 2.3 Node ID Uniqueness and Determinism

**Scenario**: Node IDs are unique and deterministic

**Test Steps**:
1. Generate sot.json from same input twice
2. Compare node IDs between runs
3. Verify IDs are identical
4. Verify no ID collisions between Value and Call nodes at same location

**Expected Results**:
- Node IDs use format: `node:val:<hash>` for Value, `node:call:<hash>` for Call
- Same input always produces same IDs
- No collisions between different node types

---

### Category 3: kloc-mapper - Edge Generation

#### 3.1 type_hint Edges

**Scenario**: type_hint edges connect type-annotated elements to their types

**Source Code**:
```php
class OrderService
{
    private OrderRepository $orderRepository;  // type_hint edge

    public function createOrder(array $input): Order  // type_hint edges
}
```

**Expected Edges**:
```json
{"type": "type_hint", "source": "node:prop:orderRepository", "target": "node:class:OrderRepository"}
{"type": "type_hint", "source": "node:arg:input", "target": "node:builtin:array"}
{"type": "type_hint", "source": "node:method:createOrder", "target": "node:class:Order"}
```

**Verification**:
- Property -> Class type hint
- Argument -> Type hint
- Method -> Return type hint

---

#### 3.2 calls Edges

**Scenario**: calls edges connect Call nodes to their targets

**Source Code**:
```php
$this->orderRepository->save($order);  // Two calls
new Order($input);                      // Constructor call
```

**Expected Edges**:
```json
{"type": "calls", "source": "node:call:access", "target": "node:prop:orderRepository"}
{"type": "calls", "source": "node:call:method", "target": "node:method:save"}
{"type": "calls", "source": "node:call:constructor", "target": "node:class:Order"}
```

**Verification**:
- Method call -> Method node
- Property access -> Property node
- Constructor call -> Class node

---

#### 3.3 receiver Edges

**Scenario**: receiver edges connect Call nodes to their receiver Values

**Source Code**:
```php
$this->orderRepository->save($order);
//                     ^^^^ Call node
// receiver = $this->orderRepository (result Value)
```

**Expected Edge**:
```json
{"type": "receiver", "source": "node:call:save", "target": "node:val:orderRepository-result"}
```

**Verification**:
- receiver edges only on instance method calls and property accesses
- No receiver edges on static calls or constructors
- Target is always a Value node

---

#### 3.4 argument Edges (with position)

**Scenario**: argument edges connect Call nodes to argument Values with position

**Source Code**:
```php
$this->emailSender->send($to, $subject, $body);
```

**Expected Edges**:
```json
{"type": "argument", "source": "node:call:send", "target": "node:val:to", "position": 0}
{"type": "argument", "source": "node:call:send", "target": "node:val:subject", "position": 1}
{"type": "argument", "source": "node:call:send", "target": "node:val:body", "position": 2}
```

**Verification**:
- Position is 0-indexed
- Order matches source code argument order
- Target is always a Value node

---

#### 3.5 produces Edges

**Scenario**: produces edges connect Call nodes to their result Values

**Source Code**:
```php
$order = $this->orderRepository->save($order);
//       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//       Call produces Value assigned to $order
```

**Expected Edge**:
```json
{"type": "produces", "source": "node:call:save", "target": "node:val:order-result"}
```

**Verification**:
- Every call that produces a value has a produces edge
- Result value's source_call_id matches the call
- Target is Value node with value_kind="result" or "local"

---

#### 3.6 assigned_from Edges

**Scenario**: assigned_from edges connect Values to their source Values

**Source Code**:
```php
$copy = $original;  // Direct value assignment
```

**Expected Edge**:
```json
{"type": "assigned_from", "source": "node:val:copy", "target": "node:val:original"}
```

**Verification**:
- Only for direct value-to-value assignments
- Not for assignments from call results (use produces instead)

---

#### 3.7 type_of Edges

**Scenario**: type_of edges connect Values to their runtime type

**Source Code**:
```php
$order = new Order();  // $order has type_of -> Order
```

**Expected Edge**:
```json
{"type": "type_of", "source": "node:val:order", "target": "node:class:Order"}
```

**Verification**:
- Value nodes with known types have type_of edges
- Target is Class/Interface node

---

#### 3.8 contains Edges for Call/Value Nodes

**Scenario**: Call and Value nodes are contained within their scope

**Expected**:
```json
{"type": "contains", "source": "node:method:createOrder", "target": "node:call:save"}
{"type": "contains", "source": "node:method:createOrder", "target": "node:val:order"}
```

**Verification**:
- Every Call node has a contains edge from its enclosing Method/Function
- Every Value node has a contains edge from its scope

---

### Category 4: kloc-cli - Unified Loading

#### 4.1 --calls Option Removal

**Scenario**: kloc-cli context command no longer accepts --calls option

**Test Steps**:
1. Run `kloc-cli context "OrderRepository" --sot sot.json --calls calls.json`
2. Expect error about unknown option

**Expected Results**:
- Command fails with "unrecognized option: --calls" or similar
- Help text does not show --calls option

---

#### 4.2 Unified sot.json Loading

**Scenario**: kloc-cli loads sot.json v2.0 with Value/Call nodes

**Test Steps**:
1. Generate sot.json v2.0 with kloc-mapper
2. Run `kloc-cli context "OrderRepository" --sot sot.json`
3. Verify output includes call information

**Expected Results**:
- Context query works with unified sot.json
- Call data appears in output (access chains, method calls)

---

#### 4.3 Backward Compatibility - sot.json v1.0

**Scenario**: kloc-cli still works with v1.0 sot.json files

**Test Steps**:
1. Use existing v1.0 sot.json (no Value/Call nodes)
2. Run queries: resolve, usages, deps, owners, inherit, overrides
3. Verify queries work correctly

**Expected Results**:
- All structural queries work normally
- No errors about missing fields
- Context query works but shows no call data

---

### Category 5: kloc-cli - Access Chain Traversal

#### 5.1 Simple Property Access Chain

**Scenario**: CLI traverses `$this->property` chain

**Source Code**:
```php
$this->orderRepository->save($order);
```

**Test Steps**:
1. Query usages of `OrderRepository::save()`
2. Verify output shows access chain: `$this->orderRepository`

**Expected Results**:
- Output includes: `on: $this->orderRepository`
- Chain built by traversing receiver edges

---

#### 5.2 Multi-Level Access Chain

**Scenario**: CLI traverses `$this->service->repository->find()` chain

**Source Code**:
```php
$this->service->repository->find($id);
```

**Expected Access Chain**: `$this->service->repository`

**Verification**:
- Correctly follows multiple receiver edges
- Stops at parameter or local variable

---

#### 5.3 Static Method Call (No Chain)

**Scenario**: Static calls have no access chain

**Source Code**:
```php
OrderFactory::create($data);
```

**Expected Results**:
- No `on:` line in output
- call_kind="method_static" recognized

---

#### 5.4 Chain Traversal Performance

**Scenario**: Access chain traversal is performant

**Test Steps**:
1. Create deep chain (5+ levels)
2. Measure traversal time
3. Verify < 10ms per query

**Expected Results**:
- Traversal is O(depth) not O(nodes)
- Max depth limit prevents infinite loops

---

### Category 6: Integration Tests

#### 6.1 Full Pipeline Test

**Scenario**: Complete workflow from .kloc archive to CLI queries

**Test Steps**:
1. Create .kloc archive from kloc-reference-project-php
2. Run `kloc-mapper map project.kloc --out sot.json`
3. Run `kloc-cli context "OrderRepository" --sot sot.json`
4. Verify complete output with call data

**Expected Results**:
- Pipeline completes without errors
- Output includes structural and call information
- Access chains display correctly

---

#### 6.2 TC1: Method Call Chain

**Source Code**:
```php
$this->orderRepository->save($order);
```

**Verify**:
- [ ] Call node exists for property access (call_kind="access")
- [ ] Call node exists for method call (call_kind="method")
- [ ] receiver edge from method call to property access result
- [ ] calls edge from method call to save() method
- [ ] argument edge from method call to $order value

---

#### 6.3 TC2: Constructor Call

**Source Code**:
```php
$order = new Order($input);
```

**Verify**:
- [ ] Call node with call_kind="constructor"
- [ ] calls edge to Order class
- [ ] argument edge with position=0 to $input value
- [ ] produces edge to $order value
- [ ] $order Value has value_kind="local"

---

#### 6.4 TC3: Access Chain Traversal

**Source Code**:
```php
$this->service->repository->find($id);
```

**Verify**:
- [ ] CLI traverses receiver edges
- [ ] Builds chain: `$this->service->repository`
- [ ] Handles result values correctly

---

#### 6.5 TC4: Type Hint vs Method Call

**Source Code**:
```php
private OrderRepository $repo;  // type_hint
$this->repo->save();            // method call
```

**Verify**:
- [ ] type_hint edge from property to OrderRepository
- [ ] calls edge from Call node to save() method
- [ ] Different edge types clearly distinguish usage patterns

---

#### 6.6 TC5: Static Method Call

**Source Code**:
```php
OrderFactory::create($data);
```

**Verify**:
- [ ] Call node with call_kind="method_static"
- [ ] No receiver edge (static calls have no receiver)
- [ ] calls edge to create() method

---

### Category 7: Edge Cases

#### 7.1 Empty .kloc Archive

**Scenario**: Archive with index.scip but no calls.json

**Expected**:
- Generates valid sot.json with structural nodes only
- No Value or Call nodes present
- No errors

---

#### 7.2 Large Call Chains

**Scenario**: Very deep chained calls

**Source Code**:
```php
$a->b()->c()->d()->e()->f();  // 5+ levels
```

**Expected**:
- Graph correctly represents all calls
- CLI traversal completes without stack overflow
- Consider max depth limit (10 suggested in spec)

---

#### 7.3 Mixed Static and Instance Calls

**Scenario**: Chain starts with static call

**Source Code**:
```php
SomeClass::factory()->process();
```

**Expected**:
- First call is method_static
- Second call is method
- produces edge connects static result to instance call receiver

---

#### 7.4 Recursive Method Calls

**Scenario**: Method calls itself

**Source Code**:
```php
function factorial($n) {
    return $n <= 1 ? 1 : $n * factorial($n - 1);
}
```

**Expected**:
- Call node for recursive call
- calls edge points to same method
- No infinite loops in graph generation

---

#### 7.5 Nullsafe Operator Handling

**Source Code**:
```php
$order?->customer?->email;
```

**Expected**:
- call_kind is still "method" or "access" (not special kind)
- Return type may be union type with null

---

### Category 8: Error Handling

#### 8.1 kloc-mapper Error Messages

| Condition | Expected Error |
|-----------|----------------|
| Missing input file | "File not found: {path}" |
| Invalid ZIP | "Invalid archive format" |
| Missing manifest.json | "Archive missing manifest.json" |
| Missing index.scip | "Archive missing index.scip" |
| Invalid SCIP protobuf | SCIP parse error with details |
| Invalid JSON in calls.json | JSON parse error with location |
| Write permission denied | "Cannot write to {path}" |

---

#### 8.2 kloc-cli Error Messages

| Condition | Expected Error |
|-----------|----------------|
| Missing sot.json | "File not found: {path}" |
| Invalid sot.json JSON | JSON parse error |
| Unknown sot.json version | Warning, attempt to proceed |
| Symbol not found | "No matches found for: {symbol}" |

---

#### 8.3 Graceful Degradation

**Scenario**: sot.json has missing optional fields

**Test Steps**:
1. Create sot.json v2.0 with some Value nodes missing type_symbol
2. Run CLI queries
3. Verify no crashes

**Expected**:
- Optional fields default to null/empty
- Queries still work with available data

---

### Category 9: Regression Tests

#### 9.1 Existing Structural Queries

**Scenario**: All existing queries work unchanged

**Queries to Test**:
- `kloc-cli resolve "App\Entity\Order"` - Exact symbol resolution
- `kloc-cli usages "App\Entity\Order" --depth 2` - Usage tracking
- `kloc-cli deps "App\Service\OrderService::createOrder()"` - Dependencies
- `kloc-cli owners "App\Service\OrderService::createOrder()"` - Containment
- `kloc-cli inherit "App\Entity\Order" --direction up` - Inheritance
- `kloc-cli overrides "App\Entity\Order::getId()"` - Method overrides

**Expected**:
- All return same results as before
- No regressions in existing functionality

---

#### 9.2 Existing Test Suites Pass

**Test Steps**:
```bash
cd kloc-mapper && uv run pytest tests/ -v
cd kloc-cli && uv run pytest tests/ -v
```

**Expected**:
- All existing tests pass
- No test modifications required for backward compat

---

## Test Data / Fixtures

### .kloc Archive Structure

```
project.kloc (ZIP)
  |-- manifest.json
  |-- index.scip
  +-- calls.json
```

### manifest.json Example

```json
{
  "version": "1.0",
  "project_name": "kloc-reference-project-php",
  "project_root": "/path/to/kloc-reference-project-php",
  "generated_at": "2026-02-05T12:00:00Z",
  "scip_version": "0.3",
  "calls_version": "3.2"
}
```

### Test sot.json Fixture

```json
{
  "version": "2.0",
  "metadata": {
    "generated_at": "2026-02-05T12:00:00Z",
    "source": "project.kloc",
    "project_root": "/path/to/project"
  },
  "nodes": [
    {"id": "node:class1", "kind": "Class", "name": "OrderService", ...},
    {"id": "node:method1", "kind": "Method", "name": "createOrder", ...},
    {"id": "node:val1", "kind": "Value", "name": "$order", "value_kind": "local", ...},
    {"id": "node:call1", "kind": "Call", "name": "save()", "call_kind": "method", ...}
  ],
  "edges": [
    {"type": "contains", "source": "node:class1", "target": "node:method1"},
    {"type": "contains", "source": "node:method1", "target": "node:call1"},
    {"type": "calls", "source": "node:call1", "target": "node:method:save"},
    {"type": "receiver", "source": "node:call1", "target": "node:val:repo-result"},
    {"type": "argument", "source": "node:call1", "target": "node:val1", "position": 0}
  ]
}
```

### kloc-reference-project-php Test Points

| File | Line | Test Focus |
|------|------|------------|
| OrderRepository.php:26 | save() | Method parameters, local variables |
| OrderRepository.php:29 | new Order() | Constructor call, produces edge |
| OrderService.php:31-38 | new Order() | Constructor with multiple arguments |
| OrderService.php:40 | ->save() | Method call chain |
| OrderService.php:43-50 | ->send() | Property access chains, multiple arguments |

---

## Manual Testing Steps

### 1. Setup

```bash
# Ensure kloc-mapper is built
cd /Users/michal/dev/ai/kloc/kloc-mapper
uv pip install -e ".[dev]"

# Ensure kloc-cli is built
cd /Users/michal/dev/ai/kloc/kloc-cli
uv pip install -e ".[dev]"
```

### 2. Generate Test Archive

```bash
# If scip-php supports .kloc output:
cd /Users/michal/dev/ai/kloc/kloc-reference-project-php
scip-php index --output project.kloc

# Or manually create:
cd /Users/michal/dev/ai/kloc/artifacts
zip -j test.kloc manifest.json index.scip calls.json
```

### 3. Run kloc-mapper

```bash
# With .kloc archive
uv run kloc-mapper map artifacts/test.kloc --out artifacts/sot-v2.json --pretty

# With plain .scip (backward compat)
uv run kloc-mapper map artifacts/index.scip --out artifacts/sot-compat.json --pretty
```

### 4. Verify Output

```bash
# Check version
jq '.version' artifacts/sot-v2.json
# Expected: "2.0"

# Count node types
jq '[.nodes[].kind] | group_by(.) | map({kind: .[0], count: length})' artifacts/sot-v2.json

# Check for Value nodes
jq '[.nodes[] | select(.kind == "Value")] | length' artifacts/sot-v2.json

# Check for Call nodes
jq '[.nodes[] | select(.kind == "Call")] | length' artifacts/sot-v2.json

# Check edge types
jq '[.edges[].type] | unique' artifacts/sot-v2.json
# Expected: ["argument", "assigned_from", "calls", "contains", "extends",
#            "implements", "overrides", "produces", "receiver", "type_hint",
#            "type_of", "uses", "uses_trait"]

# Check argument edges have position
jq '[.edges[] | select(.type == "argument")] | .[0]' artifacts/sot-v2.json
```

### 5. Run kloc-cli Queries

```bash
# Test unified loading
uv run kloc-cli context "OrderRepository" --sot artifacts/sot-v2.json

# Verify --calls option is removed
uv run kloc-cli context "OrderRepository" --sot artifacts/sot-v2.json --calls artifacts/calls.json 2>&1
# Expected: Error about unknown option

# Test backward compat with v1.0
uv run kloc-cli resolve "App\Entity\Order" --sot artifacts/sot-v1.json
```

### 6. Run Automated Tests

```bash
# kloc-mapper tests
cd /Users/michal/dev/ai/kloc/kloc-mapper
uv run pytest tests/ -v

# kloc-cli tests
cd /Users/michal/dev/ai/kloc/kloc-cli
uv run pytest tests/ -v
```

---

## Automated Test Expectations

### kloc-mapper New Tests

**File**: `kloc-mapper/tests/test_archive.py`

```python
class TestKlocArchive:
    def test_load_valid_archive(self):
        """Load valid .kloc archive successfully."""

    def test_load_archive_no_calls_json(self):
        """Archive without calls.json works (structural only)."""

    def test_invalid_archive_format(self):
        """Non-ZIP file raises appropriate error."""

    def test_missing_manifest(self):
        """Archive without manifest.json raises error."""
```

**File**: `kloc-mapper/tests/test_calls_mapper.py`

```python
class TestCallsMapper:
    def test_value_node_creation_parameter(self):
        """Parameter values become Value nodes with value_kind='parameter'."""

    def test_value_node_creation_local(self):
        """Local variables become Value nodes with value_kind='local'."""

    def test_value_node_creation_result(self):
        """Call results become Value nodes with value_kind='result'."""

    def test_call_node_creation_method(self):
        """Method calls become Call nodes with call_kind='method'."""

    def test_call_node_creation_constructor(self):
        """Constructor calls become Call nodes with call_kind='constructor'."""

    def test_calls_edge_creation(self):
        """Call nodes have calls edges to their targets."""

    def test_receiver_edge_creation(self):
        """Instance calls have receiver edges to Value nodes."""

    def test_argument_edge_with_position(self):
        """Argument edges include position field."""

    def test_produces_edge_creation(self):
        """Calls have produces edges to result Values."""

    def test_type_of_edge_creation(self):
        """Values have type_of edges to their types."""
```

**File**: `kloc-mapper/tests/test_mapper.py` (additions)

```python
class TestUnifiedOutput:
    def test_output_version_2_0(self, graph):
        """Output has version 2.0."""

    def test_has_value_nodes(self, graph):
        """Graph contains Value nodes from calls.json."""

    def test_has_call_nodes(self, graph):
        """Graph contains Call nodes from calls.json."""

    def test_new_edge_types_present(self, graph):
        """Graph contains all new edge types."""
```

### kloc-cli New Tests

**File**: `kloc-cli/tests/test_access_chain.py`

```python
class TestAccessChainTraversal:
    def test_simple_property_chain(self):
        """Traverse $this->property chain."""

    def test_multi_level_chain(self):
        """Traverse $this->a->b->c chain."""

    def test_static_call_no_chain(self):
        """Static calls return no chain."""

    def test_chain_stops_at_parameter(self):
        """Chain traversal stops at parameter value."""

    def test_chain_stops_at_local(self):
        """Chain traversal stops at local variable."""
```

**File**: `kloc-cli/tests/test_index.py` (additions)

```python
class TestUnifiedIndex:
    def test_index_value_nodes(self):
        """Index handles Value nodes correctly."""

    def test_index_call_nodes(self):
        """Index handles Call nodes correctly."""

    def test_edge_lookup_new_types(self):
        """Edge lookup works for new edge types."""
```

---

## Integration Points

### 1. scip-php to kloc-mapper

**Integration**: .kloc archive format

**Verification**:
- Archive structure matches spec
- manifest.json has required fields
- index.scip is valid SCIP protobuf
- calls.json matches calls-schema.json

### 2. kloc-mapper to kloc-cli

**Integration**: sot.json v2.0 format

**Verification**:
- Version is "2.0"
- All node kinds recognized by CLI
- All edge types recognized by CLI
- Optional fields handled gracefully

### 3. Backward Compatibility

**kloc-mapper**:
- Still accepts plain .scip files
- Outputs v2.0 format (but without runtime nodes)

**kloc-cli**:
- Still reads v1.0 sot.json files
- Queries work with missing Value/Call data

---

## Performance Considerations

### Graph Size

- sot.json v2.0 will be 5-10x larger than v1.0 (more nodes and edges)
- Typical project: < 10MB estimated
- Large project: May need streaming/pagination

### Loading Time

- kloc-cli uses msgspec for fast JSON parsing
- Expected loading time: < 1 second for typical projects
- Monitor memory usage with large graphs

### Query Performance

- Access chain traversal: O(chain depth)
- Max depth limit (10) prevents runaway recursion
- Consider LRU cache for computed chains

### Benchmarks to Establish

| Operation | Target Time |
|-----------|-------------|
| Archive extraction | < 500ms |
| Graph generation (mapper) | < 5s for reference project |
| sot.json loading (CLI) | < 1s |
| Access chain traversal | < 10ms |
| Context query | < 500ms |

---

## Troubleshooting Guide

### kloc-mapper Issues

| Symptom | Likely Cause | Resolution |
|---------|--------------|------------|
| "Invalid archive format" | File is not ZIP | Check file extension and format |
| "Missing manifest.json" | Archive structure wrong | Verify archive contents |
| No Value/Call nodes in output | calls.json missing or empty | Check archive contents |
| Wrong node IDs | ID generation changed | Verify hash function input |

### kloc-cli Issues

| Symptom | Likely Cause | Resolution |
|---------|--------------|------------|
| "Unknown option: --calls" | Expected behavior | Option removed in v2.0 |
| No access chains in output | Value/Call nodes missing | Regenerate sot.json with .kloc input |
| "KeyError: value_kind" | Old sot.json version | Regenerate with new mapper |
| Slow context queries | Large graph | Check graph size, consider pagination |

### Graph Validation

```bash
# Verify all node IDs are unique
jq '[.nodes[].id] | length == ([.nodes[].id] | unique | length)' sot.json

# Verify all edge targets exist
jq --slurpfile nodes <(jq '.nodes[].id' sot.json) '
  .edges[] | select(.target as $t | $nodes | index($t) | not)
' sot.json
# Expected: empty (all targets exist)

# Verify argument edges have position
jq '.edges[] | select(.type == "argument" and .position == null)' sot.json
# Expected: empty (all argument edges have position)
```

---

## Version History

| Date | Version | Changes |
|------|---------|---------|
| 2026-02-05 | 1.0 | Initial QA notes created |
