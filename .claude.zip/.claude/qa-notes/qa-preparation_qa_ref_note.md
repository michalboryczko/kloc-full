# QA Notes: QA Preparation - Pre-Test Pipeline Issues

## Scope

Validate the 5 pipeline fixes. Test framework updates (112 tests on feature/qa-frameworks) are out of scope and will be handled separately after these fixes land.

## Recommended Implementation Order

1. **ISSUE-02** first -- isolated one-method fix, low risk, high correctness impact
2. **ISSUE-01** second -- additive schemas, validates current output
3. **ISSUE-03** third -- largest change, touches scip-php and kloc-mapper
4. **ISSUE-14** and **ISSUE-15** anytime -- independent, low priority

## Spec Accuracy Issues

The PM spec (`docs/specs/qa-preparation.md`) has two inaccuracies in the Dev Notes section (lines 96-97):

1. **NodeKind list is wrong**: Spec lists `Constant, Namespace` but actual code (`kloc-mapper/src/models.py:10-28`) has `Const, EnumCase` (no Namespace kind exists). Correct 13 kinds: File, Class, Interface, Trait, Enum, Method, Function, Property, Const, Argument, EnumCase, Value, Call.

2. **EdgeType list is wrong**: Spec lists `defines, contains, implements, uses, inherits` but actual code (`kloc-mapper/src/models.py:30-51`) has `contains, extends, implements, uses_trait, overrides, uses, type_hint, calls, receiver, argument, produces, assigned_from, type_of`. There is no `defines` or `inherits` EdgeType.

These inaccuracies MUST be corrected before ISSUE-01 schema creation, otherwise the JSON schemas will have wrong enum values.

---

## Risk Assessment Per Issue

### ISSUE-01: kloc-contracts JSON Schemas - RISK: MEDIUM

- **Correctness risk**: Schema enum values must exactly match `kloc-mapper/src/models.py`. The PM spec has wrong values (see above). Developers must reference the code directly.
- **Optional field risk**: Several Node fields are kind-specific (`value_kind` on Value, `call_kind` on Call, `type_symbol` on Value). Schema must mark them as optional. Same for Edge `position` (only on argument edges) and `location` (optional on most edges).
- **Integration risk**: Low. Schemas are additive; nothing breaks if a schema is created.

### ISSUE-02: FUNCTION Classification Bug - RISK: HIGH (output change)

- **Bug is confirmed**: `kloc-mapper/src/mapper.py:145` catches all `descriptor.endswith("().")` as METHOD. Line 179 FUNCTION check is dead code.
- **Output change**: After fix, standalone PHP functions change from `kind: "Method"` to `kind: "Function"` in sot.json.
- **kloc-cli impact**: CLI uses `kind` as a string, does not filter by "Method" vs "Function" differently. No CLI behavior change.
- **Edge case - constructors**: `__construct()` has `#` in its descriptor (e.g., `App/Entity/Order#__construct().`), so it will correctly remain METHOD.
- **Edge case - closures**: PHP closures/anonymous functions have unique descriptor patterns. Need to verify they are not affected.

### ISSUE-03: Unified JSON Output - RISK: HIGH (architecture change)

- **Backward compatibility**: During migration, kloc-mapper should accept both old `.kloc` format and new unified JSON. The `cli.py` dispatcher currently routes by file extension.
- **Data equivalence**: The unified JSON pipeline must produce identical sot.json to the old pipeline (for the same input). This is the critical validation.
- **kloc-mapper internals change**: `mapper.py` currently receives a `scip_pb2.Index` object from `parser.py`. After ISSUE-03, it receives parsed JSON. The `SCIPMapper.__init__` and internal methods change.
- **Memory risk**: Large PHP projects could produce large unified JSON files.
- **Note**: Test fixture breakage (KlocFixtureBuilder depends on scip_pb2.py) is expected and out of scope -- will be addressed when test frameworks are updated separately.

### ISSUE-14: Version Handling - RISK: LOW

- Additive change. No output format changes.
- Risk: False-positive warnings if version field is absent in legacy data. Should be a warning, not an error.

### ISSUE-15: Documentation Update - RISK: NONE

- Docs-only change. No code impact.

---

## Test Scenarios

### ISSUE-01: kloc-contracts

#### Happy Path
- GIVEN a valid sot.json from the reference project WHEN validated against `sot-json.json` schema THEN validation passes
- GIVEN a valid unified JSON from scip-php WHEN validated against `scip-php-output.json` schema THEN validation passes
- GIVEN the `sot-json.json` schema WHEN I check the NodeKind enum THEN it has exactly 13 values matching `kloc-mapper/src/models.py:NodeKind`
- GIVEN the `sot-json.json` schema WHEN I check the EdgeType enum THEN it has exactly 12 values matching `kloc-mapper/src/models.py:EdgeType`

#### Edge Cases
- GIVEN a sot.json with Value nodes that have `value_kind` and `type_symbol` WHEN validated THEN passes (kind-specific optional fields)
- GIVEN a sot.json with File nodes that lack `range` and `enclosing_range` WHEN validated THEN passes (these are optional)
- GIVEN a sot.json with an argument edge that has `position: 0` WHEN validated THEN passes
- GIVEN a sot.json with a contains edge that lacks `position` WHEN validated THEN passes

#### Error Handling
- GIVEN a sot.json with `"kind": "Widget"` WHEN validated THEN fails with enum validation error
- GIVEN a sot.json with a node missing `id` WHEN validated THEN fails with required field error
- GIVEN a sot.json with `"type": "destroys"` edge type WHEN validated THEN fails with enum validation error

### ISSUE-02: FUNCTION Bug Fix

#### Happy Path
- GIVEN a SCIP index with standalone function `formatPrice` (descriptor: `App/Helper/formatPrice().`) WHEN kloc-mapper processes it THEN sot.json contains a node with `kind: "Function"` and `name: "formatPrice"`
- GIVEN a SCIP index with class method `Order::getId` (descriptor: `App/Entity/Order#getId().`) WHEN kloc-mapper processes it THEN sot.json contains a node with `kind: "Method"` and `name: "getId"`

#### Edge Cases
- GIVEN a SCIP index with constructor `Order::__construct` (descriptor: `App/Entity/Order#__construct().`) WHEN kloc-mapper processes it THEN sot.json contains a node with `kind: "Method"` (constructor is a method, not a function)
- GIVEN a SCIP index with both a standalone function AND a class method of the same name WHEN kloc-mapper processes it THEN both nodes exist with correct kinds (Function vs Method)
- GIVEN a SCIP index with a namespaced function `App\Helper\formatPrice` (no class, no `#` in descriptor) WHEN kloc-mapper processes it THEN kind is "Function"

#### Regression
- GIVEN the reference project sot.json WHEN compared pre-fix vs post-fix THEN ONLY standalone function nodes changed kind from "Method" to "Function"; all other nodes unchanged

### ISSUE-03: Unified JSON

#### Happy Path
- GIVEN scip-php processes the reference project with unified JSON mode WHEN complete THEN a single `.json` file exists with keys: `version`, `scip`, `calls`, `values`
- GIVEN a unified JSON file WHEN kloc-mapper processes it THEN output sot.json is identical to the `.kloc` pipeline output (for the same input project)
- GIVEN the unified JSON pipeline WHEN run end-to-end THEN kloc-cli can query the resulting sot.json normally

#### Edge Cases
- GIVEN a PHP project with no calls.json data (no function calls) WHEN scip-php produces unified JSON THEN the `calls` and `values` arrays are empty but present
- GIVEN a unified JSON file with empty `scip.documents` array WHEN kloc-mapper processes it THEN it produces an empty sot.json (no nodes, no edges) without error

#### Backward Compatibility (Migration Period)
- GIVEN an old-format `.kloc` ZIP archive WHEN passed to the updated kloc-mapper THEN it still produces correct sot.json output

#### Error Handling
- GIVEN a malformed unified JSON file (invalid JSON syntax) WHEN kloc-mapper tries to process it THEN a clear error message is shown
- GIVEN a unified JSON file missing the `scip` key WHEN kloc-mapper processes it THEN a clear error about missing required data is shown

### ISSUE-14: Version Handling

#### Happy Path
- GIVEN unified JSON input with `"version": "4.0"` WHEN kloc-mapper processes it THEN no warning is logged and processing succeeds
- GIVEN input with missing version field WHEN kloc-mapper processes it THEN a deprecation warning is logged but output is correct

#### Edge Cases
- GIVEN input with `"version": "99.0"` WHEN kloc-mapper processes it THEN a warning about unknown version is logged but processing completes
- GIVEN input with `"version": ""` (empty string) WHEN kloc-mapper processes it THEN treated same as missing version

### ISSUE-15: Documentation Update

#### Happy Path
- GIVEN the updated `docs/summary.md` WHEN compared to `kloc-mapper/src/models.py` THEN all 13 NodeKind values are listed with descriptions
- GIVEN the updated `docs/summary.md` WHEN compared to `kloc-mapper/src/models.py` THEN all 12 EdgeType values are listed with descriptions
- GIVEN the updated docs WHEN I check the Class description THEN it does NOT say "includes enums"

---

## Regression Risk Analysis

### High Risk

1. **ISSUE-02 changes sot.json output**: Standalone functions change from `kind: "Method"` to `kind: "Function"`. Mitigated by: the bug means "Function" was never produced, so no downstream consumer depends on it.

2. **ISSUE-03 changes kloc-mapper input format**: `mapper.py` currently receives a `scip_pb2.Index` object. After ISSUE-03, it receives parsed JSON dict. Internal method signatures change.

### Medium Risk

3. **ISSUE-01 schema strictness**: If schemas are too strict (e.g., requiring `enclosing_range` on all nodes), valid sot.json files will fail validation. If too loose, invalid files pass.

### Low Risk

4. **ISSUE-14 version warnings**: False-positive warnings for legacy data, but no functional impact.
5. **ISSUE-15 docs**: No code changes, no regression possible.

### Out of Scope (Expected Breakage)

- Test fixture infrastructure breakage from ISSUE-03 (KlocFixtureBuilder, pipeline_runner) is expected and will be addressed when test frameworks are updated on feature/qa-frameworks branches separately.

---

## Validation Approach

### ISSUE-01 Validation
- Compare enum values in schemas against `kloc-mapper/src/models.py` enums
- Run `jsonschema` validation on existing sot.json artifact (`contract-tests/output/sot.json`)
- Create intentionally invalid sot.json and verify schema rejects it

### ISSUE-02 Validation
- Run kloc-mapper on the reference project and verify standalone functions have `kind: "Function"`
- Verify class methods still have `kind: "Method"`
- Verify constructors (`__construct`) still have `kind: "Method"`
- Diff pre-fix vs post-fix sot.json: only function kind changes expected

### ISSUE-03 Validation
- Generate sot.json from the reference project using both old (`.kloc`) and new (unified JSON) pipelines
- Compare outputs field-by-field (allowing for metadata timestamp differences)
- Validate unified JSON output against `scip-php-output.json` schema
- Run `kloc-cli resolve` on the resulting sot.json to verify end-to-end pipeline works

### ISSUE-14 Validation
- Run kloc-mapper with various version values and check log output for appropriate warnings
- Verify sot.json output is identical regardless of input version value

### ISSUE-15 Validation
- Compare updated `docs/summary.md` against `kloc-mapper/src/models.py` for accuracy
- Verify all 13 NodeKinds and 12 EdgeTypes are listed with correct names

---

## Manual Testing Steps

1. **ISSUE-02**: Run `kloc-mapper map` on the reference project, grep sot.json for `"Function"` -- should now appear where standalone functions exist
2. **ISSUE-03**: Run full pipeline manually: `scip-php (unified JSON) -> kloc-mapper -> kloc-cli resolve "App\Entity\Order"` -- should work identically to old pipeline
3. **ISSUE-15**: Open updated `docs/summary.md` and visually compare against `kloc-mapper/src/models.py` enums
