# QA Reference Note: Context Command v2 (Issues A-E)

**Date:** 2026-02-09
**Feature Branch:** feature/cli-context-fix
**Scope:** kloc-mapper (ISSUE-A only) + kloc-contracts (ISSUE-A only) + kloc-cli (all issues)
**Spec:** `docs/specs/cli-context-fix-v2.md` (36 acceptance criteria across 4 phases)
**Issues:** 5 issues: A (value_expr), B (types), C (variable-centric), D (rich args), E (definition)
**Depends on:** Previous feature `cli-context-fix` (Phase 1-3 shipped)

---

## 0. Acceptance Criteria Traceability Matrix

The spec defines 36 acceptance criteria (AC 1-36). Each is mapped to test scenarios below. Every AC must have at least one automated test before the phase ships.

| Spec AC | Description | Test Scenarios | Test Type |
|---------|-------------|----------------|-----------|
| AC 1 | Mapper preserves `value_expr` as `expression` on argument edge | A-01, A-02 | Mapper unit + integration |
| AC 1+ | Mapper creates `assigned_from` edges via `source_call_id` chain | AF-01, AF-02, AF-03, AF-04 | Mapper unit + integration |
| AC 2 | CLI shows expression text instead of `(result)` | A-03, A-04 | CLI integration |
| AC 3 | Literal args show actual values instead of `(literal)` | A-05 | CLI integration |
| AC 4 | Constructor-as-arg shows expression | A-06 | CLI integration |
| AC 5 | Complex expression shows full text | A-07 | CLI integration |
| AC 6 | Backward compat: falls back to Value node name | A-08 | CLI unit |
| AC 7 | Schema validates new field | A-09 | Contract validation |
| AC 8 | JSON includes `value_expr` with expression text | A-10 | CLI integration |
| AC 9 | Kind 1: variable entry with nested source | C-01, C-02 | CLI integration |
| AC 10 | Kind 2: call entry for discarded result | C-03, C-04 | CLI integration |
| AC 11 | Receiver chain nested in `on:`, not separate entry | C-05, C-06 | CLI integration |
| AC 12 | Argument property_access nested in arg source chain | C-07 | CLI integration |
| AC 13 | Arguments cross-reference by graph symbol | C-08 | CLI integration |
| AC 14 | Entries in line number order | C-09 | CLI integration |
| AC 15 | Class-level query preserves structural USES | C-10 | CLI integration |
| AC 16 | JSON uses `type: "local_variable"` / `type: "call"` | C-11, C-12 | CLI integration |
| AC 17 | Method DEFINITION shows signature, args, return type | E-01, E-02 | CLI integration |
| AC 18 | Class DEFINITION shows properties, methods, inheritance | E-03, E-04 | CLI integration |
| AC 19 | Property DEFINITION shows name, type, visibility | E-05 | CLI integration |
| AC 20 | Argument DEFINITION shows name, type, method, position | E-06 | CLI integration |
| AC 21 | Constructor DEFINITION shows `(constructor)` return type | E-07 | CLI integration |
| AC 22 | Minimal DEFINITION when data unavailable | E-08 | CLI unit |
| AC 23 | JSON includes `definition` object | E-09, E-10 | CLI integration |
| AC 24 | Type in parentheses for argument with `type_of` | B-01, B-02 | CLI integration |
| AC 25 | Short name for class types | B-03 | CLI integration |
| AC 26 | Union types joined with `\|` | B-04 | CLI unit |
| AC 27 | No type shown when no `type_of` edge | B-05 | CLI unit |
| AC 28 | JSON includes `value_type` | B-06 | CLI integration |
| AC 29 | Formal parameter FQN shown | D-01 | CLI integration |
| AC 30 | Local variable arg = one-line reference with graph symbol | D-02 | CLI integration |
| AC 31 | Method parameter arg = one-line reference | D-03 | CLI integration |
| AC 32 | Literal arg = one-line inline with `literal` tag | D-04 | CLI integration |
| AC 33 | Property access arg = expanded source chain | D-05, D-06 | CLI integration |
| AC 34 | Nested constructor arg = expanded in source chain | D-07 | CLI integration |
| AC 35 | JSON: `value_ref_symbol` OR `source_chain`, never both | D-08 | CLI integration |
| AC 36 | Graceful degradation on incomplete data | D-09 | CLI unit |

---

## 1. Test Scenarios Per Phase

### Phase 1: ISSUE-A -- Preserve value_expr (AC 1-8)

#### Mapper Tests (kloc-mapper)

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| A-01 | Mapper reads `value_expr` and stores as `expression` | calls.json entry with `value_expr: "$input->productId"` | sot.json argument edge has `"expression": "$input->productId"` | 1 |
| A-02 | Mapper omits `expression` when `value_expr` is null | calls.json entry with `value_expr: null` | sot.json argument edge has NO `expression` key (or `expression: null`) | 1 |

**Test file:** `kloc-mapper/tests/test_calls_mapper.py` (new or extend existing)

**Test approach:** Create a minimal calls.json fixture with ArgumentRecords that have `value_expr`. Run the mapper. Load the resulting sot.json. Assert argument edges have `expression` fields.

```python
def test_argument_edge_preserves_value_expr():
    """Mapper reads value_expr from calls.json and stores as expression on argument edge."""
    # Create calls.json with value_expr
    calls_data = {
        "version": "4.0",
        "project_root": "",
        "values": [...],
        "calls": [{
            "id": "...",
            "kind": "method",
            "arguments": [{
                "position": 0,
                "parameter": "...",
                "value_id": "...",
                "value_expr": "$input->productId"
            }]
        }]
    }
    # Run mapper, load output, assert edge.expression == "$input->productId"
```

#### Mapper `assigned_from` Edge Tests (ISSUE-A pipeline fix)

**Background:** scip-php does NOT provide `source_value_id` (always null), so the mapper previously never created `assigned_from` edges. However, scip-php DOES provide `source_call_id` on 35 of 45 local Value nodes. The mapper will be updated in ISSUE-A to create `assigned_from` edges using the chain: `source_call_id` -> Call node -> `produces` edge -> result Value node.

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| AF-01 | Mapper creates `assigned_from` edge for local with `source_call_id` | Local value `$order` with `source_call_id` matching `new Order()` call | sot.json has `assigned_from` edge: `v:$order` -> `v:result_of_new_Order` | 1+ |
| AF-02 | All 4 createOrder() locals get `assigned_from` edges | Process full reference project calls.json | `$order`, `$processedOrder`, `$processorName`, `$savedOrder` each have `assigned_from` edges | 1+ |
| AF-03 | Locals WITHOUT `source_call_id` have no `assigned_from` edge | Local value with `source_call_id: null` | No `assigned_from` edge created; no error | 1+ |
| AF-04 | `assigned_from` edge chain resolution works | Local with `source_call_id: "src/Service/OrderService.php:45:40"` | Edge resolves through: Call node (by call ID) -> `produces` -> result Value | 1+ |

**Test file:** `kloc-mapper/tests/test_calls_mapper.py` (new or extend existing)

**Test approach for AF-01:**
```python
def test_assigned_from_edge_created_via_source_call_id():
    """Mapper creates assigned_from edge when local has source_call_id."""
    # 1. Create calls.json with a call that produces a result
    # 2. Create values with a local that has source_call_id matching the call
    # 3. Run mapper
    # 4. Assert assigned_from edge exists from local value to result value
```

**Test approach for AF-03:**
```python
def test_no_assigned_from_when_source_call_id_null():
    """Mapper gracefully handles locals without source_call_id."""
    # 1. Create values with source_call_id: null
    # 2. Run mapper
    # 3. Assert no assigned_from edges created for these values
    # 4. Assert no errors
```

#### Mapper Edge Model Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| A-02b | Edge model serializes `expression` field | Edge with expression="$x" | `to_dict()` output includes `"expression": "$x"` | 1 |
| A-02c | Edge model omits `expression` when None | Edge with expression=None | `to_dict()` output has no `expression` key | 1 |

**Test file:** `kloc-mapper/tests/test_models.py` (extend)

#### Contract Schema Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| A-09 | Schema accepts argument edge with `expression` | sot.json with expression on argument edge | `validate.py` passes | 7 |
| A-09b | Schema accepts argument edge without `expression` | sot.json without expression | `validate.py` passes (backward compat) | 7 |

**Test file:** `kloc-contracts/validate.py` (manual run or extend)

#### CLI Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| A-03 | Property access argument shows expression | `context "OrderService::createOrder"` | checkAvailability args: `$productId <- $input->productId` | 2 |
| A-04 | Multiple property accesses show expressions | Same query | checkAvailability args: `$quantity <- $input->quantity` | 2 |
| A-05 | Literal argument shows actual value | Same query | Order::__construct args include `$status <- 'pending'` | 3 |
| A-06 | Constructor-as-arg shows expression | Same query | Order::__construct args: `$createdAt <- new DateTimeImmutable()` | 4 |
| A-07 | String concatenation shows full expression | Same query | send args: `$subject <- 'Order Confirmation #' . $savedOrder->id` | 5 |
| A-08 | Backward compat: no expression falls back to Value name | Fixture without `expression` field on edges | CLI shows Value node name (e.g., `$order`) not error | 6 |
| A-10 | JSON includes `value_expr` with expression text | `--json` output | `arguments[0].value_expr == "$input->productId"` | 8 |

**Test file:** `kloc-cli/tests/test_usage_flow.py` (extend `TestPhase2ArgumentTracking`)

**Fixture requirement:** After mapper change, need to regenerate sot.json from reference project. The current fixture has 0 expression fields on argument edges. Tests A-03 through A-07 will FAIL until the fixture is regenerated with the new mapper.

**Unit test for backward compat (A-08):**

```python
def test_expression_fallback_to_value_name():
    """When argument edge has no expression field, CLI uses Value node name."""
    # Create synthetic fixture with argument edge WITHOUT expression
    # Assert CLI shows arg_node.name, not "(unknown)" or error
```

---

### Phase 2a: ISSUE-C -- Variable-centric flow + chain dedup (AC 9-16)

#### CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| C-01 | Kind 1: `$order = new Order(...)` -> variable entry | `context "OrderService::createOrder"` | Entry format: `[2] local#32$order (Order) [variable]` with `source: Order::__construct() [instantiation]` | 9 |
| C-02 | Kind 1: `$processedOrder = process($order)` -> variable entry | Same query | Entry format: `[3] local#42$processedOrder (Order) [variable]` with `source: AbstractOrderProcessor::process() [method_call]` | 9 |
| C-03 | Kind 2: `checkAvailability(...)` result discarded -> call entry | Same query | Entry format: `[1] InventoryCheckerInterface::checkAvailability() [method_call]` (call as primary) | 10 |
| C-04 | Kind 2: `send(...)` result discarded -> call entry | Same query | Entry format: `[6] EmailSenderInterface::send() [method_call]` | 10 |
| C-05 | Receiver chain nested: `$this->inventoryChecker` inside `on:` | Same query | Entry [1] has `on: $this->inventoryChecker (OrderService::$inventoryChecker)`, NO separate `[0]` entry for property access | 11 |
| C-06 | No separate entry for intermediate receiver calls | Same query | Total top-level `[N]` entries = 8 (not 15+), one per logical operation | 11 |
| C-07 | Argument property_access nested in arg source chain | Same query | `$input->productId` appears inside arg of entry [1], NOT as separate `[N]` entry | 12 |
| C-08 | Cross-reference to earlier variable entry | Same query | process().$order argument shows `local#32$order` reference | 13 |
| C-09 | Entries in line number order | Same query | Entry numbers [1]-[8] appear in ascending line order | 14 |
| C-10 | Class-level query preserves structural USES | `context "OrderRepository"` | USES shows structural deps (property_access, type_hint), NOT variable-centric entries | 15 |
| C-11 | JSON Kind 1 entry has `type: "local_variable"` | `--json` output | Variable entries have `"type": "local_variable"` with `"source"` object | 16 |
| C-12 | JSON Kind 2 entry has `type: "call"` | `--json` output | Call entries have `"type": "call"` | 16 |

**Test file:** `kloc-cli/tests/test_context_v2.py` (NEW file recommended)

**Rationale for new test file:** ISSUE-C fundamentally changes the USES output structure. Existing `test_usage_flow.py` tests assert the current call-centric format. Rather than rewriting in-place (risking merge conflicts with other work), create a new test file for the variable-centric model. The old tests can be marked as expected failures or removed once ISSUE-C ships.

#### Fixture Requirement: `assigned_from` Edges

**RESOLVED (via ISSUE-A).** The current sot.json has ZERO `assigned_from` edges, but this will be fixed as part of ISSUE-A (Phase 1). scip-php already provides `source_call_id` on 35 of 45 local Value nodes. The mapper will be updated to create `assigned_from` edges using the chain: `source_call_id` -> Call node -> `produces` edge -> result Value node.

**After ISSUE-A ships:**
- sot.json will have `assigned_from` edges for ~35 locals (those with `source_call_id`)
- 10 locals without `source_call_id` will NOT have `assigned_from` edges (graceful fallback required)
- Fixture must be regenerated after mapper changes before Phase 2 tests can pass

**Interim testing approach:** Create synthetic sot.json fixtures with `assigned_from` edges for unit tests. This allows testing the CLI logic while the mapper fix is in progress.

```python
@pytest.fixture
def synthetic_sot_with_assignments():
    """Minimal sot.json with assigned_from edges for Kind 1 testing."""
    data = {
        "version": "2.0",
        "metadata": {},
        "nodes": [
            # Method node
            {"id": "m:createOrder", "kind": "Method", ...},
            # Call node (constructor)
            {"id": "c:newOrder", "kind": "Call", "call_kind": "constructor", ...},
            # Value node: result of constructor
            {"id": "v:result", "kind": "Value", "value_kind": "result", ...},
            # Value node: local variable $order
            {"id": "v:order", "kind": "Value", "value_kind": "local",
             "name": "$order", ...},
        ],
        "edges": [
            {"type": "contains", "source": "m:createOrder", "target": "c:newOrder"},
            {"type": "contains", "source": "m:createOrder", "target": "v:order"},
            {"type": "produces", "source": "c:newOrder", "target": "v:result"},
            {"type": "assigned_from", "source": "v:order", "target": "v:result"},
        ],
    }
    ...
```

#### Chain Dedup Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| C-05b | Count top-level entries (dedup validation) | `context "OrderService::createOrder"` | Exactly 8 top-level `[N]` entries | 11, 12 |
| C-06b | Receiver chain depth test | Hypothetical: `$this->config->getSettings()->getProcessor()->process()` | One entry with 3 nested `on:` levels, not 4 separate entries | 11 |

---

### Phase 2b: ISSUE-E -- Definition section (AC 17-23)

#### CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| E-01 | Method DEFINITION shows signature | `context "OrderService::createOrder"` | DEFINITION section: `createOrder(CreateOrderInput $input): OrderOutput` | 17 |
| E-02 | Method DEFINITION shows typed arguments and return type | Same query | Arguments: `$input: CreateOrderInput`, Return type: `OrderOutput` | 17 |
| E-03 | Class DEFINITION shows properties and methods | `context "OrderService"` | Properties list (5 items), Methods list (3 items) | 18 |
| E-04 | Class DEFINITION shows modifiers | Same query | `class OrderService (final readonly)` or similar | 18 |
| E-05 | Property DEFINITION shows name, type, visibility | `context "OrderService::$orderRepository"` | `$orderRepository: OrderRepositoryInterface`, visibility, containing class | 19 |
| E-06 | Argument DEFINITION shows container and position | `context "OrderService::createOrder().$input"` | `$input: CreateOrderInput`, Argument of: `OrderService::createOrder()`, Position: 0 | 20 |
| E-07 | Constructor DEFINITION shows `(constructor)` return | `context "Order::__construct"` | Return type: `(constructor)` | 21 |
| E-08 | Minimal DEFINITION for unknown symbol | Node with no signature, no type_hint edges | Shows kind + FQN + file + line only | 22 |
| E-09 | JSON includes `definition` object for method | `context "OrderService::createOrder" --json` | JSON has `"definition"` key with `fqn`, `kind`, `signature`, `arguments`, `return_type` | 23 |
| E-10 | JSON includes `definition` object for class | `context "OrderService" --json` | JSON `definition` has `methods`, `properties`, `extends`, `implements` | 23 |

**Test file:** `kloc-cli/tests/test_context_v2.py` (same new file, separate class)

**Fixture:** Existing `kloc-reference-project-php/contract-tests/output/sot.json` is sufficient. It has Class, Method, Property, Argument nodes with `contains` and `type_hint` edges.

#### Edge Case Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| E-08b | DEFINITION section appears BEFORE USED BY | Any context query | Output order: DEFINITION, then USED BY, then USES | 17 |
| E-08c | DEFINITION consolidates header info | Method query | FQN, file, line appear in DEFINITION, not duplicated above | 17 |
| E-11 | No Enum nodes handled gracefully | If no Enum in fixture | DEFINITION shows minimal view for unknown kinds | 22 |

---

### Phase 3: ISSUE-B -- Value type resolution (AC 24-28)

#### CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| B-01 | Scalar type in parentheses | `context "OrderService::createOrder"` | checkAvailability args: `$productId (string) <- $input->productId` | 24 |
| B-02 | Integer type in parentheses | Same query | checkAvailability args: `$quantity (int) <- $input->quantity` | 24 |
| B-03 | Class type uses short name | Same query | process args: `$order (Order) <- $order` | 25 |
| B-04 | Union type display | Synthetic fixture with 2 type_of edges on one Value | Output: `$value (string\|int) <- $input->value` | 26 |
| B-05 | No type shown when no type_of edge | Synthetic fixture with Value without type_of | Output: `$param <- $value` (no parenthetical type) | 27 |
| B-06 | JSON includes `value_type` | `--json` output | Argument object has `"value_type": "string"` | 28 |
| B-07 | JSON `value_type` is null when absent | `--json` output for arg without type | Argument object has `"value_type": null` | 28 |

**Test file:** `kloc-cli/tests/test_context_v2.py` (extend)

**Fixture requirements:**
- Integration tests: Existing fixture has 99 `type_of` edges. Sufficient for B-01, B-02, B-03.
- Unit test B-04: Need synthetic fixture with multiple `type_of` edges on one Value node (union type). Reference project unlikely to have union types.
- Unit test B-05: Need synthetic fixture with Value node that has no `type_of` edge.

#### Index Method Extension

The current `get_type_of()` returns only ONE target (line 442-447 of index.py). For union types (AC 26), this needs to return ALL targets. Tests:

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| B-08 | `get_type_of_targets()` returns multiple IDs | Value with 2 type_of edges | Returns list of 2 node IDs | 26 |
| B-09 | `get_type_of_targets()` returns empty for no edges | Value with 0 type_of edges | Returns empty list | 27 |

**Test file:** `kloc-cli/tests/test_index.py` (extend)

---

### Phase 4: ISSUE-D -- Rich argument display (AC 29-36)

**Dependencies:** ISSUE-A (AC 1-8), ISSUE-B (AC 24-28), ISSUE-C (AC 9-16) must all be complete.

#### CLI Integration Tests

| ID | Scenario | Input | Expected Output | AC |
|----|----------|-------|-----------------|-----|
| D-01 | Formal parameter FQN shown | `context "OrderService::createOrder"` | Args show `process().$order (Order): ...` format | 29 |
| D-02 | Local variable arg = one-line with graph symbol | Same query | `process().$order (Order): \`$order\` local#32$order` | 30 |
| D-03 | Method parameter arg = one-line reference | Same query | `checkAvailability().$productId (string): \`$input->productId\` OrderService::createOrder().$input` | 31 |
| D-04 | Literal arg = one-line with `literal` tag | Same query | `Order::__construct().$id (int): \`0\` literal` | 32 |
| D-05 | Property access arg = expanded source chain | Same query | `send().$to (string): \`$savedOrder->customerEmail\`` with nested `source: Order::$customerEmail [property_access]` and `on: local#45$savedOrder` | 33 |
| D-06 | Multiple property accesses in OrderOutput constructor | Same query | All 6 args show source chains pointing to `local#45$savedOrder` properties | 33 |
| D-07 | Nested constructor as argument value expanded | Same query | `dispatch().$message` shows nested `OrderCreatedMessage::__construct()` with its own args | 34 |
| D-08 | JSON: `value_ref_symbol` XOR `source_chain` | `--json` output | Local var args: `value_ref_symbol` set, `source_chain` null. Property access args: `value_ref_symbol` null, `source_chain` set. | 35 |
| D-09 | Graceful degradation on incomplete data | Synthetic fixture with missing chain data | Shows expression + type, no error, no `null` in display | 36 |

**Test file:** `kloc-cli/tests/test_context_v2.py` (extend)

**Fixture:** Same regenerated sot.json as ISSUE-A + assigned_from edges fix from ISSUE-C. Additionally needs synthetic fixture for D-09.

---

## 2. Test Infrastructure

### 2.1 Existing Test Infrastructure

| File | Type | Fixture | Tests | Impact |
|------|------|---------|-------|--------|
| `kloc-cli/tests/test_usage_flow.py` | Integration | reference project sot.json | 19 tests | REWRITE needed after ISSUE-C |
| `kloc-cli/tests/test_reference_type.py` | Unit | In-memory mocks | 28 tests | KEEP unchanged |
| `kloc-cli/tests/test_callee_verification.py` | Unit | Mock index | 11 tests | KEEP unchanged |
| `kloc-cli/tests/test_index.py` | Unit | Temp file | 12 tests | EXTEND for new methods |
| `kloc-cli/tests/test_integration.py` | Integration | sot_fixed.json | 14 tests | KEEP unchanged |
| `kloc-mapper/tests/test_mapper.py` | Integration | artifacts/index.json | Existing | EXTEND for expression |
| `kloc-mapper/tests/test_models.py` | Unit | In-memory | Existing | EXTEND for Edge.expression |

### 2.2 New Test File

**`kloc-cli/tests/test_context_v2.py`** -- Houses all tests for the v2 context command output format.

Rationale: The variable-centric model (ISSUE-C) fundamentally changes the USES output. Creating a new file avoids in-place rewrites of `test_usage_flow.py` and allows both to coexist during the transition. The old test file documents the current behavior; the new file documents the target behavior.

Structure:

```python
class TestPhase1Expression:
    """Phase 1 (ISSUE-A): Expression text in argument display."""

class TestPhase2aVariableCentric:
    """Phase 2a (ISSUE-C): Variable-centric execution flow."""

class TestPhase2aChainDedup:
    """Phase 2a (ISSUE-C): Chain deduplication."""

class TestPhase2bDefinition:
    """Phase 2b (ISSUE-E): Definition section."""

class TestPhase3TypeResolution:
    """Phase 3 (ISSUE-B): Value type resolution."""

class TestPhase4RichArgDisplay:
    """Phase 4 (ISSUE-D): Rich argument display with source chains."""

class TestPhase4JsonOutput:
    """Phase 4 (ISSUE-D): JSON output for rich arguments."""

class TestBackwardCompatibility:
    """Cross-phase backward compatibility checks."""

class TestMcpServer:
    """MCP server response validation across all phases."""
```

### 2.3 Fixture Requirements

| Fixture | Used By | Status | Action |
|---------|---------|--------|--------|
| `kloc-reference-project-php/.../sot.json` | Integration tests (all phases) | EXISTS but needs regeneration | Regenerate after mapper ISSUE-A changes. Must also include `assigned_from` edges. |
| Synthetic sot.json with `expression` field | A-08 backward compat test | NEEDS CREATION | Small fixture: 1 method, 1 call, 1 argument edge with expression |
| Synthetic sot.json with `assigned_from` edges | C-01 through C-12 (interim) | NEEDS CREATION | Small fixture: 1 method, 2 calls, local variables, assigned_from edges |
| Synthetic sot.json with union `type_of` edges | B-04 union type test | NEEDS CREATION | 1 Value node with 2 type_of edges |
| Synthetic sot.json with missing chain data | D-09 degradation test | NEEDS CREATION | Argument with expression but no assigned_from or type_of |

### 2.4 How to Create Synthetic Fixtures

Follow the pattern from `test_index.py`:

```python
@pytest.fixture
def fixture_with_expression():
    """Minimal sot.json with expression on argument edges."""
    data = {
        "version": "2.0",
        "metadata": {},
        "nodes": [
            {"id": "m:1", "kind": "Method", "name": "createOrder",
             "fqn": "App\\Service\\OrderService::createOrder()",
             "symbol": "scip-php ... App/Service/OrderService#createOrder().",
             "file": "src/Service/OrderService.php",
             "range": {"start_line": 28, "start_col": 0, "end_line": 60, "end_col": 0}},
            {"id": "c:1", "kind": "Call", "name": "checkAvailability",
             "fqn": "call:checkAvailability",
             "symbol": "", "file": "src/Service/OrderService.php",
             "range": {"start_line": 30, "start_col": 8, "end_line": 30, "end_col": 60},
             "call_kind": "method"},
            {"id": "v:1", "kind": "Value", "name": "(result)",
             "fqn": "val:result",
             "symbol": "", "file": "src/Service/OrderService.php",
             "range": {"start_line": 30, "start_col": 40, "end_line": 30, "end_col": 60},
             "value_kind": "result"},
        ],
        "edges": [
            {"type": "contains", "source": "m:1", "target": "c:1"},
            {"type": "argument", "source": "c:1", "target": "v:1",
             "position": 0, "expression": "$input->productId"},
        ],
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        return f.name
```

### 2.5 Key Test Helpers to Create

```python
def find_entry_by_type(entries, entry_type):
    """Find entries by their type field (for Kind 1/2 distinction)."""
    return [e for e in entries if getattr(e, 'entry_type', None) == entry_type]

def find_variable_entry(entries, var_name):
    """Find a Kind 1 variable entry by variable name."""
    # Implementation depends on final model

def count_toplevel_entries(entries):
    """Count top-level [N] entries (for chain dedup validation)."""
    return len(entries)

def extract_argument_format(entry, param_name):
    """Extract the display format of a specific argument."""
    for arg in entry.arguments:
        if arg.param_name == param_name:
            return arg
    return None

def assert_no_separate_entry_for(entries, fqn_fragment):
    """Assert that a symbol does NOT appear as a top-level entry."""
    for e in entries:
        assert fqn_fragment not in e.fqn, (
            f"'{fqn_fragment}' should be nested, not a top-level entry. "
            f"Found: {e.fqn}"
        )
```

---

## 3. Regression Risks

### 3.1 High Risk -- Must NOT Break

| Risk | What Could Break | Current Tests | Mitigation |
|------|-----------------|---------------|------------|
| **Existing reference types** | method_call, property_access, instantiation, parameter_type, return_type | `test_reference_type.py` (28), `test_callee_verification.py` (11) | Run full suite before/after each phase |
| **Access chain building** | `$this->orderRepository` chains | `test_usage_flow.py::TestAccessChains` (4) | No changes to `build_access_chain()` |
| **USED BY direction** | Incoming usages tree | `test_usage_flow.py::TestReferenceTypeInference` | No changes to `_build_incoming_tree()` |
| **MCP JSON schema** | Existing `member_ref` structure | `test_usage_flow.py::TestJsonOutput` (2) + MCP test | New fields additive only |
| **Class-level context** | Structural USES for Class/Interface queries | `test_usage_flow.py::test_t3_4_class_level_query` | AC 15 explicitly preserves this |

### 3.2 Medium Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| **USES output restructuring (ISSUE-C)** | Every consumer parsing USES text or JSON | Document as breaking change. Create migration guide. Keep old tests for reference. |
| **Argument JSON format changes** | MCP consumers reading `arguments` array | New fields (`value_type`, `param_fqn`, `value_ref_symbol`, `source_chain`) are additive with None defaults |
| **New `definition` JSON key** | Consumers not expecting top-level `definition` | Additive; consumers ignoring unknown keys are safe |
| **`result ->` annotation removal** | Text-parsing consumers looking for `result -> $var` | Replaced by Kind 1 variable entry. Document in migration guide. |

### 3.3 Low Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| **Performance** | Chain dedup logic and source chain traversal | Benchmark with reference project |
| **Edge model expansion** | Adding `expression` field to Edge | Optional field with None default; backward compat test |

### 3.4 Regression Test Checklist

Before merging each phase, verify:

```bash
# Phase 1 (ISSUE-A):
cd /Users/michal/dev/ai/kloc/kloc-mapper && uv run pytest tests/ -v                    # mapper tests
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/test_reference_type.py -v  # 28 pass
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/test_callee_verification.py -v  # 11 pass
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/test_index.py -v           # 12 pass
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/test_usage_flow.py -v      # 19 pass (may need minor updates for expression)
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/test_context_v2.py -v      # NEW: Phase 1 tests pass

# Phase 2 (ISSUE-C + ISSUE-E):
# Same as Phase 1, PLUS:
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/test_context_v2.py -v      # Phase 2 tests pass
# NOTE: test_usage_flow.py Phase 3 tests may FAIL due to USES restructuring.
# These should be marked as expected failures or migrated.

# Phase 3 (ISSUE-B):
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/ -v                        # Full suite

# Phase 4 (ISSUE-D):
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/ -v                        # Full suite
```

---

## 4. JSON Output Tests

### 4.1 Phase 1 JSON Changes

| ID | Test | Validates | AC |
|----|------|-----------|-----|
| AJ-01 | `arguments[N].value_expr` contains expression text | Expression preserved in JSON | 8 |
| AJ-02 | `arguments[N].value_expr` is original `(result)` fallback when no expression | Backward compat | 6 |

### 4.2 Phase 2 JSON Changes

| ID | Test | Validates | AC |
|----|------|-----------|-----|
| CJ-01 | USES entries with `"type": "local_variable"` have `name`, `symbol`, `value_type`, `line`, `source` | Kind 1 JSON structure | 16 |
| CJ-02 | USES entries with `"type": "call"` have `target_fqn`, `reference_type`, `on`, `arguments` | Kind 2 JSON structure | 16 |
| CJ-03 | Kind 1 `source.arguments` cross-reference via `value_ref_symbol` | Cross-references in JSON | 13 |
| EJ-01 | Top-level `definition` object present for method query | Definition JSON | 23 |
| EJ-02 | `definition.arguments` has `name`, `type_fqn`, `type_short`, `position` | Argument detail in definition | 23 |
| EJ-03 | `definition.return_type` has `type_fqn`, `type_short` | Return type in definition | 23 |
| EJ-04 | `definition.declared_in` has `fqn`, `kind` | Container info | 23 |
| EJ-05 | Top-level `definition` present for class query with `methods`, `properties` | Class definition JSON | 23 |
| EJ-06 | `definition` not present for queries where data is unavailable | Graceful omission | 22 |

### 4.3 Phase 3 JSON Changes

| ID | Test | Validates | AC |
|----|------|-----------|-----|
| BJ-01 | `arguments[N].value_type` is a string (e.g., `"string"`) | Type in JSON | 28 |
| BJ-02 | `arguments[N].value_type` is null when no type_of edge | Null handling | 28 |
| BJ-03 | `arguments[N].value_type` for class type uses short name | Short name | 25 |

### 4.4 Phase 4 JSON Changes

| ID | Test | Validates | AC |
|----|------|-----------|-----|
| DJ-01 | `arguments[N].param_fqn` has formal parameter FQN | FQN in JSON | 29 |
| DJ-02 | Local var arg: `value_ref_symbol` set, `source_chain` null | Exclusive fields | 35 |
| DJ-03 | Property access arg: `value_ref_symbol` null, `source_chain` array | Exclusive fields | 35 |
| DJ-04 | `source_chain[M]` has `symbol_fqn`, `access_type`, `on` | Chain structure | 33 |
| DJ-05 | Nested constructor arg: `source_chain` includes nested `args` | Nested chain JSON | 34 |

---

## 5. MCP Backward Compatibility Tests

| ID | Test | Validates | Phase |
|----|------|-----------|-------|
| MCP-01 | MCP response still has `member_ref` with `reference_type` | Existing field preserved | All |
| MCP-02 | MCP response still has `member_ref.access_chain` | Existing field preserved | All |
| MCP-03 | MCP response `arguments` array structure unchanged at base level | Base fields preserved | 1 |
| MCP-04 | MCP response includes new `definition` key when available | New field additive | 2 |
| MCP-05 | MCP response USES entries distinguish `type` field | New field additive | 2 |
| MCP-06 | Consumers ignoring unknown fields still work | Additive fields only | All |

**Test approach:** Reuse the existing `test_t2_7_mcp_response_includes_member_ref` pattern from `test_usage_flow.py`. Create the MCPServer with the sot.json fixture, call `kloc_context` tool, and validate the response structure.

---

## 6. Testability Concerns and Gaps

### 6.1 `assigned_from` Edges (from testability assessment)

**Status:** RESOLVED. The reference project's sot.json currently has zero `assigned_from` edges, but the root cause is identified and will be fixed in ISSUE-A (Phase 1).

**Root cause:** scip-php does NOT provide `source_value_id` (always null), so the mapper never created `assigned_from` edges. However, scip-php DOES provide `source_call_id` on 35 of 45 local Value nodes in calls.json.

**Resolution (ISSUE-A):** The mapper will create `assigned_from` edges using the chain:
1. Read `source_call_id` from the local Value in calls.json
2. Find the corresponding Call node (by call ID)
3. Follow the `produces` edge from Call node to result Value node
4. Create `assigned_from` edge: local Value -> result Value

**Coverage:** 35 of 45 locals will get `assigned_from` edges. The remaining 10 locals without `source_call_id` must be handled gracefully (no edge created, no error, Kind 2 fallback in CLI).

**Impact on test plan:** Tests C-01, C-02, C-08, D-02, D-05, D-06, D-07 will pass against the real fixture after ISSUE-A ships and sot.json is regenerated. Synthetic fixtures can test CLI logic in isolation before that.

**Test coverage for the gap (see AF-01 through AF-04):**
- AF-01: Mapper creates `assigned_from` edge when `source_call_id` is present
- AF-02: Full reference project coverage (all 4 createOrder locals)
- AF-03: Graceful handling when `source_call_id` is null (no edge, no error)
- AF-04: Chain resolution correctness (call ID -> Call -> produces -> result)

### 6.2 Cross-Reference Format Specification

The format `local#32$order` is used throughout the spec but its exact construction rules are not defined:
- Is `32` the 0-indexed line number? 1-indexed?
- Is `$order` always the `$`-prefixed name?
- What happens with name collisions (two `$order` locals at different lines)?
- Is this the Value node's symbol or a derived format?

**Impact:** Tests C-08, D-02 need exact format to assert on.

**Recommendation:** Define the cross-reference format in the implementation plan. Tests should extract the symbol from the Value node's actual data rather than hardcoding `local#32$order`.

### 6.3 No Enum Nodes in Reference Project

The reference project has zero Enum nodes. Tests E-11 (Enum DEFINITION) and E-04 (Enum case) cannot be tested with the real fixture.

**Mitigation:** Add Enum to reference project OR use synthetic fixture.

### 6.4 No Union Type Examples

The reference project likely has no Value nodes with multiple `type_of` edges.

**Mitigation:** Use synthetic fixture for B-04.

### 6.5 Argument Edges with `value_id=null`

In calls.json, some ArgumentRecords have `value_id: null` but non-null `value_expr`. The mapper currently skips these (line 193: `if value_id and position is not None`). This means some expressions will still be lost.

**Impact:** Some arguments in the output may still show fallback names even after ISSUE-A.

**Recommendation:** Consider whether the mapper should handle null-value_id arguments differently (e.g., create a synthetic Value node for the expression, or store the expression on the Call node).

### 6.6 Existing Test Migration Plan

When ISSUE-C ships, the following tests in `test_usage_flow.py` will fail because they assert the current (call-centric) output format:

| Test Class | Tests | Impact |
|-----------|-------|--------|
| `TestPhase2ArgumentTracking` | 8 tests | Argument format changes (FQN prefix, backtick syntax) |
| `TestPhase3ExecutionFlow` | 5 tests | Entry structure changes (Kind 1/2) |

**Migration options:**
1. **Mark as `@pytest.mark.xfail`** during ISSUE-C implementation, then remove after new tests pass
2. **Move to `test_usage_flow_v1.py`** as historical reference
3. **Delete and replace** with `test_context_v2.py` equivalents

**Recommended approach:** Option 1 during development, then Option 3 after validation.

---

## 7. Test Execution Commands

```bash
# Run all kloc-cli tests
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/ -v

# Run specific test files
uv run pytest tests/test_context_v2.py -v              # NEW: v2 context tests
uv run pytest tests/test_usage_flow.py -v               # Existing: Phase 1-3 tests
uv run pytest tests/test_reference_type.py -v           # Unit: reference type inference
uv run pytest tests/test_callee_verification.py -v      # Unit: callee verification
uv run pytest tests/test_index.py -v                    # Unit: SoT index

# Run by phase
uv run pytest tests/test_context_v2.py -v -k "Phase1"
uv run pytest tests/test_context_v2.py -v -k "Phase2a"
uv run pytest tests/test_context_v2.py -v -k "Phase2b"
uv run pytest tests/test_context_v2.py -v -k "Phase3"
uv run pytest tests/test_context_v2.py -v -k "Phase4"

# Run mapper tests (Phase 1 only)
cd /Users/michal/dev/ai/kloc/kloc-mapper && uv run pytest tests/ -v

# Manual CLI verification
cd /Users/michal/dev/ai/kloc/kloc-cli
uv run kloc-cli context "OrderService::createOrder" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json

uv run kloc-cli context "OrderService::createOrder" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json --json

uv run kloc-cli context "OrderService" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json

uv run kloc-cli context "Order::__construct" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json
```

---

## 8. Phase Gate Checklist

### Phase 1 Gate (ISSUE-A)

```
[ ] AC 1-8 verified via automated tests
[ ] kloc-mapper tests pass (test_mapper.py, test_models.py)
[ ] kloc-cli existing tests pass (56+ tests green)
[ ] kloc-cli new tests pass (test_context_v2.py Phase 1)
[ ] sot.json fixture regenerated with expression fields AND assigned_from edges
[ ] assigned_from edges: ~35 locals have edges, 10 without source_call_id have none
[ ] JSON output validated (AJ-01, AJ-02)
[ ] Mapper assigned_from tests pass (AF-01 through AF-04)
[ ] MCP response validated (MCP-01 through MCP-03)
[ ] Manual: CLI shows expressions instead of (result)/(literal)
```

### Phase 2 Gate (ISSUE-C + ISSUE-E)

```
[ ] AC 9-23 verified via automated tests
[ ] assigned_from edges present in fixture (resolved via ISSUE-A source_call_id chain)
[ ] Kind 1 variable entries render correctly
[ ] Kind 2 call entries render correctly
[ ] Chain dedup: correct entry count (8 for createOrder)
[ ] Cross-references work (local#N$name format)
[ ] Class-level query unchanged (AC 15)
[ ] DEFINITION section renders for Method, Class, Property, Argument
[ ] JSON output validated (CJ-01 through CJ-03, EJ-01 through EJ-06)
[ ] MCP response validated (MCP-04, MCP-05)
[ ] Existing tests: 39 untouched tests still green (reference_type + callee + index)
[ ] Migration: test_usage_flow.py Phase 2-3 tests xfailed or migrated
[ ] Manual: Full createOrder output matches spec Phase 2 example
```

### Phase 3 Gate (ISSUE-B)

```
[ ] AC 24-28 verified via automated tests
[ ] Type parenthetical display: scalar, class, absent
[ ] Union type display (synthetic fixture)
[ ] JSON `value_type` field validated (BJ-01 through BJ-03)
[ ] All Phase 1-2 tests still green
[ ] Manual: Types visible in argument display
```

### Phase 4 Gate (ISSUE-D)

```
[ ] AC 29-36 verified via automated tests
[ ] Formal FQN display
[ ] One-line vs expanded source chain rule verified
[ ] Nested constructor expansion verified
[ ] Graceful degradation verified
[ ] JSON rich fields validated (DJ-01 through DJ-05)
[ ] MCP response validated (MCP-06)
[ ] All Phase 1-3 tests still green
[ ] Full regression: all automated tests green
[ ] Manual: Full createOrder output matches spec Phase 4 (gold standard) example
```
