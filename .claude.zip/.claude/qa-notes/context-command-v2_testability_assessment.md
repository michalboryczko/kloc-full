# Testability Assessment: Context Command v2 (Issues A-E)

**Date:** 2026-02-09
**Assessor:** QA Engineer
**Scope:** 5 issues in `docs/todo/context-command-v2/` (ISSUE-A through ISSUE-E, ISSUE-F merged into C+D)

---

## 1. Per-Issue Testability Assessment

### ISSUE-A: Preserve value_expr in sot.json pipeline

**Components:** kloc-mapper + kloc-contracts + kloc-cli
**Priority:** P1 | **Effort:** S

#### Acceptance Criteria Testability

| AC | Criterion | Testable? | Test Type | Notes |
|----|-----------|-----------|-----------|-------|
| A1 | sot.json argument edges include `expression` field | YES | Unit + Integration | Assert on mapper output |
| A2 | CLI shows `$productId <- $input->productId` instead of `(result)` | YES | Integration | Compare CLI output text |
| A3 | Literals show `status <- 'pending'` instead of `(literal)` | YES | Integration | Compare CLI output text |
| A4 | kloc-contracts schema validates the new field | YES | Unit | JSON schema validation |
| A5 | Backward compat: CLI handles edges with/without `expression` | YES | Unit | Two fixtures: one with, one without |
| A6 | No scip-php changes required | YES | Verification | Confirmed: scip-php calls.json already has `value_expr` |

**Testability Rating: STRONG**

All criteria are specific, measurable, and automatable. The data pipeline is well-defined.

#### Fixtures Status

- **Existing fixture:** `kloc-reference-project-php/contract-tests/output/sot.json` -- currently has NO `expression` field on argument edges (confirmed: 122 argument edges, 0 with expression)
- **scip-php output:** `calls.json` already has `value_expr` field (confirmed: e.g., `"value_expr": "self::$nextId++"`)
- **Fixture gap:** After mapper change, need to re-run mapper to produce a new sot.json with `expression` fields. Alternatively, create a synthetic fixture for unit tests.
- **Mapper Edge model:** Currently `Edge` dataclass has `position: Optional[int]` but no `expression` field. Needs `expression: Optional[str] = None` added.

#### Edge Cases Not Covered in Issue Docs

1. **Null value_expr**: What if scip-php's `value_expr` is null or empty string? Issue says "nullable -- omitted if scip-php doesn't provide one" but doesn't define what "omitted" means (missing key vs null value).
2. **Very long expressions**: `sprintf(...)` with multiline format strings. Is there a truncation policy?
3. **Arguments with `value_id=null`**: The mapper currently skips args where `value_id` is null (line 193). These args have `value_expr` in calls.json but no node to attach the expression to. This creates an asymmetry: some expressions are preserved, some are lost.
4. **Special characters in expressions**: Strings with quotes, newlines, or unicode in `value_expr` -- need escaping in JSON?

#### Regression Risks

- **LOW**: Adding an optional field to Edge is additive. CLI fallback ensures backward compat.
- **MEDIUM**: Mapper must handle both old and new calls.json formats (though `value_expr` already exists in current format).

---

### ISSUE-B: Display resolved types for argument values

**Components:** kloc-cli only
**Priority:** P2 | **Effort:** S

#### Acceptance Criteria Testability

| AC | Criterion | Testable? | Test Type | Notes |
|----|-----------|-----------|-----------|-------|
| B1 | Argument display includes resolved type from `type_of` edge | YES | Integration | Check output contains `(string)` etc. |
| B2 | Union types display as `Type1\|Type2` | PARTIALLY | Unit | Need fixture with multiple `type_of` edges; reference project may not have union types |
| B3 | JSON output includes `value_type` field | YES | Integration | Parse JSON, check field |
| B4 | When no `type_of` edge exists, type is omitted | YES | Unit | Mock edge-less node |
| B5 | Types use short names (e.g., `Order` not `App\Entity\Order`) | YES | Unit + Integration | FQN to short name extraction |
| B6 | Scalar types show as-is (`string`, `int`, `bool`) | YES | Integration | Check scalar arg types |

**Testability Rating: STRONG (with one gap)**

#### Fixtures Status

- **Existing fixture:** sot.json has 99 `type_of` edges. Should cover scalar and class types.
- **Union type fixture gap:** Need to verify if the reference project has any Value nodes with multiple `type_of` edges. If not, need synthetic fixture.
- **`get_type_of()` method:** Issue mentions it returns a single target. Need to check if `SoTIndex` supports multi-target lookup.

#### Edge Cases Not Covered

1. **Self-referential types**: Class method returning same class type
2. **Nullable types**: `?int` -- how does this appear in `type_of` edges? Issue says "Nullability is a property of the formal parameter definition, not the value" -- needs verification
3. **Generic types / arrays**: `array<string>`, `Collection<Order>` -- no generic type representation in graph?
4. **No type_of edge for literals**: Literal `0` might not have a `type_of` edge to `int`. Is this a gap?

#### Regression Risks

- **LOW**: Adding optional field to `ArgumentInfo`. Display change is additive.

---

### ISSUE-C: Variable-centric execution flow + chain dedup

**Components:** kloc-cli only
**Priority:** P1 | **Effort:** L (Large)

#### Acceptance Criteria Testability

| AC | Criterion | Testable? | Test Type | Notes |
|----|-----------|-----------|-----------|-------|
| C1 | Calls assigned to local -> variable entry (Kind 1) | YES | Integration | Check entry format |
| C2 | Calls with discarded result -> call entry (Kind 2) | YES | Integration | Check entry format |
| C3 | Chains fully expanded inside entries (nested `on:`) | YES | Integration | Verify nesting structure |
| C4 | Arguments cross-reference earlier entries by graph symbol | PARTIALLY | Integration | Need to parse cross-ref format |
| C5 | Entries ordered by line number | YES | Integration | Already tested in Phase 3 |
| C6 | JSON distinguishes `type: "local_variable"` from `type: "call"` | YES | Integration | Parse JSON |
| C7 | Depth filtration deferred | N/A | N/A | Not testable yet |
| C8 | Calls consumed as receivers -> nested in `on:`, not separate entry | YES | Integration | Count top-level entries, verify nesting |
| C9 | Calls consumed as arguments -> nested in `args:` source chain | YES | Integration | Count top-level entries, verify nesting |
| C10 | One logical operation = one `[N]` entry | YES | Integration | Count entries vs expected |

**Testability Rating: MODERATE**

This is the most complex issue. The acceptance criteria are testable but the output format is radically different from the current output. This will **break ALL existing usage flow tests**.

#### Critical Testability Concerns

1. **Breaking change to output format**: The shift from call-centric to variable-centric model changes the structure of every `ContextEntry` in USES output. Existing `test_usage_flow.py` tests (19 tests in `TestPhase1ReferenceTypeDistinction`, `TestPhase2ArgumentTracking`, `TestPhase3ExecutionFlow`) will need significant rewriting.

2. **Cross-reference format is new and unspecified in test-friendly terms**: The expected output uses `local#32$order` notation. How exactly is this string constructed? Is it `local#{line}${name}`? The spec should define the exact format for test assertions.

3. **Chain dedup is hard to test negatively**: How do you test that something does NOT appear as a separate entry? Need to count top-level entries and verify the expected count matches.

4. **Kind 1 vs Kind 2 distinction depends on `assigned_from` edges**: Need to verify the reference project's sot.json has `assigned_from` edges from local Values to result Values. Currently sot.json has 0 `assigned_from` edges (confirmed by edge type analysis: not in the edge type list). **This is a BLOCKER for testing Kind 1 entries**.

5. **`result_var` currently always None**: Test `test_t2_4_result_var_not_present_when_no_assignment` confirms that result_var is always None because the reference project doesn't have `assigned_from` edges. This means **the fixture cannot test variable entries** without pipeline changes.

#### Fixture Gaps (CRITICAL)

- **No `assigned_from` edges in sot.json**: The sot.json edge types are: `argument`, `calls`, `contains`, `extends`, `implements`, `overrides`, `produces`, `receiver`, `type_hint`, `type_of`, `uses`. There are NO `assigned_from` edges. This means local variable to call result relationships are invisible.
- **Impact**: Without `assigned_from` edges, the CLI cannot determine which local variables receive which call results. Kind 1 entries cannot be constructed from the current fixture.
- **Resolution options**:
  1. Update kloc-mapper to produce `assigned_from` edges (it may already support this but scip-php may not provide the data)
  2. Use synthetic fixtures with `assigned_from` edges for unit tests
  3. Re-scope: can Kind 1/Kind 2 distinction be made using `produces` edges + `contains` edges instead?

#### Edge Cases Not Covered

1. **Multiple assignments to same variable**: `$order = new Order(); $order = $otherOrder;` -- which source wins?
2. **Return statements**: `return new OrderOutput(...)` -- is this a Kind 2 entry or does the return value count as an assignment?
3. **Chained method calls on new object**: `(new Validator())->validate($data)` -- one entry or two?
4. **Closures and callbacks**: `array_map(function($x) { ... }, $items)` -- how are inline functions handled?
5. **Destructured assignments**: Not in PHP, but variable reassignment patterns

#### Regression Risks

- **CRITICAL**: Complete restructuring of USES output. All 19 usage flow tests will need rewriting.
- **HIGH**: JSON output structure changes (`type: "local_variable"` vs `type: "call"`) -- MCP consumers will break.
- **MEDIUM**: Chain dedup may hide entries that were previously visible.

---

### ISSUE-D: Rich argument display with source chains

**Components:** kloc-cli only
**Priority:** P3 | **Effort:** L (Large)
**Dependencies:** ISSUE-A, ISSUE-B, ISSUE-C (all required)

#### Acceptance Criteria Testability

| AC | Criterion | Testable? | Test Type | Notes |
|----|-----------|-----------|-----------|-------|
| D1 | Each argument shows formal parameter FQN | YES | Integration | Parse output format |
| D2 | Each argument shows source expression (from ISSUE-A) | YES | Integration | Depends on A being done |
| D3 | Local variable args -> one-line reference | YES | Integration | Check format |
| D4 | Method parameter args -> one-line reference | YES | Integration | Check format |
| D5 | Literal args -> one-line with value | YES | Integration | Check format |
| D6 | Property access / expression args -> expanded source chain | PARTIALLY | Integration | Complex nested output format |
| D7 | JSON uses `value_ref_symbol` or `source_chain` | YES | Integration | Parse JSON |
| D8 | Graceful degradation when chain data incomplete | YES | Unit | Mock incomplete data |
| D9 | Argument property_access Calls folded into arg source chain | YES | Integration | Verify no separate entry |

**Testability Rating: MODERATE**

This issue depends on A, B, and C all being complete. Testing in isolation is impossible. The output format is deeply nested and format-sensitive.

#### Testability Concerns

1. **Cascading dependency**: Cannot be tested until A, B, and C are done. Any bugs in dependencies will cascade here.
2. **Complex nested output format**: The tree output has 4+ levels of indentation. Parsing this from text output is fragile. JSON format is better for assertions.
3. **Source chain traversal**: Requires following `assigned_from` chains in the graph, which depends on the same `assigned_from` edges missing from the current fixture.
4. **Format specification is loose**: The `...` at the end of some args in the expected output is ambiguous. What exactly gets expanded vs collapsed?

#### Edge Cases Not Covered

1. **Circular source chains**: A -> B -> A
2. **Missing FQN for callee parameters**: What if the callee's Argument node is not in the index?
3. **Multi-hop chains**: `$a->b->c->d` -- how deep does expansion go?

---

### ISSUE-E: Definition section in context output

**Components:** kloc-cli only
**Priority:** P2 | **Effort:** S

#### Acceptance Criteria Testability

| AC | Criterion | Testable? | Test Type | Notes |
|----|-----------|-----------|-----------|-------|
| E1 | `context` output starts with DEFINITION section for ALL symbol types | YES | Integration | Check output structure |
| E2 | Class/Interface: shows properties and methods | YES | Integration | Count members |
| E3 | Method/Function: shows signature with typed args and return type | YES | Integration | Parse signature |
| E4 | Property: shows name, type, visibility | YES | Integration | Check format |
| E5 | Argument: shows name, type, containing method, position | YES | Integration | Check format |
| E6 | Enum Case/Constant: shows name, value, containing type | PARTIALLY | Integration | Need enum in reference project |
| E7 | JSON output includes `definition` object | YES | Integration | Parse JSON |
| E8 | Type names use short form | YES | Integration | Verify short names |
| E9 | Minimal definition when data unavailable | YES | Unit | Mock node without signature |
| E10 | Consolidates with existing header | YES | Integration | Check no duplicate header info |

**Testability Rating: STRONG**

This is the cleanest issue. Additive output, no breaking changes, independent of other issues.

#### Fixtures Status

- **Existing fixture is sufficient**: sot.json has Class, Method, Property, Argument nodes with `contains` edges, `type_hint` edges, and enough data for all symbol type tests.
- **Enum gap**: Need to verify if the reference project has Enum nodes. Node kinds show no Enum (0 Enum nodes). AC E6 cannot be tested with current fixture.

#### Edge Cases Not Covered

1. **Abstract methods**: Show `(abstract)` modifier?
2. **Static methods/properties**: Show `static` modifier?
3. **Promoted constructor properties**: PHP 8+ `public function __construct(private string $name)` -- how are these represented?
4. **Variadic parameters**: `function foo(string ...$args)`
5. **Default values**: `function foo(int $x = 0)` -- show defaults?

#### Regression Risks

- **LOW**: Adding a new section to output. Existing sections unchanged.
- **MEDIUM**: The `definition` JSON object is new. Consumers need to handle its presence.

---

## 2. Cross-Cutting Testability Issues

### 2.1 Fixture Gap: Missing `assigned_from` Edges (CRITICAL)

The reference project's sot.json has **zero** `assigned_from` edges. This edge type links local variables to the call results they receive (e.g., `$order` is assigned from `new Order()`'s result value). Without these edges:

- ISSUE-C cannot determine Kind 1 vs Kind 2 entries
- ISSUE-D cannot build source chains for variable references
- Existing test `test_t2_4_result_var_not_present_when_no_assignment` confirms `result_var` is always None

**Root cause investigation needed**: Is this because:
1. kloc-mapper doesn't produce `assigned_from` edges? (The EdgeType enum has `ASSIGNED_FROM` defined)
2. scip-php doesn't provide assignment data?
3. The reference project's code doesn't trigger this edge type?

**Recommendation**: Before proceeding with ISSUE-C or D, verify that the pipeline can produce `assigned_from` edges. If not, this is a data pipeline gap that blocks the feature.

### 2.2 Breaking Changes to Existing Tests

The context-command-v2 issues (particularly C and D) will fundamentally change the USES output format:
- **19 tests** in `test_usage_flow.py` test current output format
- **TestPhase2ArgumentTracking** (8 tests) asserts current argument format
- **TestPhase3ExecutionFlow** (5 tests) asserts current execution flow format

These tests will need to be rewritten, not just updated. A test migration plan should be part of the implementation plan.

### 2.3 Output Format Parsing for Tests

The new output formats (variable-centric entries, rich argument display, source chains) are complex nested text. Testing via text output comparison is fragile. **Recommendation**: Focus test assertions on JSON output (structured data) rather than console text format. Add a few text-format smoke tests, but rely on JSON for detailed assertions.

### 2.4 Dependency Chain Between Issues

```
ISSUE-A (foundation) --> ISSUE-B (types) --> ISSUE-D (rich display)
                      \-> ISSUE-C (variable model) -/
ISSUE-E (independent)
```

Testing strategy should follow this order:
1. ISSUE-E -- can be tested independently
2. ISSUE-A -- foundation, enables B and C/D
3. ISSUE-B -- small scope, quick win after A
4. ISSUE-C -- large scope, enables D
5. ISSUE-D -- final integration, depends on all others

---

## 3. Test Type Requirements by Issue

| Issue | Unit Tests | Integration Tests | Contract Tests | Manual Tests |
|-------|-----------|-------------------|----------------|-------------|
| A | Mapper edge creation, CLI fallback logic | Full pipeline: mapper -> sot.json -> CLI output | kloc-mapper contract test: expression field in output | Verify CLI output for OrderService::createOrder |
| B | ArgumentInfo with value_type, short name extraction | CLI output with type annotations | N/A | Spot check types in output |
| C | Kind 1/2 classification, chain dedup logic | Full execution flow output comparison | N/A | Visual inspection of createOrder flow |
| D | Source chain building, graceful degradation | Full rich argument display | N/A | Visual inspection of argument chains |
| E | Per-symbol-type definition building | DEFINITION section for each symbol type | N/A | Manual query of each symbol type |

---

## 4. Summary of Gaps and Recommendations

### CRITICAL

1. **`assigned_from` edges missing from fixture** -- blocks ISSUE-C and ISSUE-D testing. Investigate pipeline gap.
2. **ISSUE-C breaks existing tests** -- plan test migration before implementation.

### IMPORTANT

3. **Cross-reference format (`local#32$order`) needs precise specification** -- test assertions need exact format rules.
4. **Union type fixture needed** -- for ISSUE-B AC B2 testing.
5. **Enum fixture needed** -- for ISSUE-E AC E6 testing.
6. **Arguments with `value_id=null` in calls.json** -- ISSUE-A needs to handle these (expressions exist but no node to attach to).

### NICE TO HAVE

7. **Truncation policy for long expressions** -- define for ISSUE-A.
8. **JSON-first testing strategy** -- less fragile than text comparison for complex nested output.
9. **Synthetic fixture for isolated unit tests** -- don't depend solely on reference project fixture.

---

## 5. Existing Test Coverage Summary

| Test File | Tests | Coverage Area | Reuse for v2? |
|-----------|-------|---------------|---------------|
| `test_usage_flow.py` | 19 integration | Reference types, access chains, depth, JSON | REWRITE (C breaks format) |
| `test_reference_type.py` | 14+14 unit | `_infer_reference_type()` | KEEP (no changes expected) |
| `test_callee_verification.py` | 11 unit | `find_call_for_usage()`, `_call_matches_target()` | KEEP (no changes expected) |
| `test_index.py` | 12 unit | SoTIndex loading, queries | KEEP + EXTEND (new methods) |
| `test_integration.py` | 14 integration | resolve, usages, deps | KEEP (backward compat) |

**Total existing: 70 tests**
- Keep as-is: 51 (reference_type + callee_verification + index + integration)
- Rewrite/update: 19 (usage_flow)
- New tests needed: ~40-60 estimated across all issues
