# QA Notes: usage-flow-tracking-mvp

## Pipeline Setup

Every test MUST execute the full pipeline:

```bash
# Step 1: Generate SCIP index
cd scip-php && ./bin/scip-php.sh -d ../kloc-reference-project-php -o /tmp/kloc-test-output

# Step 2: Generate sot.json
cd kloc-mapper && uv run kloc-mapper map /tmp/kloc-test-output/index.kloc -o /tmp/kloc-test-output/sot.json

# Step 3: Run context queries
cd kloc-cli && uv run kloc-cli context "SYMBOL" --sot /tmp/kloc-test-output/sot.json --depth N [--impl] [--with-imports]
```

Test CANNOT pass if any command in the pipeline fails (runtime error = automatic FAIL).

Test data source: `kloc-reference-project-php/` ONLY.

SOT path shorthand: `{sot}` = `/tmp/kloc-test-output/sot.json`

---

## Mandatory Test Scenarios

### Scenario 1: Class query -- OrderService USED BY (external only) [R3]

**Command**: `kloc-cli context "App\Service\OrderService" --sot {sot} --depth 1`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 1.1 | USED BY must NOT contain `App\Service\OrderService::createOrder(...) -> $inventoryChecker [property_access]` or any other self-reference from OrderService's own methods accessing its own properties | R3 |
| 1.2 | USED BY MUST contain `App\Ui\Rest\Controller\OrderController::create(...)` as an external caller with `[method_call]` tag | R3 |

### Scenario 2: Class query -- OrderService USED BY no imports [R1]

**Command**: `kloc-cli context "App\Service\OrderService" --sot {sot} --depth 1`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 2.1 | USED BY must NOT contain `src/Ui/Rest/Controller/OrderController.php [type_hint] (line 8)` -- this is a PHP import | R1 |
| 2.2 | With `--with-imports` flag, the import line SHOULD appear | R1 |

### Scenario 3: Class query -- OrderRepository USED BY depth chaining [R7, R8]

**Command**: `kloc-cli context "App\Repository\OrderRepository" --sot {sot} --depth 3 --impl`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 3.1 | Depth 1 must show `App\Service\OrderService::createOrder(...) -> save() [method_call]` with `on: $this->orderRepository` | R7 |
| 3.2 | Depth 2 must show `App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call]` as caller of OrderService::createOrder -- proving call chain: Controller -> Service -> Repository | R7, R8 |

### Scenario 4: No type_hint cascading in depth [R8]

**Command**: `kloc-cli context "App\Repository\OrderRepository" --sot {sot} --depth 3`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 4.1 | Depth 2 must NOT show controllers that merely import OrderService -- depth chaining must NOT follow type_hint edges | R8 |
| 4.2 | Every depth 2+ entry must have reference type `method_call`, `property_access`, or `instantiation` -- never `type_hint` | R8 |

### Scenario 5: Method query -- createOrder USES sorted by line [R2]

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 1`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 5.1 | USES items must be sorted by line number. `checkAvailability` (line ~30) must appear before `$customerEmail` (line ~34) which must appear before `save` (line ~45) | R2 |
| 5.2 | `send` (line ~47) must appear after `save` (line ~45) | R2 |

### Scenario 6: FQN identifiers -- no file paths [R6]

**Command**: `kloc-cli context "App\Repository\OrderRepository" --sot {sot} --depth 2`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 6.1 | No entry in the tree should show a bare file path like `src/Service/OrderService.php` as the identifier -- must be `App\Service\OrderService` or a method FQN | R6 |
| 6.2 | File paths should ONLY appear in the location part `(src/Service/OrderService.php:12)` -- never as the main symbol name | R6 |

### Scenario 7: Access chain with property FQN [R4]

**Command**: `kloc-cli context "App\Service\OrderService::createOrder" --sot {sot} --depth 1 --impl`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 7.1 | The entry for `OrderRepository::save()` must show `on: $this->orderRepository` AND include the property FQN `App\Service\OrderService::$orderRepository` | R4 |
| 7.2 | The entry for `EmailSenderInterface::send()` must show `on: $this->emailSender` AND include property FQN `App\Service\OrderService::$emailSender` | R4 |

### Scenario 8: Method signature completeness [R5]

**Command**: `kloc-cli context "App\Service\OrderService" --sot {sot} --depth 1`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 8.1 | `OrderController::create(...)` in USED BY must show complete signature or abbreviated `(...)` -- NOT truncated mid-attribute like `(#[\Symfony\Component\HttpKernel\Attribute\MapRequestPayload]` without closing paren | R5 |
| 8.2 | Method signatures with return types must show them: `::getOrder(int $id): ?\App\Dto\OrderOutput` or abbreviated form | R5 |

### Scenario 9: Interface impl resolution with depth [R7, --impl]

**Command**: `kloc-cli context "App\Component\EmailSenderInterface::send" --sot {sot} --depth 2 --impl`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 9.1 | Must show `impl: App\Component\EmailSender::send(...)` at the appropriate level | R7, --impl |
| 9.2 | USED BY must show `App\Service\OrderService::createOrder(...)` as a caller with `on: $this->emailSender` | R7 |

### Scenario 10: CustomerService nested property chains [R2, R3]

**Command**: `kloc-cli context "App\Service\CustomerService::getCustomerById" --sot {sot} --depth 1`

| Check | Expected | Requirement |
|-------|----------|-------------|
| 10.1 | USES must show property accesses for `$customer->contact->email` and `$customer->address->street` -- ordered by line number (line ~50 before line ~55) | R2 |
| 10.2 | No self-referential noise -- only actual dependencies of getCustomerById method should appear | R3 |

---

## Pass/Fail Criteria

- **PASS**: All 10 scenarios pass all their checks AND the full pipeline runs without errors
- **FAIL**: Any check fails, or any pipeline command fails with runtime error

## Regression Checks

- Existing `kloc-cli` tests must still pass: `cd kloc-cli && uv run pytest tests/ -v`
- `--impl` flag must still work correctly with the new changes
- `--direct` flag must still work correctly
- `--json` output must include all new fields (access_chain_symbol) and respect all new filters
