# QA Reference Note: CLI Context Command Fix (Execution Flow USES)

**Date:** 2026-02-08
**Feature Branch:** feature/scip-php-indexer-issues
**Scope:** kloc-cli only (no scip-php or kloc-mapper changes)
**Spec:** `docs/specs/cli-context-fix.md` (21 acceptance criteria across 4 phases)
**Issues:** 6 issues in `kloc-cli context` command output

---

## 0. Acceptance Criteria Traceability Matrix

The spec defines 21 acceptance criteria (AC 1-21). Each is mapped to one or more test scenarios below. Every AC must have at least one automated test before the phase ships.

| Spec AC | Description | Test Scenarios | Test Type |
|---------|-------------|----------------|-----------|
| AC 1 | Constructor `new Order(...)` shows `[instantiation]` not `[type_hint]` | P1-01, P1-02, P1-03 | Integration + Unit |
| AC 2 | Parameter type `CreateOrderInput` shows `[parameter_type]` | P1-05, P1-08 | Integration + Unit |
| AC 3 | Return type `OrderOutput` shows `[return_type]` | P1-06, P1-09 | Integration + Unit |
| AC 4 | Property type hint `LoggerInterface` shows `[property_type]` | P1-07 | Integration |
| AC 5 | Tree structure unchanged, only labels change | P1-04, Regression suite | Integration |
| AC 6 | `--json` output includes new `reference_type` values | J-01, J-02, J-03 | Integration |
| AC 7 | `checkAvailability()` shows argument mappings with param names | P2-01 | Integration |
| AC 8 | Constructor `new Order()` shows argument mappings | P2-02 | Integration |
| AC 9 | Call result assigned to `$order` shows `result: $order` | P2-05 | Integration |
| AC 10 | Call with no arguments shows no `arguments:` block | P2-08 | Unit |
| AC 11 | `--json` has `arguments` array and optional `result_var` | J-04, J-05, J-06, J-07, P2-06, P2-07 | Integration |
| AC 12 | Existing MCP consumers not broken (additive fields only) | J-09, P2-09, P2-10 | Unit + Code review |
| AC 13 | USES entries ordered by line number (30, 32, 42, 45) | P3-02 | Integration |
| AC 14 | `$order` visible as result AND as argument to `process()` | P3-06, P3-07, P2-03, P2-04 | Integration |
| AC 15 | Local variable never passed to another call is NOT shown | P3-05-a (new) | Integration |
| AC 16 | Class-level context query preserves structural USES view | P3-05 | Integration |
| AC 17 | `--json` includes execution flow with line-ordered entries | J-08, P3-JSON (new) | Integration |
| AC 18 | Depth 2: `Order` shows `__construct()` internals, NOT property type hints | P4-01, P4-03 | Integration |
| AC 19 | Depth 2: callee's inner calls appear with arguments | P4-02 | Integration |
| AC 20 | Recursive method call shown but not expanded further (cycle prevention) | P4-05 | Integration |
| AC 21 | USED BY direction depth semantics unchanged | P4-04, Regression suite | Integration |

---

## 1. Test Scenarios per Phase

### Phase 1: Fix Reference Types (Issues 1, 3) -- Spec AC 1-6

**Issue 1: Constructor calls shown as [type_hint] instead of [instantiation]**

| ID | Scenario | Input | Expected Output | Spec AC |
|----|----------|-------|-----------------|---------|
| P1-01 | Constructor shows [instantiation] | `context "OrderService::createOrder" --sot sot.json` | `App\Entity\Order [instantiation]` at line 32, NOT `[type_hint]` | AC 1 |
| P1-02 | Constructor match via find_call_for_usage | Unit test: Call node with `call_kind='constructor'` targeting `__construct()`, usage edge targets Class | `find_call_for_usage()` returns the constructor Call node ID | AC 1 |
| P1-03 | Constructor for wrong class rejected | Unit test: constructor Call for class A, usage edge targets class B | `_call_matches_target()` returns False | AC 1 |
| P1-04 | Existing method_call references preserved | `context "OrderService::createOrder"` | `save()` still shows `[method_call]` with chain `$this->orderRepository`; tree structure unchanged | AC 5 |

**Issue 3: No distinction between parameter types and return types**

| ID | Scenario | Input | Expected Output | Spec AC |
|----|----------|-------|-----------------|---------|
| P1-05 | Parameter type shows [parameter_type] | `context "OrderService::createOrder"` | `CreateOrderInput [parameter_type]` at line 28 | AC 2 |
| P1-06 | Return type shows [return_type] | `context "OrderService::createOrder"` | `OrderOutput [return_type]` at line 28 | AC 3 |
| P1-07 | Property type hint shows [property_type] | `context "OrderService"` (class-level with injected dependencies) | `LoggerInterface [property_type]` (or similar property type hint) | AC 4 |
| P1-08 | Unit test: Argument source -> parameter_type | `_infer_reference_type` or new logic: edge source is Argument node | Returns `"parameter_type"` | AC 2 |
| P1-09 | Unit test: Method source -> return_type | Edge source is Method node, type_hint edge to Class | Returns `"return_type"` | AC 3 |

**Verification approach:**
- Run `context "OrderService::createOrder" --sot sot.json` and check output labels
- Run `context "OrderService::createOrder" --sot sot.json --json` and verify `reference_type` values (AC 6)
- Run existing test suite to confirm no regressions (AC 5)

### Phase 2: Argument Tracking (Issue 4) -- Spec AC 7-12

| ID | Scenario | Input | Expected Output | Spec AC |
|----|----------|-------|-----------------|---------|
| P2-01 | checkAvailability shows 2 arguments | `context "OrderService::createOrder"` | `arguments:` block with `$productId <- $input->productId` and `$quantity <- $input->quantity` | AC 7 |
| P2-02 | Constructor shows arguments | `context "OrderService::createOrder"` | `new Order()` entry has arguments: `customerEmail <- $input->customerEmail`, `productId <- $input->productId`, etc. | AC 8 |
| P2-03 | save() shows local variable argument | `context "OrderService::createOrder"` | `save()` has argument: `$order <- $processedOrder` (local variable ref) | AC 14 |
| P2-04 | process() shows argument | `context "OrderService::createOrder"` | `process()` has argument: `$order <- $order` (local variable ref) | AC 14 |
| P2-05 | Result variable assignment shown | `context "OrderService::createOrder"` | `new Order()` shows `result: $order` | AC 9 |
| P2-06 | JSON includes arguments array | `--json` output | Each USES entry with arguments has `"arguments": [{"position": 0, "param_name": "$productId", ...}]` | AC 11 |
| P2-07 | JSON includes result_var | `--json` output | Entries with result assignment have `"result_var": "$order"` | AC 11 |
| P2-08 | Empty arguments for no-arg calls | Call with no arguments | No `arguments:` block shown in console output; JSON may have empty array or absent field | AC 10 |
| P2-09 | ArgumentInfo dataclass exists | Code inspection | `results.py` has `ArgumentInfo` with `position`, `param_name`, `value_expr`, `value_source` | AC 12 |
| P2-10 | ContextEntry has arguments field | Code inspection | `ContextEntry` has `arguments: list[ArgumentInfo]` and `result_var: Optional[str]` | AC 12 |

**Verification approach:**
- Run `context "OrderService::createOrder" --sot sot.json` and check arguments blocks
- Run with `--json` and validate JSON structure matches spec (AC 11)
- Run unit tests for `_resolve_param_name()` and `_find_result_var()` helpers
- Verify MCP backward compat: existing fields unchanged, new fields additive (AC 12)

### Phase 3: Local Variables and Execution Flow (Issues 2, 6) -- Spec AC 13-17

| ID | Scenario | Input | Expected Output | Spec AC |
|----|----------|-------|-----------------|---------|
| P3-01 | Local variables appear in output | `context "OrderService::createOrder"` | `$order`, `$processedOrder`, `$savedOrder` visible in USES output | AC 14 |
| P3-02 | Execution flow ordered by line number | `context "OrderService::createOrder"` | Calls appear in source order: checkAvailability (line 30), new Order (line 32), process (line 42), save (line 45) | AC 13 |
| P3-03 | Depth 2 shows callee internals | `context "OrderService::createOrder" --depth 2` | Under `save()`, shows what save() calls internally (its execution flow) | AC 19 |
| P3-04 | Method-level uses execution flow | `context "OrderService::createOrder"` | USES section driven by Call node iteration, not just `uses` edges | AC 13 |
| P3-05 | Class-level context still structural | `context "Order"` (class query) | USES shows structural deps (extends, type_hints, etc.) -- NOT execution flow | AC 16 |
| P3-05-a | Unused local variable NOT shown | Method with a local variable never passed to another call | That variable does NOT appear in USES output | AC 15 |
| P3-06 | Local variable source tracking | `context "OrderService::createOrder"` | `$order` visible as result of `new Order()` | AC 14 |
| P3-07 | Value flow between calls | `context "OrderService::createOrder"` | `$order` is result of `new Order()`, then passed as argument to `process()` | AC 14 |
| P3-JSON | JSON includes line-ordered execution flow | `--json` output | USES entries in JSON are ordered by line number | AC 17 |

**Verification approach:**
- Compare output with expected output from spec Phase 3 section
- Verify Call node iteration order matches PHP source line numbers
- Verify class-level queries are unaffected (backward compatibility)

### Phase 4: Smart Depth Filtering (Issue 5) -- Spec AC 18-21

| ID | Scenario | Input | Expected Output | Spec AC |
|----|----------|-------|-----------------|---------|
| P4-01 | Depth 2: no structural deps for Order | `context "OrderService::createOrder" --depth 2` | `Order` at depth 2 does NOT show `$customerEmail`, `$status` property type hints | AC 18 |
| P4-02 | Depth 2: callee inner calls with args | `context "OrderService::createOrder" --depth 2` | Under callee methods, shows their internal calls with argument mappings | AC 19 |
| P4-03 | Order at depth 2 shows __construct internals | `--depth 2` | Order at depth 2 shows what `__construct()` does, not property definitions | AC 18 |
| P4-04 | USED BY depth semantics unchanged | `context "OrderService::createOrder" --depth 2` | USED BY direction still uses structural expansion, not execution flow | AC 21 |
| P4-05 | Recursive method cycle prevention | `--depth 2` or `--depth 3` with recursive method | Recursive call shown but not expanded further; no infinite loop | AC 20 |

---

## 2. Test Infrastructure

### Existing Test Infrastructure

| File | Type | Fixture | Tests |
|------|------|---------|-------|
| `tests/test_usage_flow.py` | Integration | `kloc-reference-project-php/contract-tests/output/sot.json` | 19 tests: reference types, access chains, per-subtree visited sets, JSON output |
| `tests/test_reference_type.py` | Unit | In-memory mocks (`make_edge`, `make_node`) | 14 tests: `_infer_reference_type()` for all edge/node kind combos |
| `tests/test_callee_verification.py` | Unit | Mock index (`_make_mock_index`) | 11 tests: `find_call_for_usage()`, `_call_matches_target()` |
| `tests/test_index.py` | Unit | Temp file (`sample_sot` fixture) | 12 tests: SoTIndex loading, resolution, queries |
| `tests/test_integration.py` | Integration | `artifacts/sot_fixed.json` | 14 tests: resolve, usages, deps, containment, inheritance |

### Fixture Requirements for New Tests

**Phase 1 tests can reuse existing fixtures:**
- `kloc-reference-project-php/contract-tests/output/sot.json` (v2.0 format) for integration tests
- In-memory mocks from `test_reference_type.py` pattern for unit tests of new reference type logic

**Phase 2 tests need:**
- Integration: Same `sot.json` fixture (already has Call/Value/Argument nodes with `argument` edges)
- Unit: New mock index that includes:
  - Call node with `argument` edges to Value nodes
  - Value nodes with `value_kind` of "parameter", "local", "literal"
  - `produces` edges from Call to Value (result)
  - `assigned_from` edges from local Value to result Value

**Phase 3 tests need:**
- Integration: Same `sot.json` fixture (has all Call/Value/contains data)
- Consider creating a smaller focused test sot.json with a simple 3-method call chain for cleaner test isolation

**Phase 4 tests need:**
- Integration: Same `sot.json` with depth 2 queries
- Verify `save()` depth-2 children are execution-flow only (Call nodes), not structural (property defs)

### How to Create Test sot.json Data

The existing test pattern (from `test_index.py`) shows how to create minimal sot.json fixtures:

```python
@pytest.fixture
def sample_sot():
    data = {
        "version": "2.0",
        "metadata": {},
        "nodes": [
            # Add Class, Method, Call, Value, Argument nodes
        ],
        "edges": [
            # Add contains, uses, calls, receiver, argument, produces edges
        ],
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        return f.name
```

For testing argument tracking, a fixture needs:
1. A Method node (source method)
2. Call nodes (contained by the method)
3. Value nodes for arguments (with `value_kind` = "parameter"/"local"/"literal")
4. `argument` edges from Call to Value with `position` field
5. `produces` edge from Call to Value (result)
6. Target Method node with Argument children (for param name resolution)

### Key Test Helpers to Reuse

From `test_usage_flow.py`:
- `find_entry_by_fqn(entries, fqn_substring)` -- find entry by FQN match
- `find_entry_by_member(entries, member_name)` -- find by member_ref target_name

From `test_callee_verification.py`:
- `_make_node(node_id, kind, name, ...)` -- create NodeData
- `_make_mock_index(nodes, calls_edges, contains_edges, ...)` -- create mock SoTIndex

---

## 3. Regression Risks

### High Risk - Must NOT Break

| Risk | What Could Break | Test Coverage | Mitigation |
|------|-----------------|---------------|------------|
| **Existing reference types** | method_call, property_access, type_hint classifications for non-constructor cases | `test_reference_type.py` (14 tests), `test_callee_verification.py` (11 tests) | Run full suite before/after each phase |
| **Access chain building** | `$this->orderRepository` chains for method calls | `test_usage_flow.py::TestAccessChains` (4 tests) | No changes to `build_access_chain()` logic |
| **Per-subtree visited sets** | Depth-2 entries might be lost if visited set logic changes | `test_usage_flow.py::TestPerSubtreeVisitedSet` (7 tests) | Phase 4 must preserve per-parent dedup |
| **Callee verification** | `find_call_for_usage` rejecting correct Call nodes | `test_callee_verification.py` (11 tests) | No changes to `_call_matches_target()` |
| **MCP JSON output** | Existing consumers expecting specific JSON shape | `test_usage_flow.py::TestJsonOutput` (2 tests) | New fields are additive only |
| **USED BY direction** | Incoming usages tree unchanged by this feature | `test_usage_flow.py::TestReferenceTypeInference` | No changes to `_build_incoming_tree()` |

### Medium Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| **reference_type value change** | `type_hint` -> `parameter_type`/`return_type` breaks MCP consumers matching on exact strings | Document as breaking change; consider keeping `type_hint` for backward compat with new `type_hint_kind` subfield |
| **ContextEntry field additions** | New `arguments`, `result_var` fields affect JSON serialization | Fields should be optional with default `None`/empty list |
| **Depth semantics change** | Phase 4 changes what depth 2 shows (execution flow vs structural) | Run depth-2 tests; ensure class-level queries unchanged |
| **Output verbosity** | Too many local variables in output | Consider filtering: only show locals that are passed as arguments to other calls |

### Low Risk

| Risk | What Could Break | Mitigation |
|------|-----------------|------------|
| **Performance** | `_find_result_var()` linear scan of edges | Monitor execution time; add reverse index if needed |
| **Edge cases** | Static calls, chained calls, closures | Handled in edge case table in feature-idea.md |

### Regression Test Checklist

Before merging each phase, verify:

1. `uv run pytest tests/test_reference_type.py -v` -- all 14 pass
2. `uv run pytest tests/test_callee_verification.py -v` -- all 11 pass
3. `uv run pytest tests/test_usage_flow.py -v` -- all 19 pass
4. `uv run pytest tests/test_index.py -v` -- all 12 pass
5. Manual: `uv run kloc-cli context "OrderService::createOrder" --sot <sot.json> --json` produces valid JSON
6. Manual: `uv run kloc-cli context "OrderService::createOrder" --sot <sot.json>` console output renders without errors

---

## 4. JSON Output Tests

### Current JSON Structure (before changes)

```json
{
  "target": {"fqn": "...", "file": "...", "line": 28, "signature": "..."},
  "max_depth": 1,
  "used_by": [
    {
      "depth": 1, "fqn": "...", "kind": "Method", "file": "...", "line": 25,
      "children": [],
      "member_ref": {
        "target_name": "createOrder()",
        "target_fqn": "App\\Service\\OrderService::createOrder()",
        "target_kind": "Method",
        "file": "...", "line": 25,
        "reference_type": "method_call",
        "access_chain": "$this->orderService"
      }
    }
  ],
  "uses": [
    {
      "depth": 1, "fqn": "App\\Entity\\Order", "kind": "Class",
      "file": "...", "line": 32,
      "children": [],
      "member_ref": {
        "target_name": "",
        "target_fqn": "App\\Entity\\Order",
        "target_kind": "Class",
        "reference_type": "type_hint",
        "access_chain": null
      }
    }
  ]
}
```

### Expected JSON Structure After Phase 1

Changes to validate:
- `reference_type` values: `"type_hint"` for Order at line 32 becomes `"instantiation"`
- New values: `"parameter_type"`, `"return_type"` appear for CreateOrderInput and OrderOutput

```json
{
  "uses": [
    {
      "fqn": "App\\Dto\\CreateOrderInput",
      "member_ref": {"reference_type": "parameter_type"}
    },
    {
      "fqn": "App\\Dto\\OrderOutput",
      "member_ref": {"reference_type": "return_type"}
    },
    {
      "fqn": "App\\Entity\\Order",
      "member_ref": {"reference_type": "instantiation"}
    }
  ]
}
```

### Expected JSON Structure After Phase 2

New fields to validate:

```json
{
  "uses": [
    {
      "fqn": "App\\Component\\InventoryCheckerInterface::checkAvailability",
      "member_ref": {"reference_type": "method_call", "access_chain": "$this->inventoryChecker"},
      "arguments": [
        {"position": 0, "param_name": "$productId", "value_expr": "$input->productId", "value_source": "parameter"},
        {"position": 1, "param_name": "$quantity", "value_expr": "$input->quantity", "value_source": "parameter"}
      ],
      "result_var": null
    },
    {
      "fqn": "App\\Entity\\Order",
      "member_ref": {"reference_type": "instantiation"},
      "arguments": [
        {"position": 0, "param_name": "customerEmail", "value_expr": "$input->customerEmail"},
        {"position": 1, "param_name": "productId", "value_expr": "$input->productId"}
      ],
      "result_var": "$order"
    }
  ]
}
```

### JSON Validation Tests to Add

| ID | Test | Validates |
|----|------|-----------|
| J-01 | `uses` entries with `reference_type="instantiation"` present | Phase 1 JSON |
| J-02 | `uses` entries with `reference_type="parameter_type"` present | Phase 1 JSON |
| J-03 | `uses` entries with `reference_type="return_type"` present | Phase 1 JSON |
| J-04 | `uses` entries with `arguments` array (non-empty) | Phase 2 JSON |
| J-05 | Each argument has `position` (int), `param_name` (str/null), `value_expr` (str/null) | Phase 2 structure |
| J-06 | `result_var` field present on entries with result assignment | Phase 2 JSON |
| J-07 | `arguments` absent or empty for entries with no arguments | Phase 2 edge case |
| J-08 | JSON output valid (parseable by `json.loads`) | All phases |
| J-09 | Backward compat: `member_ref` structure unchanged (additive only) | All phases |
| J-10 | `context_tree_to_dict()` includes new fields in serialization | Code coverage |

---

## 5. Files Modified per Phase (from spec)

Per `docs/specs/cli-context-fix.md`:

| File | Phase(s) | What Changes |
|------|----------|-------------|
| `src/queries/context.py` | 1, 2, 3, 4 | Reference type fixes, argument querying, execution flow traversal, smart depth |
| `src/models/results.py` | 2 | Add `ArgumentInfo` dataclass, add `arguments`/`result_var` fields to `ContextEntry` |
| `src/output/tree.py` | 1, 2, 3 | Render new reference type labels, argument blocks, line-ordered entries |
| `src/server/mcp.py` | 2, 3 | Serialize `arguments`, `result_var`, execution flow in JSON |

### Test files to update per phase

- **Phase 1:** `tests/test_reference_type.py` (add `parameter_type`, `return_type`, `property_type` unit tests); `tests/test_usage_flow.py` (update `test_tc8_direct_class_instantiation` to expect `[instantiation]`; add AC 1-6 integration tests)
- **Phase 2:** `tests/test_usage_flow.py` (add AC 7-12 integration tests for arguments, result_var); `tests/test_callee_verification.py` (if argument resolution uses mock index)
- **Phase 3:** `tests/test_usage_flow.py` (add AC 13-17 integration tests for execution flow, line ordering, class-level backward compat)
- **Phase 4:** `tests/test_usage_flow.py` (add AC 18-21 integration tests for smart depth, cycle prevention, USED BY unchanged)

---

## 6. Test Execution Commands

```bash
# Run all kloc-cli tests
cd /Users/michal/dev/ai/kloc/kloc-cli && uv run pytest tests/ -v

# Run specific test files
uv run pytest tests/test_reference_type.py -v      # Unit: reference type inference
uv run pytest tests/test_callee_verification.py -v  # Unit: callee verification
uv run pytest tests/test_usage_flow.py -v           # Integration: usage flow

# Run with keyword filter for specific scenarios
uv run pytest tests/test_usage_flow.py -v -k "instantiation"
uv run pytest tests/test_usage_flow.py -v -k "json"

# Manual CLI verification
uv run kloc-cli context "OrderService::createOrder" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json

uv run kloc-cli context "OrderService::createOrder" \
  --sot ../kloc-reference-project-php/contract-tests/output/sot.json --json
```

---

## 7. Spec Acceptance Criteria Verification Checklist

Reference: `docs/specs/cli-context-fix.md` -- 21 acceptance criteria.

### Phase 1 (AC 1-6)

| AC | Spec Requirement | How to Verify | Status |
|----|-----------------|---------------|--------|
| 1 | `new Order(...)` shows `[instantiation]` not `[type_hint]` | Integration: query `createOrder`, find Order entry, assert `reference_type == "instantiation"` | -- |
| 2 | `CreateOrderInput` param shows `[parameter_type]` | Integration: query `createOrder`, find CreateOrderInput entry, assert `reference_type == "parameter_type"` | -- |
| 3 | `OrderOutput` return shows `[return_type]` | Integration: query `createOrder`, find OrderOutput entry, assert `reference_type == "return_type"` | -- |
| 4 | Property `LoggerInterface` shows `[property_type]` | Integration: query class-level OrderService, find property type hint, assert `reference_type == "property_type"` | -- |
| 5 | Tree structure unchanged, only labels change | Regression: all 56 existing tests pass; tree.py structural output unchanged | -- |
| 6 | `--json` includes new reference_type values | Integration: `context_tree_to_dict()` output contains `"parameter_type"`, `"return_type"`, `"instantiation"` | -- |

### Phase 2 (AC 7-12)

| AC | Spec Requirement | How to Verify | Status |
|----|-----------------|---------------|--------|
| 7 | `checkAvailability()` shows argument mappings | Integration: query `createOrder`, find checkAvailability entry, assert 2 arguments with `$productId`, `$quantity` | -- |
| 8 | `new Order()` constructor shows argument mappings | Integration: query `createOrder`, find Order instantiation entry, assert arguments with `customerEmail`, `productId`, etc. | -- |
| 9 | Call result assigned to `$order` shows `result: $order` | Integration: query `createOrder`, find Order instantiation, assert `result_var == "$order"` | -- |
| 10 | No-argument call shows no `arguments:` block | Unit: mock a Call with no argument edges; assert arguments list is empty/absent in output | -- |
| 11 | JSON has `arguments` array and optional `result_var` | Integration: `--json` output, validate `arguments` is array of objects with `position`, `param_name`, `value_expr`; `result_var` is string or null | -- |
| 12 | Existing MCP consumers not broken | Code review: new fields are additive (default empty); `member_ref` structure unchanged; `ArgumentInfo` and `ContextEntry` fields have defaults | -- |

### Phase 3 (AC 13-17)

| AC | Spec Requirement | How to Verify | Status |
|----|-----------------|---------------|--------|
| 13 | USES entries ordered by line number (30, 32, 42, 45) | Integration: query `createOrder`, extract line numbers from USES entries, assert ascending order | -- |
| 14 | `$order` visible as result AND as argument to `process()` | Integration: query `createOrder`, assert Order entry has `result_var == "$order"` AND process() entry has argument `$order <- $order` | -- |
| 15 | Local variable never passed to another call is NOT shown | Integration: find a local variable in createOrder that has no inter-symbol data flow; assert it is absent from USES | -- |
| 16 | Class-level query preserves structural USES view | Integration: query `"Order"` (class), assert USES shows extends/type_hint/property_access entries, NOT execution flow | -- |
| 17 | JSON includes execution flow with line-ordered entries | Integration: `--json` output for createOrder, assert USES entries have line numbers in ascending order | -- |

### Phase 4 (AC 18-21)

| AC | Spec Requirement | How to Verify | Status |
|----|-----------------|---------------|--------|
| 18 | Depth 2: `Order` shows `__construct()` internals, NOT property type hints | Integration: query `createOrder --depth 2`, find Order children, assert NO property_type/type_hint entries, only execution flow | -- |
| 19 | Depth 2: callee inner calls appear with arguments | Integration: query `--depth 2`, find a callee's depth-2 children, assert they have argument mappings | -- |
| 20 | Recursive call shown but not expanded further | Integration: query a recursive method with `--depth 2`, assert the recursive call appears but has no children (cycle prevention); query completes in < 5s | -- |
| 21 | USED BY direction depth semantics unchanged | Integration: query `--depth 2`, assert USED BY uses structural expansion (same as before), not execution flow model | -- |

### Phase Gate Checklist

Before shipping each phase, all of the following must pass:

```
Phase 1: AC 1-6 verified + all 56 existing tests green
Phase 2: AC 7-12 verified + Phase 1 ACs still green + all existing tests green
Phase 3: AC 13-17 verified + Phase 1-2 ACs still green + all existing tests green
Phase 4: AC 18-21 verified + Phase 1-3 ACs still green + all existing tests green
```
