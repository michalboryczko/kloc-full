# Feature Team — Launch Prompt

Use this prompt to start an Agent Teams session for end-to-end feature development.

## Prerequisites

- `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` enabled in settings.json
- Feature name and context ready

## How to Use

1. Start a new Claude Code session
2. Copy the prompt below, replace `{placeholders}` with your feature details
3. Claude will spawn the team automatically
4. Immediately press Shift+Tab to enter delegate mode
5. Use Shift+Up/Down to interact with individual teammates

## Prompt Template

```
Create an agent team to develop a feature end-to-end.

Feature name: {feature-name-kebab-case}
Feature description: {what the feature should do}
Context files: {optional list of relevant files}

## Team Structure

Spawn these teammates:

### PM (Product Manager)
- **Name**: pm
- **Focus**: Create feature specification with acceptance criteria
- **Agent definition**: Read .claude/teams/feature-team/agents/team-pm.md for role instructions
- **First task**: Read the feature description, explore docs/summary.md and kloc-cli/README.md for context, then create a feature spec at docs/specs/{feature-name}.md
- **Model**: sonnet (good enough for spec writing, saves cost)

### Architect
- **Name**: architect
- **Focus**: Explore codebase and create implementation plan
- **Agent definition**: Read .claude/teams/feature-team/agents/team-architect.md for role instructions
- **First task**: Explore the codebase to understand patterns, conventions, and areas affected by {feature-name}. Wait for PM's spec before creating the plan.
- **Model**: opus (needs deep codebase understanding)

### Developer 1
- **Name**: developer-1
- **Focus**: Implement assigned work stream
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for task assignment from lead. Read spec and plan when available.
- **Model**: opus (needs to write correct code)

### Developer 2
- **Name**: developer-2
- **Focus**: Implement assigned work stream
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for task assignment from lead. Read spec and plan when available.
- **Model**: opus (needs to write correct code)

### Reviewer 1
- **Name**: reviewer-1
- **Focus**: Code review using code-reviewer skill
- **Agent definition**: Read .claude/teams/feature-team/agents/team-developer.md for role instructions
- **First task**: Wait for review assignment from lead. Read spec, plan, and QA notes while waiting.
- **Model**: opus (needs thorough analysis for review)

### QA Engineer
- **Name**: qa
- **Focus**: Test planning and validation
- **Agent definition**: Read .claude/teams/feature-team/agents/team-qa.md for role instructions
- **First task**: Review the feature requirements for testability. Once PM's spec is ready, create QA notes at .claude/qa-notes/{feature-name}_qa_ref_note.md
- **Model**: opus (needs thorough analysis)

## Workflow Phases

### Phase 1: Planning (PARALLEL)
Start PM, Architect, and QA simultaneously:
1. PM creates feature spec at docs/specs/{feature-name}.md
2. Architect explores codebase (can start before spec)
3. QA reviews requirements for testability (can start before spec)

### Phase 2: Design (SEQUENTIAL — wait for PM's spec)
1. Architect creates implementation plan at docs/specs/{feature-name}-plan.md
2. QA creates test plan at .claude/qa-notes/{feature-name}_qa_ref_note.md
3. PM reviews plan for completeness
4. If scip-php involved: QA sets up contract tests BEFORE implementation

### Phase 3: Task Decomposition (LEAD ONLY)
1. Read the architect's plan
2. Decompose into tasks with file ownership (one owner per file)
3. Create implementation tasks with: owned files, requirements, interface contracts, acceptance criteria
4. Create review tasks (blocked by implementation tasks) — assign to reviewer-1
5. Set blockedBy dependencies
6. Assign implementation tasks to developer-1 and developer-2
7. IMPORTANT: Never let a developer review their own code

### Phase 4: Implementation (PARALLEL)
1. Developer(s) implement their assigned tasks
2. QA prepares test infrastructure
3. Monitor progress, respond to questions, coordinate at integration points

### Phase 5: Code Review (SEQUENTIAL — after implementation)
1. Tell reviewer-1: "Implementation complete. Review the changes using the code-reviewer skill."
2. Reviewer uses code-reviewer skill to review all implementation changes
3. Reviewer reports verdict: APPROVE or REQUEST_CHANGES
4. If REQUEST_CHANGES:
   - Reviewer messages implementing developer with specific findings
   - Developer fixes issues
   - Reviewer re-reviews (max 3 loops)
5. All reviews must be APPROVED before proceeding

### Phase 6: QA Validation (SEQUENTIAL — after code review passes)
1. Tell QA: "Implementation complete and code review passed. Validate against test plan."
2. QA runs tests and reports PASS/FAIL
3. If FAIL: create fix tasks for developers, reviewer re-reviews fixes, then QA re-validates (max 5 loops)
4. If scip-php: QA also validates contract tests

### Phase 7: Completion
1. Verify all tasks done via TaskList
2. Verify git status (feature branch + commit)
3. Create summary at .claude/feature-team-runs/{date}-{feature-name}/summary.md
4. Shut down all teammates
5. Clean up team

## Rules for Lead

1. Use delegate mode — DO NOT implement code yourself
2. Follow phases sequentially — don't skip ahead
3. Wait for PM's spec before starting Phase 2
4. Decompose tasks with strict file ownership before assigning
5. Never assign overlapping files to multiple developers
6. **Code review MUST pass before QA validation** — no shortcuts
7. **Never let a developer review their own code**
8. QA must pass before feature is complete
9. Feature is NOT complete until there's a commit on a feature branch
10. Never push to remote — user decides when to push

## Rules for All Teammates

1. Read your agent definition file first for detailed role instructions
2. Message the lead when you complete a phase or hit a blocker
3. Message relevant teammates at integration points
4. Use TaskUpdate to mark tasks in_progress/completed
5. Refer to teammates by NAME, not UUID
```

## Variations

### Small Feature (4 agents)

Drop the Architect and dedicated reviewer. One dev reviews the other's code:

```
## Team Structure (Small)

### PM: pm (sonnet) — Create spec
### Developer 1: developer-1 (opus) — Implement + review developer-2's code
### Developer 2: developer-2 (opus) — Implement + review developer-1's code
### QA: qa (opus) — Test plan and validation

Lead does: codebase exploration + plan creation + task decomposition
Each developer reviews the other's code after implementation (cross-review).
```

### Standard Feature (7 agents — default)

Two developers, one dedicated reviewer:

```
## Team Structure (Standard)

### PM: pm (sonnet) — Create spec
### Architect: architect (opus) — Plan + design
### Developer 1: developer-1 (opus) — Work stream 1
### Developer 2: developer-2 (opus) — Work stream 2
### Reviewer 1: reviewer-1 (opus) — Code review (uses code-reviewer skill)
### QA: qa (opus) — Test plan + validation

Phase 3 creates separate tasks for each developer with non-overlapping files.
Phase 5 reviewer-1 reviews all implementation changes before QA.
```

### Large Feature (9 agents)

Three developers, two dedicated reviewers:

```
## Team Structure (Large)

### PM: pm (sonnet) — Create spec
### Architect: architect (opus) — Plan + design
### Developer 1: developer-1 (opus) — Work stream 1
### Developer 2: developer-2 (opus) — Work stream 2
### Developer 3: developer-3 (opus) — Work stream 3
### Reviewer 1: reviewer-1 (opus) — Reviews developer-1 and developer-2's code
### Reviewer 2: reviewer-2 (opus) — Reviews developer-3's code + re-reviews fixes
### QA: qa (opus) — Test plan + validation

Phase 3 creates separate tasks for each developer with non-overlapping files.
Phase 5 reviewers review in parallel, each covering assigned developers' changes.
```

### scip-php Feature

Add contract test instructions to QA:

```
## Additional for scip-php

QA has preloaded skills:
- kloc-scip-contract-scenarios — Generate WHEN/THEN test scenarios
- kloc-scip-contract-test-create — Create PHPUnit contract tests
- kloc-scip-contract-test-run — Run tests and generate docs

In Phase 2, after spec is ready:
1. QA runs kloc-scip-contract-test-run to check current state
2. QA generates scenarios with kloc-scip-contract-scenarios
3. QA creates contract tests with kloc-scip-contract-test-create
4. Tests are created BEFORE implementation (TDD)
5. Developers CAN run tests but CANNOT modify them
```

## Expected Output

```
docs/specs/{feature-name}.md              # PM's feature spec
docs/specs/{feature-name}-plan.md         # Architect's implementation plan
.claude/qa-notes/{feature-name}_qa_ref_note.md  # QA's test plan
.claude/feature-team-runs/{date}-{feature-name}/
  summary.md                              # Lead's final report
```

## Tips

- Press **Shift+Tab** immediately after team spawns to enter delegate mode
- If lead starts coding: "Stop — delegate to developers, don't implement yourself"
- If PM's spec is too thin: "PM, add more edge cases and acceptance criteria"
- If architect's plan has overlapping files: "Architect, redesign file ownership boundaries"
- Monitor progress with Shift+Up/Down
- For large features, spawn developers one at a time as tasks are ready
- **Code review must pass before QA** — if lead skips it, remind: "Phase 5 (code review) is mandatory"
- Reviewers use the `code-reviewer` skill which includes kloc business knowledge
