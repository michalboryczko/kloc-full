# Feature Team — Agent Teams Configuration

Multi-agent team for end-to-end feature development. Replaces the sequential `feature-orchestrator` workflow with parallel agent collaboration using Claude Code's [Agent Teams](https://code.claude.com/docs/en/agent-teams) feature.

## Prerequisites

- `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in settings.json or environment
- Recommended: `"teammateMode": "in-process"` in `~/.claude/settings.json`

## Team Roles

| Role | Agent | Model | Responsibility |
|------|-------|-------|----------------|
| **Lead** | team-lead | opus | Orchestrates team, decomposes work, manages review flow |
| **PM** | team-pm | sonnet | Creates feature spec, defines acceptance criteria, reviews deliverables |
| **Architect** | team-architect | opus | Explores codebase, creates implementation plan, designs interfaces |
| **Developer** (2+) | team-developer | opus | Implements code within file ownership boundaries |
| **Reviewer** (1+) | team-developer | opus | Reviews implementation using `code-reviewer` skill |
| **QA** | team-qa | opus | Creates test plan, validates implementation, runs tests |

**Note**: Developers and reviewers use the same agent definition. A developer acts as reviewer when assigned a review task. Reviewers must never review their own code.

## Team Sizes

| Size | Developers | Reviewers | Total Agents | Best For |
|------|-----------|-----------|--------------|----------|
| **Small** | 1 | 1 (dev doubles as reviewer for other's code) | 4 (Lead + PM + Dev + QA) | Simple features, 1 work stream |
| **Standard** | 2 | 1 (dedicated reviewer) | 7 (Lead + PM + Architect + 2 Dev + 1 Reviewer + QA) | Most features, 2 work streams |
| **Large** | 3 | 2 (dedicated reviewers) | 9 (Lead + PM + Architect + 3 Dev + 2 Reviewer + QA) | Complex features, 3+ work streams |

## How to Use

### Quick Start

1. Start a new Claude Code session
2. Paste the prompt from `prompt.md` (adjust feature details)
3. Claude spawns the team and manages the lifecycle
4. Use Shift+Up/Down to interact with teammates
5. Use delegate mode (Shift+Tab) to keep lead coordinating

### Customization

- **Smaller features**: Drop Architect, have Lead do planning directly (small team)
- **scip-php features**: QA agent auto-activates contract test skills
- **Plan approval**: Add `--plan-first` to require your approval before implementation begins

## Workflow Phases

```
Phase 1: Planning (parallel)
  PM: creates feature spec
  Architect: explores codebase, identifies patterns
  QA: reviews requirements for testability

Phase 2: Design (PM spec -> Architect plan -> QA test plan)
  Architect: creates implementation plan (needs PM's spec)
  QA: creates QA notes / test scenarios
  PM: reviews plan for completeness

Phase 3: Task Decomposition (Lead)
  Lead: decomposes plan into tasks with file ownership
  Lead: creates dependency graph
  Lead: assigns tasks to developers
  Lead: creates review tasks (blocked by implementation) for reviewers

Phase 4: Implementation (parallel)
  Developer(s): implement assigned streams
  QA: prepares test infrastructure

Phase 5: Code Review
  Reviewer(s): review implementation using code-reviewer skill
  If REQUEST_CHANGES: developer fixes -> reviewer re-reviews (max 3 loops)
  All reviewers must APPROVE before proceeding

Phase 6: QA Validation
  QA: validates implementation against test plan
  QA: runs automated tests
  If failures: Developer fixes -> QA re-validates (max 5 loops)

Phase 7: Completion
  Lead: verifies all tasks done + git workflow
  Lead: creates summary report
  Lead: shuts down team
```

## Output

```
.claude/feature-team-runs/{date}-{feature-name}/
  summary.md          # Lead's final report
  spec.md             # PM's feature spec (also at docs/specs/)
  plan.md             # Architect's plan (also at docs/specs/)
  qa-notes.md         # QA's test plan
  progress.md         # Implementation progress
```

## Differences from feature-orchestrator Workflow

| Aspect | feature-orchestrator | feature-team |
|--------|---------------------|-------------|
| Execution | Sequential (one agent at a time) | Parallel (agents work simultaneously) |
| Agents | Subagents (report back only) | Teammates (message each other) |
| Planning | Single planner agent | PM + Architect collaborate |
| Code Review | Not enforced | Mandatory phase before QA |
| QA timing | Notes before, validate after | QA participates throughout |
| File ownership | Not enforced | Strict ownership per developer |
| Fix loop | Orchestrator manages | Lead + Reviewer + Developer + QA coordinate directly |
| Token cost | Lower | Higher (each teammate has own context) |
| Best for | Sequential features, simple scope | Complex features, parallel workstreams |

## Tips

- Use **delegate mode** (Shift+Tab) after team spawns to keep lead coordinating
- If lead starts implementing, tell it: "Wait for teammates, delegate only"
- Monitor with Shift+Up/Down to check individual teammates
- For scip-php features, the QA agent auto-detects and uses contract test skills
- Reviewers should never review their own code — lead assigns cross-reviews
- Code review MUST pass before QA validation begins
