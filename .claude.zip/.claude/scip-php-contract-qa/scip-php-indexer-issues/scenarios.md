# Contract Test Scenarios: scip-php-indexer-issues

## Context

Six data quality issues in the scip-php indexer pipeline cause incorrect call_kind assignment, wrong uses edge locations, and misattributed receiver chains. These contract tests validate the scip-php calls.json output for the specific patterns involved in each issue, ensuring correct behavior and preventing regression.

Focus areas:
- Issue 3: call_kind for chained method calls (method vs access)
- Issues 2+4: Occurrence location accuracy and receiver attribution
- Correct chain linkage for multi-step property/method chains

## Reference Code

### File: `kloc-reference-project-php/src/Service/OrderService.php`
Lines 42-56:
```php
// Line 42: $processedOrder = $this->orderProcessor->process($order);
// Line 43: $processorName = $this->orderProcessor->getName();
// Line 45: $savedOrder = $this->orderRepository->save($processedOrder);
// Lines 47-56:
// $this->emailSender->send(
//     to: $savedOrder->customerEmail,          // line 48
//     subject: 'Order Confirmation #' . $savedOrder->id,  // line 49
//     body: sprintf(...)                        // line 50-55
// );
```

### File: `kloc-reference-project-php/src/Repository/OrderRepository.php`
Lines 29-36:
```php
// Line 29: $newOrder = new Order(
// Line 30:     id: self::$nextId++,
// Line 31:     customerEmail: $order->customerEmail,
// Line 32:     productId: $order->productId,
// Line 33:     quantity: $order->quantity,
// ...
```

---

## Scenarios

### Category: Call Kind (callkind)

#### Scenario 1: Chained method call getName() has kind=method
WHEN indexing `$this->orderProcessor->getName()` at OrderService.php line 43
THEN the call to `AbstractOrderProcessor#getName()` has:
  - kind: "method"
  - kind_type: "invocation"
  - callee containing "AbstractOrderProcessor#getName()"

This validates Issue 3: chained method calls must NOT be misclassified as property access.

#### Scenario 2: Chained property access $this->orderProcessor has kind=access
WHEN indexing `$this->orderProcessor` at OrderService.php line 43
THEN the property access to `OrderService#$orderProcessor` has:
  - kind: "access"
  - kind_type: "access"
  - callee containing "OrderService#$orderProcessor"

This validates that the property access step in the chain is correctly classified as access.

#### Scenario 3: Static property access self::$nextId has kind=access_static
WHEN indexing `self::$nextId++` in OrderRepository::save() at line 30
THEN the static property access has:
  - kind: "access_static"
  - kind_type: "access"
  - callee containing "OrderRepository#$nextId"
  - location.line: 30 (NOT 29)

This validates Issue 2: the static property access must be at line 30, not inheriting the constructor line 29.

#### Scenario 4: Chained method call process() has kind=method
WHEN indexing `$this->orderProcessor->process($order)` at OrderService.php line 42
THEN the call to `AbstractOrderProcessor#process()` has:
  - kind: "method"
  - kind_type: "invocation"
  - callee containing "AbstractOrderProcessor#process()"

This validates that chained method calls consistently get kind=method, not kind=access.

#### Scenario 5: Constructor new Order() in save() has kind=constructor
WHEN indexing `new Order(...)` in OrderRepository::save() at line 29
THEN the constructor call has:
  - kind: "constructor"
  - kind_type: "invocation"
  - callee containing "Order#__construct()"
  - location.line: 29

This validates that the constructor is distinct from the static property access on the next line.

### Category: Chain Integrity (chain)

#### Scenario 6: Chain linkage $this->orderProcessor->getName()
WHEN indexing the chain `$this->orderProcessor->getName()` at OrderService.php line 43
THEN:
  - The access to `$orderProcessor` produces a result value
  - The method call to `getName()` has receiver_value_id pointing to that result value
  - The chain flows: access(orderProcessor) -> result -> method(getName) -> result

This validates that chained expression linkage is maintained through result values.

#### Scenario 7: Chain linkage $this->orderRepository->save()
WHEN indexing the chain `$this->orderRepository->save($processedOrder)` at OrderService.php line 45
THEN:
  - The access to `$orderRepository` produces a result value
  - The method call to `save()` has receiver_value_id pointing to that result value

#### Scenario 8: Chain linkage $this->emailSender->send()
WHEN indexing the chain `$this->emailSender->send(...)` at OrderService.php line 47
THEN:
  - The access to `$emailSender` produces a result value
  - The method call to `send()` has receiver_value_id pointing to that result value

### Category: Reference Consistency (reference)

#### Scenario 9: Property access receiver in named arguments points to correct variable
WHEN indexing `$savedOrder->customerEmail` at OrderService.php line 48 (inside send() named argument)
THEN:
  - The property access has receiver_value_id pointing to $savedOrder local value
  - The receiver is NOT the emailSender property access result
  - The receiver value's symbol contains "local$savedOrder"

This validates Issue 4: property accesses inside named arguments must reference their actual receiver, not the enclosing method call's receiver.

#### Scenario 10: Multiple property accesses on $savedOrder share receiver
WHEN indexing property accesses on `$savedOrder` in OrderService::createOrder() (lines 48, 49, 52-54, 61-66)
THEN all property accesses on $savedOrder share the same receiver_value_id

This validates that the $savedOrder local variable is consistently referenced across multiple access sites.

#### Scenario 11: Property accesses on $order in save() share receiver
WHEN indexing property accesses on `$order` in OrderRepository::save() (lines 31-35)
THEN all accesses to `$order->customerEmail`, `$order->productId`, `$order->quantity`, `$order->status`, `$order->createdAt` share the same receiver_value_id pointing to the $order parameter value

### Category: Data Integrity (integrity)

#### Scenario 12: Constructor and static property access at adjacent lines are distinct calls
WHEN indexing OrderRepository::save() lines 29-30
THEN:
  - The constructor `new Order(...)` at line 29 is a separate call from `self::$nextId++` at line 30
  - They have different call IDs
  - They have different callee symbols (Order#__construct vs OrderRepository#$nextId)

This validates Issue 2: adjacent constructor and static property access must not be conflated.

#### Scenario 13: Property access inside constructor arguments has own call entry
WHEN indexing `$order->customerEmail` at OrderRepository.php line 31 (inside `new Order()` argument list)
THEN:
  - A separate call entry exists with kind=access for the property access
  - The call has callee containing "Order#$customerEmail"
  - The call has receiver_value_id pointing to the $order parameter

This validates that property accesses inside constructor argument lists get their own call records, not inheriting the constructor's metadata.

#### Scenario 14: Location accuracy for static property access in constructor args
WHEN indexing `self::$nextId++` in OrderRepository::save()
THEN:
  - The access_static call has location.line=30
  - The constructor call at line 29 has location.line=29
  - The calls are on separate lines

This validates Issue 2: the static property access location must be its actual line, not the constructor's line.

## Implementation Notes

- Tests for Issues 3 and 2 validate the scip-php indexer's call_kind assignment and location accuracy
- These tests verify calls.json output directly, not the downstream kloc-cli interpretation
- Tests should be written as concrete assertions against the calls.json query API
- Tests may pass currently (indicating scip-php already handles these correctly), which is good -- they serve as regression guards
- Some scenarios overlap with existing tests; the new tests focus specifically on the issue-related patterns
