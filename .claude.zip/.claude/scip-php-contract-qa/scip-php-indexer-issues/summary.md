# Contract QA Summary: scip-php-indexer-issues

## Feature
Fix 6 data quality issues in the scip-php indexer pipeline involving incorrect call_kind assignment, wrong uses edge locations, and chained expression handling. Key issues: method calls misclassified as property access (Issue 3), constructor argument symbol locations wrong (Issue 2+4), and property access receiver attribution errors in named arguments (Issue 4).

## Scenarios Created
- 14 scenarios generated
- Categories: callkind (6), chain (3), reference (3), integrity (2)

## Reference Code
- Existing code used:
  - `kloc-reference-project-php/src/Service/OrderService.php` (lines 42-67)
  - `kloc-reference-project-php/src/Repository/OrderRepository.php` (lines 28-42)
  - `kloc-reference-project-php/src/Service/AbstractOrderProcessor.php` (lines 24-68)
- New code created: none (all patterns already exist in the reference project)

## Tests Created
- 19 tests created across 4 test files
- Passing: 19
- Failing: 0 (all pass currently -- scip-php already handles these patterns correctly)
- Skipped: 0

### Test Files
| File | Tests | Category | Focus |
|------|-------|----------|-------|
| `tests/CallKind/ChainedCallKindTest.php` | 6 | callkind | Issue 3: call_kind for chained method calls |
| `tests/Chain/ChainedExpressionTest.php` | 3 | chain | Chain linkage for multi-step expressions |
| `tests/Reference/ReceiverAttributionTest.php` | 5 | reference | Issues 2+4: receiver attribution accuracy |
| `tests/Integrity/LocationAccuracyTest.php` | 5 | integrity | Issues 2+4: call location accuracy |

### New Test Details
| Test Name | Category | Status | Issue |
|-----------|----------|--------|-------|
| Chained method call getName() has kind=method | callkind | passed | 3 |
| Property access $this->orderProcessor has kind=access | callkind | passed | 3 |
| Chained method call process() has kind=method | callkind | passed | 3 |
| Static property self::$nextId has kind=access_static | callkind | passed | 2 |
| Constructor new Order() at line 29 has kind=constructor | callkind | passed | 2 |
| No method calls misclassified as access | callkind | passed | 3 |
| Chain: $this->orderProcessor->getName() | chain | passed | 3 |
| Chain: $this->emailSender->send() | chain | passed | 4 |
| Chain: $this->orderRepository->save() to $savedOrder | chain | passed | - |
| $savedOrder->customerEmail receiver in send() args | reference | passed | 4 |
| $savedOrder->id receiver in send() args | reference | passed | 4 |
| All $savedOrder accesses share same receiver | reference | passed | 4 |
| All $order accesses in save() share same receiver | reference | passed | 2 |
| $order->customerEmail in constructor args has own call entry | reference | passed | 2 |
| self::$nextId location is line 30 (not 29) | integrity | passed | 2 |
| Constructor and static access have distinct locations | integrity | passed | 2 |
| Property accesses in constructor args have correct line numbers | integrity | passed | 2 |
| Property accesses in send() args have correct line numbers | integrity | passed | 4 |
| No duplicate call IDs with different callees | integrity | passed | 2 |

## Overall Test Status
- Total tests: 254 (was 235)
- Passing: 224 (was 205)
- Failing: 0
- Skipped: 30 (all experimental, unchanged)

## Status
READY_FOR_DEVELOPMENT

All 19 new contract tests pass, meaning scip-php currently produces correct calls.json output for these patterns. The tests serve as regression guards to ensure correctness is maintained as fixes are implemented in the kloc-cli and scip-php components for Issues 1-6.
