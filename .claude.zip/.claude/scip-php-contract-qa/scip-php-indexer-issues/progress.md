# Progress Log: scip-php-indexer-issues

## Mode: SETUP
## Started: 2026-02-08

---

### Step 1: Initialize and Validate Current State
- **Status**: COMPLETE
- **Result**: All existing tests pass
  - Passed: 205
  - Failed: 0
  - Skipped: 30 (all experimental)
  - Error: 0
- Initialization status saved to initialization_status.json and initialization_status.md

### Step 2: Generate Test Scenarios
- **Status**: COMPLETE
- 14 scenarios generated across 4 categories (callkind, chain, reference, integrity)
- Scenarios saved to scenarios.md
- Focus areas:
  1. Issue 3: call_kind for chained method calls (access vs method)
  2. Issues 2+4: Uses edge location accuracy (constructor argument symbols)
  3. Issue 4: Property access receiver attribution in named arguments

### Step 3: Find or Create Reference Code
- **Status**: COMPLETE
- All patterns already exist in the reference project:
  - OrderService.php: chained method calls, named arguments
  - OrderRepository.php: constructor arguments, static property access
  - AbstractOrderProcessor.php: method definitions for chain targets
- No new code needed

### Step 4: Create Contract Tests
- **Status**: COMPLETE
- 19 tests created in 4 files:
  - tests/CallKind/ChainedCallKindTest.php (6 tests)
  - tests/Chain/ChainedExpressionTest.php (3 tests)
  - tests/Reference/ReceiverAttributionTest.php (5 tests)
  - tests/Integrity/LocationAccuracyTest.php (5 tests)
- First run: 1 failure (receiver kind assertion too broad for save() accesses)
- Fix: filtered to only $order parameter accesses (excluded $newOrder local)
- Second run: all 19 tests pass

### Step 5: Validate and Finalize
- **Status**: COMPLETE
- All 254 tests pass (224 passed + 30 skipped experimental)
- No regressions (original 205 passing tests still pass)
- Updated status saved to updated_status.json and updated_status.md
- Summary saved to summary.md

---

## Setup Completion
- **Finished**: 2026-02-08
- **Final status**: READY_FOR_DEVELOPMENT
- **Note**: All 19 new tests currently pass, meaning scip-php already produces correct calls.json output for these patterns. The tests serve as regression guards for Issues 1-6.

---

## Mode: VALIDATE
## Started: 2026-02-08

### Context
Implementation complete. Changes in kloc-cli/src/queries/context.py only:
1. Added _call_matches_target() helper for callee verification
2. Modified find_call_for_usage() to verify callee before returning matches
3. Replaced global visited set with cycle_guard + per-parent local_visited

### Validation Step 1: Restore Context
- **Status**: COMPLETE
- Loaded scenarios.md (14 scenarios), summary.md (19 tests), updated_status.json (baseline)
- Previous state: 254 tests, 224 passing, 0 failing, 30 skipped

### Validation Step 2: Run Tests
- **Status**: COMPLETE
- All 254 tests pass
  - Passed: 224
  - Failed: 0
  - Skipped: 30 (all experimental)
  - Error: 0
- Fresh calls.json regenerated from scip-php (unchanged indexer)

### Validation Step 3: Compare and Report
- **Status**: COMPLETE
- Zero regressions: all 224 previously passing tests still pass
- Zero changes: identical test counts and statuses
- All 19 issue-specific tests pass (call_kind, chain, reference, location accuracy)
- Validation report saved to validation_report.md

---

## Validation Completion
- **Finished**: 2026-02-08
- **Verdict**: PASS
- **Note**: kloc-cli changes do not affect scip-php calls.json output. All contract tests confirm the indexer data remains correct.
