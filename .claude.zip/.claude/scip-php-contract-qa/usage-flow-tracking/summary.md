# Contract QA Summary: usage-flow-tracking

## Feature
Validates that scip-php calls.json output supports the usage-flow-tracking spec requirements for:
- Access chains (tracking how a target is reached step-by-step)
- Receiver information (which value is the receiver of each call)
- Multiple references (same scope can have multiple calls not collapsed)
- Argument tracking (parameters passed as arguments to other methods)

## Spec Reference
- Spec: `docs/specs/usage-flow-tracking.md`
- Test Cases: TC1-TC6 (TC6 is CLI-level, not calls.json)

## Scenarios Created
- **18 scenarios** generated
- Categories covered: reference, chain, argument, smoke

### Scenarios by Test Case

| TC | Description | Tests |
|----|-------------|-------|
| TC1 | Property type hints create values with types | 2 |
| TC2 | Method calls via property have receiver_value_id | 2 |
| TC3 | Chained calls reconstructable via receiver_value_id | 4 |
| TC4 | Multiple method calls NOT collapsed | 3 |
| TC5 | Arguments reference values via value_id | 5 |
| Integration | Full chain trace + summary | 2 |

## Reference Code
Existing code used (no new code needed):
- `src/Service/OrderService.php` - chains, multiple calls, arguments
- `src/Service/NotificationService.php` - property access chain
- `src/Service/CustomerService.php` - nested property chains
- `src/Repository/OrderRepository.php` - parameter patterns
- `src/Entity/Order.php` - readonly properties with types

## Tests Created
- **File**: `kloc-reference-project-php/contract-tests/tests/UsageFlow/UsageFlowTrackingTest.php`
- **Tests**: 18
- **Passing**: 18 (100%)
- **Failing**: 0
- **Skipped**: 0

## Validation Results

### Requirements Support Status

| Requirement | Status | Evidence |
|-------------|--------|----------|
| **TC1: Type hints create typed values** | FULLY SUPPORTED | Parameter values have `type` field with class type |
| **TC2: receiver_value_id linkage** | FULLY SUPPORTED | Method calls on properties have receiver_value_id pointing to property access result |
| **TC3: Chain reconstruction** | FULLY SUPPORTED | Full chains traceable: value -> access -> result -> method -> result |
| **TC4: Multiple calls not collapsed** | FULLY SUPPORTED | Each call has unique ID; multiple accesses share receiver |
| **TC5: Argument value tracking** | FULLY SUPPORTED | Arguments have value_id pointing to local, parameter, or result values |
| **TC6: Depth expansion** | N/A | CLI-level feature, not calls.json |

## Status
**READY_FOR_DEVELOPMENT**

All spec requirements (TC1-TC5) are fully supported by the current calls.json structure.
The indexer produces all necessary data for usage flow tracking.
