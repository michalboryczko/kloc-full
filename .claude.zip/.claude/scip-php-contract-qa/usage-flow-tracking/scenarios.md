# Contract Test Scenarios: Usage Flow Tracking

## Context
The usage-flow-tracking spec (docs/specs/usage-flow-tracking.md) defines requirements for 
tracking how targets are accessed via calls.json. This validates that the scip-php indexer 
produces the data needed for:

1. **Access Chains**: Tracking step-by-step how a target is reached
2. **Receiver Information**: Which value is the receiver of each call
3. **Multiple References**: Same scope can have multiple calls that aren't collapsed
4. **Argument Tracking**: Parameters passed as arguments to other methods

## Test Cases from Spec

### TC1: Property Type Hints Create Values with Types

**Reference Code**: `src/Service/OrderService.php:20`
```php
public function __construct(
    private OrderRepository $orderRepository,
    ...
)
```

#### Scenario TC1-1: Type Hint on Property Creates Typed Value
WHEN indexing `OrderService#__construct().($orderRepository)`
THEN calls.json contains a parameter value with:
  - kind: "parameter"
  - symbol containing "($orderRepository)"
  - type containing "OrderRepository"

### TC2: Method Calls Via Property Have receiver_value_id

**Reference Code**: `src/Service/OrderService.php:40`
```php
$savedOrder = $this->orderRepository->save($order);
```

#### Scenario TC2-1: Method Call Has receiver_value_id Pointing to Property Access Result
WHEN indexing `OrderRepository#save()` call in `OrderService::createOrder()`
THEN the call has:
  - kind: "method"
  - callee containing "save"
  - receiver_value_id pointing to a result value
  - The result value's source_call_id points to an access call for orderRepository

#### Scenario TC2-2: Property Access Creates Result Value
WHEN indexing `$this->orderRepository` access
THEN calls.json contains:
  - An access call with callee containing "orderRepository"
  - A result value with the same ID as the access call
  - result value kind: "result"

### TC3: Chained Calls Reconstructed via receiver_value_id

**Reference Code**: `src/Service/NotificationService.php:20-27`
```php
$order = $this->orderRepository->findById($orderId);
...
$this->emailSender->send(to: $order->customerEmail, ...);
```

#### Scenario TC3-1: Chain Value -> Access -> Result -> Method -> Result
WHEN tracing `$this->orderRepository->findById()` chain
THEN following receiver_value_id backwards yields:
  - findById method call (receiver_value_id points to orderRepository access result)
  - orderRepository access call (receiver_value_id points to $this or null)
  - Chain terminates at $this value or null (for readonly promoted property)

#### Scenario TC3-2: Local Variable Links to Method Result
WHEN indexing `$order = $this->orderRepository->findById($orderId)`
THEN:
  - $order local value has source_call_id pointing to findById call
  - Property accesses on $order use $order local as receiver

#### Scenario TC3-3: Nested Property Access Chain
WHEN indexing `$order->customerEmail` access
THEN the access has:
  - receiver_value_id pointing to $order local value
  - A corresponding result value with kind: "result"

### TC4: Multiple Method Calls Not Collapsed

**Reference Code**: `src/Service/OrderService.php:42-53`
```php
$this->emailSender->send(...);
$this->messageBus->dispatch(...);
```

#### Scenario TC4-1: Same Scope Multiple Calls Are Separate
WHEN indexing `OrderService::createOrder()`
THEN calls.json contains multiple separate call entries:
  - inventoryChecker->checkAvailability() at line 29
  - orderRepository->save() at line 40
  - emailSender->send() at line 42
  - messageBus->dispatch() at line 53
  - Each has unique id (file:line:col)

#### Scenario TC4-2: Multiple Property Accesses on Same Object
WHEN indexing property accesses on `$savedOrder` in `OrderService::createOrder()`
THEN calls.json contains separate access entries for:
  - $savedOrder->customerEmail (line 43)
  - $savedOrder->id (line 44)
  - $savedOrder->id (line 47)
  - $savedOrder->productId (line 48)
  - $savedOrder->quantity (line 49)
  - All share the same receiver_value_id pointing to $savedOrder local

### TC5: Arguments Reference Values via value_id

**Reference Code**: `src/Service/OrderService.php:40`
```php
$savedOrder = $this->orderRepository->save($order);
```

#### Scenario TC5-1: Argument Points to Local Variable
WHEN indexing `save($order)` call argument
THEN arguments[0] has:
  - position: 0
  - value_id pointing to $order local value
  - parameter containing "($order)"

#### Scenario TC5-2: Argument Points to Property Access Result
WHEN indexing `send(to: $savedOrder->customerEmail, ...)` call
THEN arguments[0] (to:) has:
  - value_id pointing to a result value (from customerEmail access)
  - The result value has source_call_id pointing to an access call

#### Scenario TC5-3: Argument Points to Constructor Result
WHEN indexing `dispatch(new OrderCreatedMessage($savedOrder->id))`
THEN arguments[0] has:
  - value_id pointing to a result value
  - The result value has source_call_id pointing to constructor call

### TC6: Depth Expansion (Secondary Concern)

This is handled at the CLI level by following usage edges, not in calls.json.
No specific scenarios needed for calls.json validation.

## Implementation Notes

1. All tests should use existing reference code - no new code needed
2. Tests focus on data structure validity, not semantic correctness
3. Chain traversal tests verify linkage, not chain semantics
4. Multiple calls test uses count assertions on unique IDs
