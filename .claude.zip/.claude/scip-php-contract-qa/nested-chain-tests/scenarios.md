# Test Scenarios: nested-chain-tests

## Feature Overview
Test nested object property access chains and value flow tracking through Customer -> Contact/Address relationships.

## Reference Code
- `src/Entity/Contact.php` - Contact entity with email, phone
- `src/Entity/Address.php` - Address entity with street, city, postalCode, country
- `src/Entity/Customer.php` - Customer with nested Contact and Address
- `src/Repository/CustomerRepository.php` - Repository with createCustomer()
- `src/Dto/CustomerResponse.php` - Flattened response DTO
- `src/Service/CustomerService.php` - Service demonstrating nested chains (to be created)

---

## Scenario 1: Nested Property Access Chains Share Receiver

**WHEN** accessing `$customer->contact->email` AND `$customer->contact->phone` in same method

**THEN**
- Both `contact` property accesses should have same `receiver_value_id` (the $customer value)
- Both `email` and `phone` accesses should have same `receiver_value_id` (the contact result)

**Test Location**: `tests/Chain/NestedChainTest.php`

---

## Scenario 2: Multiple Nested Objects Share Parent Receiver

**WHEN** accessing `$customer->contact->email` AND `$customer->address->street` in same method

**THEN**
- Both `contact` and `address` property accesses should have same `receiver_value_id` (the $customer parameter/local)

**Test Location**: `tests/Chain/NestedChainTest.php`

---

## Scenario 3: Value Flow Traceability (Full Chain Walk)

**WHEN** CustomerResponse has `street` value from `$customer->address->street`

**THEN** we should be able to trace backwards:
1. Find the CustomerResponse constructor argument for 'street'
2. Get its `value_id` pointing to the `$street` local
3. Get `$street`'s `source_call_id` pointing to `address->street` access
4. Get that call's `receiver_value_id` pointing to address access result
5. Get address access's `receiver_value_id` pointing to `$customer`
6. Verify `$customer` is `kind=parameter` or `kind=local`

**Test Location**: `tests/Chain/NestedChainTest.php`

---

## Scenario 4: Nested Method Call Chains

**WHEN** calling `$customer->contact->getFormattedEmail()`

**THEN**
- The method call should have `receiver_value_id` pointing to contact access result
- Contact access should have `receiver_value_id` pointing to `$customer`

**Test Location**: `tests/Chain/NestedChainTest.php`

---

## Scenario 5: Deep Chain Integrity

**WHEN** we have a full chain from response argument back to entity property

**THEN**
- Every ID in the chain points to an existing entry
- No orphaned references
- Chain terminates at parameter/local

**Test Location**: `tests/Chain/NestedChainTest.php`
