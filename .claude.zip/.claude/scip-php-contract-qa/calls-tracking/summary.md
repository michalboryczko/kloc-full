# Contract QA Summary: calls-tracking

## Feature
**One Value Per Declaration Rule** - Fix the scip-php indexer to create exactly ONE value entry per variable (parameter or local) at its declaration/assignment site, instead of creating entries at each usage site.

## Problem Being Tested
The indexer currently creates value entries at every usage of a variable:
- `$order` parameter used 8 times creates 5 value entries (at usage sites)
- `$savedOrder` local used 12 times creates 12 value entries
- Each usage has a different `receiver_value_id` instead of sharing one

## Scenarios Created
- **17 scenarios** generated in `scenarios.md`
- Categories covered:
  - Reference Consistency (Parameter uniqueness)
  - Reference Consistency (Local variable uniqueness)
  - Chain Integrity (receiver_value_id sharing)
  - Data Integrity (no duplicate symbols)
  - Edge Cases

## Reference Code
Existing code used (no new code needed):
- `src/Repository/OrderRepository.php:26-45` - `save()` method
- `src/Service/OrderService.php:27-63` - `createOrder()` method
- `src/Service/NotificationService.php:18-37` - `notifyOrderCreated()` method

## Tests Created
- **10 tests** in `tests/Reference/OneValuePerDeclarationTest.php`
- All tests have `#[ContractTest]` attribute for documentation

| Test | What It Validates |
|------|------------------|
| `testOrderRepositorySaveOrderParameterSingleEntry` | $order parameter has exactly 1 value entry |
| `testOrderRepositorySaveAllAccessesShareReceiver` | All $order accesses share same receiver_value_id |
| `testOrderServiceCreateOrderInputParameterSingleEntry` | $input parameter has exactly 1 value entry |
| `testOrderServiceCreateOrderSavedOrderLocalSingleEntry` | $savedOrder local has exactly 1 value entry |
| `testOrderServiceCreateOrderSavedOrderAllAccessesShareReceiver` | All $savedOrder accesses share same receiver_value_id |
| `testNotificationServiceOrderLocalSingleEntry` | $order local has exactly 1 value entry |
| `testOrderRepositoryPropertyAccessChainSharesReceiver` | 5 property accesses share same receiver |
| `testOrderRepositoryReceiverPointsToParameter` | Receiver points to parameter kind value |
| `testOrderRepositoryNoDuplicateParameterSymbols` | No duplicate parameter symbols |
| `testOrderServiceCreateOrderNoDuplicateLocalSymbols` | No duplicate local symbols |

## Test Results
| Metric | Count |
|--------|-------|
| Total tests | 34 |
| Passing | 24 (original tests) |
| Failing | 9 (new tests - expected) |
| Skipped | 1 (existing placeholder) |

**Note**: The 9 failing tests are expected - they test the unimplemented feature. When the indexer is fixed, these tests should pass.

## Status
**READY_FOR_DEVELOPMENT**

The contract tests are ready for TDD workflow:
1. Developer implements the fix in `scip-php/src/DocIndexer.php`
2. Run `bin/run.sh test --filter OneValuePerDeclaration` to check progress
3. All 10 tests should pass when the fix is complete

## Key Files
| File | Purpose |
|------|---------|
| `.claude/scip-php-contract-qa/calls-tracking/scenarios.md` | WHEN/THEN test scenarios |
| `.claude/scip-php-contract-qa/calls-tracking/progress.md` | Setup progress log |
| `contract-tests/tests/Reference/OneValuePerDeclarationTest.php` | PHPUnit contract tests |
| `docs/feature-issues/calls-tracking-issues-v5.md` | Issue documentation |
| `docs/reference/kloc-scip/calls-and-data-flow.md` | Spec with "One Value Per Declaration" rule |

## Run Commands
```bash
# Run just the new tests
cd kloc-reference-project-php/contract-tests && bin/run.sh test --filter OneValuePerDeclaration

# Run all tests
cd kloc-reference-project-php/contract-tests && bin/run.sh test

# Generate documentation
cd kloc-reference-project-php/contract-tests && bin/run.sh docs
```
