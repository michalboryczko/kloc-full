# Contract Tests Status: calls-tracking

Generated: 2026-02-01

## Summary

| Status | Count |
|--------|-------|
| Passed | 24 |
| Failed | 9 |
| Skipped | 1 |
| Error | 0 |
| **Total** | **34** |

## New Tests (One Value Per Declaration Rule)

All 10 new tests are in `tests/Reference/OneValuePerDeclarationTest.php`.

| Status | Test Name | Issue Detected |
|--------|-----------|----------------|
| FAIL | `testOrderRepositorySaveOrderParameterSingleEntry` | 5 entries instead of 1 |
| FAIL | `testOrderRepositorySaveAllAccessesShareReceiver` | 5 different receiver IDs |
| FAIL | `testOrderServiceCreateOrderInputParameterSingleEntry` | 5 entries instead of 1 |
| FAIL | `testOrderServiceCreateOrderSavedOrderLocalSingleEntry` | 12 entries instead of 1 |
| FAIL | `testOrderServiceCreateOrderSavedOrderAllAccessesShareReceiver` | 12 different receiver IDs |
| FAIL | `testNotificationServiceOrderLocalSingleEntry` | 5 entries instead of 1 |
| FAIL | `testOrderRepositoryPropertyAccessChainSharesReceiver` | 5 different receiver IDs |
| PASS | `testOrderRepositoryReceiverPointsToParameter` | Receiver exists and is parameter kind |
| FAIL | `testOrderRepositoryNoDuplicateParameterSymbols` | Duplicate symbols found |
| FAIL | `testOrderServiceCreateOrderNoDuplicateLocalSymbols` | Duplicate symbols found |

## Evidence of Bug

The test failures prove the bug documented in `calls-tracking-issues-v5.md`:

### Parameter Values Created at Usage Sites

```
$order parameter in OrderRepository::save():
- Expected: 1 value entry at line 26 (declaration)
- Actual: 5 value entries at lines 31, 32, 33, 34, 35 (usage sites)
```

### Local Values Created at Usage Sites

```
$savedOrder local in OrderService::createOrder():
- Expected: 1 value entry at line 40 (assignment)
- Actual: 12 value entries at lines 40, 43, 47, 48, 49, 53, 56, 57, 58, 59, 60, 61
```

### Duplicate Symbols

```
Found duplicate parameter symbols:
- "OrderRepository#save().($order)": 5 copies

Found duplicate local symbols:
- "OrderService#createOrder().local$order@31": 2 copies
- "OrderService#createOrder().local$savedOrder@40": 12 copies
```

## When Fix Is Complete

After implementing the fix in `scip-php/src/DocIndexer.php`:

1. Run: `cd kloc-reference-project-php/contract-tests && bin/run.sh test --filter OneValuePerDeclaration`
2. All 10 tests should pass
3. Run: `bin/run.sh test` to verify no regressions in existing tests
