# Contract Test Scenarios: One Value Per Declaration Rule

## Context

The scip-php indexer currently creates a new value entry for EVERY usage of a variable, violating the "One Value Per Declaration Rule" documented in `docs/reference/kloc-scip/calls-and-data-flow.md`. The fix requires:

1. Create ONE parameter value at declaration site (function signature)
2. Create ONE local value at assignment site
3. When variable is used as receiver, look up existing value ID instead of creating new value

This ensures proper data flow tracking where all usages of a variable reference the single declaration value via `receiver_value_id`.

## Reference Code

### File: `kloc-reference-project-php/src/Repository/OrderRepository.php`
Lines: 26-45 - `save()` method with `$order` parameter used 5+ times

```php
public function save(Order $order): Order  // line 26: parameter declaration
{
    if ($order->id === 0) {                 // line 28: usage 1
        $newOrder = new Order(
            id: self::$nextId++,
            customerEmail: $order->customerEmail,  // line 31: usage 2
            productId: $order->productId,          // line 32: usage 3
            quantity: $order->quantity,            // line 33: usage 4
            status: $order->status,                // line 34: usage 5
            createdAt: $order->createdAt,          // line 35: usage 6
        );
        // ...
    }
    self::$orders[$order->id] = $order;     // line 42: usage 7
    return $order;                           // line 44: usage 8
}
```

### File: `kloc-reference-project-php/src/Service/OrderService.php`
Lines: 27-63 - `createOrder()` with local variables used multiple times

```php
public function createOrder(CreateOrderInput $input): OrderOutput
{
    // $input used 4 times
    $this->inventoryChecker->checkAvailability($input->productId, $input->quantity);  // line 29
    $order = new Order(
        customerEmail: $input->customerEmail,  // line 33
        productId: $input->productId,          // line 34
        quantity: $input->quantity,            // line 35
    );

    $savedOrder = $this->orderRepository->save($order);  // line 40: $order used

    // $savedOrder used 8 times
    $this->emailSender->send(
        to: $savedOrder->customerEmail,        // line 43
        subject: 'Order Confirmation #' . $savedOrder->id,  // line 44
        body: sprintf(..., $savedOrder->id, $savedOrder->productId, $savedOrder->quantity),  // lines 47-49
    );

    $this->messageBus->dispatch(new OrderCreatedMessage($savedOrder->id));  // line 53

    return new OrderOutput(
        id: $savedOrder->id,                   // line 56
        customerEmail: $savedOrder->customerEmail,  // line 57
        // ... more usages
    );
}
```

### File: `kloc-reference-project-php/src/Service/NotificationService.php`
Lines: 18-37 - `notifyOrderCreated()` with `$orderId` parameter and `$order` local

```php
public function notifyOrderCreated(int $orderId): void  // line 18: $orderId parameter
{
    $order = $this->orderRepository->findById($orderId);  // line 20: $orderId used, $order assigned

    if ($order === null) {                    // line 22: $order used
        return;
    }

    $this->emailSender->send(
        to: $order->customerEmail,            // line 27: $order used
        subject: 'Order #' . $order->id,      // line 28: $order used
        body: sprintf(..., $order->id, $order->productId, $order->quantity),  // lines 32-34
    );
}
```

---

## Scenarios

### Category 1: Reference Consistency (Parameter Value Uniqueness)

#### Scenario 1.1: Parameter Has Exactly One Value Entry
WHEN indexing `OrderRepository#save().($order)` parameter
THEN calls.json contains exactly ONE value entry with:
  - kind: "parameter"
  - symbol containing "OrderRepository#save().($order)"
  - id at declaration site (line 26, not at any usage line)

#### Scenario 1.2: Parameter Multiple Usages Share Declaration Value
WHEN indexing `OrderRepository#save()` method body
THEN all property accesses on `$order` (lines 28, 31-35, 42, 44) have:
  - receiver_value_id pointing to the SAME value ID
  - That value ID matches the parameter declaration at line 26
  - NO additional parameter value entries exist for usage sites

#### Scenario 1.3: Parameter in Condition Expression
WHEN indexing `$order->id === 0` on line 28
THEN the property access `$order->id` has:
  - receiver_value_id pointing to the parameter value at line 26
  - kind: "access" for the property access call
  - result value created for the access result

#### Scenario 1.4: Simple Parameter Passed to Call
WHEN indexing `$this->orderRepository->findById($orderId)` in NotificationService
THEN the call's arguments[0] has:
  - value_id pointing to the parameter value for `$orderId`
  - That parameter value is at the declaration site (line 18)
  - Only ONE parameter value exists for `$orderId`

---

### Category 2: Reference Consistency (Local Variable Value Uniqueness)

#### Scenario 2.1: Local Variable Has Exactly One Value Entry at Assignment
WHEN indexing `$order = new Order(...)` in OrderService#createOrder() (line 31)
THEN calls.json contains exactly ONE local value entry for `$order` with:
  - kind: "local"
  - symbol containing "local$order@31"
  - source_call_id pointing to the Order constructor call
  - id at the assignment site (line 31)

#### Scenario 2.2: Local Variable Multiple Usages Share Assignment Value
WHEN indexing `$savedOrder` in OrderService#createOrder()
THEN all property accesses on `$savedOrder` (lines 43, 44, 47-49, 53, 56-62) have:
  - receiver_value_id pointing to the SAME value ID
  - That value ID is at the assignment site (line 40)
  - NO additional local value entries exist for `$savedOrder` at usage sites

#### Scenario 2.3: Local Variable Assigned from Method Call
WHEN indexing `$order = $this->orderRepository->findById($orderId)` in NotificationService (line 20)
THEN the local value for `$order` has:
  - kind: "local"
  - symbol containing "local$order@20"
  - source_call_id pointing to the findById() method call
  - All subsequent usages of `$order` (lines 22, 27-34) reference this single value

#### Scenario 2.4: Parameter Used as Argument to Save Local
WHEN indexing `$savedOrder = $this->orderRepository->save($order)` in OrderService (line 40)
THEN:
  - The save() call's arguments[0] has value_id pointing to `$order` local at line 31
  - The `$savedOrder` local has source_call_id pointing to the save() call
  - Both locals have exactly ONE value entry each

---

### Category 3: Chain Integrity (Receiver Value Chain)

#### Scenario 3.1: Property Access Chain Uses Declaration Value
WHEN indexing `$order->customerEmail` in OrderRepository#save() (line 31)
THEN the property access call has:
  - receiver_value_id pointing to parameter value at line 26
  - kind: "access"
  - A result value exists with source_call_id pointing to this access

#### Scenario 3.2: Multiple Property Accesses Same Receiver
WHEN indexing lines 31-35 in OrderRepository#save()
THEN all property accesses on `$order`:
  - `$order->customerEmail` (line 31)
  - `$order->productId` (line 32)
  - `$order->quantity` (line 33)
  - `$order->status` (line 34)
  - `$order->createdAt` (line 35)
ALL have the SAME receiver_value_id pointing to line 26 parameter declaration

#### Scenario 3.3: Local Variable Chain After Assignment
WHEN indexing `$savedOrder->customerEmail` in OrderService (line 43)
THEN:
  - The access has receiver_value_id pointing to `$savedOrder` local value at line 40
  - The local value at line 40 has source_call_id pointing to the save() call
  - The chain is traceable: access -> local -> call -> receiver (which is $order local)

#### Scenario 3.4: Nested Property Access on Same Receiver
WHEN indexing multiple accesses on `$order` within sprintf() call in NotificationService (lines 32-34)
THEN all three accesses (`$order->id`, `$order->productId`, `$order->quantity`):
  - Share the SAME receiver_value_id
  - That receiver_value_id points to the `$order` local at line 20

---

### Category 4: Data Integrity

#### Scenario 4.1: No Duplicate Parameter Symbols
WHEN indexing entire `OrderRepository.php`
THEN no two value entries have the same symbol for any parameter:
  - Only ONE entry with symbol containing "OrderRepository#save().($order)"
  - Only ONE entry with symbol containing "OrderRepository#findById().($id)"

#### Scenario 4.2: No Duplicate Local Symbols
WHEN indexing entire `OrderService.php`
THEN no two value entries have the same symbol for any local variable:
  - Only ONE entry with symbol containing "local$order@31"
  - Only ONE entry with symbol containing "local$savedOrder@40"
  - Only ONE entry with symbol containing "local$order@67" (in getOrder)

#### Scenario 4.3: All Receiver Value IDs Exist
WHEN indexing entire project
THEN every call's receiver_value_id references an existing value entry:
  - No orphaned receiver_value_id references
  - Each referenced value has kind: parameter, local, or result

#### Scenario 4.4: Parameter Value IDs at Declaration Site
WHEN indexing all parameter values in the project
THEN each parameter value's id corresponds to its position in the function signature:
  - NOT at any usage line within the method body
  - Line number in id matches the function definition line

---

### Category 5: Edge Cases

#### Scenario 5.1: Local Variable in Conditional Block
WHEN indexing `$newOrder` in OrderRepository#save() (lines 29-36)
THEN:
  - ONE local value entry exists for `$newOrder` at line 29
  - Usages at lines 37 and 39 reference this single value
  - The local has source_call_id pointing to the Order constructor

#### Scenario 5.2: Parameter and Local Same Name Different Scope
WHEN indexing both `OrderService#createOrder().($input)` and `OrderService#getOrder().($id)`
THEN:
  - Each method's parameters have separate value entries
  - No cross-reference between methods
  - Each parameter's symbol includes its method scope

#### Scenario 5.3: Local Shadows Parameter (Not in Current Codebase)
WHEN indexing a method where a local variable is assigned with same name as parameter
THEN:
  - ONE parameter value exists at declaration
  - ONE local value exists at assignment with unique @line suffix
  - After assignment, usages reference the local value, not parameter value

#### Scenario 5.4: Return Statement with Variable
WHEN indexing `return $order;` in OrderRepository#save() (line 44)
THEN:
  - If the return value is tracked, it references the parameter value at line 26
  - No new value entry is created for the return usage

---

## Implementation Notes

1. **Category Priority**: Reference Consistency (Categories 1 & 2) should be implemented first as they validate the core fix.

2. **Test Method Naming**: Use descriptive names like:
   - `testParameterHasExactlyOneValueEntry`
   - `testLocalVariableMultipleUsagesShareValue`
   - `testReceiverValueIdPointsToDeclaration`

3. **Assertion Helpers Needed**:
   - `countValuesWithSymbol($symbol)` - to verify exactly one entry
   - `getAllReceiverValueIds($scope, $receiverName)` - to verify all point to same ID
   - `getValueAtDeclaration($scope, $paramName)` - to get declaration value ID

4. **Value ID Format**: IDs are `file:line:col`. When comparing receiver_value_id, ensure the line number matches the declaration site, not usage sites.

5. **Current Behavior Reference**: See `docs/feature-issues/calls-tracking-issues-v5.md` for examples of the WRONG current behavior that these tests will catch.
