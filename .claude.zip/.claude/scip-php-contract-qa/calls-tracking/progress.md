# Progress Log: calls-tracking

## Session Info
- **Started**: 2026-02-01
- **Mode**: SETUP
- **Feature**: calls-tracking (One Value Per Declaration Rule)

## Step 1: Initialize and Validate Current State

**Status**: COMPLETE

- Ran `bin/run.sh docs --format=json`
- Result: 23 passed, 0 failed, 1 skipped, 0 error
- All existing tests pass - safe to proceed

**Artifacts created**:
- `initialization_status.json` - summary of test state

## Step 2: Generate Test Scenarios

**Status**: COMPLETE

Read feature specs:
- `docs/specs/calls-tracking.md` - main spec
- `docs/specs/calls-tracking-plan.md` - implementation plan
- `docs/feature-issues/calls-tracking-issues-v5.md` - current issue details
- `docs/reference/kloc-scip/calls-and-data-flow.md` - "One Value Per Declaration" rule

Generated 17 scenarios across 5 categories:
- Category 1: Parameter Value Uniqueness (4 scenarios)
- Category 2: Local Variable Value Uniqueness (4 scenarios)
- Category 3: Chain Integrity (4 scenarios)
- Category 4: Data Integrity (4 scenarios)
- Category 5: Edge Cases (4 scenarios)

**Artifacts created**:
- `scenarios.md` - full WHEN/THEN scenarios

## Step 3: Find/Create Reference Code

**Status**: COMPLETE (no changes needed)

Reference code already exists in kloc-reference-project-php/src:
- `Repository/OrderRepository.php:26-45` - `save()` with `$order` parameter used 8 times
- `Service/OrderService.php:27-63` - `createOrder()` with `$input` and `$savedOrder` locals
- `Service/NotificationService.php:18-37` - `notifyOrderCreated()` with `$order` local

No new reference code needed - existing code exercises all required patterns.

## Step 4: Create Contract Tests

**Status**: COMPLETE

Created test file:
- `contract-tests/tests/Reference/OneValuePerDeclarationTest.php`

Tests created (10 total):
1. `testOrderRepositorySaveOrderParameterSingleEntry` - Scenario 1.1
2. `testOrderRepositorySaveAllAccessesShareReceiver` - Scenario 1.2
3. `testOrderServiceCreateOrderInputParameterSingleEntry` - Scenario 1.3
4. `testOrderServiceCreateOrderSavedOrderLocalSingleEntry` - Scenario 2.1
5. `testOrderServiceCreateOrderSavedOrderAllAccessesShareReceiver` - Scenario 2.2
6. `testNotificationServiceOrderLocalSingleEntry` - Scenario 2.3
7. `testOrderRepositoryPropertyAccessChainSharesReceiver` - Scenario 3.2
8. `testOrderRepositoryReceiverPointsToParameter` - Scenario 3.3
9. `testOrderRepositoryNoDuplicateParameterSymbols` - Scenario 4.1
10. `testOrderServiceCreateOrderNoDuplicateLocalSymbols` - Scenario 4.2

## Step 5: Validate Tests

**Status**: COMPLETE

Test run results:
- Total: 34 tests (24 original + 10 new)
- Passed: 24 (all original tests)
- Failed: 9 (new tests - expected, testing unimplemented feature)
- Skipped: 1 (existing placeholder)

All tests are:
- Syntactically valid
- Runnable (no PHP errors)
- Properly attributed with `#[ContractTest]`

The 9 failures correctly detect the bug documented in `calls-tracking-issues-v5.md`:
- `$order` parameter has 5 value entries (should be 1)
- `$savedOrder` local has 12 value entries (should be 1)
- Multiple different receiver_value_ids instead of shared declaration value

## Completion (SETUP)

**Status**: READY_FOR_DEVELOPMENT

All artifacts created, tests ready for TDD workflow.

---

# Validation Session

## Session Info
- **Date**: 2026-02-01
- **Mode**: VALIDATE
- **Context**: Implementation complete by feature-implementer

## Implementation Changes (from implementer)

Changes made to `scip-php/src/DocIndexer.php`:
1. Added `parameterValueIds` map to store parameter symbol to value ID mappings at declaration time
2. Added `createParameterValueRecord()` method to create ValueRecord at declaration site
3. Modified Param node handling to call `createParameterValueRecord()`
4. Modified `trackVariableExpression()` to look up existing value IDs instead of creating new values
5. Updated `resetLocals()` to clear `parameterValueIds`

Commits:
- scip-php: 30b1946 - "Implement One Value Per Declaration Rule"
- main repo: 1fd8eaf - "Add contract tests for One Value Per Declaration Rule"

## Validation Results

**Status**: PASS

Test run:
```
PHPUnit 11.5.50
Tests: 34, Assertions: 165, Skipped: 1
OK, but some tests were skipped!
```

| Metric | Previous | Current | Change |
|--------|----------|---------|--------|
| Total | 34 | 34 | - |
| Passing | 24 | 33 | +9 |
| Failing | 9 | 0 | -9 |
| Skipped | 1 | 1 | - |

All 9 previously failing tests now pass:
- `testOrderRepositorySaveOrderParameterSingleEntry`
- `testOrderRepositorySaveAllAccessesShareReceiver`
- `testOrderServiceCreateOrderInputParameterSingleEntry`
- `testOrderServiceCreateOrderSavedOrderLocalSingleEntry`
- `testOrderServiceCreateOrderSavedOrderAllAccessesShareReceiver`
- `testNotificationServiceOrderLocalSingleEntry`
- `testOrderRepositoryPropertyAccessChainSharesReceiver`
- `testOrderRepositoryNoDuplicateParameterSymbols`
- `testOrderServiceCreateOrderNoDuplicateLocalSymbols`

No regressions in existing tests.

## Artifacts Created

- `validation_report.md` - detailed validation report

## Final Status

**IMPLEMENTATION VERIFIED**

The "One Value Per Declaration Rule" is correctly implemented.
