# Updated Status: SCIP Index Contract Tests

## Generated: 2026-02-04

## Summary
- **Passed**: 178
- **Failed**: 0
- **Skipped**: 15
- **Error**: 0
- **Total**: 193

## Status: PASS

All contract tests pass (including 32 new SCIP tests).

## New Test Files Added

### tests/Scip/TypeHint/TypeHintTest.php (6 tests)
| Test | Description |
|------|-------------|
| testPropertyTypeHintCreatesOccurrence | Verifies typed properties create reference occurrences |
| testInterfaceTypeHintCreatesOccurrence | Verifies interface type hints create reference occurrences |
| testParameterTypeHintCreatesOccurrence | Verifies method parameter type hints create reference occurrences |
| testReturnTypeHintCreatesOccurrence | Verifies method return type hints create reference occurrences |
| testMultipleTypeHintsInSameMethod | Verifies both parameter and return types create separate occurrences |
| testNullableTypeHintCreatesOccurrence | Verifies nullable return types create reference occurrences |

### tests/Scip/Inheritance/InheritanceTest.php (5 tests)
| Test | Description |
|------|-------------|
| testClassImplementsInterfaceCreatesRelationship | EmailSender has implementation relationship to EmailSenderInterface |
| testInventoryCheckerImplementsInterface | InventoryChecker has implementation relationship |
| testAllImplementingClassesHaveRelationships | All implementing classes have proper relationships |
| testInterfaceSymbolsExist | EmailSenderInterface and InventoryCheckerInterface have symbols |
| testInterfaceHasDefinitionOccurrence | Interfaces have definition occurrences |

### tests/Scip/Symbol/SymbolTest.php (7 tests)
| Test | Description |
|------|-------------|
| testClassDefinitionOccurrenceExists | Order class symbol has definition occurrence |
| testMethodDefinitionOccurrenceExists | Order.getCustomerName() has definition occurrence |
| testPropertyDefinitionOccurrenceExists | Order.$customerEmail has definition occurrence |
| testInterfaceMethodDefinitionExists | EmailSenderInterface.send() has definition occurrence |
| testAllClassesHaveDefinitionOccurrences | Every class symbol has at least one definition |
| testSymbolCountIsReasonable | SCIP index has expected symbol count |
| testConstructorDefinitionExists | Class constructors have definition occurrences |

### tests/Scip/Occurrence/OccurrenceTest.php (8 tests)
| Test | Description |
|------|-------------|
| testEverySymbolHasOccurrence | Every symbol has at least one occurrence |
| testDefinitionOccurrenceHasCorrectLocation | Order class definition is in correct file |
| testReferencesTrackedAcrossFiles | Order class has references in multiple files |
| testMethodCallCreatesReferenceOccurrence | Method calls create reference occurrences |
| testPropertyAccessCreatesReferenceOccurrence | Property accesses create reference occurrences |
| testOccurrenceRolesAreCorrect | Definition and reference roles are correct |
| testConstructorCallCreatesReference | new Order() creates reference occurrence |
| testOccurrenceFilePathsAreConsistent | All occurrences have valid file paths |

### tests/Combined/Consistency/ConsistencyTest.php (6 tests)
| Test | Description |
|------|-------------|
| testMethodCallsHaveScipOccurrences | Method calls in calls.json have SCIP occurrences |
| testPropertyAccessesHaveScipOccurrences | Property accesses in calls.json have SCIP occurrences |
| testConstructorCallsHaveBothEntries | new Order() in both calls.json and SCIP |
| testSymbolFormatsAreCompatible | Symbol formats between calls.json and SCIP are compatible |
| testTypesCorrespondToScipSymbols | Value types reference valid SCIP symbols |
| testSourceFilesAreConsistentlyIndexed | Same files indexed in both outputs |

## Skipped Tests (15)
All skipped tests are experimental tests requiring `--experimental` flag:
- Array access tests (access_array kind)
- Function call tests (function kind)
- Coalesce/Ternary/Match operator tests
