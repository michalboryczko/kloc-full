# Initialization Status: SCIP Index Contract Tests

## Generated: 2026-02-04

## Summary
- **Passed**: 146
- **Failed**: 0
- **Skipped**: 15
- **Error**: 0
- **Total**: 161

## Status: PASS

All existing contract tests pass. Safe to proceed with adding new SCIP tests.

## Existing Test Categories

| Category | Count |
|----------|-------|
| argument | 14 |
| callkind | 32 |
| chain | 35 |
| integrity | 10 |
| operator | 6 |
| reference | 19 |
| schema | 2 |
| smoke | 8 |
| valuekind | 20 |

## Skipped Tests (15)
All skipped tests are experimental tests requiring `--experimental` flag:
- Array access tests (access_array kind)
- Function call tests (function kind)
- Coalesce/Ternary/Match operator tests

## Existing Test Files
- tests/Argument/ArgumentBindingTest.php
- tests/Argument/ArgumentSchemaTest.php
- tests/CallKind/CallKindTest.php
- tests/CallKind/ExperimentalKindTest.php
- tests/CallKind/NullsafeKindTest.php
- tests/Chain/ChainIntegrityTest.php
- tests/Chain/NestedChainTest.php
- tests/Integrity/DataIntegrityTest.php
- tests/Operator/OperatorTest.php
- tests/Reference/OneValuePerDeclarationTest.php
- tests/Reference/ParameterReferenceTest.php
- tests/Schema/SchemaValidationTest.php
- tests/SmokeTest.php
- tests/UsageFlow/UsageFlowTrackingTest.php
- tests/ValueKind/ValueKindTest.php
