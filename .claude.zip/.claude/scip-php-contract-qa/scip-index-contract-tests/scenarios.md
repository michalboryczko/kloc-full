# Contract Test Scenarios: SCIP Index Validation

## Context
Create contract tests for validating SCIP index output. The SCIP index contains symbols (classes, methods, properties) and occurrences (definitions, references, type hints). These tests validate that the scip-php indexer correctly generates SCIP data that can be cross-validated with calls.json.

## Reference Code

### Type Hints
File: `kloc-reference-project-php/src/Service/OrderService.php`
```php
// Lines 19-24: Constructor with typed parameters
public function __construct(
    private OrderRepository $orderRepository,          // Property type hint
    private EmailSenderInterface $emailSender,         // Interface type hint
    private InventoryCheckerInterface $inventoryChecker,
    private MessageBusInterface $messageBus,
)

// Line 27: Return type hint
public function createOrder(CreateOrderInput $input): OrderOutput

// Line 26: Parameter type hint
public function save(Order $order): Order
```

### Inheritance/Implements
File: `kloc-reference-project-php/src/Component/EmailSender.php`
```php
// Line 7: implements relationship
final class EmailSender implements EmailSenderInterface
```

File: `kloc-reference-project-php/src/Component/InventoryChecker.php`
```php
// Line 7: implements relationship
final class InventoryChecker implements InventoryCheckerInterface
```

### Class and Method Definitions
File: `kloc-reference-project-php/src/Entity/Order.php`
```php
// Line 9: Class definition
final readonly class Order

// Lines 11-18: Constructor and properties
public function __construct(
    public int $id,
    public string $customerEmail,
    ...
)

// Line 25: Method definition
public function getCustomerName(): string
```

---

## Scenarios

### Category: SCIP Type Hints (tests/Scip/TypeHint/)

#### Scenario TH-1: Property Type Hint Creates Reference Occurrence
WHEN indexing `OrderService.__construct().($orderRepository)` typed as `OrderRepository`
THEN SCIP contains a reference occurrence for the `OrderRepository` class symbol at the type hint location

**Reference**: src/Service/OrderService.php:20 - `private OrderRepository $orderRepository`

#### Scenario TH-2: Interface Type Hint Creates Reference Occurrence
WHEN indexing `OrderService.__construct().($emailSender)` typed as `EmailSenderInterface`
THEN SCIP contains a reference occurrence for the `EmailSenderInterface` symbol at the type hint location

**Reference**: src/Service/OrderService.php:21 - `private EmailSenderInterface $emailSender`

#### Scenario TH-3: Parameter Type Hint Creates Reference Occurrence
WHEN indexing `OrderRepository.save().($order)` typed as `Order`
THEN SCIP contains a reference occurrence for the `Order` class symbol at the parameter type hint

**Reference**: src/Repository/OrderRepository.php:26 - `public function save(Order $order): Order`

#### Scenario TH-4: Return Type Hint Creates Reference Occurrence
WHEN indexing `OrderRepository.save()` with return type `Order`
THEN SCIP contains a reference occurrence for the `Order` class symbol at the return type hint

**Reference**: src/Repository/OrderRepository.php:26 - `public function save(Order $order): Order`

#### Scenario TH-5: Multiple Type Hints in Same Method
WHEN indexing `OrderService.createOrder()` with parameter `CreateOrderInput` and return `OrderOutput`
THEN SCIP contains:
  - Reference occurrence for `CreateOrderInput` at parameter position
  - Reference occurrence for `OrderOutput` at return type position

**Reference**: src/Service/OrderService.php:27 - `public function createOrder(CreateOrderInput $input): OrderOutput`

---

### Category: SCIP Inheritance (tests/Scip/Inheritance/)

#### Scenario IN-1: Class Implements Interface Creates Relationship
WHEN indexing `EmailSender` class that implements `EmailSenderInterface`
THEN SCIP symbol for `EmailSender` has relationship with kind=implementation to `EmailSenderInterface`

**Reference**: src/Component/EmailSender.php:7 - `final class EmailSender implements EmailSenderInterface`

#### Scenario IN-2: Multiple Interface Implementations
WHEN indexing project with multiple classes implementing interfaces
THEN each implementing class has relationship with kind=implementation pointing to its interface

**Reference**: EmailSender -> EmailSenderInterface, InventoryChecker -> InventoryCheckerInterface

#### Scenario IN-3: Interface Symbol Has Implementation Relationships
WHEN querying relationships for `EmailSenderInterface`
THEN the interface symbol has references from implementing classes

**Reference**: src/Component/EmailSenderInterface.php

---

### Category: SCIP Symbol Definitions (tests/Scip/Symbol/)

#### Scenario SY-1: Class Definition Occurrence Exists
WHEN indexing the `Order` class
THEN SCIP contains a definition occurrence for `Order#` symbol with role=Definition

**Reference**: src/Entity/Order.php:9 - `final readonly class Order`

#### Scenario SY-2: Method Definition Occurrence Exists
WHEN indexing the `getCustomerName` method in `Order` class
THEN SCIP contains a definition occurrence for `Order#getCustomerName().` symbol with role=Definition

**Reference**: src/Entity/Order.php:25 - `public function getCustomerName(): string`

#### Scenario SY-3: Property Definition Occurrence Exists
WHEN indexing the `customerEmail` property in `Order` class
THEN SCIP contains a definition occurrence for `Order#$customerEmail.` symbol with role=Definition

**Reference**: src/Entity/Order.php:13 - `public string $customerEmail`

#### Scenario SY-4: Interface Method Definition
WHEN indexing the `send` method in `EmailSenderInterface`
THEN SCIP contains a definition occurrence for `EmailSenderInterface#send().` symbol

**Reference**: src/Component/EmailSenderInterface.php:9

#### Scenario SY-5: All Classes Have Definition Occurrences
WHEN indexing the entire project
THEN every class symbol (ending with `#`) has at least one definition occurrence

---

### Category: SCIP Occurrences (tests/Scip/Occurrence/)

#### Scenario OC-1: Every Symbol Has At Least One Occurrence
WHEN indexing the project
THEN every symbol in the SCIP index has at least one occurrence (definition or reference)

#### Scenario OC-2: Definition Occurrences Have Correct Location
WHEN indexing `Order` class definition
THEN the definition occurrence is at line 9 of src/Entity/Order.php

**Reference**: src/Entity/Order.php:9

#### Scenario OC-3: Reference Occurrences Track Type Usage
WHEN indexing usages of `Order` class
THEN reference occurrences exist at:
  - Type hints in method parameters
  - Type hints in return types
  - Type hints in property declarations
  - new Order() constructor calls

#### Scenario OC-4: Method Call Creates Reference Occurrence
WHEN indexing `$this->orderRepository->save($order)` call
THEN SCIP contains a reference occurrence for `OrderRepository#save().` at the call location

**Reference**: src/Service/OrderService.php:40

#### Scenario OC-5: Property Access Creates Reference Occurrence
WHEN indexing `$savedOrder->customerEmail` property access
THEN SCIP contains a reference occurrence for `Order#$customerEmail.` at the access location

**Reference**: src/Service/OrderService.php:43

---

### Category: Combined SCIP + calls.json Consistency (tests/Combined/Consistency/)

#### Scenario CO-1: Method Calls in calls.json Have SCIP Occurrences
WHEN indexing a method call that exists in calls.json
THEN a corresponding SCIP reference occurrence exists for the method symbol

**Verification**: For each `kind=method` call in calls.json, find matching SCIP occurrence

#### Scenario CO-2: Property Accesses in calls.json Have SCIP Occurrences
WHEN indexing a property access that exists in calls.json
THEN a corresponding SCIP reference occurrence exists for the property symbol

**Verification**: For each `kind=access` call in calls.json, find matching SCIP occurrence

#### Scenario CO-3: SCIP Symbols Match calls.json Callee Symbols
WHEN comparing method call callee symbols between calls.json and SCIP
THEN the symbol formats are compatible (after normalization)

**Example**: calls.json callee `App/Repository/OrderRepository#save().` should match SCIP symbol

#### Scenario CO-4: Constructor Calls Have Both SCIP and calls.json Entries
WHEN indexing `new Order(...)` constructor call
THEN:
  - calls.json contains a call with kind=constructor
  - SCIP contains a reference occurrence for Order class

**Reference**: src/Service/OrderService.php:31 - `$order = new Order(...)`

#### Scenario CO-5: Type Consistency Between SCIP and calls.json
WHEN a value in calls.json has a type field
THEN that type corresponds to a valid SCIP symbol

---

## Implementation Notes

1. **SCIP Query API**: Use `$this->scip()` to access ScipQuery, `$this->requireScipData()` to skip if no SCIP data

2. **Symbol Format**: SCIP uses `scip-php composer . App/Service/OrderService#createOrder().` format
   - Classes end with `#`
   - Methods end with `().`
   - Properties have `$` prefix: `#$propertyName.`

3. **Occurrence Roles**: Use `isDefinition()` and `isReference()` filters
   - Role bit 1 = Definition
   - Role bit 0 (no definition) = Reference

4. **Cross-validation**: Compare calls.json entries with SCIP occurrences using line numbers and symbol patterns

5. **Test Categories**: Use `category: 'scip'` for SCIP-only tests, `category: 'combined'` for cross-validation tests
