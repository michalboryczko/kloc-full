# Validation Report: finish-mvp

**Date**: 2026-02-01
**Mode**: VALIDATE
**Previous State**: 97 pass, 3 fail, 5 skip (after setup)
**Current State**: 104 pass, 1 fail, 1 skip

## Summary

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Total Tests | 106 | 106 | 0 |
| Passing | 97 | 104 | +7 |
| Failing | 3 | 1 | -2 |
| Skipped | 5 | 1 | -4 |
| Risky | 1 | 0 | -1 |

## Changes Since Last Run

### Fixed (previously failing, now passing)

| Test | Issue Fixed |
|------|-------------|
| `testNullCoalesceOperatorKindExists` | Field names now match schema (`left_value_id`, `right_value_id`) |
| `testFullTernaryHasAllOperandIds` | Added `condition_value_id`, renamed `true_id`/`false_id` to schema names |
| `testShortTernaryHasConditionId` | Added `condition_value_id` for ternary |

### No Longer Skipped (now passing)

| Test | Feature Implemented |
|------|---------------------|
| `testArrayAccessKindExists` | `access_array` tracking implemented |
| `testArrayAccessOnOrdersTracked` | `access_array` tracking implemented |
| `testMatchExpressionKindExists` | `match` expression tracking implemented |
| `testMatchExpressionArmsReferenceValues` | `match` arm_ids tracking implemented |

### Still Failing (1)

| Test | Reason | Verdict |
|------|--------|---------|
| `testOrderRepositorySaveAllAccessesShareReceiver` | Test logic flaw, not indexer bug | TEST_ISSUE |

**Analysis of failing test:**

The test checks that "all Order property accesses have the same receiver_value_id". It matches calls with `calleeContains('Order#')`, which includes:
- `$order->customerEmail` (lines 31-35) - CORRECTLY uses `$order` parameter as receiver
- `$newOrder->id` (line 37) - CORRECTLY uses `$newOrder` local variable as receiver

The test expects ALL Order property accesses to reference `$order`, but `$newOrder->id` is a different variable. The indexer is **correct** - `$newOrder` is a separate local variable assigned at line 29, so its property access should NOT have the same receiver as `$order`.

**Recommendation**: The test should be modified to only match property accesses where the receiver symbol contains `$order`, not all Order property accesses.

### Still Skipped (1)

| Test | Reason | Action Needed |
|------|--------|---------------|
| `testNullsafeMethodCallKind` | No nullsafe METHOD calls in reference code | Add reference code |

**Analysis**: The reference project has nullsafe property accesses (`$order?->status`) but no nullsafe method calls (`$obj?->method()`). This requires adding a method to Order entity and calling it with `?->`.

## Feature Implementation Status

| Feature | Call Kind | Status | Notes |
|---------|-----------|--------|-------|
| Static Method Calls | `method_static` | PASS | Working |
| Static Property Access | `access_static` | PASS | Working |
| Array Access | `access_array` | PASS | **NEW** - Now working |
| Nullsafe Method Calls | `method_nullsafe` | SKIP | No reference code |
| Nullsafe Property Access | `access_nullsafe` | PASS | Working |
| Null Coalesce | `coalesce` | PASS | **FIXED** - Field names |
| Short Ternary | `ternary` | PASS | **FIXED** - condition_value_id |
| Full Ternary | `ternary_full` | PASS | **FIXED** - condition_value_id |
| Match Expression | `match` | PASS | **NEW** - Now working |

## Verdict

### PASS

The implementation is successful:
- **8 of 9 features fully working** (all pass tests)
- **1 feature missing reference code** (`method_nullsafe` - test skips)
- **1 test failing due to test logic issue** (not an indexer bug)

### Scoring

| Category | Score |
|----------|-------|
| Schema Compliance | 100% (all field names correct) |
| Feature Coverage | 89% (8/9 features) |
| Test Pass Rate | 98% (104/106) |
| **Overall** | **PASS** |

## Remaining Work

### Priority 1: Fix Test Logic (Optional)
- File: `tests/Reference/OneValuePerDeclarationTest.php`
- Method: `testOrderRepositorySaveAllAccessesShareReceiver`
- Issue: Test matches `$newOrder->id` which correctly has different receiver
- Fix: Filter to only property accesses where receiver symbol contains `$order`

### Priority 2: Add Nullsafe Method Reference Code (Optional)
To make `testNullsafeMethodCallKind` pass:
1. Add a method to Order entity: `public function getStatusLabel(): string`
2. Call it with nullsafe: `$order?->getStatusLabel()`

## Implementation Summary

The implementer successfully:
1. Fixed all schema field name mismatches (`*_id` -> `*_value_id`)
2. Added `condition_value_id` to ternary operations
3. Implemented `access_array` tracking for ArrayDimFetch
4. Implemented `match` expression tracking with `subject_value_id` and `arm_ids`
5. Ensured all operator calls have `kind_type: "operator"`

All critical features for the finish-mvp milestone are working correctly.
