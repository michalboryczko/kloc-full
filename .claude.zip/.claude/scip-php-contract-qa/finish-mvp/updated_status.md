# Contract Tests Documentation
Generated: 2026-02-02 01:08:01
## Summary
| Status | Count |
|--------|-------|
| ✅ Passed | 124 |
| ❌ Failed | 18 |
| ⏭️ Skipped | 0 |
| 💥 Error | 0 |
| **Total** | **142** |
## Argument Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | Argument Parameter Symbol Present | Verifies arguments have parameter symbol linking to the callee parameter definition. | `ContractTests\Tests\Argument\ArgumentBindingTest::testArgumentParameterSymbolPresent` |
| ✅ | Argument value_expr for Complex Expressions | Verifies arguments with complex expressions (like self::$nextId++) have value_expr when value_id is null. | `ContractTests\Tests\Argument\ArgumentBindingTest::testArgumentValueExprForComplexExpressions` |
| ✅ | Order Constructor Arguments | Order constructor receives correct argument types (literal, result) | `ContractTests\Tests\Argument\ArgumentBindingTest::testOrderConstructorArguments` |
| ✅ | OrderRepository Constructor in save() | Order constructor in save() receives property access results from $order | `ContractTests\Tests\Argument\ArgumentBindingTest::testOrderRepositoryConstructorArguments` |
| ✅ | checkAvailability() Receives Property Access Results | InventoryChecker receives $input property values as arguments | `ContractTests\Tests\Argument\ArgumentBindingTest::testInventoryCheckerArguments` |
| ✅ | dispatch() Receives Constructor Result | MessageBus dispatch() receives OrderCreatedMessage constructor result | `ContractTests\Tests\Argument\ArgumentBindingTest::testMessageBusDispatchArgument` |
| ✅ | findById() Receives $orderId Parameter | Argument 0 of findById() points to $orderId parameter | `ContractTests\Tests\Argument\ArgumentBindingTest::testFindByIdArgumentPointsToParameter` |
| ✅ | save() Receives $order Local | Argument 0 of save() points to $order local variable | `ContractTests\Tests\Argument\ArgumentBindingTest::testSaveArgumentPointsToOrderLocal` |
| ✅ | send() Receives customerEmail Access Result | First argument of send() points to customerEmail property access result | `ContractTests\Tests\Argument\ArgumentBindingTest::testEmailSenderReceivesCustomerEmail` |
## Callkind Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | All Invocation Kinds Have Arguments | Verifies all calls with kind_type=invocation have an arguments array (may be empty). | `ContractTests\Tests\CallKind\CallKindTest::testAllInvocationKindsHaveArguments` |
| ✅ | Array Access Kind | Verifies array access is tracked with kind=access_array. Example: self::$orders[$id]. Per schema: $arr['key'] | `ContractTests\Tests\CallKind\CallKindTest::testArrayAccessKindExists` |
| ✅ | Array Access on self::$orders Tracked | Verifies self::$orders[$id] array access is tracked as kind=access_array with key_value_id. | `ContractTests\Tests\CallKind\CallKindTest::testArrayAccessOnOrdersTracked` |
| ✅ | Constructor Call Kind Exists | Verifies index contains constructor calls (kind=constructor). Example: new Order(). Per schema: new Foo() | `ContractTests\Tests\CallKind\CallKindTest::testConstructorCallKindExists` |
| ✅ | Function Call Kind | Verifies function calls are tracked with kind=function. Example: sprintf(). Per schema: func() | `ContractTests\Tests\CallKind\CallKindTest::testFunctionCallKindExists` |
| ✅ | Instance Methods Have Receiver When Applicable | Verifies most instance method calls have receiver_value_id. Some calls on $this in child classes may not have it tracked. | `ContractTests\Tests\CallKind\CallKindTest::testInstanceMethodsHaveReceiver` |
| ✅ | Method Call Kind Exists | Verifies index contains instance method calls (kind=method). Example: $this->orderRepository->save(). Per schema: $obj->method() | `ContractTests\Tests\CallKind\CallKindTest::testMethodCallKindExists` |
| ❌ | Nullsafe Boolean Method Has Union Return Type | Verifies nullsafe method call returning bool ($order?->isPending()) has union return_type "null|bool". | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeBooleanMethodHasUnionReturnType` |
| ❌ | Nullsafe Method Call Has Union Return Type | Verifies nullsafe method call ($order?->getCustomerName()) has union return_type containing null. For method returning string, should be "null|string" union. | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeMethodCallHasUnionReturnType` |
| ✅ | Nullsafe Method Call Kind | Verifies nullsafe method calls are tracked with kind=method_nullsafe. Example: $obj?->method(). Per schema. | `ContractTests\Tests\CallKind\CallKindTest::testNullsafeMethodCallKind` |
| ❌ | Nullsafe Method Call Uses kind=method | Verifies nullsafe method call ($order?->getCustomerName()) uses kind="method" not "method_nullsafe". Per finish-mvp spec, nullsafe semantics are captured via union return type. | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeMethodCallUsesMethodKind` |
| ❌ | Nullsafe Property Access Has Union Return Type | Verifies nullsafe property access ($order?->status) has union return_type containing null. For string property, should be "null|string" union. | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafePropertyAccessHasUnionReturnType` |
| ✅ | Nullsafe Property Access Kind | Verifies nullsafe property access is tracked with kind=access_nullsafe. Example: $obj?->property. Per schema. | `ContractTests\Tests\CallKind\CallKindTest::testNullsafePropertyAccessKind` |
| ❌ | Nullsafe Property Access Uses kind=access | Verifies nullsafe property access ($order?->status) uses kind="access" not "access_nullsafe". Per finish-mvp spec, nullsafe semantics are captured via union return type. | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafePropertyAccessUsesAccessKind` |
| ✅ | Order Constructor Call Tracked | Verifies new Order(...) constructor call is tracked as kind=constructor with arguments. | `ContractTests\Tests\CallKind\CallKindTest::testOrderConstructorCallTracked` |
| ✅ | OrderRepository save() Call Tracked | Verifies the $this->orderRepository->save($order) call is tracked as kind=method with correct callee. | `ContractTests\Tests\CallKind\CallKindTest::testOrderRepositorySaveCallTracked` |
| ✅ | Property Access Has Receiver When Applicable | Verifies most property access calls have receiver_value_id. $this->property in readonly classes may be handled differently. | `ContractTests\Tests\CallKind\CallKindTest::testPropertyAccessHasReceiver` |
| ✅ | Property Access Kind Exists | Verifies property access is tracked with kind=access. Example: $order->customerEmail. Per schema: $obj->property | `ContractTests\Tests\CallKind\CallKindTest::testPropertyAccessKindExists` |
| ✅ | Property Access on $order Tracked | Verifies $order->customerEmail property access is tracked as kind=access. | `ContractTests\Tests\CallKind\CallKindTest::testPropertyAccessOnOrderTracked` |
| ✅ | Static Method Call Kind | Verifies static method calls are tracked with kind=method_static. Example: self::$nextId++. Per schema: Foo::method() | `ContractTests\Tests\CallKind\CallKindTest::testStaticMethodCallKindExists` |
| ✅ | Static Property Access Kind | Verifies static property access is tracked with kind=access_static. Example: self::$orders. Per schema: Foo::$property | `ContractTests\Tests\CallKind\CallKindTest::testStaticPropertyAccessKindExists` |
| ✅ | sprintf Function Call Tracked | Verifies sprintf() function call is tracked as kind=function. | `ContractTests\Tests\CallKind\CallKindTest::testSprintfFunctionCallTracked` |
## Chain Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | All Chains Terminate at Valid Source | Verifies tracing any chain backwards terminates at a parameter, local, literal, or constant (not orphaned). | `ContractTests\Tests\Chain\ChainIntegrityTest::testAllChainsTerminateAtValidSource` |
| ✅ | Argument Value IDs Point to Values | Verifies every argument value_id points to an existing value entry (never a call). Per schema: argument value_id MUST reference a value. | `ContractTests\Tests\Chain\ChainIntegrityTest::testArgumentValueIdsPointToValues` |
| ✅ | Contact and Address Accesses Share Customer Receiver | Verifies that $customer->contact and $customer->address property accesses both have the same receiver_value_id (the $customer local variable). | `ContractTests\Tests\Chain\NestedChainTest::testContactAndAddressAccessesShareCustomerReceiver` |
| ✅ | Deep Chain Walk from Response to Entity | Verifies complete chain integrity: walks the full chain from a nested property access backwards through all receivers to the original source, verifying each link exists. | `ContractTests\Tests\Chain\NestedChainTest::testDeepChainWalkFromResponseToEntity` |
| ✅ | Direct Nested Access in Constructor Arguments | Verifies that getCustomerDetails with direct nested access in constructor (email: $customer->contact->email) correctly tracks the chain. | `ContractTests\Tests\Chain\NestedChainTest::testDirectNestedAccessInConstructorArguments` |
| ✅ | Every Call Has Corresponding Result Value | Verifies each call has a result value with the same ID in the values array. Per schema: calls and result values share the same ID. | `ContractTests\Tests\Chain\ChainIntegrityTest::testEveryCallHasResultValue` |
| ✅ | Full Flow: Controller Response to Entity Property | Verifies the complete data flow from CustomerController creating CustomerResponse, through CustomerService returning CustomerOutput, back to the Entity nested properties. Tests that $output->street in Controller traces to CustomerOutput, which traces to $street local in Service, which traces to $customer->address->street. | `ContractTests\Tests\Chain\NestedChainTest::testFullFlowControllerToEntity` |
| ✅ | Full Flow: Service Output to Entity Nested Chain | Verifies that CustomerOutput properties in Service can be traced back through nested entity access chains: $output.street <- $street local <- $customer->address->street <- $customer local <- repository call. | `ContractTests\Tests\Chain\NestedChainTest::testFullFlowServiceOutputToEntityChain` |
| ✅ | Method Call on Address Nested Object | Verifies $customer->address->getFullAddress() has correct chain structure. | `ContractTests\Tests\Chain\NestedChainTest::testMethodCallOnAddressNestedObject` |
| ✅ | Method Call on Nested Object Result | Verifies $customer->contact->getFormattedEmail() has correct chain: getFormattedEmail() receiver points to contact access result, contact access receiver points to $customer. | `ContractTests\Tests\Chain\NestedChainTest::testMethodCallOnNestedObjectResult` |
| ✅ | Method Chain $this->orderRepository->save() | Verifies the chain $this->orderRepository->save() is traceable: $this (value) -> orderRepository (access) -> result (value) -> save (method) -> result (value). | `ContractTests\Tests\Chain\ChainIntegrityTest::testMethodChainOrderRepositorySave` |
| ✅ | Multi-Step Chain findById()->customerEmail | Verifies multi-step chain: findById() returns Order, then access customerEmail property. | `ContractTests\Tests\Chain\ChainIntegrityTest::testMultiStepChainFindByIdCustomerEmail` |
| ✅ | Multiple Chains in Same Expression Share Receivers | Verifies that in getCustomerSummary, both $customer->contact->email and $customer->address->city share the same $customer receiver. | `ContractTests\Tests\Chain\NestedChainTest::testMultipleChainsInSameExpressionShareReceivers` |
| ❌ | Multiple Nullsafe Accesses Share Receiver | Verifies multiple nullsafe property accesses on same variable share the same receiver_value_id. In getOrderSummary(): $order?->id, $order?->customerEmail, $order?->status should all point to same $order value. | `ContractTests\Tests\CallKind\NullsafeKindTest::testMultipleNullsafeAccessesShareReceiver` |
| ✅ | Nested Address Property Accesses Share Receiver | Verifies $customer->address->street and $customer->address->city both have the same receiver_value_id for the address access. | `ContractTests\Tests\Chain\NestedChainTest::testNestedAddressPropertyAccessesShareReceiver` |
| ✅ | Nested Contact Property Accesses Share Receiver | Verifies $customer->contact->email and $customer->contact->phone both have the same receiver_value_id for the contact access (pointing to the result of $customer->contact). | `ContractTests\Tests\Chain\NestedChainTest::testNestedContactPropertyAccessesShareReceiver` |
| ✅ | No Orphaned References in Nested Chains | Verifies that all receiver_value_id and source_call_id references in CustomerService nested chains point to existing entries. | `ContractTests\Tests\Chain\NestedChainTest::testNoOrphanedReferencesInNestedChains` |
| ❌ | Nullsafe Access Has Receiver Value | Verifies nullsafe property access has receiver_value_id pointing to a valid value in the values array. | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeAccessHasReceiverValue` |
| ✅ | Nullsafe Access Result Value Exists | Verifies nullsafe property access creates a result value with source_call_id pointing to the access call. | `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeAccessResultValueExists` |
| ✅ | Property Access Chain $order->customerEmail | Verifies property access chains correctly: value (parameter/local) -> access (call) -> result (value). | `ContractTests\Tests\Chain\ChainIntegrityTest::testPropertyAccessChain` |
| ✅ | Receiver Value IDs Point to Values | Verifies every call receiver_value_id points to an existing value entry (never a call). Per schema: receiver_value_id MUST reference a value. | `ContractTests\Tests\Chain\ChainIntegrityTest::testReceiverValueIdsPointToValues` |
| ✅ | Result Values Are Kind Result | Verifies values corresponding to calls have kind=result (not parameter, local, etc.). | `ContractTests\Tests\Chain\ChainIntegrityTest::testResultValuesAreKindResult` |
| ✅ | Result Values Point Back to Source Call | Verifies every result value source_call_id equals its own id (pointing to the call that produced it). | `ContractTests\Tests\Chain\ChainIntegrityTest::testResultValuesPointBackToSourceCall` |
| ✅ | Value Flow from Entity to Service DTO | Verifies we can trace the value of $street from CustomerOutput constructor argument back through the chain: argument -> $street local -> address->street access -> address access -> $customer. | `ContractTests\Tests\Chain\NestedChainTest::testValueFlowFromEntityToResponse` |
## Integrity Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | All Argument value_ids Point to Values | Verifies every argument value_id references an existing value entry in the values array. This ensures type lookup is possible. | `ContractTests\Tests\Argument\ArgumentSchemaTest::testAllArgumentValueIdsPointToValues` |
| ✅ | Argument IDs Exist | Verifies every argument value_id references an existing value entry. Orphaned references indicate missing value entries for argument sources. | `ContractTests\Tests\Integrity\DataIntegrityTest::testAllArgumentIdsExist` |
| ✅ | Every Call Has Result Value | Verifies each call has a corresponding result value with the same ID. Missing result values break chain integrity as subsequent calls cannot reference the result. | `ContractTests\Tests\Integrity\DataIntegrityTest::testEveryCallHasResultValue` |
| ✅ | Full Integrity Report | Generates a complete integrity report counting all issue types: duplicate symbols, orphaned references, missing result values, type mismatches. Outputs summary to stderr for debugging. | `ContractTests\Tests\Integrity\DataIntegrityTest::testFullIntegrityReport` |
| ✅ | Receiver IDs Exist | Verifies every call receiver_value_id references an existing value entry. Orphaned references indicate missing value entries in the index. | `ContractTests\Tests\Integrity\DataIntegrityTest::testAllReceiverIdsExist` |
| ✅ | Result Types Match | Verifies result value type field matches the return_type of their source call. Type mismatches indicate incorrect type inference in the indexer. | `ContractTests\Tests\Integrity\DataIntegrityTest::testResultTypesMatch` |
| ✅ | Source Call IDs Exist | Verifies every value source_call_id references an existing call entry. Result values must point to the call that produced them. | `ContractTests\Tests\Integrity\DataIntegrityTest::testAllSourceCallIdsExist` |
| ✅ | Source Value IDs Exist | Verifies every value source_value_id references an existing value entry. Used for assignment tracking where a value derives from another value. | `ContractTests\Tests\Integrity\DataIntegrityTest::testAllSourceValueIdsExist` |
| ✅ | Type Lookup Via value_id Works | Verifies that for arguments with value_id, the type can be looked up via values[value_id].type. This is the replacement for the removed value_type field. | `ContractTests\Tests\Argument\ArgumentSchemaTest::testTypeLookupViaValueIdWorks` |
## Operator Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | All Operators Have Kind Type Operator | Verifies all operator kinds (coalesce, ternary, ternary_full, match) have kind_type=operator. | `ContractTests\Tests\Operator\OperatorTest::testAllOperatorsHaveKindTypeOperator` |
| ✅ | Coalesce Operands Reference Values | Verifies coalesce left_value_id and right_value_id point to existing values in the values array. | `ContractTests\Tests\Operator\OperatorTest::testCoalesceOperandsReferenceValues` |
| ✅ | Full Ternary Has All Operand IDs | Verifies full ternary ($a ? $b : $c) has condition_value_id, true_value_id, and false_value_id. | `ContractTests\Tests\Operator\OperatorTest::testFullTernaryHasAllOperandIds` |
| ✅ | Match Expression Arms Reference Values | Verifies match expression arm_ids array contains valid value references for each arm result. | `ContractTests\Tests\Operator\OperatorTest::testMatchExpressionArmsReferenceValues` |
| ✅ | Match Expression Kind Exists | Verifies match expressions are tracked with kind=match, kind_type=operator, subject_value_id, and arm_ids. | `ContractTests\Tests\Operator\OperatorTest::testMatchExpressionKindExists` |
| ✅ | Null Coalesce Operator Kind Exists | Verifies null coalesce operators ($a ?? $b) are tracked with kind=coalesce, kind_type=operator, left_value_id, right_value_id. | `ContractTests\Tests\Operator\OperatorTest::testNullCoalesceOperatorKindExists` |
| ✅ | Operators Have Result Values | Verifies operator calls have corresponding result values for data flow tracking. | `ContractTests\Tests\Operator\OperatorTest::testOperatorsHaveResultValues` |
| ✅ | Short Ternary Has Condition ID | Verifies short ternary ($a ?: $b) has condition_value_id. True value is the condition itself. | `ContractTests\Tests\Operator\OperatorTest::testShortTernaryHasConditionId` |
| ✅ | Ternary Operator Kind Exists | Verifies ternary operators ($a ? $b : $c) are tracked with kind=ternary_full, kind_type=operator, and operand IDs. | `ContractTests\Tests\Operator\OperatorTest::testTernaryOperatorKindExists` |
## Reference Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | NotificationService::notifyOrderCreated() $order - Single Value Entry | Verifies $order local has exactly ONE value entry at assignment (line 20), not entries for each of its 6 usages (lines 22, 27-34). | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testNotificationServiceOrderLocalSingleEntry` |
| ✅ | NotificationService::notifyOrderCreated() $orderId | Verifies $orderId parameter in notifyOrderCreated() has exactly one value entry and is correctly referenced when passed to findById() call. | `ContractTests\Tests\Reference\ParameterReferenceTest::testNotificationServiceOrderIdParameter` |
| ✅ | OrderRepository - No Duplicate Parameter Symbols | Verifies no parameter in OrderRepository has duplicate symbol entries (which would indicate values created at usage sites). | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderRepositoryNoDuplicateParameterSymbols` |
| ✅ | OrderRepository::save() $order - All Accesses Share Receiver | Verifies all 5 property accesses on $order (lines 31-35) have the same receiver_value_id pointing to the single parameter value at declaration. | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderRepositorySaveAllAccessesShareReceiver` |
| ✅ | OrderRepository::save() $order - Single Value Entry | Verifies $order parameter has exactly ONE value entry at declaration (line 26), not 8 entries for each usage. This is the key test for the "One Value Per Declaration Rule". | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderRepositorySaveOrderParameterSingleEntry` |
| ✅ | OrderRepository::save() - Property Access Chain on $order | Verifies the 5 consecutive property accesses on $order (customerEmail, productId, quantity, status, createdAt) all share the same receiver_value_id. | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderRepositoryPropertyAccessChainSharesReceiver` |
| ✅ | OrderRepository::save() - Receiver Points to Parameter | Verifies the shared receiver_value_id for $order property accesses points to a parameter value (kind=parameter), not a result or duplicate entry. | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderRepositoryReceiverPointsToParameter` |
| ✅ | OrderService Constructor Parameters | Verifies promoted constructor parameters ($orderRepository, $emailSender, $inventoryChecker, $messageBus) have no duplicate symbol entries. Readonly class promoted properties are handled specially by the indexer. | `ContractTests\Tests\Reference\ParameterReferenceTest::testOrderServiceConstructorParameters` |
| ✅ | OrderService::createOrder() $input - Single Value Entry | Verifies $input parameter has exactly ONE value entry at declaration, not 4 entries for each usage (lines 29, 33-35). | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderServiceCreateOrderInputParameterSingleEntry` |
| ✅ | OrderService::createOrder() $savedOrder - All Accesses Share Receiver | Verifies all property accesses on $savedOrder have the same receiver_value_id pointing to the single local value at assignment line 40. | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderServiceCreateOrderSavedOrderAllAccessesShareReceiver` |
| ✅ | OrderService::createOrder() $savedOrder - Single Value Entry | Verifies $savedOrder local has exactly ONE value entry at assignment (line 40), not multiple entries for each of its 8 usages. | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderServiceCreateOrderSavedOrderLocalSingleEntry` |
| ✅ | OrderService::createOrder() - No Duplicate Local Symbols | Verifies no local variable has duplicate symbol entries with the same @line suffix. | `ContractTests\Tests\Reference\OneValuePerDeclarationTest::testOrderServiceCreateOrderNoDuplicateLocalSymbols` |
| ✅ | OrderService::getOrder() $id | Verifies $id parameter in getOrder() has exactly one value entry. Per the spec, each parameter should have a single value entry at declaration, with all usages referencing that entry. | `ContractTests\Tests\Reference\ParameterReferenceTest::testOrderServiceGetOrderIdParameter` |
## Schema Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | All Arguments Have Position | Verifies every argument record has a position field. Per schema ArgumentRecord definition. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllArgumentsHavePosition` |
| ✅ | All Call IDs Follow Location Format | Verifies call IDs match LocationId pattern: {file}:{line}:{col}. Per schema LocationId definition. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllCallIdsFollowLocationFormat` |
| ✅ | All Call Kind Types Are Valid | Verifies every call kind_type is one of: invocation, access, operator. Per schema CallKindType enum. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllCallKindTypesAreValid` |
| ✅ | All Call Kinds Are Valid | Verifies every call kind is one of the defined enum values. Per schema CallKind enum. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllCallKindsAreValid` |
| ✅ | All Calls Have Required Fields | Verifies every call record has required fields: id, kind, kind_type, caller, location. Per schema CallRecord definition. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllCallsHaveRequiredFields` |
| ✅ | All Value IDs Follow Location Format | Verifies value IDs match LocationId pattern: {file}:{line}:{col}. Per schema LocationId definition. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllValueIdsFollowLocationFormat` |
| ✅ | All Value Kinds Are Valid | Verifies every value kind is one of: parameter, local, literal, constant, result. Per schema ValueKind enum. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllValueKindsAreValid` |
| ✅ | All Values Have Required Fields | Verifies every value record has required fields: id, kind, location. Per schema ValueRecord definition. | `ContractTests\Tests\Schema\SchemaValidationTest::testAllValuesHaveRequiredFields` |
| ❌ | Argument Fields Match Schema | Verifies argument records contain only the expected fields: position (required), parameter, value_id, value_expr. No extra fields allowed. | `ContractTests\Tests\Argument\ArgumentSchemaTest::testArgumentFieldsMatchSchema` |
| ✅ | Argument Positions Are Zero-Based | Verifies argument positions are 0-indexed and sequential for each call. | `ContractTests\Tests\Schema\SchemaValidationTest::testArgumentPositionsAreZeroBased` |
| ❌ | Arguments Have No value_type Field | Verifies argument records do NOT contain a value_type field. Per finish-mvp spec, consumers should use values[value_id].type instead. | `ContractTests\Tests\Argument\ArgumentSchemaTest::testArgumentsHaveNoValueTypeField` |
| ✅ | Call ID Matches Location | Verifies call ID is consistent with location (file:line:col format). | `ContractTests\Tests\Schema\SchemaValidationTest::testCallIdMatchesLocation` |
| ✅ | Call IDs Are Unique | Verifies all call IDs are unique within the calls array (no duplicates). | `ContractTests\Tests\Schema\SchemaValidationTest::testCallIdsAreUnique` |
| ✅ | Call Kind Type Matches Kind Category | Verifies kind_type correctly categorizes each kind. Methods/functions/constructors = invocation, property/array access = access, operators = operator. | `ContractTests\Tests\Schema\SchemaValidationTest::testCallKindTypeMatchesKindCategory` |
| ✅ | Calls Array Present and Non-Empty | Verifies calls array exists and contains entries. Required per schema. | `ContractTests\Tests\Schema\SchemaValidationTest::testCallsArrayPresentAndNonEmpty` |
| ✅ | Value ID Matches Location | Verifies value ID is consistent with location (file:line:col format). | `ContractTests\Tests\Schema\SchemaValidationTest::testValueIdMatchesLocation` |
| ✅ | Value IDs Are Unique | Verifies all value IDs are unique within the values array (no duplicates). | `ContractTests\Tests\Schema\SchemaValidationTest::testValueIdsAreUnique` |
| ✅ | Value Locations Have Required Fields | Verifies every value location has file, line, and col fields. Per schema Location definition. | `ContractTests\Tests\Schema\SchemaValidationTest::testValueLocationsHaveRequiredFields` |
| ✅ | Values Array Present and Non-Empty | Verifies values array exists and contains entries. Required per schema. | `ContractTests\Tests\Schema\SchemaValidationTest::testValuesArrayPresentAndNonEmpty` |
| ✅ | Version Format Valid | Verifies version field matches semver pattern (e.g., "3.2"). Schema requires pattern ^[0-9]+\.[0-9]+(\.[0-9]+)?$ | `ContractTests\Tests\Schema\SchemaValidationTest::testVersionFormatValid` |
## Smoke Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | Call Query Filters | Verifies CallQuery::kind() filter correctly returns only calls matching the specified kind (method) | `ContractTests\Tests\SmokeTest::testCallQueryFiltersWork` |
| ✅ | OrderRepository::save() $order Parameter | Critical acceptance test: Verifies $order parameter in OrderRepository::save() exists in index with kind=parameter, symbol containing ($order), and type containing Order | `ContractTests\Tests\SmokeTest::testOrderRepositorySaveParameterExists` |
| ✅ | Value Query Filters | Verifies ValueQuery::kind() filter correctly returns only values matching the specified kind (parameter) | `ContractTests\Tests\SmokeTest::testValueQueryFiltersWork` |
## Valuekind Tests
| Status | Test Name | Description | Code Ref |
|--------|-----------|-------------|----------|
| ✅ | Constant Values (If Present) | Verifies constant values have symbol, no source_call_id. Per schema: constant kind has symbol. | `ContractTests\Tests\ValueKind\ValueKindTest::testConstantValuesIfPresent` |
| ✅ | Literal Values Exist | Verifies index contains literal values (strings, integers, etc.). Per schema: literal kind, no symbol. | `ContractTests\Tests\ValueKind\ValueKindTest::testLiteralValuesExist` |
| ✅ | Literal Values No Source Call ID | Verifies literal values do not have source_call_id. Literals are not results of calls. | `ContractTests\Tests\ValueKind\ValueKindTest::testLiteralValuesNoSourceCallId` |
| ✅ | Literal Values No Symbol | Verifies literal values do not have a symbol field. Literals are anonymous values. | `ContractTests\Tests\ValueKind\ValueKindTest::testLiteralValuesNoSymbol` |
| ✅ | Local Symbol Format with @line | Verifies local symbols contain local$name@line pattern. Example: OrderService#createOrder().local$savedOrder@40 | `ContractTests\Tests\ValueKind\ValueKindTest::testLocalSymbolFormatWithLine` |
| ✅ | Local Values Have Symbol | Verifies all local values have a symbol field. Per schema: local kind has symbol with @line suffix. | `ContractTests\Tests\ValueKind\ValueKindTest::testLocalValuesHaveSymbol` |
| ✅ | Local Values Have Type From Source | Verifies local values inherit type from their source (call result or assigned value). | `ContractTests\Tests\ValueKind\ValueKindTest::testLocalValuesHaveTypeFromSource` |
| ✅ | Local Values May Have Source Call ID | Verifies local values assigned from calls have source_call_id. Per schema: local may have source_call_id or source_value_id. | `ContractTests\Tests\ValueKind\ValueKindTest::testLocalValuesMayHaveSourceCallId` |
| ✅ | Parameter Symbol Format | Verifies parameter symbols contain ($paramName) pattern. Example: OrderRepository#save().($order) | `ContractTests\Tests\ValueKind\ValueKindTest::testParameterSymbolFormat` |
| ✅ | Parameter Values Have Symbol | Verifies all parameter values have a symbol field. Per schema: parameter kind has symbol, no source_call_id. | `ContractTests\Tests\ValueKind\ValueKindTest::testParameterValuesHaveSymbol` |
| ✅ | Parameter Values Have Type | Verifies parameter values have type information when the parameter has a type declaration. | `ContractTests\Tests\ValueKind\ValueKindTest::testParameterValuesHaveType` |
| ✅ | Parameter Values No Source Call ID | Verifies parameter values do not have source_call_id. Parameters are inputs, not results of calls. | `ContractTests\Tests\ValueKind\ValueKindTest::testParameterValuesNoSourceCallId` |
| ✅ | Result Source Call Exists | Verifies every result value source_call_id points to an existing call in the calls array. | `ContractTests\Tests\ValueKind\ValueKindTest::testResultSourceCallExists` |
| ✅ | Result Value ID Matches Source Call ID | Verifies result values have id matching their source_call_id. Per schema: result id equals the call id that produced it. | `ContractTests\Tests\ValueKind\ValueKindTest::testResultValueIdMatchesSourceCallId` |
| ✅ | Result Values Exist | Verifies index contains result values (call results). Per schema: result kind, no symbol, always has source_call_id. | `ContractTests\Tests\ValueKind\ValueKindTest::testResultValuesExist` |
| ✅ | Result Values Have Source Call ID | Verifies all result values have source_call_id. Per schema: result always has source_call_id. | `ContractTests\Tests\ValueKind\ValueKindTest::testResultValuesHaveSourceCallId` |
| ✅ | Result Values Have Type From Call Return | Verifies result values have type matching the return_type of their source call. | `ContractTests\Tests\ValueKind\ValueKindTest::testResultValuesHaveTypeFromCallReturn` |
| ✅ | Result Values No Symbol | Verifies result values do not have a symbol field. Results are anonymous intermediate values. | `ContractTests\Tests\ValueKind\ValueKindTest::testResultValuesNoSymbol` |
## Failed Tests Details
### ❌ No Array Access Without Experimental Flag
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoArrayAccessWithoutExperimentalFlag`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoArrayAccessWithoutExperimentalFlag
Found 8 access_array calls in default output. Array access kind is experimental and should not be present without --experimental flag.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:191
```
### ❌ No Coalesce Operators Without Experimental Flag
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoCoalesceWithoutExperimentalFlag`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoCoalesceWithoutExperimentalFlag
Found 6 coalesce calls in default output. Coalesce kind is experimental and should not be present without --experimental flag.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:150
```
### ❌ No Deprecated Kinds Exist
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoDeprecatedKindsExist`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoDeprecatedKindsExist
Found deprecated kinds: access_nullsafe (8), method_nullsafe (2). These should be removed.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:270
```
### ❌ No Experimental Kinds in Default Output
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoExperimentalKindsInDefaultOutput`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoExperimentalKindsInDefaultOutput
Found experimental kinds in default output (should require --experimental flag): function (10), access_array (8), coalesce (6), ternary (2), ternary_full (4), match (3)
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:236
```
### ❌ No Function Calls Without Experimental Flag
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoFunctionCallsWithoutExperimentalFlag`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoFunctionCallsWithoutExperimentalFlag
Found 10 function calls in default output. Function kind is experimental and should not be present without --experimental flag.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:131
```
### ❌ No Match Expressions Without Experimental Flag
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoMatchWithoutExperimentalFlag`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoMatchWithoutExperimentalFlag
Found 3 match calls in default output. Match kind is experimental and should not be present without --experimental flag.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:210
```
### ❌ No Ternary Operators Without Experimental Flag
**Method**: `ContractTests\Tests\CallKind\ExperimentalKindTest::testNoTernaryWithoutExperimentalFlag`
**Error**:
```
ContractTests\Tests\CallKind\ExperimentalKindTest::testNoTernaryWithoutExperimentalFlag
Found 6 ternary calls in default output. Ternary kinds are experimental and should not be present without --experimental flag.
Failed asserting that 6 is identical to 0.
/app/contract-tests/tests/CallKind/ExperimentalKindTest.php:171
```
### ❌ No access_nullsafe Kind Exists
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNoAccessNullsafeKindExists`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNoAccessNullsafeKindExists
Should find ZERO access_nullsafe calls. Found 8. This kind should be removed.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:109
```
### ❌ No method_nullsafe Kind Exists
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNoMethodNullsafeKindExists`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNoMethodNullsafeKindExists
Should find ZERO method_nullsafe calls. Found 2. This kind should be removed.
Failed asserting that an array is empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:238
```
### ❌ Nullsafe Boolean Method Has Union Return Type
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeBooleanMethodHasUnionReturnType`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeBooleanMethodHasUnionReturnType
Should find isPending method call
Failed asserting that an array is not empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:204
```
### ❌ Nullsafe Method Call Has Union Return Type
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeMethodCallHasUnionReturnType`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeMethodCallHasUnionReturnType
Should find getCustomerName method call (kind=method, not method_nullsafe)
Failed asserting that an array is not empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:167
```
### ❌ Nullsafe Method Call Uses kind=method
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeMethodCallUsesMethodKind`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafeMethodCallUsesMethodKind
Should find method calls for getCustomerName() in OrderDisplayService (kind=method, not method_nullsafe)
Failed asserting that an array is not empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:139
```
### ❌ Nullsafe Property Access Has Union Return Type
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafePropertyAccessHasUnionReturnType`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafePropertyAccessHasUnionReturnType
Should find status property access (kind=access, not access_nullsafe)
Failed asserting that an array is not empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:75
```
### ❌ Nullsafe Property Access Uses kind=access
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafePropertyAccessUsesAccessKind`
**Error**:
```
ContractTests\Tests\CallKind\NullsafeKindTest::testNullsafePropertyAccessUsesAccessKind
Should find property access calls for $order->status in OrderDisplayService
Failed asserting that an array is not empty.
/app/contract-tests/tests/CallKind/NullsafeKindTest.php:46
```
### ❌ Multiple Nullsafe Accesses Share Receiver
**Method**: `ContractTests\Tests\CallKind\NullsafeKindTest::testMultipleNullsafeAccessesShareReceiver`
**Error**:
