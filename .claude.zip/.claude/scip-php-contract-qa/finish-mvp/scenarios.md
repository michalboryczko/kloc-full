# Contract Test Scenarios: finish-mvp

## Context

The finish-mvp feature completes the scip-php indexer MVP by implementing several schema changes:

1. **Remove `value_type` from arguments** - Consumers should use `values[value_id].type` instead
2. **Remove nullsafe kinds** - Use `access`/`method` with union return type `T|null` instead of separate `access_nullsafe`/`method_nullsafe` kinds
3. **Experimental flag** - Separate stable kinds (always output) from experimental kinds (require `--experimental`)

## Reference Code

### File: `kloc-reference-project-php/src/Service/OrderDisplayService.php`

**Nullsafe property accesses:**
```php
// Line 45: Nullsafe property + coalesce
return $order?->status ?? 'unknown';

// Line 64: Nullsafe property assignment
$status = $order?->status;

// Line 82: Nullsafe property + coalesce
$customerEmail = $order?->customerEmail ?? '';

// Line 99: Nullsafe property + coalesce
$qty = $order?->quantity ?? 0;
```

**Nullsafe method calls:**
```php
// Line 162: Nullsafe method call
return $order?->getCustomerName() ?? 'Guest';

// Line 175: Nullsafe method call
return $order?->isPending() ?? false;
```

### File: `kloc-reference-project-php/src/Entity/Order.php`

Properties with types:
- `status: string` (line 16)
- `customerEmail: string` (line 13)
- `quantity: int` (line 15)

Methods with return types:
- `getCustomerName(): string` (line 25)
- `isPending(): bool` (line 34)

---

## Scenarios

### Issue 1: Arguments Have No value_type Field

#### Scenario 1.1: Arguments Serialize Without value_type
WHEN indexing any call with arguments (e.g., `OrderRepository#save($order)`)
THEN each argument record contains ONLY:
  - `position`: integer (0-based)
  - `parameter`: SCIP symbol or null
  - `value_id`: LocationId or null
  - `value_expr`: string or null (when value_id is null)
AND `value_type` field is ABSENT from all argument records

**Category**: schema
**Test file**: `tests/Schema/SchemaValidationTest.php`

#### Scenario 1.2: Type Lookup Via value_id Works
WHEN indexing a call argument that has `value_id` pointing to a value
THEN `values[value_id].type` contains the type information
AND this type matches what `value_type` would have contained

**Category**: integrity
**Test file**: `tests/Integrity/DataIntegrityTest.php`

---

### Issue 2: Nullsafe Property Access Uses Union Return Type

#### Scenario 2.1: Nullsafe Property Access Has Kind "access"
WHEN indexing `$order?->status` in `OrderDisplayService#getStatusOrDefault()`
THEN the call record has:
  - `kind`: "access" (NOT "access_nullsafe")
  - `kind_type`: "access"
  - `callee`: symbol containing "Order#$status."
  - `receiver_value_id`: pointing to the `$order` local value

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php` (new)

#### Scenario 2.2: Nullsafe Property Access Has Union Return Type
WHEN indexing `$order?->status` (where `status` is type `string`)
THEN the call record has:
  - `return_type`: union symbol containing "null" and "string" (format: `scip-php union . null|string#`)
AND the corresponding result value has:
  - `type`: same union symbol

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php`

#### Scenario 2.3: Multiple Nullsafe Accesses On Same Variable Share Receiver
WHEN indexing multiple nullsafe accesses on `$order` in `OrderDisplayService#getOrderSummary()`
  - `$order?->id` (line 139)
  - `$order?->customerEmail` (line 140)
  - `$order?->status` (line 141)
THEN all three access calls have the same `receiver_value_id`
AND that ID points to the `$order` local value

**Category**: chain
**Test file**: `tests/Chain/NullsafeChainTest.php` (new)

#### Scenario 2.4: No access_nullsafe Kind Exists
WHEN indexing the entire reference project
THEN calls.json contains ZERO calls with `kind: "access_nullsafe"`

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php`

---

### Issue 3: Nullsafe Method Call Uses Union Return Type

#### Scenario 3.1: Nullsafe Method Call Has Kind "method"
WHEN indexing `$order?->getCustomerName()` in `OrderDisplayService#getCustomerNameOrDefault()`
THEN the call record has:
  - `kind`: "method" (NOT "method_nullsafe")
  - `kind_type`: "invocation"
  - `callee`: symbol containing "Order#getCustomerName()."
  - `receiver_value_id`: pointing to the `$order` local value
  - `arguments`: empty array (no arguments)

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php`

#### Scenario 3.2: Nullsafe Method Call Has Union Return Type
WHEN indexing `$order?->getCustomerName()` (where method returns `string`)
THEN the call record has:
  - `return_type`: union symbol containing "null" and "string"
AND the corresponding result value has:
  - `type`: same union symbol

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php`

#### Scenario 3.3: Nullsafe Boolean Method Has Union Return Type
WHEN indexing `$order?->isPending()` (where method returns `bool`)
THEN the call record has:
  - `return_type`: union symbol containing "null" and "bool"

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php`

#### Scenario 3.4: No method_nullsafe Kind Exists
WHEN indexing the entire reference project
THEN calls.json contains ZERO calls with `kind: "method_nullsafe"`

**Category**: callkind
**Test file**: `tests/CallKind/NullsafeKindTest.php`

---

### Issue 4: Experimental Flag Filtering

#### Scenario 4.1: Stable Kinds Always Present (Default Run)
WHEN indexing without `--experimental` flag
THEN calls.json contains calls with kinds:
  - `access`
  - `method`
  - `constructor`
  - `access_static`
  - `method_static`

**Category**: callkind
**Test file**: `tests/CallKind/ExperimentalKindTest.php` (new)

#### Scenario 4.2: Experimental Kinds Absent (Default Run)
WHEN indexing without `--experimental` flag
THEN calls.json contains ZERO calls with kinds:
  - `function`
  - `access_array`
  - `coalesce`
  - `ternary`
  - `ternary_full`
  - `match`

**Category**: callkind
**Test file**: `tests/CallKind/ExperimentalKindTest.php`

#### Scenario 4.3: Experimental Kinds Present With Flag
WHEN indexing with `--experimental` flag
THEN calls.json contains calls with experimental kinds (where present in code):
  - `function` (sprintf calls exist in reference project)
  - `coalesce` (null coalesce operators exist)
  - `ternary` or `ternary_full` (ternary operators exist)

**Category**: callkind
**Test file**: `tests/CallKind/ExperimentalKindTest.php`

#### Scenario 4.4: Kind Count Changes With Flag
WHEN comparing calls.json from default run vs `--experimental` run
THEN experimental run has MORE calls
AND the additional calls are all experimental kinds

**Category**: callkind
**Test file**: `tests/CallKind/ExperimentalKindTest.php`

---

### Issue 5: Chain Integrity With Nullsafe

#### Scenario 5.1: Nullsafe Access Result Links to Call
WHEN indexing `$status = $order?->status` (line 64 in OrderDisplayService)
THEN:
  - A result value exists with same ID as the access call
  - The result value has `source_call_id` equal to its own `id`
  - The result value has `kind: "result"`
  - The `$status` local value has `source_call_id` pointing to the access call

**Category**: chain
**Test file**: `tests/Chain/NullsafeChainTest.php`

#### Scenario 5.2: Nullsafe Method Result Links to Call
WHEN indexing `$order?->getCustomerName()` (line 162)
THEN a result value exists:
  - `id`: same as the method call ID
  - `kind`: "result"
  - `source_call_id`: same as `id`
  - `type`: union symbol (null|string)

**Category**: chain
**Test file**: `tests/Chain/NullsafeChainTest.php`

---

### Issue 6: Data Integrity

#### Scenario 6.1: All Receiver IDs Point to Values
WHEN indexing any call with `receiver_value_id` (including nullsafe accesses/methods)
THEN that ID exists in the values array
AND the referenced value has valid `kind` (parameter, local, literal, constant, or result)

**Category**: integrity
**Test file**: `tests/Integrity/DataIntegrityTest.php`

#### Scenario 6.2: All Call Kinds Are Valid Per Schema
WHEN indexing the entire reference project
THEN every call has a `kind` that is one of:
  - Stable: `access`, `method`, `constructor`, `access_static`, `method_static`
  - Experimental: `function`, `access_array`, `coalesce`, `ternary`, `ternary_full`, `match`
AND NO calls have deprecated kinds:
  - `access_nullsafe`
  - `method_nullsafe`

**Category**: schema
**Test file**: `tests/Schema/SchemaValidationTest.php`

---

## Implementation Notes

### Tests That Need Modification

1. **`tests/CallKind/CallKindTest.php`**:
   - `testNullsafeMethodCallKind()` - currently expects `kind=method_nullsafe`, needs to expect `kind=method` with union return type
   - `testNullsafePropertyAccessKind()` - currently expects `kind=access_nullsafe`, needs to expect `kind=access` with union return type

2. **`tests/Schema/SchemaValidationTest.php`**:
   - `testAllCallKindsAreValid()` - remove `access_nullsafe` and `method_nullsafe` from valid kinds list
   - Add test to verify arguments have no `value_type` field

3. **New test file**: `tests/CallKind/NullsafeKindTest.php`
   - Tests specific to nullsafe behavior using union return types
   - Verify kind=access/method (not *_nullsafe)
   - Verify return_type is union with null

4. **New test file**: `tests/CallKind/ExperimentalKindTest.php`
   - Tests for --experimental flag behavior
   - Should be marked as pending until flag is implemented
   - Or use test groups to skip without flag

### Union Type Symbol Format

The union return type symbol format should be:
```
scip-php union . null|{base_type}#
```

Examples:
- `scip-php union . null|string#` for nullable string
- `scip-php union . null|bool#` for nullable bool
- `scip-php union . null|int#` for nullable int

### Test Execution Considerations

For experimental flag tests:
1. Default contract test run should validate stable-only behavior
2. A separate test mode or group for experimental validation
3. Or mark experimental tests as "pending" until dev enables them

