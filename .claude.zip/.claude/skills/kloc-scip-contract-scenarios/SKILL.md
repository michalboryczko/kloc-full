---
name: kloc-scip-contract-scenarios
description: "Generate contract test scenarios for scip-php indexer from feature requests. This skill should be used when planning what contract tests to write based on a feature description or acceptance criteria. It produces structured test scenarios in the format 'WHEN indexing {symbol} THEN {expected behavior}' that can later be implemented using the kloc-scip-contract-test-create skill. Triggers include: 'generate test scenarios for...', 'what contract tests do we need for...', 'plan scenarios for testing...', 'create QA scenarios for scip-php', or when analyzing a feature request to determine required indexer validations. The skill bases scenarios on kloc-reference-project-php code patterns."
---

# KLOC SCIP Contract Test Scenario Generator

Generate structured test scenarios for scip-php contract tests from feature requests or acceptance criteria.

## Purpose

Transform feature requirements into concrete, testable scenarios that validate scip-php indexer output. Scenarios describe WHAT to test (in natural language) before HOW to test (implementation).

## Output Format

All scenarios MUST follow the format:

```
WHEN indexing {SCIP symbol or code pattern}
THEN {expected behavior in calls.json}
```

### Complete Example

```markdown
## Feature: Parameter Reference Tracking

### Scenario 1: Single Parameter Value Entry
WHEN indexing `OrderRepository#save().($order)`
THEN calls.json contains exactly ONE value entry with:
  - kind: "parameter"
  - symbol containing "($order)"
  - type containing "Order"

### Scenario 2: Parameter Usage References
WHEN indexing `OrderRepository#save()` method body
THEN all property accesses on `$order` have:
  - receiver_value_id pointing to the single parameter value
  - No duplicate parameter entries

### Scenario 3: Parameter in Argument Position
WHEN indexing the call `$this->orderRepository->save($order)` in `OrderService#createOrder()`
THEN the call's arguments[0] has:
  - value_id pointing to a local value
  - The local value has symbol containing "local$order"
```

## Documentation References

Before generating scenarios, read the current documentation:

| Document | Path | What to Learn |
|----------|------|---------------|
| Calls Schema | `docs/reference/kloc-scip/calls-schema.json` | Value kinds, call kinds, field definitions |
| Schema Docs | `docs/reference/kloc-scip/calls-schema-docs.md` | Detailed field explanations |
| Test Categories | `docs/reference/kloc-scip/contract-tests/test-categories.md` | What each category tests |
| Data Flow Examples | `docs/reference/kloc-scip/calls-and-data-flow.md` | How code maps to calls.json |

## Reference Project

All scenarios MUST reference actual code in `kloc-reference-project-php/src/`:

| File | Key Patterns |
|------|--------------|
| `Repository/OrderRepository.php` | Parameter tracking, local variables, conditionals |
| `Service/OrderService.php` | Dependency injection, method chains, named arguments |
| `Service/NotificationService.php` | Chain integrity, property access |
| `Entity/Order.php` | Readonly properties, constructor promotion |
| `Component/EmailSender.php` | Interface implementation, multiple parameters |

## Test Categories for Scenarios

### Category 1: Reference Consistency
**Focus**: Variable tracking accuracy

Scenario patterns:
- "WHEN indexing {Class#method().($param)} THEN exactly ONE parameter value entry exists"
- "WHEN indexing method body THEN all usages of {$var} share the same receiver_value_id"
- "WHEN indexing {$localVar} assignment THEN ONE local value entry at assignment line"

### Category 2: Chain Integrity
**Focus**: Method/property chain linkage

Scenario patterns:
- "WHEN indexing `$this->repository->method()` THEN chain is properly linked: value→access→result→method→result"
- "WHEN indexing property access chain THEN each step's receiver_value_id points to previous step's result"
- "WHEN indexing `$obj->prop` THEN result value exists with source_call_id pointing to the access"

### Category 3: Argument Binding
**Focus**: Argument-to-value connections

Scenario patterns:
- "WHEN indexing call with argument THEN argument.value_id points to the source value"
- "WHEN indexing named arguments THEN each argument has correct position and parameter symbol"
- "WHEN indexing chained result as argument THEN value_id points to the result value, not the call"

### Category 4: Data Integrity
**Focus**: Structural correctness

Scenario patterns:
- "WHEN indexing entire project THEN no receiver_value_id references non-existent values"
- "WHEN indexing entire project THEN every call has a corresponding result value"
- "WHEN indexing entire project THEN no duplicate parameter symbols exist"

## Workflow

### Step 1: Read Feature Request
Extract what behavior needs to be validated. Look for:
- New PHP patterns being indexed
- Edge cases mentioned
- Acceptance criteria

### Step 2: Read Schema Documentation
Read `docs/reference/kloc-scip/calls-schema.json` to understand:
- What fields are available
- What values are valid
- How relationships work

### Step 3: Find Reference Code
Search `kloc-reference-project-php/src/` for code that demonstrates the pattern.
If no matching code exists, note that the reference project may need expansion.

### Step 4: Generate Scenarios by Category
For each relevant category, generate 2-5 scenarios covering:
- Happy path (normal behavior)
- Edge cases
- Error conditions (invalid states)

### Step 5: Format Output
Output scenarios in this structure:

```markdown
# Contract Test Scenarios: {Feature Name}

## Context
{Brief description of what's being tested and why}

## Reference Code
File: `kloc-reference-project-php/src/Path/File.php`
Lines: {relevant lines}
```php
{code snippet}
```

## Scenarios

### Category 1: Reference Consistency
{scenarios}

### Category 2: Chain Integrity
{scenarios}

### Category 3: Argument Binding
{scenarios}

### Category 4: Data Integrity
{scenarios}

## Implementation Notes
{Any special considerations for implementing these scenarios}
```

## SCIP Symbol Format

Use these patterns in scenarios:

| Pattern | Meaning | Example |
|---------|---------|---------|
| `Class#method().` | Method scope | `OrderRepository#save().` |
| `Class#method().($param)` | Parameter | `OrderRepository#save().($order)` |
| `Class#method().local$var@{line}` | Local variable | `OrderService#createOrder().local$order@31` |
| `Class#$property.` | Property | `Order#$customerEmail.` |
| `Class#` | Class itself | `Order#` |

## Example: From Feature to Scenarios

### Input Feature Request
> "Support tracking of method calls with named arguments, ensuring each argument's value_id correctly references the source value."

### Generated Scenarios

```markdown
# Contract Test Scenarios: Named Argument Tracking

## Context
Named arguments in PHP 8.0+ allow passing arguments by name rather than position.
The indexer must correctly track which value is passed to which parameter.

## Reference Code
File: `kloc-reference-project-php/src/Service/OrderService.php`
Lines: 42-51
```php
$this->emailSender->send(
    to: $savedOrder->customerEmail,
    subject: 'Order Confirmation #' . $savedOrder->id,
    body: sprintf(...),
);
```

## Scenarios

### Category 3: Argument Binding

#### Scenario 1: Named Argument Positions
WHEN indexing `EmailSender#send()` call with named arguments
THEN arguments array contains entries with:
  - position: 0 for `to:`
  - position: 1 for `subject:`
  - position: 2 for `body:`

#### Scenario 2: Named Argument Value Binding
WHEN indexing `to: $savedOrder->customerEmail`
THEN argument at position 0 has:
  - value_id pointing to a result value (from property access)
  - parameter symbol containing "($to)"

#### Scenario 3: Literal in Named Argument
WHEN indexing `subject: 'Order Confirmation #' . $savedOrder->id`
THEN argument at position 1 has:
  - value_id is null (complex expression)
  - value_expr contains the expression text

### Category 1: Reference Consistency

#### Scenario 4: Receiver Consistency Across Named Args
WHEN indexing multiple property accesses on `$savedOrder` in named arguments
THEN all accesses share the same receiver_value_id pointing to the `$savedOrder` local value

## Implementation Notes
- Named arguments preserve semantic meaning but are tracked by position internally
- Complex expressions (concatenation) may have null value_id with value_expr fallback
```

## Rules

- **Always read the schema** - Don't guess field names or values
- **Reference real code** - Every scenario must map to actual kloc-reference-project-php code
- **Be specific** - Include exact field names and expected values
- **Cover categories** - Include scenarios for at least 2 categories
- **No implementation details** - Scenarios describe WHAT, not HOW (no PHPUnit code)
