# SCIP Calls Schema Quick Reference

This is a quick reference for generating test scenarios. For the authoritative schema, always read `docs/reference/kloc-scip/calls-schema.json`.

## Value Kinds

| Kind | Purpose | Has `symbol` | Has `source_call_id` |
|------|---------|--------------|----------------------|
| `parameter` | Function/method parameter | Yes | No |
| `local` | Local variable | Yes | Maybe (if from call) |
| `literal` | String/int/array literal | No | No |
| `constant` | Class/global constant | Yes | No |
| `result` | Call result value | No | Yes (always) |

## Call Kinds

| Kind | Kind Type | PHP Code |
|------|-----------|----------|
| `method` | invocation | `$obj->method()` |
| `method_static` | invocation | `Foo::method()` |
| `method_nullsafe` | invocation | `$obj?->method()` |
| `function` | invocation | `func()` |
| `constructor` | invocation | `new Foo()` |
| `access` | access | `$obj->property` |
| `access_static` | access | `Foo::$property` |
| `access_nullsafe` | access | `$obj?->property` |
| `access_array` | access | `$arr['key']` |
| `coalesce` | operator | `$a ?? $b` |
| `ternary` | operator | `$a ?: $b` |
| `ternary_full` | operator | `$a ? $b : $c` |
| `match` | operator | `match($x) {...}` |

## Key Relationships

### Value → Call (via receiver_value_id)
```
$order->customerEmail
  ↓
Call has receiver_value_id = $order value's id
```

### Call → Result (via id matching)
```
$obj->method() produces a result
  ↓
Call id = "src/File.php:10:5"
Result value id = "src/File.php:10:5" (same)
Result has source_call_id = "src/File.php:10:5"
```

### Argument → Value (via value_id)
```
$repo->save($order)
  ↓
Argument at position 0 has value_id = $order value's id
```

## SCIP Symbol Patterns

```
Full class: scip-php composer vendor/package 1.0 App/Service/OrderService#
Method:     scip-php composer vendor/package 1.0 App/Service/OrderService#createOrder().
Parameter:  scip-php composer vendor/package 1.0 App/Service/OrderService#createOrder().($input)
Local:      scip-php composer vendor/package 1.0 App/Service/OrderService#createOrder().local$order@31
Property:   scip-php composer vendor/package 1.0 App/Entity/Order#$customerEmail.
```

## Reference Project Files

| File | Contains |
|------|----------|
| `kloc-reference-project-php/src/Repository/OrderRepository.php` | `save()`, `findById()` methods with parameter and local tracking |
| `kloc-reference-project-php/src/Service/OrderService.php` | `createOrder()` with chains, named arguments, constructor calls |
| `kloc-reference-project-php/src/Service/NotificationService.php` | Property chains via `$this->` |
| `kloc-reference-project-php/src/Entity/Order.php` | Readonly class with constructor property promotion |
| `kloc-reference-project-php/src/Component/EmailSender.php` | Multiple parameters, interface implementation |

## Scenario Category Mapping

| What You're Testing | Category |
|---------------------|----------|
| "Parameter X should have one value entry" | Reference Consistency |
| "All usages of $var should share same receiver_value_id" | Reference Consistency |
| "$this->prop->method() chain should be linked" | Chain Integrity |
| "Result of access should have source_call_id" | Chain Integrity |
| "Argument 0 should point to local $order" | Argument Binding |
| "Named argument should have parameter symbol" | Argument Binding |
| "No orphaned receiver_value_id references" | Data Integrity |
| "Every call has a result value" | Data Integrity |
