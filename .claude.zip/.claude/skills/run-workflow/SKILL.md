---
name: run-workflow
description: "Execute a multi-step workflow in the main Claude context. This skill should be used when tasks require orchestrating multiple steps or spawning subagents. Workflows run in main context so they CAN spawn subagents via the Task tool. Use when user mentions a workflow name or when a task matches a workflow's purpose."
---

# Run Workflow Skill

Execute workflows defined in `.claude/workflows/`. Workflows are multi-step orchestration instructions that run in main Claude context, enabling them to spawn subagents.

## Why Workflows Exist

Subagents cannot spawn other subagents (Claude Code design limitation). Workflows solve this by providing instructions that main Claude executes directly, preserving full Task tool access.

## Workflow Location

All workflows are stored in: `.claude/workflows/{workflow-name}/workflow.md`

## Execution Process

### Step 1: Discover Available Workflows

List available workflows:

```bash
ls -1 .claude/workflows/
```

### Step 2: Match User Request to Workflow

Match the user's request to a workflow using:

1. **Exact match**: "feature-orchestrator" matches `feature-orchestrator/`
2. **Partial match**: "feature orch" matches `feature-orchestrator/`
3. **Semantic match**: "implement a new feature end-to-end" matches `feature-orchestrator/`

If no match found or multiple matches, ask user to clarify.

### Step 3: Read Workflow Definition

Read the matched workflow:

```bash
cat .claude/workflows/{workflow-name}/workflow.md
```

### Step 4: Validate Required Context

Parse the "Required Context" section from the workflow and verify:

- All required fields are provided by the user
- Validation rules pass (if specified)
- If required fields are missing, ask the user for them before proceeding

### Step 5: Execute Workflow Steps

Follow the workflow steps **in order**:

1. Execute each step's actions as described
2. Create progress files as specified
3. Verify completion criteria before moving to next step
4. When spawning subagents, use the Task tool with `subagent_type` parameter
5. For parallel subagent execution, spawn ALL subagents in a SINGLE message

## Critical Rules

- **Execute in main context**: The workflow instructions are for YOU (main Claude) to execute, not a subagent
- **Spawn subagents when instructed**: Use `Task(subagent_type=...)` as specified in workflow steps
- **Parallel execution**: When workflow says "spawn in parallel", send ONE message with MULTIPLE Task tool calls
- **Sequential steps**: Complete each step before starting the next unless workflow explicitly allows parallel
- **Progress tracking**: Create progress files as specified to enable recovery and auditing
