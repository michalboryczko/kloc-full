---
name: kloc-scip-contract-test-run
description: "Run and query scip-php contract tests. This skill should be used when needing to execute contract tests, check test status, or generate test documentation. Triggers include: 'run contract tests', 'check if tests pass', 'get contract test status', 'generate test docs', or when an agent needs current test status with descriptions. The skill provides commands for running tests (quick validation) and generating agent-friendly documentation with test results."
---

# KLOC SCIP Contract Test Runner

Run contract tests and generate documentation for scip-php indexer validation.

## Script Location

**IMPORTANT**: All commands must be run from the contract-tests directory:

```
kloc-reference-project-php/contract-tests/bin/run.sh
```

## Quick Reference

| Task | Command |
|------|---------|
| Run all tests | `bin/run.sh test` |
| Run with experimental kinds | `bin/run.sh test --experimental` |
| Run specific test | `bin/run.sh test --filter <name>` |
| Run test suite | `bin/run.sh test --suite <suite>` |
| Generate docs (markdown) | `bin/run.sh docs` |
| Generate docs (JSON) | `bin/run.sh docs --format=json` |
| Generate docs to file | `bin/run.sh docs --format=json --output=FILE` |

## Task 1: Run Tests (Quick Validation)

To verify all contract tests pass:

```bash
cd kloc-reference-project-php/contract-tests && bin/run.sh test
```

The script automatically:
1. Generates fresh `calls.json` index using scip-php
2. Builds Docker container
3. Runs PHPUnit tests
4. Reports pass/fail status

### Run with Experimental Call Kinds

```bash
# Include experimental kinds: function, access_array, coalesce, ternary, match
bin/run.sh test --experimental
```

This:
1. Generates index with `--experimental` flag (enables all call kinds)
2. Runs all tests including experimental-only tests (marked with `experimental: true`)

### Run Specific Tests

```bash
# By test name pattern
bin/run.sh test --filter testOrderRepository

# By test suite
bin/run.sh test --suite smoke      # Basic validation
bin/run.sh test --suite integrity  # Data structure checks
bin/run.sh test --suite reference  # Variable reference consistency
bin/run.sh test --suite chain      # Call chain linkage
bin/run.sh test --suite argument   # Argument binding correctness
```

### Interpreting Results

- **OK (green)**: All tests passed
- **FAILURES (red)**: Some tests failed - check output for details
- **Exit code 0**: Success
- **Exit code non-zero**: Failure

## Task 2: Generate Documentation (Agent-Friendly)

To get structured test information with descriptions and status:

```bash
cd kloc-reference-project-php/contract-tests && bin/run.sh docs --format=json
```

### Output Formats

| Format | Use Case | Command |
|--------|----------|---------|
| `json` | **Agent processing** - structured, parseable | `--format=json` |
| `markdown` | Human reading, documentation | (default) |
| `csv` | Spreadsheet import | `--format=csv` |

### Writing to File

```bash
# Write JSON to file for agent consumption
bin/run.sh docs --format=json --output=test-status.json

# Write markdown documentation
bin/run.sh docs --output=TESTS.md
```

### JSON Output Structure

The JSON output contains structured test information:

```json
{
  "tests": [
    {
      "name": "OrderRepository::save() $order",
      "description": "Verifies $order parameter has single value entry",
      "category": "reference",
      "status": "active",
      "class": "ContractTests\\Tests\\Reference\\ParameterReferenceTest",
      "method": "testOrderRepositorySaveOrderParameter",
      "codeReference": "ContractTests\\Tests\\Reference\\ParameterReferenceTest::testOrderRepositorySaveOrderParameter"
    }
  ],
  "summary": {
    "total": 25,
    "byCategory": {
      "smoke": 5,
      "integrity": 8,
      "reference": 6,
      "chain": 3,
      "argument": 3
    },
    "byStatus": {
      "active": 24,
      "pending": 1
    }
  }
}
```

## Agent Usage Patterns

### Pattern 1: Quick Health Check

To verify the indexer is working correctly:

```bash
cd kloc-reference-project-php/contract-tests && bin/run.sh test --suite smoke
```

### Pattern 2: Get Full Test Status for Decision Making

To understand current test coverage and status:

```bash
cd kloc-reference-project-php/contract-tests && bin/run.sh docs --format=json --output=/tmp/contract-tests-status.json
```

Then read the file to understand:
- What tests exist
- What each test verifies (description)
- Which categories have coverage
- Current status (active/pending/skipped)

### Pattern 3: Verify After Implementation

After implementing changes, run full test suite:

```bash
cd kloc-reference-project-php/contract-tests && bin/run.sh test
```

Check exit code for pass/fail.

### Pattern 4: Run Specific Category After Changes

If implementing chain-related features:

```bash
cd kloc-reference-project-php/contract-tests && bin/run.sh test --suite chain
```

## Test Categories

| Category | Purpose | When to Run |
|----------|---------|-------------|
| `smoke` | Basic framework validation | Always first |
| `integrity` | Data structure correctness | After schema changes |
| `reference` | Variable reference tracking | After value tracking changes |
| `chain` | Method/property chain linkage | After call chain changes |
| `argument` | Argument binding | After argument tracking changes |
| `callkind` | Call kind coverage | After adding new kinds |
| `operator` | Operator tracking | With `--experimental` flag |

## Experimental Mode

The indexer has two modes:

**Default mode**: Generates only stable call kinds (`access`, `method`, `constructor`, `access_static`, `method_static`)

**Experimental mode** (`--experimental`): Also includes `function`, `access_array`, `coalesce`, `ternary`, `ternary_full`, `match`

Tests marked with `experimental: true` in their `#[ContractTest]` attribute:
- Are skipped in default mode
- Run only with `--experimental` flag

Use `--experimental` when testing operator tracking or function call features.

## Documentation Reference

For detailed framework documentation:
- `docs/reference/kloc-scip/contract-tests/README.md` - Overview
- `docs/reference/kloc-scip/contract-tests/framework-api.md` - API reference
- `docs/reference/kloc-scip/contract-tests/test-categories.md` - Category details
