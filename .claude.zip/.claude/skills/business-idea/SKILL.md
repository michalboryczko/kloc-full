---
name: business-idea
description: Document feature ideas with CLI interface examples and use cases. Use this skill when you need to formally document a business/product feature idea. Supports two modes - 'quick' for brief feature listings and 'detailed' for comprehensive feature documentation with use cases and examples.
argument-hint: [mode: quick|detailed] [feature-name or topic]
---

This skill creates formal documentation for kloc feature ideas, focusing on the user experience and CLI interface.

## Modes

### Quick Mode
For documenting multiple ideas briefly. Use when generating roadmap items or listing several features.

**Output format**: Single markdown file with multiple feature entries
**Location**: `docs/ideas/{topic}-ideas.md`

### Detailed Mode
For deep-diving into a single feature with comprehensive documentation.

**Output format**: Full feature document with examples and use cases
**Location**: `docs/ideas/{feature-name}.md`

## Workflow

### Step 1: Parse Arguments

Parse `$ARGUMENTS` to determine:
- **Mode**: First word should be `quick` or `detailed` (default: `detailed`)
- **Topic/Feature**: Remaining text is the feature name or topic

Examples:
- `quick cli-improvements` → Quick mode, topic "cli-improvements"
- `detailed dead-code-detection` → Detailed mode, feature "dead-code-detection"
- `semantic-search` → Detailed mode (default), feature "semantic-search"

### Step 2: Gather Context

1. Read `kloc-cli/README.md` to understand current CLI commands
2. Read `docs/summary.md` for current capabilities
3. If related to existing features, read relevant files in `docs/specs/`

### Step 3: Generate Documentation

**For Quick Mode**: Use template at `references/template-quick.md`
**For Detailed Mode**: Use template at `references/template-detailed.md`

### Step 4: Save Output

Create the documentation file:
- Quick: `docs/ideas/{topic}-ideas.md`
- Detailed: `docs/ideas/{feature-name}.md`

Create `docs/ideas/` directory if it doesn't exist.

## Template References

- `references/template-quick.md` — Brief format for multiple ideas
- `references/template-detailed.md` — Comprehensive single-feature format

## Content Guidelines

### CLI Interface Examples

Always include realistic CLI invocations:
```bash
# Good: Specific, realistic command
kloc-cli find-dead-code --sot sot.json --threshold 90

# Bad: Vague or incomplete
kloc-cli deadcode
```

### Output Examples

Show what users would see:
```
Dead Code Analysis for project:

Found 23 potentially unused symbols:

  CLASS  App\Service\LegacyPaymentHandler
         Last referenced: never
         Suggestion: Safe to remove

  METHOD App\Entity\User::getDeprecatedField()
         Last referenced: 2 files (test only)
         Suggestion: Review before removal
```

### Use Cases

Structure as user scenarios:
1. **Persona**: Who is doing this?
2. **Goal**: What do they want to achieve?
3. **Action**: What do they do?
4. **Result**: What happens?

### Reference Code

When possible, reference `kloc-reference-project-php` for examples:
```
Example from kloc-reference-project-php:
- Class: CallsExamples/MethodCalls.php
- Shows: Method call tracking patterns
```

If no suitable reference exists, create PHP pseudocode that illustrates the feature.
