# Feature: {Feature Name}

> Generated: {date}
> Status: Idea
> Priority: {High / Medium / Low}

## Summary

**One-liner**: {Single sentence that explains the feature}

**Problem**: {What pain point does this solve?}

**Solution**: {How does this feature solve it?}

**Target users**: {Who benefits from this?}

---

## CLI Interface

### Primary Command

```bash
kloc-cli {command} {required-args} --sot sot.json [options]
```

### Options

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--{option}` | {type} | {default} | {description} |
| `--json` | flag | false | Output as JSON for programmatic use |

### Examples

**Basic usage**:
```bash
kloc-cli {command} "App\Service\PaymentService" --sot sot.json
```

**With options**:
```bash
kloc-cli {command} "App\Service\PaymentService" --sot sot.json --{option} {value}
```

---

## Expected Output

### Human-readable format

```
{Feature Name} for App\Service\PaymentService:

{Descriptive header}

  {CATEGORY}  {Item name}
              {Detail line 1}
              {Detail line 2}

  {CATEGORY}  {Another item}
              {Detail line 1}

Summary: {X items found, Y recommendations}
```

### JSON format (--json)

```json
{
  "symbol": "App\\Service\\PaymentService",
  "results": [
    {
      "type": "{category}",
      "name": "{item name}",
      "details": {
        "{key}": "{value}"
      }
    }
  ],
  "summary": {
    "total": 0,
    "by_category": {}
  }
}
```

---

## Use Cases

### Use Case 1: {Scenario Name}

**Persona**: {AI Agent / Developer / Tech Lead}

**Situation**: {Context - what is happening}

**Goal**: {What the user wants to achieve}

**Action**:
```bash
kloc-cli {command} {args} --sot sot.json
```

**Expected result**:
```
{What the user sees}
```

**Value delivered**: {Why this helps the user}

---

### Use Case 2: {Scenario Name}

**Persona**: {AI Agent / Developer / Tech Lead}

**Situation**: {Context - what is happening}

**Goal**: {What the user wants to achieve}

**Action**:
```bash
kloc-cli {command} {args} --sot sot.json
```

**Expected result**:
```
{What the user sees}
```

**Value delivered**: {Why this helps the user}

---

### Use Case 3: {Scenario Name}

**Persona**: {AI Agent / Developer / Tech Lead}

**Situation**: {Context - what is happening}

**Goal**: {What the user wants to achieve}

**Action**:
```bash
kloc-cli {command} {args} --sot sot.json
```

**Expected result**:
```
{What the user sees}
```

**Value delivered**: {Why this helps the user}

---

## Reference Examples

### From kloc-reference-project-php

{If applicable, reference real code from the reference project}

**File**: `kloc-reference-project-php/src/{path}`

**Relevant pattern**:
```php
// Code snippet showing the pattern this feature would analyze
```

**How this feature applies**:
{Explain what the feature would do with this code}

---

### Pseudocode Example

{If no reference project example exists, create illustrative PHP code}

```php
<?php
// Example: {What this code demonstrates}

namespace App\Example;

class {ExampleClass}
{
    // {Comment explaining what this illustrates}
    public function {exampleMethod}(): void
    {
        // {Implementation that shows the feature's use case}
    }
}
```

**What the feature detects/analyzes**:
{Explain how the feature would process this example}

---

## Edge Cases

| Scenario | Input | Expected Behavior |
|----------|-------|-------------------|
| {Edge case 1} | `{example input}` | {What should happen} |
| {Edge case 2} | `{example input}` | {What should happen} |
| {Edge case 3} | `{example input}` | {What should happen} |
| Empty results | `{example}` | Clear message: "No {items} found" |
| Invalid symbol | `{nonexistent}` | Error: "Symbol not found: {symbol}" |

---

## Future Potential

### Immediate extensions
- {What could be added in v2 of this feature}
- {Additional options or modes}

### Enables future features
- {What bigger features this unlocks}
- {How this builds toward the intelligent service vision}

### Integration opportunities
- {How this could work with other kloc commands}
- {MCP/AI agent integration possibilities}

---

## Complexity Assessment

**Estimated effort**: {S / M / L}

**Requires**:
- [ ] New CLI command
- [ ] New query type
- [ ] Schema changes
- [ ] Index changes
- [ ] New output formatter

**Dependencies**:
- {List any features that must exist first}
- {Or "None - can be implemented independently"}

**Risks**:
- {Potential issues or challenges}

---

## Success Criteria

When this feature is complete, users can:
1. {Specific capability 1}
2. {Specific capability 2}
3. {Specific capability 3}

**Measurable outcomes**:
- {How we know this is working - e.g., "AI agents can complete X task with Y% fewer queries"}

---

## Open Questions

- {Any unresolved design decisions}
- {Questions that need user input}
- {Technical uncertainties}

---

## Related

- **Existing commands**: {Links to related kloc-cli commands}
- **Specs**: {Links to related feature specs in docs/specs/}
- **Issues**: {Any related issues or discussions}
