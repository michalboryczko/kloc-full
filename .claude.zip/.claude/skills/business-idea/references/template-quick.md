# Feature Ideas: {Topic}

> Generated: {date}
> Mode: Quick listing

## Overview

{1-2 sentences describing this collection of ideas}

---

## Ideas

### 1. {Feature Name}

**One-liner**: {Single sentence description}

**User benefit**: {Who benefits and how}

**CLI interface**:
```bash
kloc-cli {command} {args} --sot sot.json
```

**Example output**:
```
{Brief example of what user would see}
```

**Complexity**: {S / M / L}
**Dependencies**: {None / List prerequisites}
**Enables**: {What future features this unlocks}

---

### 2. {Feature Name}

**One-liner**: {Single sentence description}

**User benefit**: {Who benefits and how}

**CLI interface**:
```bash
kloc-cli {command} {args} --sot sot.json
```

**Example output**:
```
{Brief example of what user would see}
```

**Complexity**: {S / M / L}
**Dependencies**: {None / List prerequisites}
**Enables**: {What future features this unlocks}

---

{Repeat for each idea}

---

## Priority Matrix

| # | Feature | Value | Effort | Priority |
|---|---------|-------|--------|----------|
| 1 | {name} | High/Med/Low | S/M/L | {1-N} |
| 2 | {name} | High/Med/Low | S/M/L | {1-N} |

## Recommended Order

1. **Start with**: {Feature} — {Why this first}
2. **Then**: {Feature} — {Why this second}
3. **Later**: {Feature} — {Why defer this}

---

## Notes

{Any additional context, constraints, or considerations}
