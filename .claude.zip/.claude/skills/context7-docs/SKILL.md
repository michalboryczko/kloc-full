---
name: context7-docs
description: Fetch up-to-date library documentation using Context7 MCP tools. This skill should be used automatically when working with external libraries, frameworks, or APIs where current documentation would improve code quality. Triggers include implementing features with unfamiliar libraries, debugging library-specific issues, checking API signatures, or verifying best practices for any programming library.
---

# Context7 Docs

## Overview

This skill provides access to up-to-date documentation for any programming library or framework through Context7 MCP tools. Use it proactively when working with external dependencies to ensure code follows current APIs and best practices.

## When to Use

Automatically fetch documentation when:

- Implementing features using external libraries (React, Express, Prisma, etc.)
- Debugging issues that may stem from incorrect API usage
- Unsure about method signatures, parameters, or return types
- Checking for deprecated patterns or recommended alternatives
- Working with libraries that have frequent updates (AI/ML frameworks, frontend frameworks)

## Workflow

### Step 1: Resolve Library ID

Before querying documentation, resolve the library name to a Context7-compatible ID:

```
mcp__context7__resolve-library-id
  libraryName: "react"
  query: "How to use useEffect cleanup function"
```

The query parameter helps rank results by relevance. Select the most appropriate library based on:
- Name similarity (exact matches prioritized)
- Documentation coverage (higher code snippet counts preferred)
- Source reputation

### Step 2: Query Documentation

Once you have the library ID, fetch relevant documentation:

```
mcp__context7__query-docs
  libraryId: "/vercel/next.js"
  query: "How to set up authentication with middleware"
```

Write specific, detailed queries. Good examples:
- "How to set up authentication with JWT in Express.js"
- "React useEffect cleanup function examples"
- "Prisma transaction handling with error rollback"

Avoid vague queries like "auth" or "hooks".

## Guidelines

- Limit to 3 tool calls per question - if not found after 3 attempts, proceed with best available information
- If user provides a library ID directly (format: `/org/project`), skip the resolve step
- Prefer fetching docs proactively rather than guessing at APIs
- When documentation reveals breaking changes or deprecations, inform the user
