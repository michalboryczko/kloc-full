#!/usr/bin/env bash
set -euo pipefail

PROGRESS_DIR=".claude/progress"

usage() {
  cat <<'EOF'
Usage: progress.sh <command> [args]

Commands:
  init <feature-name> [version]      Create a new progress file (auto-increments version if not specified)
  add-step <feature> <version> <title>       Add a step, prints step number
  add-substep <feature> <version> <step#> <title>  Add a substep under a step
  status <feature> <version> <ref> <status>  Set status (ref: 1, 1.1, etc.)
                                   status: done|in_progress|waiting|pending
  show <feature> [version]           Display the progress file (latest if version omitted)
EOF
  exit 1
}

# Get the directory for a feature
feature_dir() {
  echo "${PROGRESS_DIR}/${1}"
}

# Get the progress file path for a feature and version
progress_file() {
  local feature="$1"
  local version="$2"
  echo "${PROGRESS_DIR}/${feature}/progress-v${version}.md"
}

# Find the latest version number for a feature (0 if none exist)
latest_version() {
  local feature="$1"
  local dir
  dir=$(feature_dir "$feature")
  if [[ ! -d "$dir" ]]; then
    echo "0"
    return
  fi
  local max=0
  for f in "$dir"/progress-v*.md; do
    [[ -e "$f" ]] || continue
    if [[ "$f" =~ progress-v([0-9]+)\.md$ ]]; then
      local n="${BASH_REMATCH[1]}"
      (( n > max )) && max=$n
    fi
  done
  echo "$max"
}

# Get next version number
next_version() {
  local feature="$1"
  local latest
  latest=$(latest_version "$feature")
  echo $(( latest + 1 ))
}

ensure_file() {
  local feature="$1"
  local version="$2"
  local f
  f=$(progress_file "$feature" "$version")
  if [[ ! -f "$f" ]]; then
    echo "Error: Progress file not found: $f" >&2
    exit 1
  fi
  echo "$f"
}

cmd_init() {
  local name="$1"
  local version="${2:-}"

  # Auto-determine version if not specified
  if [[ -z "$version" ]]; then
    version=$(next_version "$name")
  fi

  local dir
  dir=$(feature_dir "$name")
  local f
  f=$(progress_file "$name" "$version")

  mkdir -p "$dir"
  if [[ -f "$f" ]]; then
    echo "Progress file already exists: $f"
    exit 1
  fi
  cat > "$f" <<TMPL
# Progress: ${name} (v${version})

<!-- Steps are numbered. Substeps use parent.child notation. -->
<!-- Status markers: [ ] pending, [~] in_progress, [w] waiting, [x] done -->

TMPL
  echo "Created $f"
}

next_step_num() {
  local f="$1"
  local max=0
  while IFS= read -r line; do
    if [[ "$line" =~ ^##\ ([0-9]+)\. ]]; then
      local n="${BASH_REMATCH[1]}"
      (( n > max )) && max=$n
    fi
  done < "$f"
  echo $(( max + 1 ))
}

cmd_add_step() {
  local name="$1" version="$2" title="$3"
  local f
  f=$(ensure_file "$name" "$version")
  local num
  num=$(next_step_num "$f")
  echo "## ${num}. [ ] ${title}" >> "$f"
  echo ""  >> "$f"
  echo "$num"
}

next_substep_num() {
  local f="$1" step="$2"
  local max=0
  local in_step=0
  while IFS= read -r line; do
    if [[ "$line" =~ ^##\ ${step}\. ]]; then
      in_step=1
      continue
    fi
    if [[ $in_step -eq 1 && "$line" =~ ^## ]]; then
      break
    fi
    if [[ $in_step -eq 1 && "$line" =~ ^-\ \[.\]\ \*\*${step}\.([0-9]+)\*\* ]]; then
      local n="${BASH_REMATCH[1]}"
      (( n > max )) && max=$n
    fi
  done < "$f"
  echo $(( max + 1 ))
}

cmd_add_substep() {
  local name="$1" version="$2" step="$3" title="$4"
  local f
  f=$(ensure_file "$name" "$version")
  local sub
  sub=$(next_substep_num "$f" "$step")
  local ref="${step}.${sub}"

  # Find the step heading line number and insert after last substep or heading
  local insert_after=0
  local ln=0
  local in_step=0
  while IFS= read -r line; do
    ln=$(( ln + 1 ))
    if [[ "$line" =~ ^##\ ${step}\. ]]; then
      in_step=1
      insert_after=$ln
      continue
    fi
    if [[ $in_step -eq 1 ]]; then
      if [[ "$line" =~ ^## ]]; then
        break
      fi
      # Track any non-empty line (substeps) as last content line
      if [[ "$line" =~ ^- ]]; then
        insert_after=$ln
      fi
    fi
  done < "$f"

  if [[ $insert_after -eq 0 ]]; then
    echo "Error: Step $step not found" >&2
    exit 1
  fi

  local substep_line="- [ ] **${ref}** ${title}"
  local tmp
  tmp=$(mktemp)
  head -n "$insert_after" "$f" > "$tmp"
  echo "$substep_line" >> "$tmp"
  tail -n +"$(( insert_after + 1 ))" "$f" >> "$tmp"
  mv "$tmp" "$f"
  echo "$ref"
}

status_marker() {
  case "$1" in
    done)        echo "x" ;;
    in_progress) echo "~" ;;
    waiting)     echo "w" ;;
    pending)     echo " " ;;
    *) echo "Error: Invalid status: $1 (use done|in_progress|waiting|pending)" >&2; exit 1 ;;
  esac
}

cmd_status() {
  local name="$1" version="$2" ref="$3" status="$4"
  local f
  f=$(ensure_file "$name" "$version")
  local marker
  marker=$(status_marker "$status")

  if [[ "$ref" =~ \. ]]; then
    # Substep: - [.] **ref** ...
    sed -i '' "s/^- \[.\] \*\*${ref}\*\*/- [${marker}] **${ref}**/" "$f"
  else
    # Step: ## N. [.] ...
    sed -i '' "s/^## ${ref}\. \[.\]/## ${ref}. [${marker}]/" "$f"
  fi
  echo "Updated ${ref} -> ${status}"
}

cmd_show() {
  local name="$1"
  local version="${2:-}"

  # If version not specified, use latest
  if [[ -z "$version" ]]; then
    version=$(latest_version "$name")
    if [[ "$version" == "0" ]]; then
      echo "Error: No progress files found for feature: $name" >&2
      exit 1
    fi
  fi

  local f
  f=$(ensure_file "$name" "$version")
  cat "$f"
}

[[ $# -lt 1 ]] && usage

cmd="$1"; shift

case "$cmd" in
  init)       [[ $# -lt 1 ]] && usage; cmd_init "$1" "${2:-}" ;;
  add-step)   [[ $# -lt 3 ]] && usage; cmd_add_step "$1" "$2" "$3" ;;
  add-substep) [[ $# -lt 4 ]] && usage; cmd_add_substep "$1" "$2" "$3" "$4" ;;
  status)     [[ $# -lt 4 ]] && usage; cmd_status "$1" "$2" "$3" "$4" ;;
  show)       [[ $# -lt 1 ]] && usage; cmd_show "$1" "${2:-}" ;;
  *) usage ;;
esac
