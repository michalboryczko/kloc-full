---
name: progress-tracker
description: Track progress on features and tasks using structured markdown files with steps and substeps. This skill should be used when starting work on a feature, multi-step task, or any work that benefits from tracking completion of individual steps. It provides commands to initialize progress files, add steps and substeps, and update their status.
allowed-tools: Bash(rm -rf .claude/progress/*)
argument-hint: [feature-name or path to plan/spec file]
---

# Progress Tracker

## Overview

Track feature and task progress using structured markdown files stored in `.claude/progress/{feature_name}/`. Each feature gets a dedicated directory with versioned progress files (`progress-v1.md`, `progress-v2.md`, etc.) containing numbered steps and substeps, each with a status marker (pending, in_progress, waiting, done).

## Script Location

The bundled script is at: `scripts/progress.sh` (relative to this skill directory).

Set the script path variable before use:

```bash
PROGRESS_SCRIPT="<skill-directory>/scripts/progress.sh"
```

## Commands

### Initialize a feature

```bash
bash "$PROGRESS_SCRIPT" init <feature-name> [version]
```

Creates `.claude/progress/<feature-name>/progress-v<version>.md`. Version auto-increments from highest existing version (or v1 if none) if not specified.

### Add a step

```bash
bash "$PROGRESS_SCRIPT" add-step <feature-name> <version> "Step title"
```

Prints the step number (e.g., `1`). Use this number to add substeps.

### Add a substep

```bash
bash "$PROGRESS_SCRIPT" add-substep <feature-name> <version> <step#> "Substep title"
```

Prints the substep reference (e.g., `1.2`).

### Update status

```bash
bash "$PROGRESS_SCRIPT" status <feature-name> <version> <ref> <status>
```

- `ref`: Step number (`1`) or substep reference (`1.2`)
- `status`: `done`, `in_progress`, `waiting`, or `pending`

### Show progress

```bash
bash "$PROGRESS_SCRIPT" show <feature-name> [version]
```

If version is omitted, shows the latest version.

## Workflow

1. At the start of a feature, run `init` with a kebab-case feature name.
2. Break the work into steps using `add-step`. Record the returned step numbers.
3. For granular tracking, add substeps using `add-substep` with the parent step number.
4. Before starting work on a step, mark it `in_progress`.
5. After completing a step, mark it `done`.
6. Use `show` to review current progress at any time.

## Initialize from a plan or spec file

When `$ARGUMENTS` contains a file path (plan, spec, or context file), read that file and generate a progress tracker from its content:

1. **Read the file** — use the Read tool to load the referenced file immediately.
2. **Extract steps** — identify phases, sections, numbered steps, or checkbox items from the file structure. Each top-level phase/section becomes a **step**. Each sub-task, checkbox, or file-level change within a phase becomes a **substep**.
3. **Derive feature name** — use kebab-case from the file's title or filename (e.g., `docs/specs/scip-php-calls-tracking.md` → `scip-php-calls-tracking`).
4. **Determine version** — check `.claude/progress/<name>/` for existing versions and auto-increment (or use v1 if none).
5. **Run the script** — call `init`, then `add-step` for each step (capture returned step number), then `add-substep` for each sub-task using the parent step number.
6. **Verify completeness** — run `show` and confirm every phase/step from the source file is represented. If anything is missing, add it. All statuses must be `pending`.

### Mapping rules

- Phase/section headings → steps (imperative form: "Add X" not "X")
- Checkbox items (`- [ ]`) → substeps under their parent phase
- File manifest entries → substeps under the relevant step
- Always add a final step "Testing and validation" if the source file includes test cases
- Never mark anything as `in_progress` or `done` — all items start as `pending`

## File Format

Progress files use this structure:

```markdown
# Progress: feature-name

## 1. [x] First step
- [x] **1.1** Substep one
- [~] **1.2** Substep two

## 2. [ ] Second step

## 3. [w] Third step (waiting)
```

Status markers: `[ ]` pending, `[~]` in_progress, `[w]` waiting, `[x]` done.
