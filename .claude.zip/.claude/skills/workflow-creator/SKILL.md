---
name: workflow-creator
description: "Generate Claude Code workflows for multi-agent orchestration. This skill should be used when creating new workflows that coordinate multiple agents, refactoring existing workflows between Task-driven and Standard patterns, or when the user needs to understand workflow architecture. Triggers include: 'create a workflow for...', 'make a workflow', 'refactor workflow to use agents', 'convert to standard workflow', or when designing multi-step orchestration."
argument-hint: "[workflow-name] [--type task|standard] [--from existing-workflow]"
---

# Workflow Creator

Generate and refactor Claude Code workflows for multi-agent orchestration.

## Overview

Workflows are instructions that main Claude executes directly, enabling spawning of subagents (which subagents themselves cannot do). This skill creates two types of workflows:

| Type | Description | Agent Reuse | Best For |
|------|-------------|-------------|----------|
| **Task-driven** | Uses Task tool to spawn/resume agents | Yes (via agent IDs) | Complex orchestration, agent state preservation |
| **Standard** | Passes context as references between steps | No | Simple orchestration, stateless execution |

## Workflow Output Location

All workflows are created in: `.claude/workflows/{workflow-name}/`

```
.claude/workflows/{workflow-name}/
├── workflow.md    # Main workflow definition
└── CLAUDE.md      # Quick reference for the workflow
```

## Workflow Types

### Task-Driven Workflows

Use `Task(subagent_type, resume)` to spawn and resume agents. Agents maintain state across invocations.

**Key features:**
- Store and reuse agent IDs: `qa_agent_id = {returned_agent_id}`
- Resume agents with context: `Task(resume: "{agent_id}", prompt: "...")`
- Agents can run tests, validate work, maintain conversation history
- Better for iterative loops (fix → test → fix)

**Pattern:**
```markdown
### Step N: Spawn Agent
1. Spawn agent:
   Task(subagent_type: "my-agent", prompt: "...")
2. Store agent ID: `agent_id = {returned_id}`

### Step N+1: Resume Agent
1. Resume with new context:
   Task(resume: "{agent_id}", prompt: "Validate changes...")
```

### Standard Workflows

Pass context as file references between steps. Each agent invocation is stateless.

**Key features:**
- Context passed via file paths in prompts
- Simpler mental model - no state to track
- Better for independent steps that don't need conversation history
- Each step reads/writes to well-defined file locations

**Pattern:**
```markdown
### Step N: First Agent
1. Spawn agent:
   Task(subagent_type: "agent-a", prompt: "
        Read context: docs/specs/{feature}.md
        Write output: .claude/progress/{feature}/step-n.md")

### Step N+1: Second Agent
1. Spawn agent:
   Task(subagent_type: "agent-b", prompt: "
        Read context: .claude/progress/{feature}/step-n.md
        Continue work...")
```

## Usage

### Create New Workflow

When `$ARGUMENTS` contains a workflow name and optionally `--type`:

1. **Determine type**: Default to `standard` unless `--type task` specified or the workflow requires agent state reuse
2. **Gather requirements**: Ask about:
   - What agents will be spawned?
   - What's the input/output for each step?
   - Are there validation loops? (suggest Task-driven if yes)
   - What context files are needed?
3. **Generate workflow**: Create `workflow.md` and `CLAUDE.md`

### Refactor Existing Workflow

When `$ARGUMENTS` contains `--from {existing-workflow}`:

1. Read the existing workflow
2. Determine target type (opposite of current, or specified via `--type`)
3. Convert:
   - **Standard → Task-driven**: Add agent ID tracking, convert to resume pattern
   - **Task-driven → Standard**: Remove resume, add file-based context passing
4. Write refactored workflow

## Workflow Template Structure

Every workflow.md MUST follow this structure:

```markdown
# {Workflow Name}

{Brief description of what the workflow accomplishes}

## Required Context

| Field | Required | Description |
|-------|----------|-------------|
| `field_name` | Yes/No | What this field is for |

### Validation Rules

- Rule 1: Field X must be kebab-case
- Rule 2: If A provided, B must also be provided

## Progress Tracking

Progress files: `.claude/progress/{identifier}/`
{Other artifact locations}

## Workflow Steps

### Step 1: {Name}

**Goal**: {What this step achieves}

**Actions**:
1. {Action to take}
2. {Another action}

**Completion Criteria**:
- {How to verify this step is complete}

---

### Step N: {Subagent Step}

**Goal**: {What this step achieves}

**CRITICAL**: Spawn subagent using Task tool.

**Actions**:
1. Spawn subagent:
   ```
   Task(
     subagent_type: "{agent-name}",
     prompt: "{detailed prompt with context}"
   )
   ```
2. {Handle result}

**Completion Criteria**:
- {Verification}

---

### Final Step: Summary

**Goal**: Report completion to user.

**Actions**:
1. Summarize what was accomplished
2. List files created/modified
3. Report status
4. Suggest next steps

## Error Handling

- {How to handle specific failures}
- {Recovery options}

## Rules

- {Workflow-specific rules}
- NEVER skip steps
- NEVER push to remote unless explicitly requested
```

## CLAUDE.md Template

Create a quick reference file:

```markdown
# {Workflow Name}

{One-line description}

## Quick Start

```
/run-workflow {workflow-name}

Field 1: value
Field 2: value
```

## Steps Overview

1. **Step Name** - Brief description
2. **Step Name** - Brief description
...

## Agents Used

- `agent-name` - What it does

## Key Files

- `path/to/file` - Description
```

## Decision Guide: Which Type to Use?

Ask these questions:

1. **Does any agent need to remember previous conversation?**
   - Yes → Task-driven (use resume)
   - No → Either works

2. **Are there validation/fix loops?**
   - Yes → Task-driven (resume QA agent for re-validation)
   - No → Standard is fine

3. **Do agents need to verify their own changes?**
   - Yes → Task-driven (agent runs tests, reports back)
   - No → Standard is fine

4. **Is context complex and needs summarization between steps?**
   - Yes → Task-driven (agent summarizes, orchestrator passes summary)
   - No → Standard (just pass file paths)

## Parallel Execution

Both workflow types support parallel agent spawning:

```markdown
### Step N: Parallel Work

**CRITICAL**: Spawn ALL agents in a SINGLE message.

**Actions**:
1. Prepare context for each target
2. Spawn in parallel (one message, multiple Task calls):
   - Task(subagent_type: "worker", prompt: "Target 1...")
   - Task(subagent_type: "worker", prompt: "Target 2...")
   - Task(subagent_type: "worker", prompt: "Target 3...")
3. Collect all results
```

## References

See `references/` for:
- `workflow-pattern-guide.md` - Generic workflow pattern documentation
- `workflows-architecture.md` - Architecture decisions and rationale
- `example-task-driven.md` - Full Task-driven workflow example
- `example-standard.md` - Full Standard workflow example
