# Workflows Architecture Documentation

This document explains the workflow system architecture, why it was created, and how to use it.

## The Problem: Agents Cannot Spawn Subagents

### Original Architecture (Agent-Based)

```
Main Claude
    └── Task(subagent_type: "cross-project-sync")
            └── cross-project-sync agent runs
                    └── ❌ CANNOT spawn project-changes-implementer
                        (subagents don't have Task tool with subagent_type)
```

**Why it fails:**
- When Claude spawns an agent using `Task(subagent_type: "...")`, that agent runs as a **subagent**
- Subagents receive a **restricted toolset** - they do NOT get the `Task` tool with `subagent_type` parameter
- This is by design in Claude Code to prevent infinite recursion
- Result: An agent that needs to orchestrate other agents **cannot do so**

### New Architecture (Workflow-Based)

```
Main Claude
    └── Reads workflow.md (skill loads it)
    └── Executes steps in MAIN context
            └── Step 4: Task(subagent_type: "project-changes-implementer") ✅ WORKS!
            └── Step 4: Task(subagent_type: "project-changes-implementer") ✅ WORKS!
            └── ... (parallel execution)
```

**Why it works:**
- Workflows are **instructions** executed by **main Claude**, not a subagent
- Main Claude HAS the full `Task` tool with `subagent_type` parameter
- Main Claude can spawn as many subagents as needed
- Subagents return results to main Claude, which continues the workflow

## Architecture Components

### 1. Workflows Directory

Location: `.claude/workflows/`

```
.claude/workflows/
├── cross-project-sync/
│   └── workflow.md
├── another-workflow/
│   └── workflow.md
└── ...
```

Each workflow has its own directory containing `workflow.md`.

### 2. Workflow File Structure

A workflow.md file contains:

```markdown
# Workflow Name

Description of what this workflow does.

## Required Context

| Field | Required | Description |
|-------|----------|-------------|
| `field_name` | Yes/No | What this field is for |

## Workflow Steps

### Step 1: Name
**Goal**: What this step achieves
**Actions**: What to do
**Completion Criteria**: How to know it's done

### Step 2: Name
...

### Step N: Spawn Subagents (if needed)
**CRITICAL**: Use Task tool with subagent_type to spawn agents in parallel
```

### 3. Run-Workflow Skill

Location: `.claude/skills/run-workflow/SKILL.md`

The skill's job:
1. **Discover** - List available workflows in `.claude/workflows/`
2. **Match** - Find the workflow user requested (exact, partial, or semantic match)
3. **Validate** - Check if required context is provided
4. **Execute** - Tell main Claude to follow the workflow steps

### 4. Subagent Definitions

Location: `.claude/agents/`

Agents like `project-changes-implementer` are still defined as agents because:
- They are **spawned BY** the workflow (not spawning others)
- They do focused, single-project work
- They don't need to spawn further subagents

## How It All Works Together

### Invocation Flow

```
User: "/run-workflow cross-project-sync to implement X"
                    │
                    ▼
┌─────────────────────────────────────────────┐
│ run-workflow SKILL                          │
│ 1. Lists .claude/workflows/                 │
│ 2. Matches "cross-project-sync"             │
│ 3. Reads workflow.md                        │
│ 4. Validates required context               │
│ 5. Returns workflow instructions to Claude  │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│ MAIN CLAUDE executes workflow steps         │
│                                             │
│ Step 1: Analyze requirements                │
│         → Creates 01-requirements.md        │
│                                             │
│ Step 2: Find related projects               │
│         → Creates 02-related-projects.md    │
│                                             │
│ Step 3: Initialize git                      │
│         → Creates 03-git-initialization.md  │
│                                             │
│ Step 4: SPAWN SUBAGENTS (parallel)          │
│         → Task(project-changes-implementer) │
│         → Task(project-changes-implementer) │
│         → Task(project-changes-implementer) │
│         → ... (all in ONE message)          │
│         → Creates 04-implementation.md      │
│                                             │
│ Step 5: Review and commit                   │
│         → Creates 05-commits.md             │
│                                             │
│ Step 6: Create summary                      │
│         → Creates SUMMARY.md                │
└─────────────────────────────────────────────┘
```

### Key Insight: Parallel Subagent Spawning

The workflow instructs main Claude to spawn multiple subagents in a **single message**.
When main Claude sends one message with multiple Task tool calls, they execute in parallel:

```
Task tool call 1: subagent_type="project-changes-implementer", project="admin-api"
Task tool call 2: subagent_type="project-changes-implementer", project="order-api"
Task tool call 3: subagent_type="project-changes-implementer", project="scoring-api"
... all in the same message = parallel execution
```

## Comparison: Agent vs Workflow

| Aspect | Agent | Workflow |
|--------|-------|----------|
| Runs in | Subagent context | Main Claude context |
| Can spawn subagents | ❌ No | ✅ Yes |
| Has full Task tool | ❌ No | ✅ Yes |
| Context isolation | ✅ Isolated | ❌ Uses main context |
| Good for | Leaf tasks, focused work | Orchestration, multi-step coordination |

## When to Use What

### Use an AGENT when:
- The task is focused on a single unit of work
- No need to spawn other agents
- You want context isolation
- Examples: `project-changes-implementer`, `git-initializer`

### Use a WORKFLOW when:
- You need to orchestrate multiple agents
- The task has multiple sequential steps
- You need to spawn subagents in parallel
- Examples: `cross-project-sync`, any multi-project coordination

## Creating a New Workflow

### Step 1: Create the directory

```bash
mkdir -p .claude/workflows/my-workflow/
```

### Step 2: Create workflow.md

```markdown
# My Workflow

Description of what this workflow does.

## Required Context

| Field | Required | Description |
|-------|----------|-------------|
| `task_description` | Yes | What to do |
| `optional_field` | No | Extra info |

## Progress Tracking Directory

All progress files: `/path/to/progress/{identifier}/`

## Workflow Steps

### Step 1: Preparation
**Goal**: Set up for the task
**Actions**:
1. Do something
2. Create progress file: `01-preparation.md`
**Completion Criteria**: File created

### Step 2: Execute
**Goal**: Do the main work
**Actions**:
1. If parallel work needed, spawn subagents:
   - Use Task tool with subagent_type
   - Spawn ALL in a single message for parallel execution
2. Create progress file: `02-execution.md`
**Completion Criteria**: All subagents completed

### Step 3: Finalize
**Goal**: Wrap up
**Actions**:
1. Collect results
2. Create SUMMARY.md
**Completion Criteria**: Summary created
```

### Step 3: The skill auto-discovers it

The `run-workflow` skill automatically lists `.claude/workflows/` directories, so new workflows are immediately available.

## File Locations Summary

```
.claude/
├── workflows/                      # Workflow definitions
│   └── cross-project-sync/
│       └── workflow.md
│
├── skills/                         # Skills (including run-workflow)
│   └── run-workflow/
│       └── SKILL.md
│
├── agents/                         # Agent definitions (leaf workers)
│   ├── project-changes-implementer.md
│   └── git-initializer.md
│
└── docs/                           # Documentation
    └── workflows-architecture.md   # This file
```

## Progress Tracking

Workflows create progress files in a dedicated directory:

```
/home/michal-boryczko/paypo/agent/cross-project-sync/{ticket}/
├── 01-requirements.md
├── 02-related-projects.md
├── 03-git-initialization.md
├── 04-implementation.md
├── 05-commits.md
└── SUMMARY.md
```

This allows:
- Resuming interrupted workflows
- Auditing what was done
- Debugging failures
- Tracking progress across multiple runs

## Key Takeaways

1. **Subagents cannot spawn subagents** - this is a Claude Code design decision
2. **Workflows run in main context** - they CAN use the full Task tool
3. **Use workflows for orchestration** - when you need to coordinate multiple agents
4. **Use agents for leaf work** - focused, single-purpose tasks
5. **Skills bridge the gap** - the run-workflow skill loads and validates workflows
6. **Parallel execution** - spawn multiple subagents in one message for parallelism
