# Example: Standard Workflow

This is the Feature Orchestrator workflow - a Standard workflow that passes context via file references between steps.

## Key Characteristics

1. **File-Based Context**: Each step reads from and writes to specific file paths
2. **Stateless Agents**: Each agent invocation is independent (no resume)
3. **Context as References**: Prompts include file paths for agents to read
4. **Fresh Invocations**: Each step spawns a fresh agent instance

## Workflow Summary

```
Step 1: Feature Spec (skill) → writes docs/specs/{feature}.md
Step 2: Planning (agent) → reads spec, writes plan + progress files
Step 2.5: QA Notes (agent) → reads spec+plan, writes QA notes
Step 3: Implementation (agent) → reads all above, implements feature
Step 4: QA Validation (agent) → reads QA notes, validates feature
Step 4.5: Fix Loop (fresh agents each time)
Step 5: Progress Validation
Step 6: Summary
```

## Context Passing Pattern

### Step Writes Output

```markdown
### Step 2: Feature Planning (Subagent)

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "feature-planner",
     prompt: "Plan the feature {feature_name}.
              Spec file: docs/specs/{feature_name}.md
              Context files: {context_files}
              Feature name: {feature_name}"
   )
   ```

**Completion Criteria**:
- Plan file exists at `docs/specs/{feature_name}-plan.md`
- Progress file exists at `.claude/progress/{feature_name}.md`
```

### Next Step Reads Previous Output

```markdown
### Step 3: Feature Implementation (Subagent)

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "feature-implementer",
     prompt: "Implement feature {feature_name} following the plan.
              Plan file: docs/specs/{feature_name}-plan.md
              Spec file: docs/specs/{feature_name}.md
              Progress file: .claude/progress/{feature_name}.md
              QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md
              Context files: {context_files}"
   )
   ```
```

### Validation with Fresh Agent

```markdown
### Step 4: QA Validation (Subagent)

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "generalist-qa",
     prompt: "Test the implemented feature: {feature_name}

              ## Context
              - Feature spec: docs/specs/{feature_name}.md
              - Implementation plan: docs/specs/{feature_name}-plan.md
              - QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md
              - Progress file: .claude/progress/{feature_name}.md

              ## Context from Implementer
              {summary_of_what_implementer_built}

              ## Required
              Run tests, verify behaviors, report PASS or FAIL"
   )
   ```
```

## When to Use This Pattern

- Steps are largely independent
- No need for agent to remember previous conversations
- Context can be fully captured in files
- Simpler mental model preferred
- Each validation run should be clean/unbiased

## Comparison with Task-Driven

| Aspect | Standard | Task-Driven |
|--------|----------|-------------|
| Agent memory | None (fresh each time) | Preserved via resume |
| Context passing | File paths in prompt | Agent remembers + new prompt |
| Fix loops | Fresh QA agent each iteration | Resume same QA agent |
| Complexity | Simpler | More complex |
| Bias | Unbiased (fresh eyes each time) | May have confirmation bias |

## Full Workflow

See: `.claude/workflows/feature-orchestrator/workflow.md`
