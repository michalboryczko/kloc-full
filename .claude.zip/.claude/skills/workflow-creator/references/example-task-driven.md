# Example: Task-Driven Workflow

This is the TDD SCIP Orchestrator workflow - a Task-driven workflow that uses agent ID tracking and resume capability.

## Key Characteristics

1. **Agent ID Tracking**: Stores `qa_agent_id` from Step 2.5 for reuse in Steps 4 and 4.5
2. **Resume Pattern**: Uses `Task(resume: "{agent_id}")` to continue agent conversations
3. **Validation Loops**: QA agent is resumed multiple times during fix loops
4. **State Preservation**: QA agent maintains context about test scenarios across invocations

## Workflow Summary

```
Step 1: Feature Spec (skill)
Step 2: Planning (feature-planner agent)
Step 2.5: Contract Test Setup (scip-php-contract-qa agent) → STORE qa_agent_id
Step 3: Implementation (feature-implementer agent)
Step 4: Validation (RESUME qa_agent_id)
Step 4.5: Fix Loop (implementer → RESUME qa_agent_id → repeat)
Step 5: Progress Validation
Step 6: Summary
```

## Agent ID Usage Pattern

### Initial Spawn (Step 2.5)

```markdown
### Step 2.5: Contract Test Setup (Subagent) - TDD

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     prompt: "Run contract QA in SETUP mode..."
   )
   ```
2. **IMPORTANT**: Store the agent ID for later resume: `qa_agent_id = {returned_agent_id}`
```

### Resume for Validation (Step 4)

```markdown
### Step 4: Contract Test Validation (Subagent)

**CRITICAL**: Resume the same `scip-php-contract-qa` agent using the stored `qa_agent_id`.

**Actions**:
1. Resume the QA agent via Task tool:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_agent_id}",
     prompt: "Run contract QA in VALIDATE mode..."
   )
   ```
```

### Resume in Fix Loop (Step 4.5)

```markdown
### Step 4.5: Implementation Fix Loop

**Actions** (repeat until tests pass):
1. Spawn `feature-implementer` with failure context
2. Resume QA agent for re-validation:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_agent_id}",
     prompt: "Re-validate feature {feature_name} after fixes..."
   )
   ```
```

## When to Use This Pattern

- Agent needs to remember test scenarios created earlier
- Validation/fix loops where same agent should track what passed/failed
- Complex orchestration where agent context is valuable
- QA agent that builds up knowledge about the feature over time

## Full Workflow

See: `.claude/workflows/tdd-scip-orchestrator/workflow.md`
