# Workflow Pattern Guide for Claude Code

A generic guide for implementing multi-agent orchestration in Claude Code using the workflow pattern.

## The Core Problem

Claude Code has a limitation: **subagents cannot spawn other subagents**.

When you define a custom agent and Claude spawns it using the `Task` tool, that agent runs in a restricted context without access to the `Task(subagent_type)` tool. This prevents hierarchical agent architectures.

```
Main Claude (has Task tool with subagent_type)
    └── Spawns Agent A (subagent - NO Task tool with subagent_type)
            └── ❌ Cannot spawn Agent B
```

## The Solution: Workflow Pattern

Instead of defining orchestration logic as an agent, define it as a **workflow** - a set of instructions that **main Claude executes directly**.

```
Main Claude (has Task tool with subagent_type)
    └── Reads workflow instructions
    └── Executes steps itself
            └── ✅ Can spawn Agent A
            └── ✅ Can spawn Agent B
            └── ✅ Can spawn Agent C (all in parallel)
```

## Architecture Components

### 1. Workflows

**What**: Step-by-step instructions for main Claude to follow.

**Where**: `.claude/workflows/{workflow-name}/workflow.md`

**Purpose**: Define orchestration logic that may need to spawn multiple subagents.

### 2. Skills

**What**: Reusable capabilities that run in main Claude context.

**Where**: `.claude/skills/{skill-name}/SKILL.md`

**Purpose**: The `run-workflow` skill discovers, validates, and loads workflows.

### 3. Agents

**What**: Focused, single-purpose workers.

**Where**: `.claude/agents/{agent-name}.md`

**Purpose**: Leaf-level execution that doesn't need to spawn other agents.

## Directory Structure

```
.claude/
├── workflows/                    # Orchestration instructions
│   ├── workflow-a/
│   │   └── workflow.md
│   └── workflow-b/
│       └── workflow.md
│
├── skills/                       # Skills (run in main context)
│   └── run-workflow/
│       └── SKILL.md
│
└── agents/                       # Leaf workers (spawned by workflows)
    ├── worker-agent-1.md
    └── worker-agent-2.md
```

## Workflow File Template

```markdown
# Workflow Name

Brief description of what this workflow accomplishes.

## Required Context

Define what information must be provided to run this workflow:

| Field | Required | Description |
|-------|----------|-------------|
| `field_1` | Yes | Description of required field |
| `field_2` | No | Description of optional field |

### Validation Rules

- Rule 1: If X is provided, Y must also be provided
- Rule 2: Field Z can be inferred from W if not provided

## Progress Tracking

Where to store progress files: `/path/to/progress/{identifier}/`

## Workflow Steps

### Step 1: [Step Name]

**Goal**: What this step achieves.

**Actions**:
1. Action to take
2. Another action
3. Create progress file: `01-step-name.md`

**Completion Criteria**: How to verify this step is complete.

---

### Step 2: [Another Step]

**Goal**: What this step achieves.

**Actions**:
1. Action to take

---

### Step N: [Parallel Execution Step]

**Goal**: Execute work across multiple targets in parallel.

**CRITICAL**: Spawn subagents using the Task tool.

**Actions**:
1. Prepare context for each target
2. Spawn subagents in PARALLEL using a SINGLE message with MULTIPLE Task calls:
   - Task(subagent_type: "worker-agent", target: "target-1")
   - Task(subagent_type: "worker-agent", target: "target-2")
   - Task(subagent_type: "worker-agent", target: "target-3")
3. Wait for all to complete
4. Create progress file with results

---

### Final Step: Summary

**Goal**: Create final summary.

**Actions**:
1. Aggregate results from all steps
2. Create SUMMARY.md

## Error Handling

- How to handle failures
- Recovery options
- What to document when errors occur
```

## Run-Workflow Skill Template

```markdown
---
name: run-workflow
description: "Execute a multi-step workflow in the main Claude context.
Use when tasks require orchestrating multiple steps or spawning subagents.
Workflows run in main context so they CAN spawn subagents."
---

# Run Workflow Skill

## Workflow Location

Workflows stored in: `.claude/workflows/`

## Execution Process

### Step 1: Discover Workflows

List available workflows:
```bash
ls -1 .claude/workflows/
```

### Step 2: Match Workflow

Match user request to workflow using:
1. Exact match: "workflow-a" → workflow-a/
2. Partial match: "work a" → workflow-a/
3. Semantic match: "do the A thing" → workflow-a/

### Step 3: Read Workflow

Read the workflow definition:
```bash
cat .claude/workflows/{name}/workflow.md
```

### Step 4: Validate Context

Parse "Required Context" section and verify:
- All required fields are provided
- Validation rules pass
- If missing, ask user for information

### Step 5: Execute

Follow workflow steps in order:
1. Execute each step's actions
2. Create progress files
3. Verify completion criteria
4. When spawning subagents, use Task tool (works because we're in main context)
```

## Worker Agent Template

```markdown
---
name: worker-agent
description: "Focused worker that executes a specific task.
Spawned by workflows to handle individual units of work."
model: sonnet
---

# Worker Agent

You execute focused tasks as part of a larger workflow.

## Input

You receive:
- Task identifier
- Target/scope of work
- Specific instructions
- Any relevant context

## Working Directory

Store progress in: `/path/to/progress/{task}/{target}/`

Create these files:
- `plan.md` - What you'll do
- `progress.md` - Current status
- `changes.txt` - Files modified

## Execution

1. Create working directory
2. Create plan.md
3. Execute the task
4. Update progress.md
5. List changes in changes.txt

## Rules

- Follow instructions exactly
- Stay within scope
- Document everything
- Report completion status
```

## Key Concepts

### Why Workflows Work

| Aspect | Agent | Workflow |
|--------|-------|----------|
| Execution context | Subagent (restricted) | Main Claude (full access) |
| Task tool access | ❌ No subagent_type | ✅ Full access |
| Can spawn agents | ❌ No | ✅ Yes |
| Context isolation | ✅ Yes | ❌ No (uses main context) |

### Parallel Execution

To run multiple agents in parallel, spawn them in a **single message**:

```
Main Claude sends ONE message containing:
- Task call 1: worker-agent for target-1
- Task call 2: worker-agent for target-2
- Task call 3: worker-agent for target-3

All three execute simultaneously.
```

### Progress Tracking

Workflows should create progress files:
- Enables resuming interrupted workflows
- Provides audit trail
- Helps debug failures
- Shows status to user

### Context Validation

Always validate required context before execution:
- Prevents partial runs with missing data
- Asks user for missing information upfront
- Documents what's needed vs. optional

## When to Use What

### Use a WORKFLOW when:
- Task requires spawning multiple subagents
- Task has multiple sequential steps
- You need orchestration logic
- Parallel execution across targets is needed

### Use an AGENT when:
- Task is focused on single unit of work
- No need to spawn other agents
- Task benefits from context isolation
- It will be spawned BY a workflow

### Use a SKILL when:
- Capability should run in main context
- It's reusable across different tasks
- It doesn't require complex multi-step orchestration
- Examples: run-workflow, container-exec, git-commit

## Common Patterns

### Fan-Out Pattern

```
Workflow Step N:
    └── Spawn Agent for Target 1 ─┐
    └── Spawn Agent for Target 2  ├── Parallel
    └── Spawn Agent for Target 3 ─┘
    └── Collect all results
```

### Sequential with Parallel Middle

```
Step 1: Analyze (sequential)
Step 2: Prepare (sequential)
Step 3: Execute (parallel - spawn many agents)
Step 4: Verify (sequential)
Step 5: Commit (sequential)
```

### Conditional Spawning

```
Step N:
    If condition A: spawn agent-type-a
    If condition B: spawn agent-type-b
    Otherwise: skip
```

## Limitations

1. **Context usage**: Workflows run in main context, so results accumulate there
2. **No nested workflows**: A workflow cannot spawn another workflow as a subagent
3. **Manual orchestration**: You must implement the orchestration logic in workflow.md

## Best Practices

1. **Clear step boundaries**: Each step should have clear completion criteria
2. **Progress files**: Always create progress files for recoverability
3. **Validate early**: Check required context before starting work
4. **Parallel when possible**: Spawn independent agents in single message
5. **Keep agents focused**: Agents should do one thing well
6. **Document errors**: Workflow should specify error handling
