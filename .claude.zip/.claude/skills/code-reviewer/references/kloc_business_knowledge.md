# kloc Business Knowledge for Code Reviewers

This reference provides domain-specific knowledge that reviewers must be aware of when reviewing kloc code changes.

## What is kloc?

**KLOC** (Knowledge of Code) provides the best possible context for AI coding agents by mapping code structure and relationships into a queryable format.

### Core Components

| Component | Language | Purpose |
|-----------|----------|---------|
| **scip-php** | Go | PHP indexer — generates SCIP index from PHP source code |
| **kloc-mapper** | Python | Parses SCIP index into Source-of-Truth JSON (SoT JSON) |
| **kloc-cli** | Python | Loads SoT JSON and answers queries (usages, deps, context) |

### Data Flow

```
PHP Source Code → scip-php (Go indexer) → SCIP Index (.scip)
    → kloc-mapper (Python) → SoT JSON
    → kloc-cli (Python) → Query responses for AI agents
```

## Critical Domain Rules

### 1. Source-of-Truth (SoT) Model

The SoT JSON is the canonical data representation. When reviewing changes to kloc-mapper:

- **Node types**: File, Class, Interface, Trait, Method, Function, Property, Const, Argument, EnumCase
- **Edge types**: `contains`, `extends`, `implements`, `uses_trait`, `overrides`, `uses`
- **DIRECT FACTS ONLY** — Never store transitive relationships. If A extends B and B extends C, only store A→extends→B and B→extends→C, NOT A→extends→C
- **Deterministic output** — Same SCIP input must always produce identical JSON output. Watch for dict ordering, set iteration, unstable sorts
- **Containment hierarchy** — File→Class→Method→Argument must be correct. A Method cannot be a child of a File directly if it belongs to a Class

### 2. SCIP Symbol Format

SCIP symbols follow a strict format: `scheme manager package version descriptor`

When reviewing code that handles symbols:
- Never use string splitting/hacking to parse symbols — use proper SCIP parsing
- Symbol comparison must be exact (they are unique identifiers)
- `symbol_roles` is a bitmask — use bitwise operations, not equality checks
- Occurrence `range` can be 3-element `[line, startChar, endChar]` or 4-element `[startLine, startChar, endLine, endChar]`

### 3. scip-php Indexer (Go)

When reviewing Go indexer changes:
- Must produce valid SCIP protocol buffer output
- Symbol descriptors must follow SCIP spec (package, type, method, term, etc.)
- PHP-specific patterns to handle: traits, interfaces, abstract classes, enums, union types, nullable types
- `parent::` resolution must find actual ancestor method, not just parent class
- Contract tests in `kloc-reference-project-php/contract-tests/` validate indexer output — changes must not break existing tests
- Reference PHP code lives in `kloc-reference-project-php/src/` — this is test fixture code, not production code

### 4. kloc-cli Queries

When reviewing CLI changes:
- In-memory indexes must maintain O(1) lookup performance
- `symbol_to_node_id`, `node_id_to_node`, `incoming_edges`, `outgoing_edges` are the core indexes
- BFS expansion in `context` command must respect depth limits
- All commands must support `--json` output for machine consumption
- CLI is used by AI coding agents — response format and speed matter

### 5. kloc-mapper Pipeline

When reviewing mapper changes:
- Pipeline: Parse Protobuf → Extract Symbols → Build Edges → Normalize IDs → Output SoT JSON
- IDs must be stable and deterministic
- Edge building must handle: class inheritance, interface implementation, trait usage, method overrides, symbol references
- Override detection: only for same signature in direct parent chain

## Common Review Mistakes in kloc

### Things Reviewers Miss

1. **Transitive edges sneaking in** — A mapper change that adds "convenience" edges violates the direct-facts-only rule
2. **Non-deterministic JSON** — Using `dict` iteration order or `set` without sorting produces flaky output
3. **Symbol string manipulation** — Splitting on `/` or `.` instead of proper SCIP parsing breaks on edge cases
4. **Missing node types** — Adding support for a new PHP construct without updating both mapper AND cli
5. **Contract test breakage** — Indexer changes that alter symbol format or occurrence positions break downstream tests
6. **O(n) scans in CLI** — Adding a feature that iterates all nodes instead of using indexes degrades performance for large codebases

### Things Reviewers Should Flag

1. Changes to SoT JSON schema without updating both mapper and cli
2. New edge types without documentation in summary.md
3. Indexer changes without corresponding contract tests
4. CLI changes that don't support `--json` output
5. Mapper changes that affect determinism (random, unordered iteration)
6. Go indexer changes that don't handle PHP edge cases (traits, enums, union types)

## Project Structure

```
kloc/
├── scip-php/                    # Go — PHP SCIP indexer (submodule)
├── kloc-mapper/                 # Python — SCIP → SoT JSON
│   └── src/kloc_mapper/
├── kloc-cli/                    # Python — Query interface
│   └── src/kloc_cli/
├── kloc-reference-project-php/  # PHP — Test fixture code + contract tests
│   ├── src/                     # Reference PHP code
│   └── contract-tests/          # PHPUnit contract tests
│       ├── tests/
│       └── bin/run.sh
├── docs/
│   ├── summary.md               # Project overview
│   └── specs/                   # Feature specs and plans
└── .claude/
    └── qa-notes/                # QA reference notes
```

## Customer Personas

When reviewing user-facing changes, consider these users:

1. **AI Coding Agent** — Needs fast, precise, structured JSON responses. Latency and format matter more than human readability.
2. **Human Developer** — Needs to understand unfamiliar code quickly. Output should be scannable and contextual.
3. **Tech Lead** — Needs system-level insights for architecture decisions. Wants dependency graphs and impact analysis.
