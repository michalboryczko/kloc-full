---
name: code-reviewer
description: Code review skill with general review methodology and kloc-specific business knowledge. Use when reviewing code changes, pull requests, or when asked for "cr" / "code review". Covers correctness, architecture, security, performance, and kloc domain awareness.
---

# Code Review Skill

Structured code review process with kloc project domain awareness. Use this skill whenever you are asked to review code, do a "cr", or validate implementation quality.

## When to Use

- When asked for "cr", "code review", or "review this"
- After implementing changes (self-review before handing off)
- When assigned as a reviewer in a feature team
- When validating another developer's implementation

## Review Process

### Step 1: Understand the Context

Before reviewing code:
1. Read the feature spec if available: `docs/specs/{feature-name}.md`
2. Read the implementation plan: `docs/specs/{feature-name}-plan.md`
3. Read the QA notes: `.claude/qa-notes/{feature-name}_qa_ref_note.md`
4. Understand WHAT the change is supposed to do and WHY

### Step 2: Review the Diff

Use `git diff` or `git diff HEAD~1` to see the actual changes. Review in this order:

#### 2a. Correctness (Critical)

- Does the code do what the spec/plan says it should?
- Are all acceptance criteria addressed?
- Are edge cases handled (check QA notes)?
- Are there off-by-one errors, null checks, boundary conditions?
- Does error handling cover failure modes?

#### 2b. Architecture & Design

- Does the code follow existing codebase patterns and conventions?
- Is the abstraction level appropriate (not over/under-engineered)?
- Are responsibilities properly separated?
- Are new dependencies justified?
- Does file organization match project structure?

#### 2c. Security

- Is user input validated and sanitized?
- Are there injection risks (SQL, command, path traversal)?
- Are secrets/credentials properly handled (not hardcoded)?
- Are permissions/auth checks in place where needed?

#### 2d. Performance

- Are there N+1 query patterns or unnecessary loops?
- Is data loaded efficiently (no loading everything into memory)?
- Are expensive operations cached where appropriate?
- Are there blocking operations that should be async?

#### 2e. Maintainability

- Is the code readable without extensive comments?
- Are names descriptive and consistent with codebase conventions?
- Is there unnecessary duplication?
- Are tests adequate for the changes?

### Step 3: kloc Domain Check

**IMPORTANT**: Read `references/kloc_business_knowledge.md` for project-specific review concerns.

Key kloc-specific things to watch for:
- **SoT JSON integrity** — changes to mapper output must preserve the Source-of-Truth model (nodes, edges, containment hierarchy)
- **SCIP symbol handling** — symbol strings must be parsed/compared correctly, not with string hacks
- **Direct facts only** — no transitive edges should be stored in SoT
- **Deterministic output** — same input must always produce same output (JSON key ordering, stable sorting)
- **CLI index performance** — O(1) lookups must be maintained, no full scans
- **Contract test compatibility** — changes must not break existing contract tests in `kloc-reference-project-php/contract-tests/`
- **scip-php indexer correctness** — if reviewing indexer changes, verify SCIP protocol compliance

### Step 4: Write Review Report

Structure your findings as:

```markdown
## Code Review: {feature/change name}

### Summary
{1-2 sentence overview of what was reviewed}

### Verdict: APPROVE / REQUEST_CHANGES / COMMENT

### Findings

#### Critical (must fix)
- [{severity}] {file}:{line} — {description}
  - Evidence: {what you observed}
  - Fix: {suggested resolution}

#### Important (should fix)
- [{severity}] {file}:{line} — {description}

#### Suggestions (nice to have)
- {file}:{line} — {description}

### What Looks Good
- {positive observations}
```

### Step 5: Report Back

- If reviewing for a team: message the lead with verdict and key findings
- If self-reviewing: fix critical/important issues before marking task complete
- If reviewing another developer's code: message the developer with findings so they can fix

## Severity Levels

| Level | Meaning | Action |
|-------|---------|--------|
| **Critical** | Bug, security issue, data loss risk | Must fix before merge |
| **High** | Significant functionality impact | Should fix before merge |
| **Medium** | Code quality, maintainability | Fix if time allows |
| **Low** | Style, naming, minor improvements | Optional |

## Reference Documentation

- **kloc Business Knowledge**: `references/kloc_business_knowledge.md` — Domain-specific review concerns
- **Code Review Checklist**: `references/code_review_checklist.md` — Detailed review checklist
- **Coding Standards**: `references/coding_standards.md` — Project coding standards
- **Common Antipatterns**: `references/common_antipatterns.md` — Antipatterns to flag
