---
name: feature-issues
description: Document and analyze feature implementation issues through iterative conversation. This skill should be used when reviewing a feature's output, identifying problems, investigating root causes, and documenting fixes needed. Triggers include "let's document issues for [feature]", "help me note problems with [feature]", "analyze issues in [feature]", or when iteratively describing problems one by one.
---

# Feature Issues

Document and analyze implementation issues for a feature through iterative conversation, with codebase investigation and solution suggestions.

## Workflow

### 1. Initialize Session

When the user invokes this skill or mentions wanting to document feature issues:

1. Ask for the **feature name** (kebab-case, e.g., `calls-indexing`)
2. Check for existing issue files: `.claude/feature-issues/{feature}/issues-v*.md`
3. Determine version:
   - If user specifies version, use it
   - Otherwise, auto-increment from highest existing version (or v1 if none)
4. Create the output directory and file with header from `references/issue-template.md`
5. Look for related context:
   - Spec: `docs/specs/{feature}.md`
   - Plan: `docs/specs/{feature}-plan.md`
   - Progress: `.claude/progress/{feature}/progress-v*.md`
   - Existing issues: `.claude/feature-issues/{feature}/`

Confirm readiness: "Ready to document issues for **{feature}** (v{N}). Describe the first issue."

### 2. Issue Documentation Loop

For each issue the user describes:

#### A. Understand the Problem

- Listen to user's description of what's wrong
- Ask clarifying questions if the problem is unclear
- Request examples if not provided

#### B. Investigate

Actively search for context:

- **Codebase search**: Use Grep/Glob to find related code
- **Examples**: Check test files, fixtures, sample data the user mentions
- **Specs/docs**: Read relevant documentation
- **Git history**: Check recent changes if relevant to understanding the issue
- **Current behavior**: Examine actual output/behavior if files are available

#### C. Analyze and Suggest

- Identify the root cause based on investigation
- Propose concrete solutions with specific file changes
- Consider edge cases and implications
- Suggest which files need modification

#### D. Document

Add the issue to the output file following the template structure:

```markdown
## Issue {N}: {Title}

### Context
{Background from investigation}

### Problem
{User's description + investigated details}

### Proposed Solution
{Concrete changes with rationale}

### Files to modify
{Specific files and what changes}
```

#### E. Confirm and Continue

After documenting, confirm: "Issue {N} documented. Say **next** for another issue, or **done** to finalize."

### 3. Transition Phrases

Recognize these as signals to move on:
- "ok", "next", "next issue", "another one", "continue"
- "that's it", "done", "finalize", "save"

### 4. Finalize

When user indicates completion:

1. Save the final file to `.claude/feature-issues/{feature}/issues-v{N}.md`
2. Provide summary:
   - Number of issues documented
   - Key files affected
   - Suggested implementation order if dependencies exist

## Output Location

```
.claude/feature-issues/{feature}/issues-v{iteration}.md
```

Example: `.claude/feature-issues/calls-indexing/issues-v2.md`

## Investigation Checklist

When investigating each issue, check:

- [ ] Related source files (search by class/function names mentioned)
- [ ] Test files and fixtures
- [ ] Existing specs and documentation
- [ ] Examples provided by user
- [ ] Current output/behavior if available
- [ ] Similar patterns elsewhere in codebase

## Template Reference

See `references/issue-template.md` for the full issue documentation format.
