# Issue Documentation Template

Each issue in the output file follows this structure:

```markdown
## Issue {N}: {Short descriptive title}

**Reference:** {Link to relevant spec or doc if applicable}

### Context

{Background information explaining the current state and why this matters}

### Problem

{Clear description of what's wrong or missing, with concrete examples}

**Example — current behavior:**
```{language}
{Code or output showing the problem}
```

Problems:
- {Bullet point 1}
- {Bullet point 2}

### Proposed Solution

**1. {First change}**

{Description of what to change and why}

**2. {Second change}**

{Description}

### Expected output after fix

{Show what the corrected behavior/output should look like}

```{language}
{Example of correct output}
```

### Edge cases

| Case | Behavior |
|------|----------|
| {case 1} | {expected behavior} |
| {case 2} | {expected behavior} |

### Files to modify

- `path/to/file1.ext` — {what changes needed}
- `path/to/file2.ext` — {what changes needed}

---
```

## File Header Template

```markdown
# {Feature Name} — Issues

This document tracks issues identified during {feature name} implementation/review.

**Feature context:**
- Spec: `docs/specs/{feature}.md`
- Plan: `docs/specs/{feature}-plan.md`
- Progress: `.claude/progress/{feature}.md`

**Version:** {iteration}
**Created:** {date}

---

{Issues follow...}
```
