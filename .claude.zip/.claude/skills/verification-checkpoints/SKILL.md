---
name: verification-checkpoints
description: QA verification checkpoint system for kloc pipeline features. This skill should be used by QA agents to create, track, and sign off on verification checkpoint lists before completing any feature validation. It provides structured checkpoint lists per component (full/e2e, cli, mapper, scip) with a formal sign-off process. Triggers include completing QA validation, feature sign-off, or when the team lead asks for verification status.
---

# Verification Checkpoints

Structured QA sign-off system that ensures all critical verification steps are completed before a feature is considered done. Each component has a reference checkpoint list. QA agents create verification runs, mark checkpoints as they test, and formally sign off with a confirmation workflow.

## When to Use

- **Always** before reporting final QA PASS/FAIL to the team lead
- After completing all test scenarios from the QA notes
- When the lead requests verification status

## CLI Location

The CLI tool is at:
```
.claude/skills/verification-checkpoints/scripts/verification_checkpoints.py
```

Set the PROJECT_ROOT environment variable if not running from the kloc project root:
```bash
export PROJECT_ROOT=/Users/michal/dev/ai/kloc
```

## Workflow

### 1. Create a Verification Run

At the start of QA validation, create a run for each relevant component:

```bash
# For full e2e pipeline verification
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  new --feature=<feature-name> --component=full --agent-id=<your-agent-id>

# For specific component verification
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  new --feature=<feature-name> --component=scip --agent-id=<your-agent-id>
```

Components: `full` (e2e pipeline), `cli` (kloc-cli), `mapper` (kloc-mapper), `scip` (scip-php)

The command outputs a `run-id` to use in subsequent commands.

### 2. Mark Checkpoints During Testing

As each verification step is completed, mark it:

```bash
# Single checkpoint
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  check --run-id=<run-id> --checkpoint=e2e-001 --result=pass --notes="Pipeline completed in 12s"

# Multiple checkpoints at once (comma-separated)
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  check --run-id=<run-id> --checkpoint=e2e-001,e2e-002,e2e-003 --result=pass

# Mark a failure
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  check --run-id=<run-id> --checkpoint=scip-004 --result=fail --notes="PHPStan found 2 errors in Indexer.php"

# Skip a checkpoint with reason
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  check --run-id=<run-id> --checkpoint=cli-006 --result=skip --notes="Not applicable to this feature"
```

Results: `pass`, `fail`, `skip`

### 3. Check Status

Review progress at any time:

```bash
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  status --run-id=<run-id>
```

### 4. Sign Off

When all checkpoints are addressed, request sign-off:

```bash
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  sign --run-id=<run-id>
```

This displays a confirmation message with risk acknowledgment and generates a confirmation UUID.

To confirm the sign-off, re-run with the provided confirmation ID:

```bash
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py \
  sign --run-id=<run-id> --confirmation-id=<uuid>
```

This marks the run as signed and generates a markdown summary at `.claude/verification-summaries/<run-id>-summary.md`.

### 5. List Runs

View all runs or filter by feature:

```bash
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py list
python .claude/skills/verification-checkpoints/scripts/verification_checkpoints.py list --feature=<feature-name>
```

## Reference Checkpoint Files

Reference checkpoint lists are at `references/checkpoints-{component}.json`. Each contains checkpoints with:

- `id` — Unique checkpoint identifier (e.g., `e2e-001`, `scip-003`)
- `category` — Grouping (pipeline, unit-tests, linting, output, regression, etc.)
- `checkpoint` — What to verify (human-readable description)
- `severity` — critical, high, medium, low
- `verification` — How to verify (specific command or action)

To add or modify checkpoints for a component, edit the corresponding reference JSON file.

## Output Files

- **Run files**: `.claude/verification-runs/<run-id>.json` — Full checkpoint state per run
- **Summaries**: `.claude/verification-summaries/<run-id>-summary.md` — Generated on sign-off

## Integration with QA Workflow

Before reporting final results to the team lead:

1. Create verification runs for all relevant components
2. Work through checkpoints systematically — run the verification command for each
3. Mark each checkpoint with result and notes
4. If any critical checkpoints fail, report to lead immediately (do not wait for sign-off)
5. When all checkpoints are addressed, sign off each run
6. Include the summary file path(s) in the final QA report to the lead

**A feature is NOT fully validated until all relevant verification runs are signed off.**
