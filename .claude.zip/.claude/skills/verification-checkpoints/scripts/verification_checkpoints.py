#!/usr/bin/env python3
"""
Verification Checkpoints CLI — QA sign-off tool for kloc pipeline features.

Commands:
  new     Create a new verification run from reference checkpoints
  check   Mark a checkpoint as pass/fail/skip
  status  Show current progress for a run
  sign    Request or confirm sign-off on a verification run

Usage:
  python verification_checkpoints.py new --feature=xxx --component=full|cli|mapper|scip --agent-id=qa-1
  python verification_checkpoints.py check --run-id=xxx --checkpoint=e2e-001 --result=pass --notes="All good"
  python verification_checkpoints.py status --run-id=xxx
  python verification_checkpoints.py sign --run-id=xxx
  python verification_checkpoints.py sign --run-id=xxx --confirmation-id=<uuid>
"""

import argparse
import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

# Resolve paths relative to the skill directory
SKILL_DIR = Path(__file__).resolve().parent.parent
REFERENCES_DIR = SKILL_DIR / "references"

# Runs are stored in the project's .claude directory
PROJECT_ROOT = Path(os.environ.get("PROJECT_ROOT", SKILL_DIR.parent.parent.parent))
RUNS_DIR = PROJECT_ROOT / ".claude" / "verification-runs"
SUMMARIES_DIR = PROJECT_ROOT / ".claude" / "verification-summaries"

VALID_COMPONENTS = ["full", "cli", "mapper", "scip"]
VALID_RESULTS = ["pass", "fail", "skip"]
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def load_reference(component: str) -> dict:
    """Load reference checkpoint list for a component."""
    ref_file = REFERENCES_DIR / f"checkpoints-{component}.json"
    if not ref_file.exists():
        print(f"Error: Reference file not found: {ref_file}", file=sys.stderr)
        sys.exit(1)
    with open(ref_file) as f:
        return json.load(f)


def load_run(run_id: str) -> dict:
    """Load a verification run by ID."""
    run_file = RUNS_DIR / f"{run_id}.json"
    if not run_file.exists():
        print(f"Error: Run not found: {run_id}", file=sys.stderr)
        print(f"  Expected at: {run_file}", file=sys.stderr)
        sys.exit(1)
    with open(run_file) as f:
        return json.load(f)


def save_run(run: dict) -> None:
    """Save a verification run."""
    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    run_file = RUNS_DIR / f"{run['run_id']}.json"
    with open(run_file, "w") as f:
        json.dump(run, f, indent=2)


def cmd_new(args: argparse.Namespace) -> None:
    """Create a new verification run from reference checkpoints."""
    reference = load_reference(args.component)
    run_id = f"{args.feature}-{args.component}-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"

    run = {
        "run_id": run_id,
        "feature": args.feature,
        "component": args.component,
        "agent_id": args.agent_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "in_progress",
        "confirmation_id": None,
        "signed": False,
        "signed_at": None,
        "signed_by": None,
        "checkpoints": [],
    }

    for cp in reference["checkpoints"]:
        run["checkpoints"].append({
            "id": cp["id"],
            "category": cp["category"],
            "checkpoint": cp["checkpoint"],
            "severity": cp["severity"],
            "verification": cp["verification"],
            "result": "pending",
            "notes": "",
            "checked_at": None,
        })

    save_run(run)

    print(f"Verification run created: {run_id}")
    print(f"  Feature:    {args.feature}")
    print(f"  Component:  {args.component}")
    print(f"  Agent:      {args.agent_id}")
    print(f"  Checkpoints: {len(run['checkpoints'])}")
    print(f"  File:       {RUNS_DIR / f'{run_id}.json'}")
    print()
    print("Next steps:")
    print(f"  1. Run checks:  python {__file__} check --run-id={run_id} --checkpoint=<id> --result=pass|fail|skip")
    print(f"  2. View status: python {__file__} status --run-id={run_id}")
    print(f"  3. Sign off:    python {__file__} sign --run-id={run_id}")


def cmd_check(args: argparse.Namespace) -> None:
    """Mark a checkpoint as pass/fail/skip."""
    run = load_run(args.run_id)

    if run["signed"]:
        print("Error: This run is already signed. Cannot modify checkpoints.", file=sys.stderr)
        sys.exit(1)

    found = False
    for cp in run["checkpoints"]:
        if cp["id"] == args.checkpoint:
            cp["result"] = args.result
            cp["notes"] = args.notes or ""
            cp["checked_at"] = datetime.now(timezone.utc).isoformat()
            found = True
            break

    if not found:
        print(f"Error: Checkpoint '{args.checkpoint}' not found in run '{args.run_id}'", file=sys.stderr)
        print(f"  Available: {', '.join(cp['id'] for cp in run['checkpoints'])}", file=sys.stderr)
        sys.exit(1)

    save_run(run)
    symbol = {"pass": "[PASS]", "fail": "[FAIL]", "skip": "[SKIP]"}[args.result]
    print(f"{symbol} {args.checkpoint}: {run['checkpoints'][[cp['id'] for cp in run['checkpoints']].index(args.checkpoint)]['checkpoint']}")
    if args.notes:
        print(f"  Notes: {args.notes}")


def cmd_check_batch(args: argparse.Namespace) -> None:
    """Mark multiple checkpoints at once."""
    run = load_run(args.run_id)

    if run["signed"]:
        print("Error: This run is already signed. Cannot modify checkpoints.", file=sys.stderr)
        sys.exit(1)

    checkpoint_ids = [cid.strip() for cid in args.checkpoints.split(",")]
    now = datetime.now(timezone.utc).isoformat()

    updated = 0
    for cp in run["checkpoints"]:
        if cp["id"] in checkpoint_ids:
            cp["result"] = args.result
            cp["notes"] = args.notes or ""
            cp["checked_at"] = now
            updated += 1
            symbol = {"pass": "[PASS]", "fail": "[FAIL]", "skip": "[SKIP]"}[args.result]
            print(f"{symbol} {cp['id']}: {cp['checkpoint']}")

    if updated == 0:
        print(f"Error: No matching checkpoints found.", file=sys.stderr)
        sys.exit(1)

    save_run(run)
    print(f"\nUpdated {updated} checkpoint(s).")


def cmd_status(args: argparse.Namespace) -> None:
    """Show current progress for a run."""
    run = load_run(args.run_id)

    total = len(run["checkpoints"])
    by_result = {}
    by_severity = {"critical": [], "high": [], "medium": [], "low": []}

    for cp in run["checkpoints"]:
        by_result.setdefault(cp["result"], []).append(cp)
        if cp["result"] != "pass":
            by_severity[cp["severity"]].append(cp)

    passed = len(by_result.get("pass", []))
    failed = len(by_result.get("fail", []))
    skipped = len(by_result.get("skip", []))
    pending = len(by_result.get("pending", []))

    print(f"=== Verification Run: {run['run_id']} ===")
    print(f"Feature:   {run['feature']}")
    print(f"Component: {run['component']}")
    print(f"Agent:     {run['agent_id']}")
    print(f"Status:    {run['status']}")
    print(f"Signed:    {'YES' if run['signed'] else 'NO'}")
    print()
    print(f"Progress: {passed}/{total} passed, {failed} failed, {skipped} skipped, {pending} pending")
    print()

    # Show by category
    categories = {}
    for cp in run["checkpoints"]:
        categories.setdefault(cp["category"], []).append(cp)

    for cat, cps in sorted(categories.items()):
        print(f"  [{cat}]")
        for cp in cps:
            symbol = {
                "pass": "  [PASS]",
                "fail": "  [FAIL]",
                "skip": "  [SKIP]",
                "pending": "  [    ]",
            }[cp["result"]]
            severity_tag = f"({cp['severity']})" if cp["result"] != "pass" else ""
            print(f"    {symbol} {cp['id']}: {cp['checkpoint']} {severity_tag}")
            if cp["notes"]:
                print(f"           Notes: {cp['notes']}")
        print()

    # Show blockers
    critical_fails = [cp for cp in run["checkpoints"] if cp["result"] == "fail" and cp["severity"] == "critical"]
    if critical_fails:
        print("!! CRITICAL FAILURES !!")
        for cp in critical_fails:
            print(f"  - {cp['id']}: {cp['checkpoint']}")
            if cp["notes"]:
                print(f"    {cp['notes']}")
        print()

    if pending:
        print(f"Remaining: {pending} checkpoint(s) still pending")


def cmd_sign(args: argparse.Namespace) -> None:
    """Request or confirm sign-off on a verification run."""
    run = load_run(args.run_id)

    if run["signed"]:
        print(f"This run is already signed.")
        print(f"  Signed by: {run['signed_by']}")
        print(f"  Signed at: {run['signed_at']}")
        return

    # Check for pending items
    pending = [cp for cp in run["checkpoints"] if cp["result"] == "pending"]
    failed = [cp for cp in run["checkpoints"] if cp["result"] == "fail"]
    critical_fails = [cp for cp in failed if cp["severity"] == "critical"]

    if args.confirmation_id:
        # === CONFIRMATION PHASE ===
        if run["confirmation_id"] is None:
            print("Error: No sign-off has been requested yet. Run 'sign' without --confirmation-id first.", file=sys.stderr)
            sys.exit(1)

        if args.confirmation_id != run["confirmation_id"]:
            print("Error: Invalid confirmation ID. The provided ID does not match.", file=sys.stderr)
            print(f"  Expected: {run['confirmation_id']}", file=sys.stderr)
            sys.exit(1)

        # Valid confirmation — sign off
        run["signed"] = True
        run["signed_at"] = datetime.now(timezone.utc).isoformat()
        run["signed_by"] = run["agent_id"]
        run["status"] = "signed"
        save_run(run)

        # Generate summary
        summary_path = generate_summary(run)

        print()
        print("=" * 60)
        print("  VERIFICATION SIGN-OFF CONFIRMED")
        print("=" * 60)
        print()
        print(f"  Run:          {run['run_id']}")
        print(f"  Signed by:    {run['signed_by']}")
        print(f"  Signed at:    {run['signed_at']}")
        print(f"  Summary:      {summary_path}")
        print()
    else:
        # === REQUEST PHASE ===
        total = len(run["checkpoints"])
        passed = len([cp for cp in run["checkpoints"] if cp["result"] == "pass"])

        print()
        print("=" * 70)
        print("  VERIFICATION SIGN-OFF REQUEST")
        print("=" * 70)
        print()
        print(f"  Run:        {run['run_id']}")
        print(f"  Feature:    {run['feature']}")
        print(f"  Component:  {run['component']}")
        print(f"  Progress:   {passed}/{total} passed")
        print()

        if pending:
            print(f"  WARNING: {len(pending)} checkpoint(s) still PENDING:")
            for cp in pending:
                print(f"    - {cp['id']}: {cp['checkpoint']} ({cp['severity']})")
            print()

        if failed:
            print(f"  WARNING: {len(failed)} checkpoint(s) FAILED:")
            for cp in failed:
                print(f"    - {cp['id']}: {cp['checkpoint']} ({cp['severity']})")
                if cp["notes"]:
                    print(f"      Notes: {cp['notes']}")
            print()

        if critical_fails:
            print("  !! CRITICAL: There are CRITICAL checkpoint failures. !!")
            print("  !! Signing off with critical failures is strongly discouraged. !!")
            print()

        print("-" * 70)
        print()
        print("  Are you sure that you want to confirm you have tested all critical")
        print("  things and you accept potential risk and responsibility (that may")
        print("  include financial penalty or even prison)?")
        print()
        print("-" * 70)

        # Generate confirmation ID
        confirmation_id = str(uuid.uuid4())
        run["confirmation_id"] = confirmation_id
        run["status"] = "pending_sign"
        save_run(run)

        print()
        print("  To confirm, re-run this command with the confirmation ID:")
        print()
        print(f"  python {__file__} sign --run-id={args.run_id} --confirmation-id={confirmation_id}")
        print()


def generate_summary(run: dict) -> Path:
    """Generate a markdown summary file from a signed verification run."""
    SUMMARIES_DIR.mkdir(parents=True, exist_ok=True)
    summary_path = SUMMARIES_DIR / f"{run['run_id']}-summary.md"

    total = len(run["checkpoints"])
    passed = len([cp for cp in run["checkpoints"] if cp["result"] == "pass"])
    failed = len([cp for cp in run["checkpoints"] if cp["result"] == "fail"])
    skipped = len([cp for cp in run["checkpoints"] if cp["result"] == "skip"])

    lines = []
    lines.append(f"# Verification Summary: {run['run_id']}")
    lines.append("")
    lines.append(f"| Field | Value |")
    lines.append(f"|-------|-------|")
    lines.append(f"| Feature | {run['feature']} |")
    lines.append(f"| Component | {run['component']} |")
    lines.append(f"| Agent | {run['agent_id']} |")
    lines.append(f"| Created | {run['created_at']} |")
    lines.append(f"| Signed | {run['signed_at']} |")
    lines.append(f"| Signed By | {run['signed_by']} |")
    lines.append(f"| Confirmation ID | `{run['confirmation_id']}` |")
    lines.append("")
    lines.append(f"## Results")
    lines.append("")
    lines.append(f"| Metric | Count |")
    lines.append(f"|--------|-------|")
    lines.append(f"| Total | {total} |")
    lines.append(f"| Passed | {passed} |")
    lines.append(f"| Failed | {failed} |")
    lines.append(f"| Skipped | {skipped} |")
    lines.append("")

    # Group by category
    categories = {}
    for cp in run["checkpoints"]:
        categories.setdefault(cp["category"], []).append(cp)

    lines.append("## Checkpoints")
    lines.append("")

    for cat, cps in sorted(categories.items()):
        lines.append(f"### {cat}")
        lines.append("")
        lines.append("| ID | Checkpoint | Severity | Result | Notes |")
        lines.append("|-----|-----------|----------|--------|-------|")
        for cp in cps:
            result_icon = {"pass": "PASS", "fail": "FAIL", "skip": "SKIP", "pending": "PENDING"}[cp["result"]]
            notes = cp["notes"].replace("|", "\\|") if cp["notes"] else "-"
            lines.append(f"| {cp['id']} | {cp['checkpoint']} | {cp['severity']} | {result_icon} | {notes} |")
        lines.append("")

    # Failures section
    failures = [cp for cp in run["checkpoints"] if cp["result"] == "fail"]
    if failures:
        lines.append("## Failures")
        lines.append("")
        for cp in failures:
            lines.append(f"### {cp['id']}: {cp['checkpoint']}")
            lines.append(f"- **Severity**: {cp['severity']}")
            lines.append(f"- **Verification**: {cp['verification']}")
            lines.append(f"- **Notes**: {cp['notes'] or 'None'}")
            lines.append("")

    # Sign-off statement
    lines.append("---")
    lines.append("")
    lines.append(f"*Signed off by `{run['signed_by']}` at {run['signed_at']}.*")
    lines.append(f"*Confirmation ID: `{run['confirmation_id']}`*")
    lines.append("")

    with open(summary_path, "w") as f:
        f.write("\n".join(lines))

    return summary_path


def cmd_list(args: argparse.Namespace) -> None:
    """List all verification runs, optionally filtered by feature."""
    if not RUNS_DIR.exists():
        print("No verification runs found.")
        return

    runs = []
    for f in sorted(RUNS_DIR.glob("*.json")):
        with open(f) as fh:
            run = json.load(fh)
            if args.feature and run["feature"] != args.feature:
                continue
            runs.append(run)

    if not runs:
        print(f"No runs found{' for feature ' + args.feature if args.feature else ''}.")
        return

    print(f"{'Run ID':<50} {'Component':<10} {'Status':<15} {'Progress'}")
    print("-" * 95)
    for run in runs:
        total = len(run["checkpoints"])
        passed = len([cp for cp in run["checkpoints"] if cp["result"] == "pass"])
        print(f"{run['run_id']:<50} {run['component']:<10} {run['status']:<15} {passed}/{total}")


def main():
    parser = argparse.ArgumentParser(
        prog="verification-checkpoints",
        description="QA verification checkpoint system for kloc pipeline features",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # new
    p_new = subparsers.add_parser("new", help="Create a new verification run")
    p_new.add_argument("--feature", required=True, help="Feature name (kebab-case)")
    p_new.add_argument("--component", required=True, choices=VALID_COMPONENTS, help="Component to verify")
    p_new.add_argument("--agent-id", required=True, help="Agent ID performing verification")

    # check
    p_check = subparsers.add_parser("check", help="Mark a checkpoint")
    p_check.add_argument("--run-id", required=True, help="Verification run ID")
    p_check.add_argument("--checkpoint", required=True, help="Checkpoint ID (e.g., e2e-001) or comma-separated list")
    p_check.add_argument("--result", required=True, choices=VALID_RESULTS, help="Result: pass, fail, or skip")
    p_check.add_argument("--notes", default="", help="Optional notes")

    # status
    p_status = subparsers.add_parser("status", help="Show run progress")
    p_status.add_argument("--run-id", required=True, help="Verification run ID")

    # sign
    p_sign = subparsers.add_parser("sign", help="Request or confirm sign-off")
    p_sign.add_argument("--run-id", required=True, help="Verification run ID")
    p_sign.add_argument("--confirmation-id", default=None, help="Confirmation UUID from sign request")

    # list
    p_list = subparsers.add_parser("list", help="List all verification runs")
    p_list.add_argument("--feature", default=None, help="Filter by feature name")

    args = parser.parse_args()

    if args.command == "new":
        cmd_new(args)
    elif args.command == "check":
        if "," in args.checkpoint:
            args.checkpoints = args.checkpoint
            cmd_check_batch(args)
        else:
            cmd_check(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "sign":
        cmd_sign(args)
    elif args.command == "list":
        cmd_list(args)


if __name__ == "__main__":
    main()
