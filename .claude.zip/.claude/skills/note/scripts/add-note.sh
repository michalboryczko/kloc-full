#!/usr/bin/env bash
# Adds a note to notes.md under the correct category
# Usage: add-note.sh <category> <note>
#   category: observations, issues, feature-requests

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# Walk up from .claude/skills/note/scripts/ to project root
NOTES_FILE="${NOTES_DIR:-$(cd "$SCRIPT_DIR/../../../.." && pwd)/notes.md}"
CATEGORY="$1"
shift
NOTE="$*"

if [[ -z "$NOTE" ]]; then
  echo "Usage: add-note.sh <observations|issues|feature-requests> <note text>" >&2
  exit 1
fi

# Normalize category
case "$CATEGORY" in
  obs|observation|observations) HEADER="Observations" ;;
  issue|issues|bug|bugs) HEADER="Issues" ;;
  feat|feature|feature-request|feature-requests|fr) HEADER="Feature Requests" ;;
  *) echo "Unknown category: $CATEGORY (use observations, issues, or feature-requests)" >&2; exit 1 ;;
esac

# Ensure file exists with all sections
if [[ ! -f "$NOTES_FILE" ]]; then
  printf "# Observations\n\n# Issues\n\n# Feature Requests\n" > "$NOTES_FILE"
fi

# Ensure section exists
if ! grep -q "^# $HEADER" "$NOTES_FILE"; then
  printf "\n# %s\n" "$HEADER" >> "$NOTES_FILE"
fi

# Count existing entries in this section to determine next number
LAST_NUM=$(sed -n "/^# $HEADER/,/^# /p" "$NOTES_FILE" | grep -cE '^[0-9]+\.' || true)
NEXT_NUM=$((LAST_NUM + 1))

# Insert the note after the last entry in the section
python3 -c "
import sys
header = '# $HEADER'
note = '${NEXT_NUM}. **${NOTE}**'
lines = open('$NOTES_FILE').readlines()
result = []
found = False
inserted = False
for i, line in enumerate(lines):
    result.append(line)
    if line.strip() == header:
        found = True
    elif found and not inserted:
        if line.startswith('# ') and line.strip() != header:
            result.insert(len(result)-1, note + '\n\n')
            inserted = True
if found and not inserted:
    if result and result[-1].strip():
        result.append('\n')
    result.append(note + '\n')
open('$NOTES_FILE', 'w').writelines(result)
"

echo "Added $HEADER #$NEXT_NUM: $NOTE"
