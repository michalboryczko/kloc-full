---
name: note
description: Add notes to notes.md categorized as observations, issues, or feature-requests. Use when the user wants to record observations, bugs, or feature ideas.
allowed-tools: Bash(bash .claude/skills/note/scripts/add-note.sh *)
argument-hint: [observations|issues|feature-requests]
---

This skill adds categorized notes to `notes.md` at the project root.

## Workflow

1. Examine the most recent conversation context to extract noteworthy items.
2. Check `$ARGUMENTS` for an explicit category (`observations`, `issues`, `feature-requests`, or abbreviations: `obs`, `fr`, `bug`).
3. If no category is specified, auto-classify each note:
   - **observations** - Facts learned, behaviors noticed, how things work, insights
   - **issues** - Bugs, broken behavior, errors, things that don't work correctly
   - **feature-requests** - Ideas for new features, improvements, enhancements
4. Summarize each note into ONE concise sentence (~15 words max). Use technical terms from the codebase.
5. If multiple distinct things to note, run the script once per note with the appropriate category.

## Execution

Run the bundled script for each note:

```
bash .claude/skills/note/scripts/add-note.sh <category> "<note text>"
```

The script handles auto-numbering, file creation, and section management.

Report what was added after execution.
