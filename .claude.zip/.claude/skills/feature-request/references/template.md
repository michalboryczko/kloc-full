# Feature Request: <title>

## Goal

<1-2 sentences: what this feature does and what problem it solves>

## Why

<Context on why this is needed. Reference current behavior, limitations, or pain points.>

## Usage examples

### Example 1: <scenario name>

**Before** (current behavior):
```
<code or CLI showing current state>
```

**After** (expected behavior):
```
<code or CLI showing desired state>
```

### Example 2: <scenario name>

<repeat as needed>

## Detailed behavior

### <Aspect 1>

<Describe expected behavior in detail>

### <Aspect 2>

<Describe expected behavior in detail>

## Edge cases

| Case | Expected behavior |
|------|-------------------|
| <edge case 1> | <what should happen> |
| <edge case 2> | <what should happen> |
| <edge case 3> | <what should happen> |

## Dev notes

- **<file or component>**: <suggested change or observation>
- **<file or component>**: <suggested change or observation>

## Open questions

- <Any unresolved decisions or things to clarify during implementation>
