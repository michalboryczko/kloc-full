---
name: feature-request
description: Create detailed feature request specs from conversation context. This skill should be used when the user wants to document a feature idea, improvement, or change as a formal spec for implementation planning. Outputs markdown files to docs/specs/.
argument-hint: [short title or description, or path to existing file]
---

This skill generates feature request specification documents in `docs/specs/` from conversation context. It does NOT create progress tracker files — that is the responsibility of the progress-tracker skill or the feature-planner agent.

## Workflow

1. Analyze `$ARGUMENTS` and the current conversation to identify the feature being requested. **If `$ARGUMENTS` contains a file path** (e.g., `@docs/plan.md`, `docs/specs/foo.md`, or any path-like string), **immediately read that file** using the Read tool and use its content as the primary source. If `$ARGUMENTS` is a title or description (not a path), use it as the primary input.
2. Identify any files, code, or documentation mentioned in context. Read those files to gather implementation details, current behavior, and relevant code references.
3. If the conversation references specific components, modules, or patterns, read them to understand the current architecture.
4. Generate the spec document following the template structure in `references/template.md`.
5. Save to `docs/specs/<kebab-case-title>.md`.

## Content requirements

### Goal and Why
Extract the motivation from conversation context. Reference specific limitations or pain points discussed.

### Usage examples
Create concrete before/after examples showing how the feature changes behavior. Use real code patterns from the codebase — read relevant source files to match naming conventions, APIs, and data structures.

### Detailed behavior
Break the feature into discrete behavioral aspects. Each aspect gets its own subsection with enough detail for a developer to implement without ambiguity.

### Edge cases
Identify boundary conditions, error scenarios, and unusual inputs. Present as a table with expected behavior for each case. Consider:
- Empty/null inputs
- Conflicting configurations
- Backwards compatibility concerns
- Performance implications for large inputs
- Interaction with existing features

### Dev notes
Reference specific files, classes, or functions that would need changes. Use the format `file_path:line_number` where applicable. Include suggested approaches when the conversation provides implementation direction.

### Open questions
List any unresolved decisions or ambiguities that need clarification before or during implementation.

## File naming

Derive the filename from the feature title in kebab-case:
- "Add call tracking to scip-php" → `docs/specs/scip-php-call-tracking.md`
- "Split uses into uses and calls edges" → `docs/specs/split-uses-calls-edges.md`

## Input from existing file

When `$ARGUMENTS` contains a path to an existing file (e.g., a plan, spec, or notes file):

1. **Read the file first** — use the Read tool to load the file contents before doing anything else.
2. **Extract structure** — identify goals, phases, steps, acceptance criteria, and implementation details from the file.
3. **Cross-reference the codebase** — if the file mentions source files, classes, or functions, read those files to add accurate `file_path:line_number` references to the dev notes section.
4. **Generate the spec** — use the file content as the primary source (not conversation context). Map the file's structure into the template sections.

## Multiple features

If the conversation contains multiple distinct feature requests, create separate spec files for each. Inform the user of all files created.
