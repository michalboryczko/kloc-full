---
name: kloc-scip-contract-test-create
description: "Create SCIP contract tests from plain English scenarios. This skill should be used when the user wants to write tests for scip-php indexer output. It translates natural language test descriptions into PHPUnit test code using the contract test framework. Triggers include: 'write a contract test for...', 'test that the indexer correctly...', 'verify that calls.json contains...', 'create test to check parameter references', or any request to validate scip-php calls.json output. The skill expects scenario descriptions (what to test, which class/method, what behavior to verify) rather than code snippets."
---

# KLOC SCIP Contract Test Creator

Create PHPUnit contract tests for validating scip-php indexer output from plain English test scenarios.

## Purpose

Translate natural language test descriptions into working PHPUnit test code that validates `calls.json` output from the scip-php indexer. Tests verify that code analysis correctly captures values, calls, and their relationships.

## Input Requirements

Provide test scenarios as descriptions, not code. Include:

1. **What to test**: The PHP class/method being analyzed
2. **What behavior to verify**: Parameter references, chain integrity, argument binding, or data integrity
3. **Expected outcome**: What the test should verify in calls.json

### Example Input

> "Test that OrderRepository::save() has a single value entry for the $order parameter and all usages reference it"

> "Verify that when OrderService::createOrder() calls save(), the first argument points to the $order local variable"

> "Check that the chain $this->orderRepository->save() in NotificationService has proper linkage"

## Documentation References

Before writing tests, always consult the up-to-date documentation:

| Document | Path | Purpose |
|----------|------|---------|
| JSON Schema | `docs/reference/kloc-scip/calls-schema.json` | Complete schema definition for calls.json |
| Framework API | `docs/reference/kloc-scip/contract-tests/framework-api.md` | Query and assertion APIs |
| Writing Tests | `docs/reference/kloc-scip/contract-tests/writing-tests.md` | Patterns and examples |
| Test Categories | `docs/reference/kloc-scip/contract-tests/test-categories.md` | Category descriptions |
| Agent Instructions | `kloc-reference-project-php/contract-tests/CLAUDE.md` | Quick reference |

**CRITICAL**: Read the JSON schema file to understand the exact structure of values and calls. The schema contains enum definitions, field descriptions, and validation rules that inform test assertions.

## Test Categories

### Category 1: Reference Consistency
Verify that each variable has exactly ONE value entry and all usages reference it.

```php
$this->assertReferenceConsistency()
    ->inMethod('App\Repository\OrderRepository', 'save')
    ->forParameter('$order')
    ->verify();
```

### Category 2: Chain Integrity
Verify that method/property chains are properly linked: value → call → result → call → result.

```php
$this->assertChain()
    ->startingFrom('App\Service\OrderService', 'createOrder', '$this')
    ->throughAccess('orderRepository')
    ->throughMethod('save')
    ->verify();
```

### Category 3: Argument Binding
Verify that method arguments are correctly linked to their source values.

```php
$this->assertArgument()
    ->inMethod('App\Service\OrderService', 'createOrder')
    ->atCall('save')
    ->position(0)
    ->pointsToLocal('$order')
    ->verify();
```

### Category 4: Data Integrity
Verify structural correctness of the entire index.

```php
$this->assertIntegrity()
    ->noParameterDuplicates()
    ->allReceiverValueIdsExist()
    ->verify();
```

## Test Structure

Every test MUST follow this structure and use the `#[ContractTest]` attribute:

```php
<?php

declare(strict_types=1);

namespace ContractTests\Tests\{Category};

use ContractTests\Attribute\ContractTest;
use ContractTests\CallsContractTestCase;

class {FeatureName}Test extends CallsContractTestCase
{
    /**
     * Test: {Class}::{method}() - {scenario}
     *
     * Code reference: src/Path/To/File.php:{line}
     *   {actual PHP code being tested}
     *
     * Expected: {what the test verifies}
     */
    #[ContractTest(
        name: '{Class}::{method}() {scenario}',
        description: '{Detailed description of what the test verifies}',
        category: '{category}',
    )]
    public function test{DescriptiveName}(): void
    {
        // Test implementation using query/assertion API
    }
}
```

## ContractTest Attribute

Every test method MUST use the `#[ContractTest]` attribute for documentation:

```php
use ContractTests\Attribute\ContractTest;

#[ContractTest(
    name: 'OrderRepository::save() $order',
    description: 'Verifies $order parameter has single value entry. Per spec, each parameter should have one value entry at declaration.',
    category: 'reference',
)]
public function testOrderRepositorySaveOrderParameter(): void
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | string | Yes | Human-readable test name |
| `description` | string | Yes | What the test verifies (detailed) |
| `category` | string | No | `smoke`, `integrity`, `reference`, `chain`, `argument`, `callkind`, `operator` |
| `status` | string | No | `active` (default), `skipped`, `pending` |
| `experimental` | bool | No | If `true`, test only runs with `--experimental` flag |

**Note**: Code reference (`ClassName::methodName`) is auto-generated via reflection.

### Experimental Tests

For tests that validate experimental call kinds (function, access_array, operators), use:

```php
#[ContractTest(
    name: 'Array Access Kind Exists',
    description: 'Verifies array access is tracked with kind=access_array.',
    category: 'callkind',
    experimental: true,  // Only runs with bin/run.sh test --experimental
)]
public function testArrayAccessKindExists(): void
```

## Translation Process

### Step 1: Identify Test Category

From the scenario description, determine which category applies:

| Scenario Keywords | Category | Assertion |
|-------------------|----------|-----------|
| "single value entry", "one value", "all usages reference" | Reference Consistency | `assertReferenceConsistency()` |
| "chain", "linkage", "flows through", "→" | Chain Integrity | `assertChain()` |
| "argument points to", "passes X to", "receives" | Argument Binding | `assertArgument()` |
| "no duplicates", "all IDs exist", "structural" | Data Integrity | `assertIntegrity()` |

### Step 2: Identify the Target Code

Extract from the scenario:
- **Class**: Full namespace (e.g., `App\Repository\OrderRepository`)
- **Method**: Method name (e.g., `save`)
- **Variable**: Parameter or local variable name (e.g., `$order`)

### Step 3: Read the Source File

Always read the actual PHP source file to:
1. Get the exact line number for the code reference
2. Copy the actual code snippet for documentation
3. Understand the exact variable names and types

### Step 4: Write the Test

Combine the category assertion with the identified targets.

## Query API Quick Reference

### Finding Values

```php
// By kind and symbol
$this->values()->kind('parameter')->symbolContains('save().($order)')->one();

// In specific method scope
$this->inMethod('App\Repository\OrderRepository', 'save')
    ->values()->kind('parameter')->all();

// By location
$this->values()->inFile('src/Repository/OrderRepository.php')->atLine(26)->first();
```

### Finding Calls

```php
// By kind and callee
$this->calls()->kind('method')->calleeContains('save')->all();

// By caller scope
$this->calls()->callerMatches('*OrderService#createOrder().*')->all();

// With specific receiver
$this->calls()->withReceiverValueId($valueId)->all();
```

## SCIP Symbol Format

PHP namespaces convert to SCIP symbols:

```
App\Repository\OrderRepository → App/Repository/OrderRepository
```

Symbol patterns:
- `Class#method().` - Method definition
- `Class#method().($param)` - Parameter
- `Class#method().local$var@line` - Local variable
- `Class#$property.` - Property

## Workflow

1. **Receive scenario description** from user
2. **Read JSON schema** (`docs/reference/kloc-scip/calls-schema.json`) for structure reference
3. **Read framework API** (`docs/reference/kloc-scip/contract-tests/framework-api.md`) for available methods
4. **Read target PHP file** to get exact code reference and line number
5. **Identify test category** based on what's being verified
6. **Determine test file location**:
   - `tests/Reference/` for Category 1
   - `tests/Chain/` for Category 2
   - `tests/Argument/` for Category 3
   - `tests/Integrity/` for Category 4
7. **Write the test** following the structure template
8. **Include code reference** in PHPDoc with file:line and code snippet

## Important Rules

- **Never guess line numbers** - always read the source file
- **Use full namespaces** - `App\Repository\OrderRepository` not just `OrderRepository`
- **Include dollar signs** - `$order` not `order` for variable names
- **Reference real code** - tests must reference actual kloc-reference-project-php code
- **Follow naming conventions** - `test{DescriptiveName}` in camelCase

## Test Directory

All tests are in: `kloc-reference-project-php/contract-tests/tests/`
