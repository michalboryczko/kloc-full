# Contract Test Framework API Reference

This is a comprehensive reference for the contract test framework API. For the most current documentation, always read the source files directly.

## Source Documentation Locations

| Document | Path |
|----------|------|
| JSON Schema | `docs/reference/kloc-scip/calls-schema.json` |
| Framework API | `docs/reference/kloc-scip/contract-tests/framework-api.md` |
| Writing Tests | `docs/reference/kloc-scip/contract-tests/writing-tests.md` |
| Test Categories | `docs/reference/kloc-scip/contract-tests/test-categories.md` |

## Value Kinds (from calls-schema.json)

| Kind | Description | Has `symbol` | Has `source_call_id` |
|------|-------------|--------------|----------------------|
| `parameter` | Function/method parameter at declaration in signature | Yes | No |
| `local` | Local variable at assignment site. Symbol has @line suffix | Yes | Maybe (if from call) |
| `literal` | String/int/float/array literal at usage site | No | No |
| `constant` | Class or global constant reference | Yes | No |
| `result` | Result of a call operation. ID matches the call's ID | No | Yes (always) |

## Call Kinds (from calls-schema.json)

| Kind | Kind Type | Example | Has Receiver | Has Arguments |
|------|-----------|---------|--------------|---------------|
| `method` | invocation | `$obj->method()` | Yes | Yes |
| `method_static` | invocation | `Foo::method()` | No | Yes |
| `method_nullsafe` | invocation | `$obj?->method()` | Yes | Yes |
| `function` | invocation | `func()` | No | Yes |
| `constructor` | invocation | `new Foo()` | No | Yes |
| `access` | access | `$obj->property` | Yes | No |
| `access_static` | access | `Foo::$property` | No | No |
| `access_nullsafe` | access | `$obj?->property` | Yes | No |
| `access_array` | access | `$arr['key']` | Yes | No (has key_value_id) |
| `coalesce` | operator | `$a ?? $b` | No | No (has left/right_value_id) |
| `ternary` | operator | `$a ?: $b` | No | No |
| `ternary_full` | operator | `$a ? $b : $c` | No | No |
| `match` | operator | `match($x) {...}` | No | No (has subject/arm IDs) |

## ValueQuery Methods

```php
$this->values()
    // Kind filters
    ->kind('parameter')           // parameter, local, literal, constant, result

    // Symbol filters
    ->symbol('exact symbol')      // Exact match
    ->symbolContains('partial')   // Contains string
    ->symbolMatches('*pattern*')  // Wildcard pattern

    // Scope filters
    ->inCaller('*ClassName#method().*')  // Within caller scope

    // Location filters
    ->inFile('src/Path/File.php')
    ->atLine(26)

    // Source filters
    ->hasSourceCallId()           // Values from call results
    ->hasSourceValueId()          // Values from other values

    // Results
    ->all()                       // Array of all matches
    ->first()                     // First match or null
    ->one()                       // Exactly one match (fails otherwise)
    ->count()                     // Count of matches
    ->assertCount(1, 'message')   // Assert count equals
```

## CallQuery Methods

```php
$this->calls()
    // Kind filters
    ->kind('method')              // method, method_static, access, etc.
    ->kindType('invocation')      // invocation, access, operator

    // Callee/Caller filters
    ->calleeContains('save')
    ->calleeMatches('*Order#save().')
    ->callerContains('OrderService')
    ->callerMatches('*OrderService#createOrder().*')

    // Receiver filters
    ->hasReceiver()
    ->withReceiverValueId($id)

    // Location filters
    ->inFile('src/Service/OrderService.php')
    ->atLine(40)
    ->inMethod('App\Service\OrderService', 'createOrder')

    // Results
    ->all()
    ->first()
    ->one()
    ->count()
    ->assertCount(3, 'message')
    ->assertAllShareReceiver('message')
```

## MethodScope

```php
$scope = $this->inMethod('App\Repository\OrderRepository', 'save');
$scope->values()->kind('parameter')->all();
$scope->calls()->kind('method')->all();
$scope->getScopePattern();  // "App/Repository/OrderRepository#save()"
```

## Assertion APIs

### ReferenceConsistencyAssertion

```php
$result = $this->assertReferenceConsistency()
    ->inMethod('App\Repository\OrderRepository', 'save')
    ->forParameter('$order')     // or ->forLocal('$varName')
    ->verify();

$result->success;       // bool
$result->valueCount;    // int (should be 1)
$result->callCount;     // int (usages as receiver)
```

### ChainIntegrityAssertion

```php
$result = $this->assertChain()
    ->startingFrom('App\Service\OrderService', 'createOrder', '$this')
    ->throughAccess('orderRepository')
    ->throughMethod('save')
    ->verify();

$result->stepCount();   // int
$result->finalType();   // string or null
$result->rootValue();   // array (starting value)
$result->finalValue();  // array (final result value)
$result->steps();       // array (all steps)
```

### ArgumentBindingAssertion

```php
$this->assertArgument()
    ->inMethod('App\Service\OrderService', 'createOrder')
    ->atCall('save')              // or ->atLine(40)
    ->position(0)
    ->pointsToLocal('$order')     // or ->pointsToParameter('$param')
                                  // or ->pointsToResultOf('access', 'pattern')
                                  // or ->pointsToLiteral()
    ->verify();
```

### DataIntegrityAssertion

```php
$this->assertIntegrity()
    ->noParameterDuplicates()
    ->noLocalDuplicatesPerLine()
    ->allReceiverValueIdsExist()
    ->allArgumentValueIdsExist()
    ->allSourceCallIdsExist()
    ->allSourceValueIdsExist()
    ->everyCallHasResultValue()
    ->resultValueTypesMatch()
    ->verify();

// Or get report without failing:
$report = $this->integrityReport();
$report->hasIssues();    // bool
$report->totalIssues();  // int
$report->summary();      // string
```

## CallsData Direct Access

```php
$data = $this->callsData();

$data->valueCount();
$data->callCount();
$data->version();

$data->values();
$data->calls();

$data->getValueById('src/File.php:10:8');
$data->getCallById('src/File.php:10:18');

$data->hasValue('src/File.php:10:8');
$data->hasCall('src/File.php:10:18');
```

## SCIP Symbol Patterns

```
Namespace conversion:
  App\Repository\OrderRepository → App/Repository/OrderRepository

Symbol patterns:
  Class#method().              - Method scope
  Class#method().($param)      - Parameter
  Class#method().local$var@42  - Local variable at line 42
  Class#$property.             - Property

Wildcard patterns:
  *OrderRepository#save().*    - Any OrderRepository.save scope
  *#save().($order)            - Any save method's $order parameter
```

## Test File Organization

```
kloc-reference-project-php/contract-tests/tests/
├── SmokeTest.php              # Basic smoke tests
├── Reference/                  # Category 1: Reference Consistency
│   └── ParameterReferenceTest.php
├── Chain/                      # Category 2: Chain Integrity
│   └── ChainIntegrityTest.php
├── Argument/                   # Category 3: Argument Binding
│   └── ArgumentBindingTest.php
└── Integrity/                  # Category 4: Data Integrity
    └── DataIntegrityTest.php
```
