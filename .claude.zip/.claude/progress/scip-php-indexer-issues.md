# Progress: scip-php-indexer-issues

## Phase 1: Callee verification guard (Issue 6) [kloc-cli]
- [x] Add callee verification in find_call_for_usage() line-matching loop (context.py:198-209)
- [x] Add callee verification in fallback container-matching loop (context.py:212-220)
- [x] Write unit test: find_call_for_usage returns None when callee doesn't match target_id
- [x] Write integration test: $nextId shows [static_property] not [instantiation]
- [x] Write integration test: getName() shows [method_call] not [property_access]
- [x] Write integration test: $customerEmail doesn't show [method_call] with wrong receiver

## Phase 2: Per-subtree visited set (Issue 5) [kloc-cli]
- [x] Replace global visited set with cycle_guard + per-parent local_visited
- [x] Preserve cycle prevention for start_id
- [x] Write integration test: depth-2 includes $customerEmail and $productId under save()
- [x] Write integration test: depth-1 save() still shows all 10 uses
- [x] Write integration test: no infinite loops with self-referencing methods

## Phase 3: Uses edge location accuracy (Issues 2+4) [scip-php, kloc-mapper]
- [x] Investigate SCIP occurrence positions for self::$nextId++ at line 30 — CORRECT, no fix needed
- [x] ~~Fix location source~~ — N/A, data already correct
- [x] Verify $savedOrder->customerEmail gets separate occurrence position — CONFIRMED correct
- [x] ~~Rebuild reference project index~~ — N/A, no changes needed

## Phase 4: call_kind for chained method calls (Issue 3) [scip-php]
- [x] Investigate calls.json output for getName() at line 43 — call_kind=method (CORRECT)
- [x] ~~Fix call_kind assignment~~ — N/A, already correct
- [x] ~~Rebuild reference project index~~ — N/A, no changes needed
- [x] Verify fix doesn't break existing contract tests — 224/224 passing

## Phase 5: Testing and validation
- [x] Run kloc-cli test suite — 59 passed, 0 failed
- [x] Run kloc-mapper test suite — 56 passed, 0 failed
- [x] Run scip-php contract tests — 224 passed, 30 skipped, 0 failed
- [x] End-to-end validation against all 8 acceptance criteria — ALL PASS
- [x] Verify no regressions in test_usage_flow.py — ALL PASS
