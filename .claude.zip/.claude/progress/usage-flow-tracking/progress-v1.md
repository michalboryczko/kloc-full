# Progress: usage-flow-tracking (v1)

<!-- Steps are numbered. Substeps use parent.child notation. -->
<!-- Status markers: [ ] pending, [~] in_progress, [w] waiting, [x] done -->

## 1. [x] Add reference types from sot.json (Phase 1a)
- [x] **1.1** Add reference_type field to MemberRef dataclass in results.py
- [x] **1.2** Create _infer_reference_type() helper in context.py for edge-based classification
- [x] **1.3** Call _infer_reference_type() when creating MemberRef in _build_incoming_tree()
- [x] **1.4** Update print_context_tree() to display [reference_type] after member name
- [x] **1.5** Update context_tree_to_dict() to include reference_type in member_ref dict
- [x] **1.6** Add unit tests for reference type inference

## 2. [x] Add access chains from calls.json (Phase 1b)
- [x] **2.1** Create kloc-cli/src/graph/calls.py with CallsData class
- [x] **2.2** Implement msgspec structs for calls.json schema (ValueRecord, CallRecord)
- [x] **2.3** Implement CallsData.load() with indexed lookups (by_id, by_location)
- [x] **2.4** Implement CallsData.get_call_at(file, line, col) for location-based lookup
- [x] **2.5** Implement CallsData.build_access_chain(call) using receiver_value_id traversal
- [x] **2.6** Add access_chain field to MemberRef dataclass
- [x] **2.7** Add --calls / -c option to context command in cli.py
- [x] **2.8** Modify ContextQuery.execute() to accept optional calls_data parameter
- [x] **2.9** Integrate calls lookup in _build_incoming_tree() when calls_data available
- [x] **2.10** Update print_context_tree() to display on: chain when access_chain present
- [x] **2.11** Update context_tree_to_dict() to include access_chain in output
- [x] **2.12** Add integration tests using kloc-reference-project-php calls.json

## 3. [x] Testing and validation
- [x] **3.1** Create test fixtures from kloc-reference-project-php output
- [x] **3.2** Test TC1: Type hint detection (OrderService -> $orderRepository)
- [x] **3.3** Test TC2: Method call via property (createOrder() -> save())
- [x] **3.4** Test TC3: Interface type hint (OrderService -> EmailSenderInterface)
- [x] **3.5** Test TC4: Interface method call (createOrder() -> send())
- [x] **3.6** Test TC5: Constructor call (createOrder() -> new Order())
- [x] **3.7** Test TC6: Multiple references same scope (save() and findById())
- [x] **3.8** Verify JSON output format matches spec
- [x] **3.9** Verify graceful degradation without --calls

## 4. [x] Fix TC8: Constructor call detection for direct class references
- [x] **4.1** Add calls_data lookup in direct reference branch for constructor detection
- [x] **4.2** Add get_constructor_at method to CallsData class
- [x] **4.3** Add test case for TC8 constructor detection

