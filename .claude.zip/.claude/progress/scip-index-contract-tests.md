# Progress: SCIP Index Contract Tests

## Feature
Add SCIP index validation support to contract test framework.

## Status: Complete

## Steps

### Phase 1: Framework Implementation
- [x] **1.1** Install scip CLI in Docker container (Dockerfile)
- [x] **1.2** Add SCIP JSON generation to bin/run.sh
- [x] **1.3** Create ScipData.php to load index.scip.json
- [x] **1.4** Create ScipQuery.php for querying SCIP data
- [x] **1.5** Create SymbolQuery.php for symbol queries
- [x] **1.6** Create OccurrenceQuery.php for occurrence queries
- [x] **1.7** Update CallsContractTestCase to load SCIP data
- [x] **1.8** Update config.php and bootstrap.php with SCIP paths
- [x] **1.9** Verify framework works (manual test) - 161 tests pass

### Phase 2: Test Directory Reorganization
- [x] **2.1** Create tests/Scip/ directory
- [x] **2.2** Create tests/Combined/ directory
- [N/A] **2.3** Create tests/Calls/ directory (defer - existing tests stay in place)
- [N/A] **2.4** Move existing tests to tests/Calls/ (defer to separate PR)

### Phase 3: SCIP Contract Tests
- [x] **3.1** Create tests/Scip/TypeHint/TypeHintTest.php (6 tests)
- [x] **3.2** Create tests/Scip/Inheritance/InheritanceTest.php (5 tests)
- [x] **3.3** Create tests/Scip/Symbol/SymbolTest.php (7 tests)
- [x] **3.4** Create tests/Scip/Occurrence/OccurrenceTest.php (8 tests)

### Phase 4: Combined Validation Tests
- [x] **4.1** Create tests/Combined/Consistency/ConsistencyTest.php (6 tests)
- [N/A] **4.2** tests/UsageFlow/ already exists from previous work

### Phase 5: Validation
- [x] **5.1** Run all contract tests - 193 tests, 1027 assertions
- [x] **5.2** Verify SCIP tests pass - All pass (15 skipped are experimental)
- [ ] **5.3** Commit changes

## Test Results Summary

| Category | Tests |
|----------|-------|
| Existing calls.json tests | 161 |
| New SCIP tests | 26 |
| New Combined tests | 6 |
| **Total** | **193** |

All tests pass (15 skipped are experimental tests that require --experimental flag).

## Files Created

### Framework
- `src/ScipData.php` - SCIP JSON data loader
- `src/Query/ScipQuery.php` - Entry point for SCIP queries
- `src/Query/SymbolQuery.php` - Symbol filtering
- `src/Query/OccurrenceQuery.php` - Occurrence filtering

### Tests
- `tests/Scip/TypeHint/TypeHintTest.php`
- `tests/Scip/Inheritance/InheritanceTest.php`
- `tests/Scip/Symbol/SymbolTest.php`
- `tests/Scip/Occurrence/OccurrenceTest.php`
- `tests/Combined/Consistency/ConsistencyTest.php`

### Modified
- `Dockerfile` - Added scip CLI installation
- `bin/run.sh` - Added SCIP JSON generation
- `config.php` - Added scip_json path
- `tests/bootstrap.php` - Added SCIP_JSON_PATH constant
- `src/CallsContractTestCase.php` - Added SCIP query methods

## Context Files
- Spec: docs/specs/scip-index-contract-tests.md
- Existing framework: kloc-reference-project-php/contract-tests/src/
- Existing tests: kloc-reference-project-php/contract-tests/tests/
