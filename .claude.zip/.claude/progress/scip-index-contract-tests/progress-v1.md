# Progress: scip-index-contract-tests (v1)

<!-- Steps are numbered. Substeps use parent.child notation. -->
<!-- Status markers: [ ] pending, [~] in_progress, [w] waiting, [x] done -->

## 1. [x] Install scip CLI in Dockerfile

## 2. [x] Add SCIP JSON generation to bin/run.sh

## 3. [x] Create ScipData.php class

## 4. [x] Create ScipQuery.php query builder

## 5. [x] Create SymbolQuery.php query builder

## 6. [x] Create OccurrenceQuery.php query builder

## 7. [x] Update CallsContractTestCase.php with SCIP support

## 8. [x] Update config.php and bootstrap.php for SCIP paths

## 9. [x] Test the framework - verify existing tests pass

