# Progress: unified-graph-format (v1)

<!-- Steps are numbered. Substeps use parent.child notation. -->
<!-- Status markers: [ ] pending, [~] in_progress, [w] waiting, [x] done -->

## 1. [x] Extend kloc-mapper models and add .kloc archive support
- [x] **1.1** Add VALUE and CALL to NodeKind enum in src/models.py
- [x] **1.2** Add value_kind field to Node dataclass
- [x] **1.3** Add call_kind field to Node dataclass
- [x] **1.4** Add type_symbol field to Node dataclass
- [x] **1.5** Add new edge types to EdgeType enum (type_hint, calls, receiver, argument, produces, assigned_from, type_of)
- [x] **1.6** Add position field to Edge dataclass
- [x] **1.7** Create src/archive.py with KlocArchive class for .kloc loading
- [x] **1.8** Add manifest.json parsing to archive loader
- [x] **1.9** Update SoTGraph version to 2.0
- [x] **1.10** Update CLI to accept .kloc or .scip input
- [x] **1.11** Add unit tests for new models

## 2. [x] Transform calls.json data into graph nodes and edges
- [x] **2.1** Create src/calls_mapper.py module
- [x] **2.2** Implement Value node creation from calls.json values array
- [x] **2.3** Generate Value node IDs based on file:line:col location
- [x] **2.4** Implement Call node creation from calls.json calls array
- [x] **2.5** Generate Call node IDs based on file:line:col location
- [x] **2.6** Generate contains edges from Method/Function to Call nodes
- [x] **2.7** Generate calls edges from Call nodes to target Method/Function/Property
- [x] **2.8** Generate receiver edges from Call nodes to Value nodes
- [x] **2.9** Generate argument edges with position from Call nodes to Value nodes
- [x] **2.10** Generate produces edges from Call nodes to result Value nodes
- [x] **2.11** Generate assigned_from edges between Value nodes
- [x] **2.12** Generate type_of edges from Value nodes to Class/Interface nodes
- [x] **2.13** Generate type_hint edges from Argument/Property/Method to type nodes
- [x] **2.14** Integrate calls_mapper into SCIPMapper pipeline
- [x] **2.15** Add integration tests with kloc-reference-project-php

## 3. [x] Update CLI to consume the new unified graph format
- [x] **3.1** Remove --calls option from context command in src/cli.py
- [x] **3.2** Delete src/graph/calls.py file
- [x] **3.3** Update NodeData model to include value_kind, call_kind, type_symbol fields
- [x] **3.4** Update EdgeData model to include position field
- [x] **3.5** Update loader.py NodeSpec/EdgeSpec for new fields
- [x] **3.6** Update SoTIndex to index VALUE and CALL nodes
- [x] **3.7** Update SoTIndex edge indexing for new edge types
- [x] **3.8** Implement build_access_chain function in context.py
- [x] **3.9** Implement get_containing_scope helper function
- [x] **3.10** Update ContextQuery to traverse graph for access chains
- [x] **3.11** Update tree.py to display Call/Value nodes
- [x] **3.12** Update tree.py to show new edge types
- [x] **3.13** Add unit tests for new graph traversal functions
- [x] **3.14** Update integration tests

## 4. [x] Comprehensive testing and documentation updates
- [x] **4.1** Create end-to-end test: .kloc -> sot.json -> CLI queries
- [x] **4.2** Test method call chain traversal
- [x] **4.3** Test constructor call generation
- [x] **4.4** Test access chain traversal for chained property access
- [x] **4.5** Test type_hint vs method_call edge differentiation
- [x] **4.6** Test backward compatibility with v1.0 sot.json
- [x] **4.7** Test backward compatibility with plain .scip input
- [x] **4.8** Performance test with large codebase
- [x] **4.9** Update kloc-mapper CLAUDE.md
- [x] **4.10** Update kloc-cli CLAUDE.md
- [x] **4.11** Update README files as needed

