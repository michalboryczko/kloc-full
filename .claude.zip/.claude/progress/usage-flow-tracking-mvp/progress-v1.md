# Progress: usage-flow-tracking-mvp (v1)

<!-- Steps are numbered. Substeps use parent.child notation. -->
<!-- Status markers: [ ] pending, [~] in_progress, [w] waiting, [x] done -->

## 1. [x] Implement R8: Depth chaining rules (Foundation)
- [x] **1.1** Define CHAINABLE_REFERENCE_TYPES constant in context.py
- [x] **1.2** Modify depth expansion to check reference_type before expanding children
- [x] **1.3** Treat entries without member_ref or reference_type as non-chainable (leaf)
- [x] **1.4** Add inline comments explaining chaining rule rationale

## 2. [x] Implement R7: Recursive USED BY depth (Foundation)
- [x] **2.1** Add _resolve_containing_method(node_id) helper to ContextQuery
- [x] **2.2** Modify child expansion: resolve containing method, find callers of that method at depth N+1
- [x] **2.3** Handle case where source IS a method (use directly) vs File node (no chaining)
- [x] **2.4** Implement per-branch visited set for cycle prevention
- [x] **2.5** Verify USES direction depth still works correctly

## 3. [x] Implement R3: External-only USED BY for class queries (Foundation)
- [x] **3.1** Add _is_internal_reference(source_id, target_class_id) helper
- [x] **3.2** Filter out internal references in _build_incoming_tree() for Class/Interface/Trait/Enum targets
- [x] **3.3** Handle self:: and static:: edge cases
- [x] **3.4** Ensure filter does NOT apply to method-level queries

## 4. [x] Implement R1: Hide import statements by default (Core)
- [x] **4.1** Add with_imports parameter to ContextQuery.execute()
- [x] **4.2** Add --with-imports flag to context command in cli.py
- [x] **4.3** Add _is_import_reference() helper function in context.py
- [x] **4.4** Filter out imports in _build_incoming_tree() when with_imports is False
- [x] **4.5** Ensure --with-imports works with --json output

## 5. [x] Implement R6: FQN identifiers for OOP symbols (Core)
- [x] **5.1** Add resolve_file_to_class() helper to SoTIndex in graph/index.py
- [x] **5.2** Resolve File node entries to class FQN in _build_incoming_tree()
- [x] **5.3** Implement resolution rules: single class, multiple classes (filename match), no class

## 6. [x] Implement R2: Sort results by line number (Core)
- [x] **6.1** Sort entries in _build_incoming_tree() by (file, line)
- [x] **6.2** Sort entries in _build_outgoing_tree() by (file, line)
- [x] **6.3** Sort entries in _build_deps_subtree() for consistency

## 7. [x] Implement R4: Access chain property FQN (Polish)
- [x] **7.1** Add access_chain_symbol field to MemberRef in models/results.py
- [x] **7.2** Create resolve_access_chain_symbol() helper in context.py
- [x] **7.3** Populate access_chain_symbol when building entries with access chains
- [x] **7.4** Update print_context_tree() to display property FQN after access chain
- [x] **7.5** Update context_tree_to_dict() to include access_chain_symbol in JSON
- [x] **7.6** Omit field when property FQN cannot be resolved (no placeholder)

## 8. [x] Implement R5: Complete method signatures (Polish)
- [x] **8.1** Investigate root cause: check sot.json FQN/docs for methods with PHP attributes
- [x] **8.2** Fix signature property regex in node.py to handle PHP attributes
- [x] **8.3** Fix extract_fqn_from_descriptor() in mapper if FQN includes attribute text
- [x] **8.4** Ensure (...) shorthand used for long signatures, never mid-expression truncation

## 9. [x] Testing and validation
- [x] **9.1** Run existing tests to confirm no regressions
- [x] **9.2** Test Scenario 1 (R8): OrderRepository depth 3 -- no depth-2 under type_hint
- [x] **9.3** Test Scenario 2 (R7): OrderRepository depth 2 -- depth-2 shows OrderController under OrderService
- [x] **9.4** Test Scenario 3 (R3): OrderService class -- no internal self-references
- [x] **9.5** Test Scenario 4 (R1): Default hides imports; --with-imports shows them
- [x] **9.6** Test Scenario 5 (R6): No file paths as primary identifiers
- [x] **9.7** Test Scenario 6 (R2): USES entries sorted by line number
- [x] **9.8** Test Scenario 7 (R4): Access chain shows property FQN
- [x] **9.9** Test Scenario 8 (R5): OrderController::create(...) signature well-formed
- [x] **9.10** Test Scenario 9 (R8+R7): OrderRepository depth 3 -- correct chain Repository <- Service <- Controller
- [x] **9.11** Test Scenario 10 (R8 negative): OrderController not under type_hint branch

