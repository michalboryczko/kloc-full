# Audit Results: File Path References Outside `.claude/`

## Summary

Found **5 items** that create files outside `.claude/` directory:
- 2 agents
- 3 skills

## Results

### Agents

**ai-engineer.md** - No file creation paths specified (outputs code to user's project)

**feature-implementer.md** - OK, uses `.claude/progress/{feature-name}.md`

**feature-planner.md** - Creates files in `docs/specs/`:
- Output: `docs/specs/{feature-name}-plan.md`
- Also uses: `.claude/progress/{feature-name}/progress-v1.md` (OK)

**generalist-qa.md** - No file creation paths specified (creates tests in project test directories)

**prd.md** - Creates `prd.md` at project root or user-specified location:
- Output: `prd.md` (user location or project root)

**scip-php-contract-qa.md** - OK, uses `kloc/.claude/scip-php-contract-qa/{feature_name}/`

**software-engineer-agent-v1.md** - No file creation paths specified (general agent)

---

### Skills

**code-reviewer** - No file creation (uses scripts for analysis only)

**context7-docs** - No file creation (fetches documentation)

**feature-issues** - OK, uses `.claude/feature-issues/{feature}/issues-v*.md`

**feature-request** - Creates files in `docs/specs/`:
- Output: `docs/specs/<kebab-case-title>.md`

**kloc-scip-contract-scenarios** - No file output specified (generates content for other tools)

**kloc-scip-contract-test-create** - Creates tests in `kloc-reference-project-php/contract-tests/tests/`
- This is project code, not agent artifacts - expected behavior

**kloc-scip-contract-test-run** - Uses `/tmp/` for temp output
- Minor issue: should use scratchpad directory instead

**note** - Creates files at project root:
- Output: `notes.md`

**progress-tracker** - OK, uses `.claude/progress/{feature_name}/`

**prompt-engineering-dspy** - No file creation (documentation skill)

**run-workflow** - OK, uses `.claude/workflows/`

**senior-architect** - No file creation (uses scripts for analysis only)

**skill-creator** - Creates skills in `.claude/skills/` (appropriate location)

**workflow-creator** - OK, uses `.claude/workflows/{workflow-name}/`

**writing-plans** - Creates files in `docs/plans/`:
- Output: `docs/plans/YYYY-MM-DD-<feature-name>.md`

---

## Items Needing Update

| Item | Type | Current Path | Recommended Path |
|------|------|--------------|------------------|
| feature-planner | agent | `docs/specs/{name}-plan.md` | `.claude/specs/{name}-plan.md` |
| feature-request | skill | `docs/specs/{name}.md` | `.claude/specs/{name}.md` |
| note | skill | `notes.md` | `.claude/notes.md` |
| writing-plans | skill | `docs/plans/{date}-{name}.md` | `.claude/plans/{date}-{name}.md` |
| prd | agent | `prd.md` (user location) | Consider `.claude/prd/{name}.md` |

## Considerations

Some files may intentionally be placed in `docs/` because:
1. They're meant to be committed to version control as project documentation
2. They're human-readable specs that the team references
3. They're part of the project's documentation, not Claude artifacts

**Recommendation**: Ask the user whether these should be:
- A) Moved to `.claude/` for consistency (Claude-only artifacts)
- B) Kept in `docs/` (project documentation, committed to repo)
