# TDD SCIP Orchestrator

Test-Driven Development workflow for scip-php indexer features using contract tests.

## Quick Start

```
/run-workflow tdd-scip-orchestrator

Feature name: nullsafe-operator-tracking
Context: Track nullsafe operators (?->) in PHP code...
```

## Key Differences from feature-orchestrator

| Aspect | feature-orchestrator | tdd-scip-orchestrator |
|--------|---------------------|----------------------|
| Testing | generalist-qa (notes) | scip-php-contract-qa (tests) |
| Approach | QA notes → implement → validate | Create tests → implement → validate |
| Test artifacts | `.claude/qa-notes/` | `.claude/scip-php-contract-qa/{feature}/` |
| Implementer can run tests | No | Yes (via skill) |
| Implementer can modify tests | N/A | NO (forbidden) |
| QA agent resume | Fresh each time | Resume same agent (qa_agent_id) |

## Workflow Steps

1. **Feature Spec** - Generate spec from requirements
2. **Planning** - Create implementation plan
3. **Contract Test Setup** - Create tests BEFORE implementation (TDD)
4. **Implementation** - Implement to make tests pass (can run tests, cannot modify)
5. **Validation** - Resume QA agent to validate
6. **Fix Loop** - If tests fail, fix implementation and re-validate
7. **Summary** - Report completion status

## Agent IDs

The workflow tracks:
- `qa_agent_id` - For resuming the scip-php-contract-qa agent

## Skills Used

- `feature-request` - Generate spec
- `kloc-scip-contract-test-run` - Implementer runs tests to verify changes

## Agents Used

- `feature-planner` - Create implementation plan
- `scip-php-contract-qa` - Setup and validate contract tests
- `feature-implementer` - Implement the feature
