# TDD SCIP Orchestrator Workflow

Coordinate end-to-end feature development for scip-php indexer using Test-Driven Development with contract tests. This workflow creates contract tests BEFORE implementation, then validates implementation against those tests.

## Required Context

| Field | Required | Description |
|-------|----------|-------------|
| `feature_name` | Yes | Kebab-case name for the feature (e.g., 'nullsafe-operator-tracking') |
| `context` | Yes | Description, requirements, or reference files for the feature |
| `context_files` | No | List of relevant files to pass to sub-agents |

### Validation Rules

- Feature name must be provided in kebab-case format
- At least a description or context files must be provided

## Progress Tracking

Progress files: `.claude/progress/{feature_name}.md`
Spec files: `docs/specs/{feature_name}.md`
Plan files: `docs/specs/{feature_name}-plan.md`
Contract QA artifacts: `.claude/scip-php-contract-qa/{feature_name}/`

## Workflow Steps

### Step 1: Feature Request Spec

**Goal**: Generate a detailed feature specification document.

**Actions**:
1. Invoke the `feature-request` skill via the Skill tool with the user's context
2. Pass: feature name, description, and any context files
3. Wait for completion

**Completion Criteria**:
- File exists at `docs/specs/{feature_name}.md`
- Contains sections: Goal, Usage examples, Detailed behavior, Edge cases, Dev notes, Acceptance criteria

---

### Step 2: Feature Planning (Subagent)

**Goal**: Create a detailed implementation plan based on the spec.

**CRITICAL**: Spawn the `feature-planner` subagent using the Task tool.

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "feature-planner",
     prompt: "Plan the feature {feature_name}.
              Spec file: docs/specs/{feature_name}.md
              Context files: {context_files}
              Feature name: {feature_name}"
   )
   ```
2. Wait for completion
3. Read the generated plan file

**Completion Criteria**:
- Plan file exists at `docs/specs/{feature_name}-plan.md`
- Progress file exists at `.claude/progress/{feature_name}.md`
- Progress file has all steps marked as `pending`

---

### Step 2.5: Contract Test Setup (Subagent) - TDD

**Goal**: Create contract tests BEFORE implementation using the scip-php-contract-qa agent. This is the TDD approach - tests first.

**CRITICAL**: Spawn the `scip-php-contract-qa` subagent in **setup mode** using the Task tool.

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     prompt: "Run contract QA in SETUP mode for feature: {feature_name}

              ## Feature Context
              {feature_description_and_requirements}

              ## Spec and Plan
              - Spec file: docs/specs/{feature_name}.md
              - Plan file: docs/specs/{feature_name}-plan.md
              - Context files: {context_files}

              ## Your Task
              1. Validate existing tests pass (ABORT if failures)
              2. Generate test scenarios from the feature spec
              3. Find or create reference code in kloc-reference-project-php/src
              4. Create contract tests for each scenario
              5. Ensure tests are runnable (they may fail - that's expected in TDD)

              ## Output
              All artifacts go to: .claude/scip-php-contract-qa/{feature_name}/"
   )
   ```
2. Wait for completion
3. **IMPORTANT**: Store the agent ID for later resume: `qa_agent_id = {returned_agent_id}`
4. Read the generated artifacts:
   - `.claude/scip-php-contract-qa/{feature_name}/scenarios.md`
   - `.claude/scip-php-contract-qa/{feature_name}/summary.md`
   - `.claude/scip-php-contract-qa/{feature_name}/updated_status.md`
5. Verify tests are runnable (may be failing - expected in TDD)

**Contract Test Validation Loop**:
If test setup fails or scenarios are incomplete:
1. Resume the same agent:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_agent_id}",
     prompt: "Test setup incomplete. Issues:
              {list_of_issues}

              Please fix and complete the test setup."
   )
   ```
2. Repeat until tests are runnable (max 3 iterations)

**Completion Criteria**:
- QA artifacts exist at `.claude/scip-php-contract-qa/{feature_name}/`
- Contract tests are created and runnable
- `qa_agent_id` is stored for Step 4

---

### Step 3: Feature Implementation (Subagent)

**Goal**: Implement the feature following the plan. Implementer can run tests to verify own changes but CANNOT modify tests.

**CRITICAL**: Spawn the `feature-implementer` subagent using the Task tool.

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "feature-implementer",
     prompt: "Implement feature {feature_name} following the plan.

              ## Files
              - Plan file: docs/specs/{feature_name}-plan.md
              - Spec file: docs/specs/{feature_name}.md
              - Progress file: .claude/progress/{feature_name}.md
              - Context files: {context_files}

              ## Contract Tests (TDD)
              Contract tests have been created BEFORE implementation.
              - Test scenarios: .claude/scip-php-contract-qa/{feature_name}/scenarios.md
              - Test status: .claude/scip-php-contract-qa/{feature_name}/updated_status.md
              - Tests location: kloc-reference-project-php/contract-tests/tests/

              ## Running Tests
              Use the skill `kloc-scip-contract-test-run` to run tests and verify your changes:
              ```bash
              cd kloc-reference-project-php/contract-tests && bin/run.sh test
              ```
              Or run specific tests:
              ```bash
              cd kloc-reference-project-php/contract-tests && bin/run.sh test --filter {test_name}
              ```

              ## CRITICAL RULES
              1. You MAY run tests to verify your implementation
              2. You MUST NOT modify the contract tests
              3. Your goal is to make the tests PASS through implementation changes
              4. If a test seems wrong, note it but DO NOT change the test
              5. QA agent will validate after you're done"
   )
   ```
2. Wait for completion
3. Read the progress file to check implementation status
4. Capture implementer's notes about any test concerns

**Completion Criteria**:
- Feature-implementer has completed its work
- Check progress file for step completion status

---

### Step 4: Contract Test Validation (Subagent) - MANDATORY

**Goal**: Validate implementation against contract tests. **CRITICAL: Feature is NOT complete until contract tests pass.**

**CRITICAL**: Resume the same `scip-php-contract-qa` agent using the stored `qa_agent_id`.

**Actions**:
1. Summarize implementation context from feature-implementer
2. Resume the QA agent via Task tool:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_agent_id}",
     prompt: "Run contract QA in VALIDATE mode for feature: {feature_name}

              ## Implementation Complete
              The feature-implementer has completed implementation.

              ## Context from Implementer
              {summary_of_what_implementer_built}
              {any_notes_or_concerns_from_implementer}

              ## Your Task
              1. Run all contract tests
              2. Compare with previous state
              3. Report PASS/FAIL/PARTIAL
              4. If failures, provide detailed report for implementer"
   )
   ```
3. Wait for completion and capture validation results

**Validation Results Handling**:
- If **PASS**: Proceed to Step 5 (Progress Validation)
- If **FAIL** or **PARTIAL**: Go to **Step 4.5: Implementation Fix Loop**

---

### Step 4.5: Implementation Fix Loop (CRITICAL)

**Goal**: Fix issues found by contract tests and re-validate until tests pass.

**CRITICAL**: This loop MUST continue until tests pass. Feature cannot be marked complete with failing tests.

**Actions (repeat until tests pass or max 5 iterations)**:
1. Spawn `feature-implementer` with test failure context:
   ```
   Task(
     subagent_type: "feature-implementer",
     prompt: "Fix contract test failures for feature {feature_name}

              ## Test Failure Report
              {detailed_test_failure_report}

              ## Context
              - Plan file: docs/specs/{feature_name}-plan.md
              - Spec file: docs/specs/{feature_name}.md
              - Test scenarios: .claude/scip-php-contract-qa/{feature_name}/scenarios.md
              - Progress file: .claude/progress/{feature_name}.md
              - Context files: {context_files}

              ## Running Tests
              Use skill `kloc-scip-contract-test-run` to verify fixes:
              ```bash
              cd kloc-reference-project-php/contract-tests && bin/run.sh test
              ```

              ## CRITICAL RULES
              1. Fix the implementation to make tests pass
              2. DO NOT modify the contract tests
              3. If a test is genuinely incorrect, note it for QA review
              4. QA will re-validate after your fixes"
   )
   ```
2. Wait for implementer to complete fixes
3. Capture summary of fixes made
4. Resume QA agent for re-validation:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_agent_id}",
     prompt: "Re-validate feature {feature_name} after fixes

              ## Previous Failures
              {previous_test_failures}

              ## Fixes Applied
              {summary_of_fixes_from_implementer}

              ## Implementer Notes
              {any_concerns_about_tests}

              ## Required
              1. Run contract tests
              2. Verify previously failing tests now pass
              3. Check for regressions
              4. Report PASS or FAIL with details"
   )
   ```
5. If QA reports **PASS**: Exit loop, proceed to Step 5
6. If QA reports **FAIL**: Repeat from step 1

**Iteration Tracking**:
- Track iteration count
- After 5 iterations with failing tests: STOP and report to user
- User must decide whether to continue, adjust tests, or accept current state

**Completion Criteria**:
- Contract tests report PASS
- OR: Maximum 5 iterations reached (report to user for manual decision)

---

### Step 5: Progress Validation Loop

**Goal**: Ensure all implementation steps are complete AND git workflow was executed.

**Actions**:
1. Read progress file at `.claude/progress/{feature_name}.md`
2. Check if ALL steps are marked as `done`
3. Check git status:
   - Run `git branch --show-current` to verify we're on a feature branch (not `main`/`master`)
   - Run `git log --oneline -1` to verify there's a commit for this feature
4. If any steps remain incomplete OR git workflow incomplete:
   - Identify what's missing
   - Re-spawn `feature-implementer` to complete:
     ```
     Task(
       subagent_type: "feature-implementer",
       prompt: "Continue implementing feature {feature_name}.
                Remaining steps: {list_of_incomplete_steps}
                Missing git workflow: {branch_missing or commit_missing}
                Plan file: docs/specs/{feature_name}-plan.md
                Progress file: .claude/progress/{feature_name}.md

                Use skill `kloc-scip-contract-test-run` to verify tests still pass.
                DO NOT modify contract tests."
     )
     ```
   - **After implementer completes**: Re-run validation (resume qa_agent_id) - go back to Step 4
5. Repeat until (all steps `done` AND on feature branch AND commit exists AND tests pass) OR max 3 loops

**Completion Criteria**:
- All steps in progress file marked as `done`
- On a feature branch (not main/master)
- Commit exists for the implementation
- Contract tests PASS (from Step 4)
- OR: 3 validation loops completed (report to user)

---

### Step 6: Summary

**Goal**: Report completion status to user.

**Actions**:
1. Summarize what was implemented
2. List any files created or modified
3. Report contract test status:
   - Number of test iterations required
   - Final test result (PASS or MAX_ITERATIONS_REACHED)
   - Test coverage (from `.claude/scip-php-contract-qa/{feature_name}/summary.md`)
4. Report git status:
   - Current branch name
   - Commit hash and message for the implementation commit
5. Report any remaining incomplete steps (if validation loop maxed out)
6. Suggest next steps (push, create PR, additional testing, review, etc.)

**Completion Criteria**:
- User has been informed of the outcome
- User knows the contract test status
- User knows the branch name and can push when ready

## Error Handling

- If feature-request skill fails: Report error and ask user to provide more context
- If feature-planner fails: Report error, check if spec file exists, retry once
- If scip-php-contract-qa fails in setup: Report error, check for existing test failures
- If feature-implementer fails: Report error, check progress file, retry with remaining steps
- If tests fail after 5 iterations: Report to user with detailed failure info for manual decision
- After 3 validation loops with incomplete steps: Report to user for manual intervention

## Rules

- ALWAYS pass the same feature name to every tool/agent call
- NEVER skip steps or reorder them
- NEVER run steps in parallel - each step depends on the previous step's output
- NEVER implement code yourself - always delegate to feature-implementer
- After each step completes, read the output files and briefly summarize before proceeding
- If context files are provided by the user, pass them to EVERY sub-agent call
- NEVER push to remote - workflow ends with local commit, user decides when to push
- Feature is NOT complete until there's a commit on a feature branch

### TDD Contract Test Rules (CRITICAL)

- **Tests are created BEFORE implementation** (TDD approach)
- **NEVER mark a feature complete without contract tests passing**
- **Store and reuse qa_agent_id** - resume the same QA agent for validation
- **Implementer CAN run tests** to verify own changes
- **Implementer CANNOT modify tests** - only implementation
- **If tests seem wrong**: Implementer notes concerns, QA reviews in next iteration
- **The Implementer → QA loop continues until tests pass** (max 5 iterations)
- If tests cannot pass after 5 iterations, STOP and report to user

### Agent ID Tracking

Throughout this workflow, track these agent IDs for resume capability:
- `qa_agent_id`: From Step 2.5, used in Steps 4 and 4.5
- This enables the QA agent to maintain context about scenarios and test state
