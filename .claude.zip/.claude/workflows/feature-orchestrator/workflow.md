# Feature Orchestrator Workflow

Coordinate end-to-end feature development by delegating to specialized sub-agents. This workflow handles the full lifecycle from spec creation through implementation and validation.

## Required Context

| Field | Required | Description |
|-------|----------|-------------|
| `feature_name` | Yes | Kebab-case name for the feature (e.g., 'user-authentication') |
| `context` | Yes | Description, requirements, or reference files for the feature |
| `context_files` | No | List of relevant files to pass to sub-agents |

### Validation Rules

- Feature name must be provided in kebab-case format
- At least a description or context files must be provided

## Progress Tracking

Progress files: `.claude/progress/{feature_name}.md`
Spec files: `docs/specs/{feature_name}.md`
Plan files: `docs/specs/{feature_name}-plan.md`
QA notes: `.claude/qa-notes/{feature_name}_qa_ref_note.md`
Contract QA artifacts (if scip-php): `.claude/scip-php-contract-qa/{feature_name}/`

## scip-php Detection

After Step 2 (Planning), determine if the feature involves `scip-php` changes:

1. Read the spec and plan files
2. Check if any of these are true:
   - The spec mentions `scip-php`, `indexer`, `SCIP index`, or PHP indexing
   - The plan includes steps that modify files under `scip-php/`
   - Context files include files under `scip-php/`
   - The user explicitly mentioned scip-php as relevant
3. Set `scip_php_involved = true/false` based on the check
4. If `scip_php_involved`: Steps 2.7, 4.1 become MANDATORY, and the implementer receives contract test context

## Workflow Steps

### Step 1: Feature Request Spec

**Goal**: Generate a detailed feature specification document.

**Actions**:
1. Invoke the `feature-request` skill via the Skill tool with the user's context
2. Pass: feature name, description, and any context files
3. Wait for completion

**Completion Criteria**:
- File exists at `docs/specs/{feature_name}.md`
- Contains sections: Goal, Usage examples, Detailed behavior, Edge cases, Dev notes, Acceptance criteria

---

### Step 2: Feature Planning (Subagent)

**Goal**: Create a detailed implementation plan based on the spec.

**CRITICAL**: Spawn the `feature-planner` subagent using the Task tool.

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "feature-planner",
     prompt: "Plan the feature {feature_name}.
              Spec file: docs/specs/{feature_name}.md
              Context files: {context_files}
              Feature name: {feature_name}"
   )
   ```
2. Wait for completion
3. Read the generated plan file

**Completion Criteria**:
- Plan file exists at `docs/specs/{feature_name}-plan.md`
- Progress file exists at `.claude/progress/{feature_name}.md`
- Progress file has all steps marked as `pending`

---

### Step 2.5: QA Notes Generation (Subagent)

**Goal**: Create QA testing notes BEFORE implementation starts. These notes guide testing and become part of the feature spec.

**CRITICAL**: Spawn the `generalist-qa` subagent using the Task tool.

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "generalist-qa",
     prompt: "Create QA testing notes for feature: {feature_name}

              ## Your Task
              Create comprehensive QA testing notes that describe HOW to test this feature.
              Include test scenarios, edge cases, expected behaviors, and validation steps.

              ## Context
              - Spec file: docs/specs/{feature_name}.md
              - Plan file: docs/specs/{feature_name}-plan.md
              - Context files: {context_files}

              ## Output
              Write the QA notes to: .claude/qa-notes/{feature_name}_qa_ref_note.md

              ## Include in Notes
              - Test scenarios (happy path, edge cases, error cases)
              - Expected behaviors for each scenario
              - Data/fixtures needed for testing
              - Manual testing steps if applicable
              - Automated test expectations
              - Integration points to verify
              - Performance considerations if relevant"
   )
   ```
2. Wait for completion
3. Read the generated QA notes file
4. **Validate QA notes quality**:
   - Check if notes are comprehensive
   - Verify notes cover acceptance criteria from spec
   - Ensure notes have actionable test scenarios

**QA Notes Validation Loop**:
If QA notes are incomplete or missing critical scenarios:
1. Spawn `generalist-qa` again with:
   ```
   Task(
     subagent_type: "generalist-qa",
     prompt: "Improve QA testing notes for feature: {feature_name}

              ## Current QA Notes (need improvement)
              File: .claude/qa-notes/{feature_name}_qa_ref_note.md

              ## Issues Found
              {list_of_issues_with_current_notes}

              ## Context
              - Spec file: docs/specs/{feature_name}.md
              - Plan file: docs/specs/{feature_name}-plan.md

              ## Required
              Update the QA notes to address the issues above.
              Keep existing good content, add missing scenarios."
   )
   ```
2. Repeat validation until notes are satisfactory (max 3 iterations)

**Completion Criteria**:
- QA notes file exists at `.claude/qa-notes/{feature_name}_qa_ref_note.md`
- Notes contain test scenarios for happy path, edge cases, and error handling
- Notes align with acceptance criteria from spec
- Notes are actionable (implementer can reference them, QA can use them for testing)

---

### Step 2.7: Contract Test Setup (Subagent) - CONDITIONAL on scip-php

**Goal**: If `scip_php_involved == true`, create contract tests BEFORE implementation to validate indexer behavior.

**Skip Condition**: If `scip_php_involved == false`, skip this step entirely and proceed to Step 3.

**CRITICAL**: Spawn the `scip-php-contract-qa` subagent in **setup mode** using the Task tool.

**Actions**:
1. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     prompt: "Run contract QA in SETUP mode for feature: {feature_name}

              ## Feature Context
              {feature_description_and_requirements}

              ## Spec and Plan
              - Spec file: docs/specs/{feature_name}.md
              - Plan file: docs/specs/{feature_name}-plan.md
              - Context files: {context_files}

              ## Your Task
              1. Validate existing tests pass (ABORT if failures)
              2. Generate test scenarios from the feature spec
              3. Find or create reference code in kloc-reference-project-php/src
              4. Create contract tests for each scenario
              5. Ensure tests are runnable (they may fail - that's expected)

              ## Output
              All artifacts go to: .claude/scip-php-contract-qa/{feature_name}/"
   )
   ```
2. Wait for completion
3. **IMPORTANT**: Store the agent ID for later resume: `qa_contract_agent_id = {returned_agent_id}`
4. Read the generated artifacts:
   - `.claude/scip-php-contract-qa/{feature_name}/scenarios.md`
   - `.claude/scip-php-contract-qa/{feature_name}/summary.md`
   - `.claude/scip-php-contract-qa/{feature_name}/updated_status.md`
5. Verify tests are runnable (may be failing - expected before implementation)

**Contract Test Validation Loop**:
If test setup fails or scenarios are incomplete:
1. Resume the same agent:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_contract_agent_id}",
     prompt: "Test setup incomplete. Issues:
              {list_of_issues}

              Please fix and complete the test setup."
   )
   ```
2. Repeat until tests are runnable (max 3 iterations)

**Completion Criteria**:
- QA artifacts exist at `.claude/scip-php-contract-qa/{feature_name}/`
- Contract tests are created and runnable
- `qa_contract_agent_id` is stored for Step 4.1

---

### Step 3: Feature Implementation (Subagent)

**Goal**: Implement the feature following the plan.

**CRITICAL**: Spawn the `feature-implementer` subagent using the Task tool.

**Actions**:
1. Spawn subagent via Task tool. **If `scip_php_involved`**, include contract test context:
   ```
   Task(
     subagent_type: "feature-implementer",
     prompt: "Implement feature {feature_name} following the plan.
              Plan file: docs/specs/{feature_name}-plan.md
              Spec file: docs/specs/{feature_name}.md
              Progress file: .claude/progress/{feature_name}.md
              QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md
              Context files: {context_files}

              IMPORTANT: Reference the QA notes file while implementing.
              The QA notes describe test scenarios that will be validated after implementation.

              {IF scip_php_involved:}
              ## Contract Tests (scip-php)
              Contract tests have been created BEFORE implementation.
              - Test scenarios: .claude/scip-php-contract-qa/{feature_name}/scenarios.md
              - Test status: .claude/scip-php-contract-qa/{feature_name}/updated_status.md
              - Tests location: kloc-reference-project-php/contract-tests/tests/

              ## Running Contract Tests
              Use the skill `kloc-scip-contract-test-run` to run tests and verify your changes:
              ```bash
              cd kloc-reference-project-php/contract-tests && bin/run.sh test
              ```

              ## CRITICAL RULES for scip-php
              1. You MAY run contract tests to verify your implementation
              2. You MUST NOT modify the contract tests
              3. Your goal is to make the tests PASS through implementation changes
              4. If a test seems wrong, note it but DO NOT change the test
              {END IF}"
   )
   ```
2. Wait for completion
3. Read the progress file to check implementation status
4. If `scip_php_involved`: Capture implementer's notes about any contract test concerns

**Completion Criteria**:
- Feature-implementer has completed its work
- Check progress file for step completion status

---

### Step 4: QA Validation (Subagent) - MANDATORY

**Goal**: Run QA testing on the implemented feature. **CRITICAL: Feature is NOT complete until QA passes.**

**CRITICAL**: Spawn the `generalist-qa` subagent using the Task tool.

**Actions**:
1. Summarize implementation context from feature-implementer (what was built, any notes)
2. Spawn subagent via Task tool:
   ```
   Task(
     subagent_type: "generalist-qa",
     prompt: "Test the implemented feature: {feature_name}

              ## Your Task
              Execute QA testing based on the QA notes. Run tests, verify behaviors, check edge cases.

              ## Context from Orchestrator
              - Feature spec: docs/specs/{feature_name}.md
              - Implementation plan: docs/specs/{feature_name}-plan.md
              - QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md
              - Progress file: .claude/progress/{feature_name}.md
              - Context files: {context_files}

              ## Context from Implementer
              {summary_of_what_implementer_built}
              {any_notes_or_concerns_from_implementer}

              ## Required Actions
              1. Read the QA notes to understand test scenarios
              2. Run automated tests if they exist
              3. Verify expected behaviors from spec
              4. Check edge cases and error handling
              5. Document any failures or issues found

              ## Output
              Report:
              - PASS: All tests pass, feature works as expected
              - FAIL: List specific failures with details for implementer to fix

              If FAIL, be specific about:
              - What test/scenario failed
              - Expected vs actual behavior
              - Steps to reproduce
              - Suggested fix direction"
   )
   ```
3. Wait for completion and capture QA results

**QA Results Handling**:
- If **PASS**: Proceed to Step 5 (Progress Validation)
- If **FAIL**: Go to **Step 4.5: Implementation Fix Loop**

---

### Step 4.1: Contract Test Validation (Subagent) - CONDITIONAL on scip-php

**Goal**: If `scip_php_involved == true`, validate implementation against contract tests. **CRITICAL: Feature is NOT complete until contract tests pass.**

**Skip Condition**: If `scip_php_involved == false`, skip this step.

**CRITICAL**: Resume the same `scip-php-contract-qa` agent using the stored `qa_contract_agent_id`.

**Actions**:
1. Summarize implementation context from feature-implementer
2. Resume the QA agent via Task tool:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_contract_agent_id}",
     prompt: "Run contract QA in VALIDATE mode for feature: {feature_name}

              ## Implementation Complete
              The feature-implementer has completed implementation.

              ## Context from Implementer
              {summary_of_what_implementer_built}
              {any_notes_or_concerns_from_implementer}

              ## Your Task
              1. Run all contract tests
              2. Compare with previous state
              3. Report PASS/FAIL/PARTIAL
              4. If failures, provide detailed report for implementer"
   )
   ```
3. Wait for completion and capture contract validation results

**Contract Validation Results Handling**:
- If **PASS**: Proceed (combine with Step 4 generalist-qa results)
- If **FAIL** or **PARTIAL**: Include contract test failures in **Step 4.5: Implementation Fix Loop**

---

### Step 4.5: Implementation Fix Loop (CRITICAL)

**Goal**: Fix issues found by QA (and contract tests if scip-php involved) and re-test until all pass.

**CRITICAL**: This loop MUST continue until QA passes (and contract tests pass if applicable). Feature cannot be marked complete with failing QA.

**Actions (repeat until all pass or max 5 iterations)**:
1. Spawn `feature-implementer` with combined failure context:
   ```
   Task(
     subagent_type: "feature-implementer",
     prompt: "Fix QA failures for feature {feature_name}

              ## QA Failure Report
              {detailed_qa_failure_report}

              {IF scip_php_involved AND contract_tests_failed:}
              ## Contract Test Failure Report
              {detailed_contract_test_failure_report}

              ## Contract Test Context
              - Test scenarios: .claude/scip-php-contract-qa/{feature_name}/scenarios.md
              - Tests location: kloc-reference-project-php/contract-tests/tests/

              ## Running Contract Tests
              Use skill `kloc-scip-contract-test-run` to verify fixes:
              ```bash
              cd kloc-reference-project-php/contract-tests && bin/run.sh test
              ```
              DO NOT modify contract tests - only fix implementation.
              {END IF}

              ## Context
              - Plan file: docs/specs/{feature_name}-plan.md
              - Spec file: docs/specs/{feature_name}.md
              - QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md
              - Progress file: .claude/progress/{feature_name}.md
              - Context files: {context_files}

              ## Required
              Fix the specific issues reported by QA.
              Do NOT mark the feature complete - QA will re-verify."
   )
   ```
2. Wait for implementer to complete fixes
3. Capture summary of fixes made
4. Re-run generalist QA:
   ```
   Task(
     subagent_type: "generalist-qa",
     prompt: "Re-test feature {feature_name} after fixes

              ## Previous Failures
              {previous_qa_failures}

              ## Fixes Applied
              {summary_of_fixes_from_implementer}

              ## Context
              - QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md
              - Spec: docs/specs/{feature_name}.md

              ## Required
              1. Verify the previously failing scenarios now pass
              2. Run full test suite to check for regressions
              3. Report PASS or FAIL with details"
   )
   ```
5. **If `scip_php_involved`**: Also re-run contract test validation:
   ```
   Task(
     subagent_type: "scip-php-contract-qa",
     resume: "{qa_contract_agent_id}",
     prompt: "Re-validate feature {feature_name} after fixes

              ## Previous Failures
              {previous_contract_test_failures}

              ## Fixes Applied
              {summary_of_fixes_from_implementer}

              ## Implementer Notes
              {any_concerns_about_tests}

              ## Required
              1. Run contract tests
              2. Verify previously failing tests now pass
              3. Check for regressions
              4. Report PASS or FAIL with details"
   )
   ```
6. If all QA reports **PASS** (generalist + contract if applicable): Exit loop, proceed to Step 5
7. If any report **FAIL**: Repeat from step 1

**Iteration Tracking**:
- Track iteration count
- After 5 iterations with failing QA: STOP and report to user
- User must decide whether to continue or accept current state

**Completion Criteria**:
- QA reports PASS
- OR: Maximum 5 iterations reached (report to user for manual decision)

---

### Step 5: Progress Validation Loop

**Goal**: Ensure all implementation steps are complete AND git workflow was executed.

**Actions**:
1. Read progress file at `.claude/progress/{feature_name}.md`
2. Check if ALL steps are marked as `done`
3. Check git status:
   - Run `git branch --show-current` to verify we're on a feature branch (not `main`/`master`)
   - Run `git log --oneline -1` to verify there's a commit for this feature
4. If any steps remain incomplete OR git workflow incomplete (no feature branch or no commit):
   - Identify what's missing (steps and/or git)
   - Re-spawn `feature-implementer` to complete:
     ```
     Task(
       subagent_type: "feature-implementer",
       prompt: "Continue implementing feature {feature_name}.
                Remaining steps: {list_of_incomplete_steps}
                Missing git workflow: {branch_missing or commit_missing}
                Plan file: docs/specs/{feature_name}-plan.md
                Progress file: .claude/progress/{feature_name}.md
                QA notes: .claude/qa-notes/{feature_name}_qa_ref_note.md"
     )
     ```
   - **After implementer completes**: Re-run QA validation (go back to Step 4)
5. Repeat until (all steps `done` AND on feature branch AND commit exists AND QA passed) OR maximum 3 validation loops reached

**Completion Criteria**:
- All steps in progress file marked as `done`
- On a feature branch (not main/master)
- Commit exists for the implementation
- QA has passed (from Step 4)
- OR: 3 validation loops completed (report remaining items to user)

---

### Step 6: Summary

**Goal**: Report completion status to user.

**Actions**:
1. Summarize what was implemented
2. List any files created or modified
3. Report QA status:
   - Number of QA iterations required
   - Final QA result (PASS or MAX_ITERATIONS_REACHED)
   - Any known limitations or edge cases
4. If `scip_php_involved`: Report contract test status:
   - Contract test result (PASS or FAIL)
   - Test coverage (from `.claude/scip-php-contract-qa/{feature_name}/summary.md`)
   - Number of contract test iterations required
5. Report git status:
   - Current branch name
   - Commit hash and message for the implementation commit
6. Report any remaining incomplete steps (if validation loop maxed out)
7. Suggest next steps (push, create PR, additional testing, review, etc.)

**Completion Criteria**:
- User has been informed of the outcome
- User knows the QA status
- User knows the branch name and can push when ready

## Error Handling

- If feature-request skill fails: Report error and ask user to provide more context
- If feature-planner fails: Report error, check if spec file exists, retry once
- If scip-php-contract-qa fails in setup: Report error, check for existing test failures, retry once
- If feature-implementer fails: Report error, check progress file, retry with remaining steps
- If QA fails after 5 iterations: Report to user with detailed failure info for manual decision
- If contract tests fail after 5 iterations: Report to user with test failure details for manual decision
- After 3 validation loops with incomplete steps: Report to user for manual intervention

## Rules

- ALWAYS pass the same feature name to every tool/agent call
- NEVER skip steps or reorder them
- NEVER run steps in parallel - each step depends on the previous step's output
- NEVER implement code yourself - always delegate to feature-implementer
- After each step completes, read the output files and briefly summarize before proceeding
- If context files are provided by the user, pass them to EVERY sub-agent call
- NEVER push to remote - workflow ends with local commit, user decides when to push
- Feature is NOT complete until there's a commit on a feature branch

### QA Rules (CRITICAL)

- **NEVER mark a feature complete without QA passing**
- QA notes MUST be created BEFORE implementation starts
- QA validation MUST be run AFTER implementation completes
- If QA fails, implementation MUST be fixed and QA re-run
- Pass QA notes file to implementer so they can reference test expectations
- Pass implementation context to QA so they know what was built
- The QA → Implementer → QA loop continues until QA passes (max 5 iterations)
- If QA cannot pass after 5 iterations, STOP and report to user - do not continue

### Contract Test Rules (when scip-php involved)

- **Detect scip-php involvement** after planning (Step 2) using spec/plan content
- **Contract tests are created BEFORE implementation** (Step 2.7)
- **NEVER mark a feature complete without contract tests passing** (if scip-php involved)
- **Store and reuse `qa_contract_agent_id`** - resume the same QA agent for validation
- **Implementer CAN run contract tests** to verify own changes
- **Implementer CANNOT modify contract tests** - only implementation code
- **If tests seem wrong**: Implementer notes concerns, QA reviews in next iteration
- **Both generalist QA and contract tests must pass** before feature is complete
- The fix loop addresses both generalist QA failures and contract test failures together

### Agent ID Tracking

Throughout this workflow, track these agent IDs for resume capability:
- `qa_contract_agent_id` (if scip-php involved): From Step 2.7, used in Steps 4.1 and 4.5
