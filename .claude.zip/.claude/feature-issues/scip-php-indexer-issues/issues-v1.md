# scip-php Indexer Issues

This document tracks data quality issues found during usage-flow-tracking-mvp QA. These affect the accuracy of reference types and access chains in kloc-cli output.

**Feature context:**
- Discovered during: `docs/specs/usage-flow-tracking-mvp.md`
- Test data: `kloc-reference-project-php`
- Pipeline: scip-php -> kloc-mapper -> kloc-cli

**Version:** v1
**Created:** 2026-02-06

---

## Issue 1: Missing property accesses at depth 2 (customerEmail, productId in save())

### Context

When querying `OrderService::createOrder` with `--depth 2`, the `save()` method's depth-2 subtree is missing `$customerEmail` (line 31) and `$productId` (line 32), even though they appear correctly at depth-1 when querying `save()` directly.

### Problem

**Depth-1 query of save() shows all 10 uses (correct):**
```
== USES ==  (querying save() directly)
├── [1] App\Entity\Order [type_hint] (line 26)
├── [1] App\Entity\Order::$id [property_access] (line 28)
├── [1] App\Repository\OrderRepository [instantiation] (line 30)
├── [1] App\Repository\OrderRepository::$nextId [instantiation] (line 30)
├── [1] App\Entity\Order::$customerEmail [static_property] (line 31)  ← present
├── [1] App\Entity\Order::$productId [property_access] (line 32)     ← present
├── [1] App\Entity\Order::$quantity [property_access] (line 33)
├── [1] App\Entity\Order::$status [property_access] (line 34)
├── [1] App\Entity\Order::$createdAt [property_access] (line 35)
└── [1] App\Repository\OrderRepository::$orders [static_property] (line 37)
```

**Depth-2 from createOrder shows only 7 uses (missing 3):**
```
├── [1] App\Repository\OrderRepository::save() [method_call] (line 45)
│   ├── [2] App\Entity\Order::$id [property_access] (line 28)
│   ├── [2] App\Repository\OrderRepository [instantiation] (line 30)
│   ├── [2] App\Repository\OrderRepository::$nextId [instantiation] (line 30)
│   │                                                           ← line 31 missing
│   │                                                           ← line 32 missing
│   ├── [2] App\Entity\Order::$quantity [property_access] (line 33)
│   ├── [2] App\Entity\Order::$status [property_access] (line 34)
│   ├── [2] App\Entity\Order::$createdAt [property_access] (line 35)
│   └── [2] App\Repository\OrderRepository::$orders [static_property] (line 37)
```

Missing entries:
- `App\Entity\Order [type_hint]` (line 26) — the return/param type hint
- `App\Entity\Order::$customerEmail` (line 31)
- `App\Entity\Order::$productId` (line 32)

### Investigation

The sot.json graph data is correct:
- `save()` has `uses` edges to `Order::$productId` and `Order::$customerEmail`
- Call nodes exist at lines 31 and 32 with correct `call_kind=access` and receivers pointing to `$order` parameter
- The `uses` edges do NOT have line/file properties — they are bare structural edges

The depth-2 expansion in `_build_outgoing_tree()` iterates `uses` edges from `save()` and tries to correlate each with a Call node using `find_call_for_usage()`. This correlation relies on matching the target node + location. If the `uses` edge has no location metadata, the call matching may fail for some entries while succeeding for others (perhaps based on order of iteration or ambiguous matches).

### Proposed Solution

**1. Investigate `_build_outgoing_tree()` depth expansion in `kloc-cli/src/queries/context.py`**

The depth-2 code path reuses the same tree-building logic as depth-1, but may be filtering differently or hitting deduplication. Compare the two code paths to find why 3 entries are dropped.

**2. Check if `uses` edges without location metadata are handled correctly**

The bare `uses` edges (no file/line) may be excluded by a filter that requires location data. The `type_hint` at line 26 is the return type annotation — it may be filtered by import detection logic (R1) incorrectly.

### Files to modify

- `kloc-cli/src/queries/context.py` — Investigate `_build_outgoing_tree()` depth expansion logic, particularly filtering and Call node correlation at depth > 1

---

## Issue 2: Constructor arguments inherit `[instantiation]` reference type

### Context

At `OrderRepository::save()` line 30, the code is:
```php
$newOrder = new Order(           // line 29 — constructor call
    id: self::$nextId++,         // line 30 — static property access
    customerEmail: $order->customerEmail,  // line 31
```

### Problem

**Current output:**
```
├── [2] App\Repository\OrderRepository [instantiation] (line 30)
├── [2] App\Repository\OrderRepository::$nextId [instantiation] (line 30)
```

Problems:
- `OrderRepository` is shown with `[instantiation]` at line 30, but nothing instantiates OrderRepository — `new Order(...)` instantiates Order
- `$nextId` is shown with `[instantiation]` but it's a static property access (`self::$nextId++`)

### Investigation — Root Cause Identified

**Two bugs combine to produce wrong reference types:**

**Bug A: Uses edge location mismatch (scip-php/mapper issue)**

The `uses` edges from `save()` have incorrect location data:
```
save() -> OrderRepository (class): location line=29, col=20
save() -> OrderRepository::$nextId: location line=29, col=26
```

But `self::$nextId++` is at line 30, not line 29. The uses edge locations point to line 29 (the `new Order(` expression start), not to line 30 where the actual `self::` reference occurs. The correct Call node for `$nextId` (`access_static`) is at line 30.

**Bug B: `find_call_for_usage()` matches wrong Call node (kloc-cli issue)**

The function searches `calls + call_children` for a Call at the edge's line:

1. `calls` = Call nodes targeting `$nextId` → `[node:call:6e03083a2bcb5078]` (line **30**, `access_static`) — line 30 ≠ 29, **skipped**
2. `call_children` = ALL Call nodes in `save()` → finds `node:call:550922d6baa166e3` (line **29**, `constructor`) — line 29 == 29, **matched!**

The constructor targets `Order::__construct()`, which has nothing to do with `$nextId`. But `find_call_for_usage()` never checks whether the matched Call actually targets the right node. It takes the first Call at the matching line from the unfiltered `call_children` list.

Same for `OrderRepository` class:
- No Call nodes target `OrderRepository` class (empty `calls` list)
- `call_children` search finds the constructor at line 29 → returns `constructor` → `[instantiation]`

### Proposed Solution

**1. Fix `find_call_for_usage()` to verify callee match (kloc-cli)**

In the line-matching loop, after finding a Call node at the right line, verify that its `callee` (via `calls` edge) matches the `target_id` of the uses edge. This prevents the constructor from matching for `$nextId`:

```python
# Current (buggy):
for call_id in calls + call_children:
    if call_line == line:
        return call_id  # No target verification!

# Fixed:
for call_id in calls + call_children:
    if call_line == line:
        # Verify this Call actually targets the expected node
        call_target = index.get_call_target(call_id)
        if call_target == target_id:
            return call_id
```

**2. Fix uses edge location for constructor arguments (scip-php/mapper)**

The uses edge for `self::$nextId++` at line 30 should have `location.line=30`, not `line=29`. The occurrence location is being incorrectly set to the containing `new Order()` expression line.

### Files to modify

- `kloc-cli/src/queries/context.py` — `find_call_for_usage()`: Add callee verification in line-matching loop
- `scip-php` or `kloc-mapper` — Fix uses edge location for symbols referenced inside constructor argument lists

---

## Issue 3: Method call `getName()` misclassified as `[property_access]`

### Context

At `OrderService::createOrder()` line 43:
```php
$processorName = $this->orderProcessor->getName();
```

### Problem

**Current output:**
```
├── [1] App\Service\AbstractOrderProcessor::getName(): string [property_access] (line 43)
```

`getName()` is a method call but shows as `[property_access]`.

### Investigation

The Call node at line 43 has `call_kind=access`. In scip-php, `access` represents property access (`$obj->property`). But `getName()` is a method call, which should be `call_kind=method`.

The scip-php indexer distinguishes access patterns:
- `access` → property access: `$obj->property`
- `method` → method call: `$obj->method()`

The indexer at `$this->orderProcessor->getName()` may be classifying the receiver chain access (`$this->orderProcessor`) and the final method call (`->getName()`) as separate calls, and the `getName()` call is getting the `access` kind from the receiver instead of `method`.

### Proposed Solution

This is a **scip-php indexer issue**. The `call_kind` emitted for `getName()` should be `method`, not `access`.

Alternatively, kloc-cli could use a fallback: when a Call node has `call_kind=access` but the callee target is a Method node (not a Property), override the reference type to `method_call`.

### Files to modify

- `scip-php/src/...` — Fix `call_kind` assignment for method calls in chained expressions
- OR `kloc-cli/src/queries/context.py` — Add fallback in `get_reference_type_from_call()`: if `call_kind` suggests property but target is Method, use `method_call`

---

## Issue 4: Named arguments misattributed to wrong receiver chain

### Context

At `OrderService::createOrder()` lines 47-48:
```php
$this->emailSender->send(
    to: $savedOrder->customerEmail,  // line 48
```

### Problem

**Current output:**
```
├── [1] App\Entity\Order::$customerEmail [method_call] (line 48)
│           on: $this->emailSender (App\Service\OrderService::$emailSender)
```

Problems:
- `$customerEmail` is a property access on `$savedOrder`, but shows as `[method_call]`
- The access chain shows `on: $this->emailSender` — but the receiver is `$savedOrder`, not `$this->emailSender`
- The property FQN shows `$emailSender` which is the `send()` method's receiver, not the `$customerEmail` access's receiver

### Investigation

The `$savedOrder->customerEmail` access at line 48 is inside the argument list of `$this->emailSender->send(...)`. The Call node for `send()` spans lines 47-50. When `find_call_for_usage()` looks for a Call node matching the `uses` edge to `Order::$customerEmail` at line 48, it finds the `send()` Call node (which covers that line range) and inherits its receiver chain and call_kind.

The actual access to `$customerEmail` should have its own Call node with `call_kind=access` and `receiver=$savedOrder`.

### Proposed Solution

**1. Check if scip-php emits a separate Call node for `$savedOrder->customerEmail`**

If scip-php does emit it, then `find_call_for_usage()` is picking the wrong one. Fix the matching to prefer the Call node whose callee matches the usage target.

If scip-php does NOT emit a separate Call for property accesses within method arguments, this is a scip-php issue.

**2. Improve `find_call_for_usage()` target matching**

When multiple Call nodes exist at overlapping line ranges, prefer the Call node whose `callee` symbol matches the `uses` edge target symbol.

### Files to modify

- `scip-php/src/...` — Ensure property accesses within method arguments get their own Call nodes
- `kloc-cli/src/queries/context.py` — Improve `find_call_for_usage()` to match by callee, not just proximity

---

## Issue 5: Global visited set in `_build_outgoing_tree()` drops depth-2 entries

### Context

When querying `OrderService::createOrder()` with `--depth 2`, the `save()` method's depth-2 subtree is missing `$productId` (line 32) and `$customerEmail` (line 31). The scip-php index data is correct — both Call nodes and Value nodes exist with proper `call_kind=access`, `callee`, and `receiver_value_id`. The issue is in kloc-cli's tree builder.

### Problem

**Depth-2 output from `createOrder --depth 2` is missing `$productId` and `$customerEmail`:**
```
├── [1] App\Repository\OrderRepository::save() [method_call] (line 45)
│   ├── [2] App\Entity\Order::$id [property_access] (line 28)
│   ├── [2] App\Repository\OrderRepository [instantiation] (line 30)
│   ├── [2] App\Repository\OrderRepository::$nextId [instantiation] (line 30)
│   │                                                           ← line 31 ($customerEmail) missing
│   │                                                           ← line 32 ($productId) missing
│   ├── [2] App\Entity\Order::$quantity [property_access] (line 33)
│   ├── [2] App\Entity\Order::$status [property_access] (line 34)
│   ├── [2] App\Entity\Order::$createdAt [property_access] (line 35)
│   └── [2] App\Repository\OrderRepository::$orders [static_property] (line 37)
```

Yet querying `save()` directly at depth 1 shows all 10 entries including `$productId` and `$customerEmail`.

**Evidence that scip-php data is correct:**

calls.json has the correct Call node for `$productId`:
```json
{
    "id": "src/Repository/OrderRepository.php:32:35",
    "kind": "access",
    "callee": "...App/Entity/Order#$productId.",
    "receiver_value_id": "src/Repository/OrderRepository.php:26:31",
    "location": { "file": "src/Repository/OrderRepository.php", "line": 32, "col": 35 }
}
```

And the receiver value node (the `$order` parameter):
```json
{
    "id": "src/Repository/OrderRepository.php:26:31",
    "kind": "parameter",
    "symbol": "...App/Repository/OrderRepository#save().($order)",
    "type": "...App/Entity/Order#"
}
```

sot.json also has the correct data — `save()` has `uses` edges to `Order::$productId` and `Order::$customerEmail`, and Call nodes exist at lines 31/32 with `call_kind=access` and proper receiver edges.

### Investigation

**Root cause: Global `visited` set in `_build_outgoing_tree()` causes DFS-order-dependent data loss.**

The `_build_outgoing_tree()` method at `context.py:784` uses a single global `visited` set shared across all depth levels. The tree is built via DFS — when a depth-1 entry is processed, its depth-2 children are expanded immediately before the next depth-1 entry.

`createOrder()` has `uses` edges to 22 targets, including:
- `Order::$productId` (same node as save()'s target)
- `Order::$customerEmail` (same node as save()'s target)
- `Order::$quantity`, `Order::$status`, `Order::$createdAt`, `Order::$id` (also overlap)
- `OrderRepository::save()` (the method whose depth-2 we want)

The overlap between `createOrder()` and `save()` targets:

| save() target | Also in createOrder() deps? | Shows at depth 2? |
|---|---|---|
| `Order::$productId` | YES | NO — visited at depth 1 before save() |
| `Order::$customerEmail` | YES | NO — visited at depth 1 before save() |
| `Order` (class) | YES | NO — visited at depth 1 before save() |
| `Order::$id` | YES | YES — save() processed before this depth-1 edge |
| `Order::$quantity` | YES | YES — save() processed before this depth-1 edge |
| `Order::$status` | YES | YES — save() processed before this depth-1 edge |
| `Order::$createdAt` | YES | YES — save() processed before this depth-1 edge |
| `OrderRepository` (class) | NO | YES |
| `OrderRepository::$nextId` | NO | YES |
| `OrderRepository::$orders` | NO | YES |

The DFS iteration order determines which depth "claims" each node. Targets iterated before `save()` in `createOrder()`'s edge list get added to `visited` at depth 1, making them invisible at depth 2. Targets iterated after `save()` are claimed at depth 2 (by save()'s expansion), then skipped at depth 1.

This means the depth-2 subtree content is **non-deterministic** — it depends on the iteration order of edges from `get_deps()`, which has no guaranteed ordering.

### Proposed Solution

**1. Remove global visited deduplication for USES depth expansion**

The `visited` set should NOT prevent a node from appearing at multiple depths. In the USES direction, the same property can legitimately be accessed by both a parent method and its callees. Each depth level should show the actual dependencies of that specific method, regardless of what other methods at other depths also reference.

**2. Use per-subtree visited sets**

Instead of a single global `visited`, each `build_tree()` call at depth N should have its own visited set to prevent duplicates within the same level, but not across depths. This is similar to what the USED BY direction already does with `branch_visited`.

**3. Alternative: per-depth visited set**

Track visited per (target_id, parent_id) pair rather than just target_id. This allows the same target to appear under different parents at different depths.

### Files to modify

- `kloc-cli/src/queries/context.py` — `_build_outgoing_tree()`: Change the `visited` set to be per-parent or per-depth instead of global. The fix at line 809 (`if target_id in visited: continue`) needs to allow the same target at different depths/parents.

---

## Issue 6: Defensive fallback — never display incorrect data; handle unsupported patterns explicitly

### Context

Issues 2, 3, and 4 all share a common pattern: `find_call_for_usage()` matches the **wrong** Call node and the output confidently displays an incorrect reference type, receiver chain, or both. This is worse than showing no data — incorrect data misleads users.

Additionally, some PHP usage patterns are not fully supported by scip-php (e.g., `self::$nextId++` static property increment, compound expressions in constructor arguments). These should be explicitly classified rather than silently misclassified.

### Problem

**1. Wrong match is worse than no match**

When `find_call_for_usage()` cannot find the correct Call node, it currently falls through to `call_children` (all Call nodes in the method) and picks whichever one happens to be at the same line — regardless of whether it targets the right symbol. This produces confidently wrong output:

- `self::$nextId++` → matched to `new Order()` constructor → shows `[instantiation]` instead of `[static_property]`
- `$savedOrder->customerEmail` → matched to `send()` call → shows `[method_call]` with wrong receiver
- `$this->orderProcessor->getName()` → matched to property access Call → shows `[property_access]`

**2. Unsupported usage patterns should be explicit**

Some patterns that scip-php doesn't fully index:
- `self::$prop++` / `self::$prop--` (static property increment/decrement)
- Property accesses inside constructor named arguments
- Chained method calls where receiver resolution is ambiguous

These should be classified as a recognizable "unsupported" or "unresolved" type rather than inheriting an incorrect type from a nearby Call node.

### Proposed Solution

**1. kloc-cli: Never return unverified Call matches**

`find_call_for_usage()` must verify that any matched Call node actually targets the correct symbol before returning it. If no verified match exists, return `None` and let the caller fall back to `_infer_reference_type()` which uses the target node's kind:

```python
# In line-matching loop:
for call_id in calls + call_children:
    if call_line == line:
        call_target = index.get_call_target(call_id)
        if call_target == target_id:  # Verify callee matches
            return call_id
        # Don't return — wrong target, keep searching
```

This ensures: **no match is better than a wrong match**. The inferred type from `_infer_reference_type()` (e.g., `property_access` for Property targets, `method_call` for Method targets) is always more correct than a wrong Call node's `call_kind`.

**2. scip-php: Index unsupported patterns with explicit markers**

For patterns scip-php can't fully resolve (static property increment, compound expressions in constructor args), the indexer should either:
- Emit a Call node with a special `call_kind` (e.g., `unresolved`) so downstream tools know this is best-effort
- Or emit no Call node at all, letting kloc-cli use inference (which is correct for simple cases)

Current gap: scip-php emits correct Call nodes for `self::$nextId++` (`access_static`) but the **uses edge location** points to the wrong line (line 29 instead of 30), preventing the correct match. This is a location accuracy issue in the mapper/indexer.

**3. kloc-cli: Consider `[unknown]` reference type**

When both Call-based matching and inference fail (e.g., target is a Class node but it's not a type_hint — it's a `self::` qualifier), display `[unknown]` or `[unresolved]` rather than guessing. This makes data quality issues visible to users instead of hiding them behind incorrect labels.

### Design Principle

> **Consistency over completeness**: It is better to show `[unknown]` or omit a reference type than to show a wrong one. Wrong data erodes trust; missing data prompts investigation.

### Files to modify

- `kloc-cli/src/queries/context.py` — `find_call_for_usage()`: Add callee verification, return None for unverified matches
- `kloc-cli/src/queries/context.py` — `_infer_reference_type()`: Consider adding `[unknown]` fallback for ambiguous cases
- `scip-php` — Fix uses edge location accuracy for symbols inside constructor argument lists
- `scip-php` — Consider explicit `call_kind` for unresolvable patterns

---

## Summary

| # | Issue | Component | Severity |
|---|-------|-----------|----------|
| 1 | Missing property accesses at depth 2 (symptom) | kloc-cli | High — data loss in depth expansion |
| 2 | Constructor args inherit `[instantiation]` type | kloc-cli / scip-php | Medium — wrong reference type |
| 3 | `getName()` misclassified as `[property_access]` | scip-php | Medium — wrong call_kind |
| 4 | Named args misattributed to enclosing call receiver | scip-php / kloc-cli | Medium — wrong receiver chain |
| 5 | Global visited set drops depth-2 entries (root cause of #1) | kloc-cli | **High** — non-deterministic data loss |
| 6 | Defensive fallback: never display incorrect data | kloc-cli / scip-php | **High** — design principle |

### Design Principle

> **Consistency over completeness**: Never display a confidently wrong reference type. If the correct Call node can't be matched, fall back to inference or show `[unknown]`. Wrong data is worse than missing data.

### Implementation order

1. **Issue 6** first — add callee verification to `find_call_for_usage()`. This is a one-line guard that immediately fixes Issues 2, 3, and 4 at the kloc-cli level (they fall back to correct inference instead of wrong Call matches).
2. **Issue 5** — fix global visited set in `_build_outgoing_tree()` to resolve depth-2 data loss.
3. **Issues 2 + 4 location fix** — fix uses edge location accuracy in scip-php/mapper for constructor arguments and chained expressions.
4. **Issue 3** — fix `call_kind` in scip-php for chained method calls (or keep kloc-cli inference fallback).
