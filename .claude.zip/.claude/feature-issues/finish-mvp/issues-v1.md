# finish-mvp — Issues

This document tracks issues identified during finish-mvp implementation/review.

**Feature context:**
- Spec: `docs/specs/finish-mvp.md` (if exists)
- Related: scip-php indexer call kinds implementation
- Tests: `kloc-reference-project-php/contract-tests/`

**Version:** 1
**Created:** 2026-02-02

---

## Summary

| # | Issue | Status | Priority |
|---|-------|--------|----------|
| 1 | Remove redundant `arguments[].value_type` | 📄 Docs updated | Medium |
| 2 | Fix column numbering (0-based) | 📄 Docs updated | High |
| 3 | Missing types across calls and values | ⏳ Pending | High |
| 4 | Remove `*_nullsafe` kinds (use union types) | 📄 Docs updated | Medium |
| 5 | Mark experimental kinds (`--experimental`) | 📄 Docs updated | High |
| 6 | Test coverage gaps and notes | ⏳ Pending | Medium |
| 7 | Update documentation and schema | ✅ Done | High |

**Legend:** ✅ Done | 📄 Docs updated (impl pending) | ⏳ Pending

### Schema Changes (Applied to Docs)

**Stable kinds** (default output):
- `access`, `method`, `constructor`, `access_static`, `method_static`

**Experimental kinds** (opt-in via `--experimental`):
- `access_array`, `coalesce`, `ternary`, `ternary_full`, `match`, `function`

**Removed kinds:**
- `access_nullsafe`, `method_nullsafe` → use `access`/`method` with union return type `T|null`

**Removed fields:**
- `arguments[].value_type` → use `values[value_id].type` instead

**Column numbering:**
- Line: 1-based, Column: 0-based (documentation now consistent)

---

## Summary

| # | Issue | Priority | Impact |
|---|-------|----------|--------|
| 1 | Remove redundant `arguments[].value_type` | Medium | Schema simplification |
| 2 | Fix column numbering (0-based vs 1-based) | High | Correctness |
| 3 | Missing types across calls and values | High | Core functionality |
| 4 | Remove `*_nullsafe` kinds (use union types) | Medium | Schema simplification |
| 5 | Mark experimental kinds (`--experimental` flag) | High | Stability |
| 6 | Test coverage gaps and notes | Medium | Quality |
| 7 | Update documentation and schema | High | Consistency |

**Stable kinds (default output):**
- `access`, `method`, `constructor`, `access_static`, `method_static`

**Experimental kinds (opt-in via `--experimental`):**
- `access_array`, `coalesce`, `ternary`, `ternary_full`, `match`, `function`

**Kinds to remove:**
- `access_nullsafe`, `method_nullsafe` (use `access`/`method` with union return type)

---

## Issue 1: Redundant `value_type` in arguments

### Context

Arguments in `calls.json` have both `value_type` and `value_id` fields. The `value_id` points to an entry in the `values` array, which also has a `type` field.

### Problem

`calls[].arguments[].value_type` duplicates information available via `values[value_id].type`.

**Example — current output:**
```json
// In calls[].arguments[]
{
  "position": 2,
  "parameter": "...Customer#__construct().($contact)",
  "value_type": "...App/Entity/Contact#",  // <-- REDUNDANT
  "value_id": "src/Repository/CustomerRepository.php:36:36",
  "value_expr": "$customer->contact"
}

// In values[]
{
  "id": "src/Repository/CustomerRepository.php:36:36",
  "type": "...App/Entity/Contact#"  // <-- Same info available here
}
```

Problems:
- Data duplication in output (17 non-null value_types across 155 arguments)
- Extra computation in `DocIndexer::resolveValueType()` for data already tracked
- Larger JSON output files
- Two sources of truth for the same information

### Proposed Solution

**1. Remove `valueType` from `ArgumentRecord`**

Delete the `valueType` property and parameter from `ArgumentRecord.php`.

**2. Update `DocIndexer` argument tracking**

Remove the `resolveValueType()` call when building arguments.

**3. Update schema**

Remove `value_type` from the calls.json schema.

### Expected output after fix

```json
// In calls[].arguments[]
{
  "position": 2,
  "parameter": "...Customer#__construct().($contact)",
  "value_id": "src/Repository/CustomerRepository.php:36:36",
  "value_expr": "$customer->contact"
}
```

Consumers needing type info look up `values[value_id].type`.

### Edge cases

| Case | Behavior |
|------|----------|
| `value_id` is null | No type available (same as today when both are null) |
| Value not in values array | Shouldn't happen - indicates bug elsewhere |

### Files to modify

- `scip-php/src/Calls/ArgumentRecord.php` — Remove `valueType` property
- `scip-php/src/DocIndexer.php` — Remove `resolveValueType()` call in argument tracking
- `docs/reference/kloc-scip/calls-schema.json` — Remove `value_type` from argument schema
- Contract tests — Update any tests checking `value_type` in arguments

---

## Issue 2: Column numbering inconsistency (0-based vs 1-based)

### Context

The calls.json schema defines column numbering, but there's a mismatch between the schema definition and the actual indexer output.

### Problem

For line 50 of CustomerService.php: `        $email = $customer->contact->email;`

The `$` of `$email` is at:
- **Position 8** (0-indexed: 8 spaces of indentation)
- **Position 9** (1-indexed)

**Current output:** `col: 8` (0-based)

**Schema definition (calls-schema.json:62):**
```json
"col": {
  "type": "integer",
  "description": "1-based column number (byte offset from start of line)."
}
```

**Documentation inconsistency:**
- `calls-schema.json:34`: "Line and column are 1-based"
- `calls-schema.json:62`: "1-based column number"
- `calls-schema-docs.md:186`: "0-based column" ← contradicts schema!

Problems:
- Schema says 1-based, implementation outputs 0-based
- Documentation is internally inconsistent
- Consumers relying on schema will have off-by-one errors

### Proposed Solution

**Option A: Fix implementation to match schema (1-based)**

Update the indexer to output 1-based columns as the schema specifies. This is the safer approach since the schema is the contract.

**Option B: Fix schema to match implementation (0-based)**

Update schema to document 0-based columns and fix the inconsistent docs. Requires updating all consumers.

**Recommendation:** Option A - fix implementation to match schema.

### Expected output after fix

```json
{
  "id": "src/Service/CustomerService.php:50:9",  // Was :50:8
  "location": {
    "line": 50,
    "col": 9  // Was 8
  }
}
```

### Files to modify

- `scip-php/src/DocIndexer.php` — Add +1 to column values when creating IDs/locations
- `docs/reference/kloc-scip/calls-schema-docs.md` — Fix to say "1-based" consistently
- Contract tests — Update expected column values

---

## Issue 3: Missing types across calls and values

### Context

The scip-php indexer should populate type information for:
1. `calls[].return_type` — the type of the call result
2. `values[].type` — the type of values (including call results)

This enables downstream tools to understand data flow types.

### Problem

Type information is missing in many cases even when types are explicitly declared.

**Example — `$this->postalCode` (typed `string` in Address entity):**

```php
// Address.php line 16
public string $postalCode,

// Address.php line 23
return sprintf('...', ..., $this->postalCode, ...);
```

**Call entry:**
```json
{
  "kind": "access",
  "callee": "...App/Entity/Address#$postalCode.",
  "return_type": null  // Should be "scip-php php builtin . string#"
}
```

**Value entry (result of that call):**
```json
{
  "id": "src/Entity/Address.php:23:75",
  "kind": "result",
  "type": null  // Should be "scip-php php builtin . string#"
}
```

**Coverage by kind:**

| Kind | Total | With return_type | % |
|------|-------|------------------|---|
| constructor | 16 | 16 | 100% |
| method | 34 | 28 | 82% |
| access | 129 | 45 | **35%** |
| access_static | 8 | 0 | **0%** |
| access_nullsafe | 8 | 0 | **0%** |
| access_array | 8 | 0 | **0%** |
| method_static | 3 | 0 | **0%** |
| method_nullsafe | 2 | 0 | **0%** |
| coalesce | 6 | 0 | **0%** |
| ternary | 2 | 0 | **0%** |
| ternary_full | 4 | 0 | **0%** |
| match | 3 | 0 | **0%** |
| function | 10 | 0 | **0%** |

Problems:
- `access` has 65% missing types (84 of 129 calls)
- `method` has 18% missing types (6 of 34 calls)
- All new call kinds have 100% missing types
- `function` calls have 100% missing types
- `values[].type` also missing for corresponding result entries

### Proposed Solution

**1. Fix type resolution for `access` calls**

Investigate why 65% of property accesses lack return_type. The type should come from the property declaration.

**2. Fix type resolution for `method` calls**

Investigate why 18% of method calls lack return_type.

**3. Add return_type for all new call kinds**

- `access_static`, `access_nullsafe`, `access_array` — use property type
- `method_static`, `method_nullsafe` — use method return type
- `function` — use function return type
- `coalesce` — LHS type (or union LHS|RHS)
- `ternary`, `ternary_full` — union of branch types
- `match` — union of arm return types

**4. Ensure `values[].type` matches `calls[].return_type`**

When creating a result value for a call, propagate the return_type to the value's type field.

### Files to modify

- `scip-php/src/DocIndexer.php` — Fix type resolution across all call kinds
- `scip-php/src/Types/Types.php` — May need helpers for resolving member types

---

## Issue 4: Unnecessary `*_nullsafe` kinds - should be union return type

### Context

The indexer currently uses separate kinds for nullsafe operations:
- `access_nullsafe` (vs `access`)
- `method_nullsafe` (vs `method`)

### Problem

Nullsafe operator `?->` doesn't change *what* is being accessed - it changes the *return type* semantics. The operation is still a property access or method call.

**Current (wrong):**
```json
{
  "kind": "access_nullsafe",
  "callee": "...Order#$status.",
  "return_type": "string"
}
```

**Should be:**
```json
{
  "kind": "access",
  "callee": "...Order#$status.",
  "return_type": "string|null"  // Union type captures nullsafe semantics
}
```

Problems:
- Unnecessary kind proliferation (2 extra kinds)
- Consumers must handle `access` and `access_nullsafe` separately
- The nullsafe behavior is already expressible via union return type
- Schema and code complexity for no added value

### Proposed Solution

**1. Remove `access_nullsafe` and `method_nullsafe` kinds**

Use `access` and `method` instead.

**2. Set return_type to union with null**

When tracking `NullsafePropertyFetch` or `NullsafeMethodCall`:
- Resolve the base type `T`
- Set `return_type` to `T|null` (union symbol)

**3. Update schema**

Remove `access_nullsafe` and `method_nullsafe` from valid kinds.

### Expected output after fix

```php
$order?->status  // string property
```

```json
{
  "kind": "access",
  "return_type": "scip-php union . null|string#"
}
```

### Files to modify

- `scip-php/src/DocIndexer.php` — Change nullsafe tracking to use base kind + union type
- `scip-php/src/Calls/CallRecord.php` — Remove nullsafe kinds from enum/validation
- `docs/reference/kloc-scip/calls-schema.json` — Remove nullsafe kinds

---

## Issue 5: Mark incomplete call kinds as experimental

### Context

Several new call kinds were added but lack complete implementation (especially return_type resolution - see Issue 3). These should be opt-in until fully implemented.

### Problem

Experimental/incomplete features are mixed with stable output, causing:
- Consumers get incomplete data by default
- Contract tests must handle partially-implemented kinds
- Hard to distinguish stable vs work-in-progress features

**Experimental kinds (incomplete implementation):**
- `access_array` — array dimension access
- `coalesce` — null coalesce operator
- `ternary` — short ternary
- `ternary_full` — full ternary
- `match` — match expression
- `function` — global function calls

**Stable kinds (keep as default):**
- `access`, `method`, `constructor`
- `access_static`, `method_static`

### Proposed Solution

**1. Add `--experimental` flag to scip-php CLI**

```bash
# Default: only stable kinds
./bin/scip-php.sh -d /path/to/project -o /output

# With experimental kinds
./bin/scip-php.sh -d /path/to/project -o /output --experimental
```

**2. Update DocIndexer to check flag**

Skip tracking for experimental kinds unless flag is set.

**3. Update contract-tests/bin/run.sh**

Add option to run with experimental flag:
```bash
bin/run.sh test                    # stable only
bin/run.sh test --experimental     # include experimental
```

**4. Update documentation**

- `scip-php/CLAUDE.md` — document the flag
- `contract-tests/CLAUDE.md` — document experimental option
- `docs/reference/kloc-scip/calls-schema.json` — mark kinds as experimental

**5. Mark contract tests for experimental kinds**

Tests for experimental kinds should be skipped by default or in separate suite.

### Files to modify

- `scip-php/bin/scip-php` — Add `--experimental` CLI option
- `scip-php/src/Indexer.php` — Pass flag to DocIndexer
- `scip-php/src/DocIndexer.php` — Check flag before tracking experimental kinds
- `scip-php/bin/scip-php.sh` — Pass through experimental flag
- `kloc-reference-project-php/contract-tests/bin/run.sh` — Add experimental option
- `kloc-reference-project-php/contract-tests/CLAUDE.md` — Document experimental usage
- `scip-php/CLAUDE.md` — Document the flag
- `docs/reference/kloc-scip/calls-schema.json` — Add experimental marker to kinds

### Expected behavior

```bash
# Default output (stable only)
$ ./bin/scip-php.sh -d project -o out
# calls.json contains: access, method, constructor, access_static, method_static

# Experimental output
$ ./bin/scip-php.sh -d project -o out --experimental
# calls.json also contains: access_array, coalesce, ternary, ternary_full, match, function
```

---

## Issue 6: General notes and test coverage gaps

### What's Working

**Value tracking (stable kinds):**
- ✅ Parameter values created at declaration site
- ✅ Local variables linked to their assignment RHS via `source_call_id`
- ✅ Arguments link to source values via `value_id`
- ✅ Multiple locals with same name get unique symbols: `local$status@64`, `local$status@141`
- ✅ Property access chains share receivers correctly

**Example working flow:**
```
Parameter $email at 59:15
    ↓ value_id
Contact constructor arg (email: $email)
    ↓ source_call_id
Local $contact at 66:8
    ↓ value_id
Customer constructor arg (contact: $contact)
```

### Test Coverage Gaps

**1. Full controller-to-entity flow test**

Need comprehensive test that verifies we can trace from:
```
CustomerController::get()
  → CustomerService::getCustomerById()
    → CustomerOutput constructor
      → $customer->contact->email
        → Contact#$email property
```

All values, calls, types, and symbols should be resolvable.

**2. Parameter → local → argument chain**

Test that when parameter flows through a local:
```php
function foo($input) {
    $local = $input;  // local gets value from parameter
    bar($local);      // argument links to local
}
```
We can trace: `argument.value_id` → local → `local.source_call_id` → ... → parameter

**3. Same variable name in different scopes**

Test that values are correctly distinguished:
```php
function a() { $x = 1; }  // local$x@lineA
function b() { $x = 2; }  // local$x@lineB - different symbol
```

**4. Property access return types**

Test that `$entity->stringProperty` has `return_type: string` (ties to Issue 3).

**5. Nested object type propagation**

Test that `$customer->contact` has `return_type: Contact#` AND the resulting value has `type: Contact#`.

### Existing Tests May Need Updates

Some existing contract tests may need notes/updates for:

1. **Tests checking experimental kinds** — Should be skipped or moved to experimental suite
2. **Tests expecting return_type** — May need to be marked as expected failures until Issue 3 is fixed
3. **Tests checking column numbers** — May need adjustment if Issue 2 (1-based vs 0-based) is fixed

### Additional Coverage Needed: Return Types and Value Types

**Return value tracking tests:**
- `calls[].return_type` should be populated for all resolvable calls
- `values[].type` should match for result values
- Test that return type flows correctly: `method return_type` → `result value type` → `local value type`

**Example test case:**
```php
$output = $service->getCustomerById($id);  // return_type: CustomerOutput
// $output local should have type: CustomerOutput
// When $output->email accessed, receiver_value_id points to $output value
```

### Recommendations

1. **Add integration test suite** for full-flow tracing scenarios
2. **Add negative tests** for edge cases (unresolvable types, dynamic access)
3. **Document current limitations** in test descriptions
4. **Prioritize fixing Issue 3** (type resolution) as it affects most value flow verification
5. **Add return type flow tests** verifying call return_type propagates to value type

---

## Issue 7: Update kloc-scip documentation and schema for consistency

**STATUS: DOCUMENTATION UPDATED** ✅

### Changes Made

The following documentation files have been updated:

**1. `docs/reference/kloc-scip/calls-schema.json`:**
- ✅ Removed `access_nullsafe` and `method_nullsafe` from CallKind enum
- ✅ Added `x-experimental-kinds` array marking experimental kinds
- ✅ Updated enum descriptions to note nullsafe handling via union types
- ✅ Removed `value_type` from ArgumentRecord
- ✅ Fixed column numbering to document 0-based (matching implementation)

**2. `docs/reference/kloc-scip/calls-schema-docs.md`:**
- ✅ Split call kinds into Stable and Experimental tables
- ✅ Added nullsafe handling explanation
- ✅ Removed `value_type` from argument table
- ✅ Added type lookup note for arguments
- ✅ Clarified column is 0-based

**3. `docs/reference/kloc-scip/calls-and-data-flow.md`:**
- ✅ Split call kinds into Stable and Experimental tables
- ✅ Added nullsafe handling explanation
- ✅ Removed `value_type` from argument structure
- ✅ Updated examples to remove value_type

### Remaining Implementation Work

These documentation changes describe the TARGET state. Implementation updates still needed:

1. **scip-php indexer** — Remove nullsafe kinds, implement union return types
2. **scip-php indexer** — Remove `value_type` from ArgumentRecord
3. **scip-php indexer** — Add `--experimental` flag support
4. **Contract tests** — Update to match new schema

---

