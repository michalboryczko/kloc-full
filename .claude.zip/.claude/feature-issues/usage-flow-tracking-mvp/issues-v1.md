# Usage Flow Tracking MVP — Issues

This document tracks issues identified during usage-flow-tracking-mvp implementation/review.

**Feature context:**
- Unified graph format: `docs/reference/kloc-mapper/source-of-truth-graph.md`
- Context query implementation: `src/queries/context.py`

**Version:** 1
**Created:** 2026-02-05

---

## Issue 1: PHP import statements (`use`) shown as duplicate type_hint references

### Context

In PHP, `use` statements at the top of files are import declarations that bring classes into scope. When a class is actually used in the file (method calls, property types, etc.), those actual usages are already captured and shown in the output.

### Problem

The output includes import statements as `[type_hint]` references, which duplicates information already present from actual usages:

**Example — current behavior:**
```
== USED BY ==
App\Service\OrderService
├── [1] App\Ui\Rest\Controller\OrderController::__construct(...) [type_hint] ...
├── [1] src/Ui/Rest/Controller/OrderController.php [type_hint] (src/Ui/Rest/Controller/OrderController.php:8)  ← IMPORT
├── [1] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] ...
```

Problems:
- Line 8 is just `use App\Service\OrderService;` — an import, not an actual usage
- This duplicates the information already shown by the constructor type hint and method call
- Adds noise to the output without providing additional insight

### Proposed Solution

**1. Skip import statements by default**

Filter out references that are PHP `use` statements. These can be identified by:
- The source is a File node (not a method/class)
- Line number is typically in the first ~30 lines
- Reference type is `type_hint` with no actual code usage at that location

**2. Add `--with-imports` CLI flag**

Allow users to include import statements when explicitly requested:
```bash
kloc-cli context "App\Service\OrderService" --sot sot.json --with-imports
```

### Future consideration (IMPORTANT)

Consider implementing a unified query language for filtering results, similar to:
- GraphQL for selecting specific fields/relationships
- Docker inspect's Go template syntax for filtering
- jq-style filtering for JSON output

This would allow users to filter by reference_type, node kind, depth, etc. without adding many CLI flags.

### Expected output after fix

```
== USED BY ==
App\Service\OrderService
├── [1] App\Ui\Rest\Controller\OrderController::__construct(...) [type_hint] ...
├── [1] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] ...
│           on: $this->orderService
└── [1] App\Ui\Rest\Controller\OrderController::get(...) -> getOrder() [method_call] ...
            on: $this->orderService
```

### Files to modify

- `src/cli.py` — Add `--with-imports` flag to context command
- `src/queries/context.py` — Filter out import references by default, pass flag to include them

---

## Issue 2: Usages not displayed in source code order

### Context

When reading code, developers follow top-to-bottom flow. The output should reflect this natural reading order to make it easier to understand the execution flow and code structure.

### Problem

Items in USES direction appear in arbitrary order (likely by internal node ID or insertion order), not matching the order they appear in source code.

**Example — current behavior:**
```
== USES ==
App\Service\OrderService::createOrder(...)
├── [1] App\Component\EmailSenderInterface::send(...) [method_call] (src/Service/OrderService.php:47)
├── [1] App\Dto\CreateOrderInput::$customerEmail [property_access] (src/Service/OrderService.php:34)
├── [1] App\Service\OrderService::$orderRepository [property_access] (src/Service/OrderService.php:45)
├── [1] App\Component\InventoryCheckerInterface::checkAvailability(...) [method_call] (src/Service/OrderService.php:30)
...
```

The line numbers jump: 47 → 34 → 45 → 30 — not following execution flow.

Problems:
- Hard to follow the logical flow of the method
- Doesn't match how developers read code (top to bottom)
- Makes it harder to understand the sequence of operations

### Proposed Solution

**1. Sort USES items by source line number**

For method context, sort usages by the line number where they occur:
- Line 30: `checkAvailability()` call
- Line 34: `$customerEmail` access
- Line 45: `$orderRepository` access
- Line 47: `send()` call

**2. Analysis needed for other contexts**

For class-level queries and other node types (values, arguments, consts), the best ordering strategy needs analysis:
- Classes: Order by member declaration order? Or group by member type (properties, then methods)?
- Arguments: Order by position in signature?
- Values: Order by first assignment line?

**NEEDS ANALYSIS**: A business analyst should determine the optimal ordering strategy for each node kind to maximize developer comprehension.

### Expected output after fix

```
== USES ==
App\Service\OrderService::createOrder(...)
├── [1] App\Component\InventoryCheckerInterface::checkAvailability(...) [method_call] (src/Service/OrderService.php:30)
├── [1] App\Dto\CreateOrderInput::$customerEmail [property_access] (src/Service/OrderService.php:34)
├── [1] App\Service\OrderService::$orderRepository [property_access] (src/Service/OrderService.php:45)
├── [1] App\Component\EmailSenderInterface::send(...) [method_call] (src/Service/OrderService.php:47)
...
```

### Files to modify

- `src/queries/context.py` — Sort children by line number before returning tree
- `src/output/tree.py` — Ensure tree renderer preserves sort order

---

## Issue 3: USED BY shows internal self-references instead of only external usages

### Context

When querying "who uses X", the expected answer is external consumers — other classes/methods that depend on X. Internal implementation details (a class's own methods accessing its own properties via `$this->`) are not meaningful "usages" from an API perspective.

### Problem

When querying a **class**, USED BY includes internal references where the class's own methods access its own properties:

**Example — current behavior:**
```
== USED BY ==
App\Service\OrderService
├── [1] App\Ui\Rest\Controller\OrderController::__construct(...) [type_hint] ← EXTERNAL (good)
├── [1] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] ← EXTERNAL (good)
├── [1] App\Service\OrderService::createOrder(...) -> $inventoryChecker [property_access] ← INTERNAL (noise)
├── [1] App\Service\OrderService::createOrder(...) -> $orderProcessor [property_access] ← INTERNAL (noise)
├── [1] App\Service\OrderService::createOrder(...) -> $orderRepository [property_access] ← INTERNAL (noise)
├── [1] App\Service\OrderService::createOrder(...) -> $emailSender [property_access] ← INTERNAL (noise)
├── [1] App\Service\OrderService::createOrder(...) -> $messageBus [property_access] ← INTERNAL (noise)
```

Problems:
- `OrderService::createOrder()` accessing `$this->inventoryChecker` is internal implementation, not an external usage
- This clutters the output with self-references that don't answer "who depends on this class?"
- Makes it harder to identify actual external consumers

### Proposed Solution

**1. For Class queries: Filter to external references only**

USED BY for a class should only show references from **outside** that class:
- Type hints in other classes' constructors/methods ✓
- Method calls from other classes ✓
- Instantiations from other classes ✓
- Internal `$this->property` accesses from own methods ✗ (filter out)

**2. For Method queries: Only show actual calls to that method**

When querying a specific method, USED BY should show where that method is called, not internal property accesses within it.

**3. NEEDS ANALYSIS: Arguments flow**

Current handling of arguments in USED BY needs review:
- What does it mean for an argument to be "used by" something?
- Is this tracking where argument values flow to?
- Analyst should clarify expected behavior

### Expected output after fix

```
== USED BY ==
App\Service\OrderService
├── [1] App\Ui\Rest\Controller\OrderController::__construct(...) [type_hint] (src/Ui/Rest/Controller/OrderController.php:21)
├── [1] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] (src/Ui/Rest/Controller/OrderController.php:57)
│           on: $this->orderService
└── [1] App\Ui\Rest\Controller\OrderController::get(...) -> getOrder() [method_call] (src/Ui/Rest/Controller/OrderController.php:28)
            on: $this->orderService
```

### Edge cases

| Case | Behavior |
|------|----------|
| Static method calling own class | Filter out (internal) |
| Trait method accessing host class property | TBD - needs analysis |
| Parent class accessing child property | TBD - needs analysis |
| `self::` or `static::` references | Filter out (internal) |

### Files to modify

- `src/queries/context.py` — Add filtering logic to exclude internal references based on containment
- May need to check if source node is contained within target class

---

## Issue 4: Access chain missing full property symbol reference

### Context

When a method is called via a property (e.g., `$this->orderService->createOrder()`), the output shows the access chain as `on: $this->orderService`. However, this doesn't provide the full symbol/FQN of the property being accessed, making it harder to navigate to or query that property.

### Problem

The access chain shows only the textual representation without the actual symbol reference:

**Example — current behavior:**
```
== USED BY ==
App\Service\OrderService::createOrder(...)
└── [1] App\Ui\Rest\Controller\OrderController::create(...) [method_call] (src/Ui/Rest/Controller/OrderController.php:57)
            on: $this->orderService
```

Problems:
- No way to know the full FQN of `$orderService` property
- Can't easily navigate to the property definition
- For programmatic use (JSON output), no symbol reference to query further

### Proposed Solution

**Add full property symbol to access chain display**

Include the FQN of the property used in the access chain:

```
            on: $this->orderService (App\Ui\Rest\Controller\OrderController::$orderService)
```

Or alternatively as a separate line:
```
            on: $this->orderService
            via: App\Ui\Rest\Controller\OrderController::$orderService
```

**For JSON output**

The `MemberRef` model should include the property symbol:
```json
{
  "access_chain": "$this->orderService",
  "access_chain_symbol": "App\\Ui\\Rest\\Controller\\OrderController::$orderService"
}
```

### Expected output after fix

**CLI output:**
```
== USED BY ==
App\Service\OrderService::createOrder(...)
└── [1] App\Ui\Rest\Controller\OrderController::create(...) [method_call] (src/Ui/Rest/Controller/OrderController.php:57)
            on: $this->orderService (App\Ui\Rest\Controller\OrderController::$orderService)
```

**JSON output:**
```json
{
  "target_fqn": "App\\Service\\OrderService::createOrder(...)",
  "reference_type": "method_call",
  "access_chain": "$this->orderService",
  "access_chain_symbol": "App\\Ui\\Rest\\Controller\\OrderController::$orderService"
}
```

### Files to modify

- `src/models/results.py` — Add `access_chain_symbol` field to `MemberRef`
- `src/queries/context.py` — Resolve property symbol when building access chain
- `src/output/tree.py` — Display property symbol alongside access chain

---

## Issue 5: Method signature display is truncated/malformed

### Context

Method FQNs include their full signature (parameters, return type). When displayed, the signature should be complete and readable.

### Problem

The method signature appears truncated, missing the closing parenthesis and the actual argument after PHP attributes:

**Example — current behavior:**
```
App\Ui\Rest\Controller\OrderController::create(#[\Symfony\Component\HttpKernel\Attribute\MapRequestPayload]
```

Problems:
- Missing closing `)` parenthesis
- Missing the actual argument name/type after the attribute (e.g., `CreateOrderInput $input`)
- Signature is incomplete and hard to read

### Proposed Solution

**1. Investigate FQN generation in kloc-mapper**

The FQN stored in sot.json may already be truncated. Check if `scip-php` or `kloc-mapper` is generating incomplete signatures.

**2. Ensure complete signature display**

The full signature should be:
```
App\Ui\Rest\Controller\OrderController::create(#[\Symfony\Component\HttpKernel\Attribute\MapRequestPayload] \App\Ui\Rest\Request\CreateOrderRequest $request): \Symfony\Component\HttpFoundation\JsonResponse
```

Or simplified (without attributes):
```
App\Ui\Rest\Controller\OrderController::create(\App\Ui\Rest\Request\CreateOrderRequest $request): \Symfony\Component\HttpFoundation\JsonResponse
```

### Investigation needed

- Check sot.json to see if FQN is already malformed at source
- If source is correct, check output/tree.py for display truncation
- PHP attributes in signatures may need special handling

### Files to modify

- `kloc-mapper/src/mapper.py` — If FQN generation is the issue
- `src/output/tree.py` — If display truncation is the issue
- Possibly `scip-php` if the SCIP index has incomplete data

---

## Issue 6: File paths used as identifiers instead of FQN for OOP symbols

### Context

In object-oriented code, every reference should be identified by its fully qualified name (FQN), not a file path. File paths are a secondary locator, not the primary identifier.

### Problem

Some references display a file path as the main identifier instead of the FQN:

**Example — current behavior:**
```
== USED BY ==
App\Repository\OrderRepository
├── [1] src/Service/OrderService.php [type_hint] (src/Service/OrderService.php:12)
```

This is a PHP `use App\Repository\OrderRepository;` import in `OrderService.php`, but the caller is shown as a **file path** (`src/Service/OrderService.php`) instead of the class FQN (`App\Service\OrderService`).

Problems:
- File paths are not meaningful identifiers for OOP code — the FQN is
- Inconsistent with other entries that correctly show FQN (e.g., `App\Ui\Rest\Controller\OrderController::__construct(...)`)
- Breaks the mental model: everything in the tree should be a symbol, not a filesystem artifact

### Proposed Solution

**Always resolve file-level references to their containing class/namespace FQN**

When a reference originates from a File node (e.g., a `use` import at file level), resolve upward to the class that owns that file:
- `src/Service/OrderService.php` → `App\Service\OrderService`
- `src/Ui/Rest/Controller/OrderController.php` → `App\Ui\Rest\Controller\OrderController`

This can be done by traversing the `contains` edges: File → Class.

If a file contains multiple classes, use the primary class (first class, or the one matching the filename).

### Expected output after fix

```
== USED BY ==
App\Repository\OrderRepository
├── [1] App\Service\OrderService [type_hint] (src/Service/OrderService.php:12)
```

Note: Combined with Issue 1 (skip imports), this particular line would likely be filtered out entirely. But the fix is still needed for any remaining file-level references that aren't imports.

### Edge cases

| Case | Behavior |
|------|----------|
| File with single class | Resolve to that class FQN |
| File with multiple classes | Resolve to primary class (filename match) |
| File with no class (e.g., config, script) | Keep file path as identifier |
| Namespace-only file | Resolve to namespace FQN |

### Files to modify

- `src/queries/context.py` — When source node is a File, resolve to contained class
- `src/graph/index.py` — May need helper to resolve File → primary Class

---

## Issue 7: USED BY depth traversal not chaining up the call graph

### Context

When using `--depth 3`, the USED BY direction should trace the call chain upward through callers. For example, if A calls B which calls C, querying C with depth 3 should show B at depth 1 and A at depth 2.

### Problem

USED BY only shows direct callers (depth 1) but does not continue traversing upward to find callers-of-callers:

**Example — current behavior (`--depth 3`):**
```
== USED BY ==
App\Repository\OrderRepository
├── [1] App\Service\OrderService::createOrder(...) -> save() [method_call] (src/Service/OrderService.php:45)
│           on: $this->orderRepository
├── [1] App\Service\OrderDisplayService::getDisplayName(...) -> findById() [method_call] (src/Service/OrderDisplayService.php:81)
│           on: $this->orderRepository
```

But `OrderController::create()` has `$this->orderService->createOrder($input)` — this should appear at depth 2 as a caller of `createOrder()`:

Problems:
- Depth 1 callers shown correctly
- Depth 2+ callers missing entirely — the chain stops at depth 1
- `--depth 3` is effectively behaving like `--depth 1` for USED BY
- This defeats the purpose of the depth parameter for understanding full call chains

### Expected output after fix

```
== USED BY ==
App\Repository\OrderRepository
├── [1] App\Service\OrderService::createOrder(...) -> save() [method_call] (src/Service/OrderService.php:45)
│           on: $this->orderRepository
│   └── [2] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] (src/Ui/Rest/Controller/OrderController.php:57)
│               on: $this->orderService
│       └── [3] ... (any callers of OrderController::create)
├── [1] App\Service\OrderDisplayService::getDisplayName(...) -> findById() [method_call] (src/Service/OrderDisplayService.php:81)
│           on: $this->orderRepository
│   └── [2] ... (callers of getDisplayName)
```

### Proposed Solution

**1. Fix USED BY recursive traversal**

The `_build_incoming_tree` method likely only processes one level. It needs to recursively find callers of each depth-1 node and continue up to the requested depth.

For each caller at depth N:
- Find the **method** that contains the call
- Then find all callers of **that method** → these are depth N+1

**2. RE-EVALUATE: Depth semantics for both USES and USED BY**

The depth parameter needs a consistent definition across both directions:

| Direction | Depth 1 | Depth 2 | Depth 3 |
|-----------|---------|---------|---------|
| USES | Direct dependencies of target | Dependencies of those dependencies | ... |
| USED BY | Direct callers of target | Callers of those callers | ... |

**NEEDS ANALYSIS**: Review and confirm that depth works symmetrically in both directions. Current USES seems to work at multiple depths — verify the same traversal logic applies to USED BY.

### Files to modify

- `src/queries/context.py` — Fix `_build_incoming_tree` to recursively traverse callers at depth 2+

---

## Issue 8: Depth traversal through type_hint/imports produces cascading irrelevant noise

### Context

This is a critical correctness issue that compounds Issues 1, 6, and 7. When depth traversal follows `type_hint` references (especially imports), it chains into completely unrelated code, producing garbage results.

### Problem

Depth chaining through type_hint references creates a broken logical chain:

**Example — current behavior (`--depth 3`):**
```
== USED BY ==
App\Repository\OrderRepository
├── [1] src/Service/OrderService.php [type_hint] (src/Service/OrderService.php:12)          ← import statement
│   ├── [2] App\Ui\Rest\Controller\OrderController::__construct(...) -> OrderService [type_hint] ...  ← who uses OrderService!
│   ├── [2] src/Ui/Rest/Controller/OrderController.php -> OrderService [type_hint] ...                ← more noise
│   ├── [2] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] ...    ← irrelevant
│   └── [2] App\Ui\Rest\Controller\OrderController::get(...) -> getOrder() [method_call] ...          ← irrelevant
```

**The broken logic chain:**
1. Depth 1: "OrderRepository is imported in OrderService.php" — OK but noisy (see Issue 1)
2. Depth 2: "Who uses OrderService?" — **WRONG QUESTION**. The depth 2 should ask "who uses OrderRepository through OrderService", not "who uses OrderService itself"

The controllers at depth 2 **do NOT use OrderRepository** — they use OrderService. The type_hint import created a false chain:
```
OrderRepository → (imported in) OrderService.php → (used by) OrderController
```
This implies `OrderController` depends on `OrderRepository`, which is **factually incorrect**.

Problems:
- **Incorrect data**: Shows dependencies that don't exist
- **Noise explosion**: Every import creates a false chain to everything that uses the importing class
- **Misleading**: A developer reading this would think OrderController depends on OrderRepository

### Proposed Solution

**1. USED BY depth chaining must only follow actual call/usage chains**

Depth should only chain through relationships where there is a real **data or call flow**:

| Chain through | Example | Valid? |
|--------------|---------|--------|
| method_call → caller of that method | `repo.save()` → `service.createOrder()` → `controller.create()` | ✓ YES |
| property_access → caller | `$this->repo` → caller of method | ✓ YES |
| type_hint (import) → users of importer | `use OrderRepo` → users of OrderService | ✗ NO |
| type_hint (constructor param) → instantiator | `__construct(OrderRepo $repo)` → DI container | ✓ MAYBE |

**2. Define explicit chaining rules**

For USED BY at depth N+1, only follow from depth N if the reference type is:
- `method_call` → find callers of the **method** containing that call
- `property_access` → find callers of the **method** containing that access
- `instantiation` → find callers of the **method** containing that instantiation

Do NOT chain from:
- `type_hint` (imports, parameter types, return types)
- `extends` / `implements`

### Expected output after fix

```
== USED BY ==
App\Repository\OrderRepository
├── [1] App\Service\OrderService::createOrder(...) -> save() [method_call] (src/Service/OrderService.php:45)
│           on: $this->orderRepository
│   └── [2] App\Ui\Rest\Controller\OrderController::create(...) -> createOrder() [method_call] (src/Ui/Rest/Controller/OrderController.php:57)
│               on: $this->orderService
├── [1] App\Service\OrderService::getOrder(...) -> findById() [method_call] (src/Service/OrderService.php:72)
│           on: $this->orderRepository
│   └── [2] App\Ui\Rest\Controller\OrderController::get(...) -> getOrder() [method_call] (src/Ui/Rest/Controller/OrderController.php:28)
│               on: $this->orderService
```

This correctly shows the **actual call chain**: Controller → Service → Repository.

### Files to modify

- `src/queries/context.py` — Add reference-type filter for depth chaining in `_build_incoming_tree`

---

